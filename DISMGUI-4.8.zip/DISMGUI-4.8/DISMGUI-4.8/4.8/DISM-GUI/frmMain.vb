﻿Imports System.Globalization                    ' for culture, language and zone
Imports System.Resources                        ' for langue translation en to fr
Imports System.Text
Imports System.IO
Imports System.Text.RegularExpressions
Imports System.Management
Imports System.Windows

Public Class frmMain
    Public Property RedirectStandardOutput As Boolean ' output redirection flag
    Dim strFolderName As String                 ' FolderName of Wim file

    Dim ImageMounted As Boolean = False         ' flag ImageMounted value is True if one (or more) image is mounted

    Dim strMountedImageLocation As String       ' Path to Wim mounted
    Dim strIndex As String                      ' index of wim
    Dim strWIM As String                        ' name of wim file

    Dim strOutput As String                     ' result of dism command
    Dim strDISMExitCode As String               ' return code error of dism command

    Dim blnDISMCommit As Boolean                ' Flag blnDISMCommit: blnDISMCommit = True (use for commit change)
    Dim strDriverLocation As String             ' Path to driver folder
    Dim blnForceUnsigned As Boolean             ' Flag for force unsigned drivers
    Dim strDISMArguments As String              ' arguments for DISM command
    Dim strPackageLocation As String            ' Path to package folder
    Dim strLocation As String                   ' 
    Dim blnIgnoreCheck As Boolean               ' flag ignore check 
    Dim strDelDriverLocation As String          ' Path to driver deleted folder
    Dim strPackageName As String                ' name of installed package
    Dim strPackagePath As String                ' folder of package
    Dim strFeatureName As String                ' feature name 
    Dim OnlineMode As Boolean = False           ' flag OnlineMode / OfflineMode
    Dim strProductKey As String                 ' product key of windows
    Dim strEdition As String                    ' edition of windows
    Dim strXMLFileName As String                ' Unattend file
    Dim strProductCode As String                ' product code
    Dim strPatchCode As String                  ' Path to Patch windows 
    Dim strMSPFileName As String                ' Name of patch windows
    Dim strSource As String
    Dim strDest As String
    Dim strFilename As String
    Dim strNameMetadata As String
    Dim strNameDescription As String
    Dim strCompression As String
    Dim strAppendIndex As String
    Dim UseDismADK As Boolean = False           ' toggle between dism windows or ADK dism
    Dim ResMan As ResourceManager
    Dim CultInfo As CultureInfo                 ' fr-FR or en-US (default)
    Dim ListInfosWimGestionMontage As New List(Of InfosWIM) ' For index in TabPage "Mount Control"
    Dim ListInfosWimApplyImage As New List(Of InfosWIM)     ' For index in Tabpage "Apply Wim / Swm Image"
    Dim ListInfosWimExportImage As New List(Of InfosWIM)    ' For index in TabPage "Export Image"
    Dim ListInfosWimCleanupImage As New List(Of InfosWIM)   ' For index in TabPage "Cleanup Image"
    '
    ' Sub btnOpenWIM_Click
    ' 
    ' Use for Open File dialog Box WIM/ESD
    ' save the result on txtWIM form variable
    ' Warning: It's not possible to mount ESD image but you can verify index from ESD file !
    ' Only Wim file can be mounted !
    ' "GestionMontage_WimInfos.txt" is creating on the current application folder
    ' Rev: 31/07/2022
    '
    Private Sub btnOpenWIM_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnMountControl_OpenWIM.Click

        ' Dim strFileName As String
        Dim DidWork As Integer                                  ' result for dialogue box

        'dlgOpenFile.InitialDirectory = Environment.SpecialFolder.MyComputer
        dlgOpenFile.InitialDirectory = "C:\"
        dlgOpenFile.Title = "Choose WIM file to Open"           ' title of dialog box
        dlgOpenFile.Filter = ("WIM Files(*.wim)|*.wim|ESD Files(*.esd)|*.esd|VHD Files(*.vhd)|*.vhd_
                              |VHDX Files(*.vhdx)|*.vhdx|Ffu Files(*.ffu)|*.ffu|All Files (*.*)|*.*") ' filter extension
        DidWork = dlgOpenFile.ShowDialog                        ' show dialog box

        If DidWork = DialogResult.OK Then                       ' user selected filename from dialog box ?
            ' strFileName = dlgOpenFile.FileName
            TxtMountControl_ImageFile.Text = dlgOpenFile.FileName                  ' user choice filename
            DisplayImageInfos("GestionMontage_WimInfos.txt", TxtMountControl_ImageFile.Text)
            Me.CmbMountControl_Index.Items.Clear()                           ' clear index count in Form
            ListInfosWimGestionMontage.Clear()                  ' clear list<T> description index
            UpdateListIndexWim("GestionMontage_WimInfos.txt", ListInfosWimGestionMontage) ' Mise à jour des index

            For IdxFor As Integer = 1 To ListInfosWimGestionMontage.Count
                Me.CmbMountControl_Index.Items.Add(IdxFor.ToString)
            Next
        End If
    End Sub
    '
    ' Sub DisplayImageInfos
    ' 
    ' Retreive information from WIM,FFU,VHD / VHDX and ESD file
    ' Rev: 31/07/2022
    '
    Private Sub DisplayImageInfos(NomFichier As String, NomFichierWim As String)

        txtOutput.Text = ""
        strWIM = NomFichierWim                      ' Wim or ESD filename
        'strDISMArguments = "/Get-WimInfo /WimFile:""" & NomFichierWim & """"     ' arguments line for dism.exe old WinPE
        strDISMArguments = "/Get-ImageInfo /ImageFile:""" & NomFichierWim & """"  ' arguments line for dism.exe new WinPE
        txtOutput.Text = "Command line that running is:" & vbCrLf & "Dism.exe " & strDISMArguments & vbCrLf
        BackgroundWorkerDISMCommand.RunWorkerAsync(strDISMArguments)
        frmProgress.ShowDialog()
        txtOutput.Text = txtOutput.Text & strOutput & vbCrLf & "Exit code:" & strDISMExitCode

        Try
            If System.IO.File.Exists(NomFichier) = True Then ' delete old file (no append function)
                System.IO.File.Create(NomFichier).Dispose()
            End If
            ' creation new file on the current application directory
            Using sw As StreamWriter = New StreamWriter(NomFichier, True, Encoding.UTF8)
                sw.WriteLine(strOutput)
                sw.Close()
            End Using
        Catch ex As Exception
            ' Let the user know what went wrong.
            'Console.WriteLine("The file could not be read:")
            'Console.WriteLine(e.Message)
            MessageBox.Show("DisplayImageInfos, Error on created filename wiminfos.txt: " + ex.Message.ToString())
        End Try

    End Sub
    '
    ' Create a list of informations index from wim or esd file automatically
    ' warning: extract string from dism command depend of culture and langage from environnement
    ' You must modified offset from substring in consequences !
    ' Rev: 31/07/2022
    '
    Private Sub UpdateListIndexWim(NomFichier As String, ByRef ListInfosWim As List(Of InfosWIM))
        Dim FileName As String = NomFichier           ' filename in application folder
        Dim LigneFic As String = ""
        Dim StrSansEspace As String = ""
        Dim StrSize As String = ""
        Dim StrResult As String = ""
        Dim IdxDebStr, IdxSize As Integer

        ListInfosWim.Clear()                          ' clear list of InfosWim

        Try
            Using sr As StreamReader = New StreamReader(NomFichier) ' open stream from file
                While (sr.EndOfStream <> True)                      ' end of file ?
                    IdxDebStr = 0                                   ' use for research substring
                    LigneFic = sr.ReadLine()                        ' read a line
                    IdxDebStr = LigneFic.IndexOf("Index")           ' "Index" position search for sync
                    If (IdxDebStr = 0) Then                         ' Index is found
                        Dim AWim As InfosWIM = New InfosWIM()       ' create new instance of InfosWim

                        AWim.Index = Convert.ToInt32(LigneFic.Substring(IdxDebStr + 8, (LigneFic.Length) - 8)) ' index number Int32
                        LigneFic = sr.ReadLine()                    ' read a line
                        AWim.Nom = LigneFic.Substring(6, (LigneFic.Length) - 6) ' Name for this index of wim
                        LigneFic = sr.ReadLine()                    ' read a line
                        AWim.Description = LigneFic.Substring(14, (LigneFic.Length) - 14) ' Description for this index of wim
                        LigneFic = sr.ReadLine()                ' lecture taille wim ' read a line
                        ' StrSansEspace = LigneFic.Replace("\u00A0", String.Empty) ' supprime les espaces en UTF8
                        ' StrSansEspace = Regex.Replace(LigneFic, "\s+", "") ' delete all space from string before conversion
                        'StrSansEspace = Regex.Replace(LigneFic, "[\s,.]", "") ' delete space, dot and comma
                        StrSize = Regex.Replace(LigneFic, "[^0-9]", "")
                        'MessageBox.Show(StrSize)
                        'IdxSize = LigneFic.IndexOf(":")
                        'MessageBox.Show("position du ':' " + IdxSize.ToString())
                        'StrResult = StrSansEspace.Substring(IdxSize, StrSansEspace.Length - 13)
                        'MessageBox.Show("Extract: " + StrResult)
                        'AWim.Taille = Convert.ToUInt64(StrSansEspace.Substring(7, StrSansEspace.Length - 13)) ' size for this index of wim
                        AWim.Taille = Convert.ToUInt64(StrSize)
                        ListInfosWim.Add(AWim)                      ' add to list
                    End If
                End While
                sr.Close()                                          ' close stream reader
            End Using                                               ' dispose stream

        Catch ex As Exception                                       ' catch exception
            MessageBox.Show("UpdateListIndexWim, read error from file: " + ex.Message.ToString()) ' message error
        End Try
    End Sub
    '
    ' Sub UpdateForMountedImageInfo
    ' warning: extract string from dism command depend of culture and langage from environnement
    ' You must modified offset from substring in consequences !
    '
    ' Rev: 31/07/2022
    '
    Private Sub UpdateForMountedImageInfo(NomFichier As String, ByRef ACmbBox As ComboBox)
        Dim FileName As String = NomFichier           ' filename in application folder
        Dim LigneFic As String = ""
        Dim StrSansEspace As String = ""
        Dim IdxDebStr As Integer

        'CmbBoxDriverManagement_UseImageMounted.Items.Clear()
        ACmbBox.Items.Clear()
        'CmbBoxDriverManagement_UseImageMounted.Text = ""
        ACmbBox.Text = ""

        Try
            Using sr As StreamReader = New StreamReader(NomFichier) ' open stream from file
                While (sr.EndOfStream <> True)                      ' end of file ?
                    IdxDebStr = 0                                   ' use for research substring
                    LigneFic = sr.ReadLine()                        ' read a line
                    IdxDebStr = LigneFic.IndexOf("Répertoire de montage : ") ' position search for sync
                    If IdxDebStr <> -1 Then
                        ' CmbBoxDriverManagement_UseImageMounted.Items.Add(LigneFic.Substring(24, (LigneFic.Length) - 24))
                        ACmbBox.Items.Add(LigneFic.Substring(24, (LigneFic.Length) - 24))
                    End If
                End While
                sr.Close()                                          ' close stream reader
            End Using                                               ' dispose stream

        Catch ex As Exception                                       ' catch exception
            MessageBox.Show("UpdateForMountedImageInfo, read error from file: " + ex.Message.ToString()) ' message error
        End Try
    End Sub
    '
    ' Sub DisplayMountedImageInfos
    ' 
    ' Retreive persistant informations from Windows environnement of mounted images
    ' 
    ' Rev: 31/07/2022
    '
    Private Sub DisplayMountedImageInfo(NomFichier As String)

        txtOutput.Text = ""
        strDISMArguments = "/Get-MountedImageInfo"
        txtOutput.Text = "Command line that running is:" & vbCrLf & "Dism.exe " & strDISMArguments & vbCrLf
        BackgroundWorkerDISMCommand.RunWorkerAsync(strDISMArguments)
        frmProgress.ShowDialog()
        txtOutput.Text = txtOutput.Text & strOutput & vbCrLf & "Exit code:" & strDISMExitCode

        Try
            If System.IO.File.Exists(NomFichier) = True Then ' delete old file (no append function)
                System.IO.File.Create(NomFichier).Dispose()
            End If
            ' creation new file on the current application directory
            Using sw As StreamWriter = New StreamWriter(NomFichier, True, Encoding.UTF8)
                sw.WriteLine(strOutput)
                sw.Close()
            End Using
        Catch ex As Exception
            ' Let the user know what went wrong.
            'Console.WriteLine("The file could not be read:")
            'Console.WriteLine(e.Message)
            MessageBox.Show("DisplayMountedImageInfo Error on created file: " + ex.Message.ToString())
        End Try
    End Sub
    '
    ' Sub btnOpenMount_Click
    '
    ' use for select an empty folder for mount wim file later
    ' save the result on txtMount form variable
    ' Rev: 31/07/2022

    Private Sub btnOpenMount_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnMountControl_OpenMount.Click
        ' Dim dirs As String()
        ' Dim files As String()
        Dim DidWork As Integer

        dlgOpenFolder.ShowNewFolderButton = False
        dlgOpenFolder.RootFolder = Environment.SpecialFolder.MyComputer
        DidWork = dlgOpenFolder.ShowDialog()
        If DidWork = DialogResult.OK Then
            TxtMountControl_MountLocation.Text = dlgOpenFolder.SelectedPath
        End If

        'Try
        ' dirs = System.IO.Directory.GetDirectories(TxtMountControl_MountLocation.Text)
        ' files = System.IO.Directory.GetFiles(TxtMountControl_MountLocation.Text)
        ' If dirs.Length = 0 And files.Length = 0 Then ' check if there is no directory or filename
        ' Else
        ' MessageBox.Show("You must choose an empty folder to mount the WIM !")
        ' End If
        ' Catch ex As Exception
        ' MessageBox.Show("btnOpenMount_Click, error detected: " + ex.Message.ToString()) ' message error
        ' End Try
    End Sub
    '
    ' Sub BtnMountControl_MountImage_Click
    ' 
    ' Rev: 31/07/2022
    '
    Private Sub BtnMountControl_MountImage_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnMountControl_MountImage.Click

        txtOutput.Text = ""
        If TxtMountControl_ImageFile.Text = "" Or TxtMountControl_MountLocation.Text = "" Or CmbMountControl_Index.Text = "" Then
            MsgBox("You must select a WIM,FFU,VHD file, mount location and index for mount image first !")
        Else
            ' txtMount.Text = Replace(txtMount.Text, """", "")      ' prevent for filename with space
            strFolderName = TxtMountControl_MountLocation.Text      ' save path in global variable 
            strIndex = CmbMountControl_Index.Text                   ' save index
            ' txtWIM.Text = Replace(txtWIM.Text, """", "")          ' prevent for filename with space
            strWIM = TxtMountControl_ImageFile.Text                 ' save path in global variable

            strDISMArguments = "/Mount-Image /ImageFile:" & """" & strWIM & """" & " /Index:" & strIndex & " /MountDir:" & """" & strFolderName & """"

            If ChkMountControl_ReadOnly.Checked = True Then
                strDISMArguments = strDISMArguments & " /ReadOnly"
            End If
            If ChkBoxMountControl_Optimize.Checked = True Then
                strDISMArguments = strDISMArguments & " /Optimize"
            End If
            If ChkBoxMountControl_CheckIntegrity.Checked = True Then
                strDISMArguments = strDISMArguments & " /CheckIntegrity"
            End If

            txtOutput.Text = "Command line that running is:" & vbCrLf & "Dism.exe " & strDISMArguments & vbCrLf
            BackgroundWorkerDISMCommand.RunWorkerAsync(strDISMArguments)
            frmProgress.ShowDialog()
            txtOutput.Text = txtOutput.Text & strOutput & vbCrLf & "Exit code:" & strDISMExitCode
            'BackgroundWorkerMount.RunWorkerAsync()                  ' run async command
            'frmProgress.ShowDialog()                                ' show speudo progress bar
            ' txtOutput.Text = txtOutput.Text & strOutput & vbCrLf & "Exit code processus: " & strDISMExitCode     ' update console messages
            'txtOutput.Text = strOutput                              ' update GUI console
        End If
    End Sub
    '
    ' Sub AboutToolStripMenuItem_Click
    ' 
    ' use from StripMenu for show dialogue box About this software
    ' Rev: 31/07/2022
    '
    Private Sub AboutToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AboutToolStripMenuItem.Click
        frmAbout.ShowDialog()                                  ' about author

    End Sub
    '
    ' Sub frmMain_FormClosing
    ' 
    ' Just ask for confirmation to exit application !
    ' Now, it's possible to use multi-mounted image
    ' I'm use persistant information (register in windows), via dism /Get-MountedImageInfo
    '  
    ' Rev: 31/07/2022
    '
    Private Sub frmMain_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        If MessageBox.Show("Are you sure you want to exit?", "Exit?", MessageBoxButtons.YesNo, MessageBoxIcon.Question) = DialogResult.Yes Then
            'If ImageMounted = True Then             ' check if one or more image is mounted 
            'If MessageBox.Show("You currently have an image Mounted.  Do you want to dismount her before exiting?", "Image mounted", MessageBoxButtons.YesNo, MessageBoxIcon.Question) = DialogResult.Yes Then
            'DismountWIM()
            'BackgroundWorkerDisMount.RunWorkerAsync()
            'frmProgress.ShowDialog()
            'Else
            'e.Cancel = False
            'End If
            'Else
            'Do Nothing - Exit form
            'End If
        Else
            e.Cancel = True
        End If
    End Sub
    '
    ' BtnMountControl_UnmountImage_Click
    '
    ' Save context of mount variable and call Dismount fonctionnality
    ' Rev: 23/08/2022
    '
    Private Sub BtnMountControl_UnmountImage_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnMountControl_UnmountImage.Click

        txtOutput.Text = ""                                  ' clear the console view
        strFolderName = TxtMountControl_MountLocation.Text   ' save in globale variable strFolderName
        strIndex = CmbMountControl_Index.Text                ' save in globale variable strIndex 
        strWIM = TxtMountControl_ImageFile.Text                ' save in globale variable strWim

        If TxtMountControl_MountLocation.Text = "" Then
            MessageBox.Show("You must select a mount location before execute this command !")
            Exit Sub
        End If

        strDISMArguments = "/Unmount-Image /MountDir:" & """" & strFolderName & """"
        If RadBtnMountControl_Discard.Checked Then              ' /discard option is checked ?
            strDISMArguments = strDISMArguments & " /Discard"
        End If
        If RadBtnMountControl_Commit.Checked Then               ' /Commit option is checked ?
            strDISMArguments = strDISMArguments & " /Commit"
        End If
        If ChkBoxMountControl_Append.Checked Then               ' /Append option is checked ?
            strDISMArguments = strDISMArguments & " /Append"
        End If
        If ChkBoxMountControl_CheckIntegrity.Checked Then       ' /CheckIntegrity option is checked ?
            strDISMArguments = strDISMArguments & " /CheckIntegrity"
        End If

        txtOutput.Text = "Command line that running is:" & vbCrLf & "Dism.exe " & strDISMArguments & vbCrLf
        'BackgroundWorkerDisMount.RunWorkerAsync()
        BackgroundWorkerDISMCommand.RunWorkerAsync(strDISMArguments)
        frmProgress.ShowDialog()
        txtOutput.Text = txtOutput.Text & strOutput & vbCrLf & "Exit code:" & strDISMExitCode
    End Sub
    '
    ' Sub btnOpenFolder_Click
    '
    ' start a new task (processus explorer) with mount wim folder parameter
    ' Rev: 31/07/2022
    '
    Private Sub btnOpenFolder_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnMountControl_OpenMountedFolder.Click
        Dim OpenFolder As New Process

        If (TxtMountControl_MountLocation.Text = "") Then
            MessageBox.Show("Mount Localtion is required for this command.")
            Exit Sub
        End If
        Process.Start("Explorer.exe", TxtMountControl_MountLocation.Text)
    End Sub
    '
    ' Sub btnExit_Click
    '
    ' Close the actual form
    ' Rev: 31/07/2022
    '
    Private Sub btnExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

        Me.Close()
    End Sub
    '
    ' Sub  OpenDISMLogToolStripMenuItem_Click
    '
    ' start a new task (processus Notepad.exe) to dism log folder
    ' Rev: 31/07/2022
    '
    Private Sub OpenDISMLogToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OpenDISMLogToolStripMenuItem.Click

        Dim strWinDir As String = System.Environment.GetEnvironmentVariable("windir")
        Dim OpenDISMLog As New Process
        Process.Start("Notepad.exe", strWinDir & "\Logs\DISM\dism.log")
    End Sub
    '
    ' Sub  btnGetDrivers_Click
    ' Use to display drivers in Offline or Online mode
    ' rev: 31/07/2022
    '
    Private Sub btnGetDrivers_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnDriverManagement_GetDrivers.Click

        txtOutput.Text = ""
        'If (ImageMounted = False And ChkBoxDriverManagement_Online.Checked = False) Then
        If (CmbBoxDriverManagement_UseImageMounted.Text = "" And ChkBoxDriverManagement_Online.Checked = False) Then
            ' MessageBox.Show("No WIM is mounted.  You must mount a WIM before running this command (Offline mode) or use /Online option.")
            MessageBox.Show("No image selected.  You must selected an image before running this command (Offline mode) or use /Online option.")
        Else
            If (ChkBoxDriverManagement_Online.Checked) Then
                strDISMArguments = "/Online" & " /Get-Drivers"
            Else
                'strDISMArguments = "/Image:""" & strMountedImageLocation & """" & " /Get-Drivers"
                strDISMArguments = "/Image:""" & CmbBoxDriverManagement_UseImageMounted.Text & """" & " /Get-Drivers"
            End If
            txtOutput.Text = "Command line that running is:" & vbCrLf & "Dism.exe " & strDISMArguments & vbCrLf
            BackgroundWorkerDISMCommand.RunWorkerAsync(strDISMArguments)
            'BackgroundGetDrivers.RunWorkerAsync()
            frmProgress.ShowDialog()
            txtOutput.Text = txtOutput.Text & strOutput & vbCrLf & "Exit code:" & strDISMExitCode
        End If
    End Sub
    '
    ' Sub BackgroundWorkerMount_DoWork
    ' Use to mount image WIM,FFU or VHD file with checkbox parameters
    ' 
    ' Rev: 31/07/2022
    '
    Private Sub BackgroundWorkerMount_DoWork(ByVal sender As System.Object, ByVal e As System.ComponentModel.DoWorkEventArgs) Handles BackgroundWorkerMount.DoWork

        strDISMExitCode = ""                ' reset return exit code value
        Dim DISM As New Process()
        DISM.StartInfo.StandardOutputEncoding = Encoding.GetEncoding(CultureInfo.CurrentCulture.TextInfo.OEMCodePage)
        DISM.StartInfo.RedirectStandardOutput = True
        DISM.StartInfo.RedirectStandardError = True
        DISM.StartInfo.UseShellExecute = False
        DISM.StartInfo.CreateNoWindow = True
        DISM.StartInfo.FileName = "Dism.exe"

        strDISMArguments = "/Mount-Image /ImageFile:" & """" & strWIM & """" & " /Index:" & strIndex & " /MountDir:" & """" & strFolderName & """"

        If ChkMountControl_ReadOnly.Checked = True Then
            strDISMArguments = strDISMArguments & " /ReadOnly"
        End If
        If ChkBoxMountControl_Optimize.Checked = True Then
            strDISMArguments = strDISMArguments & " /Optimize"
        End If
        If ChkBoxMountControl_CheckIntegrity.Checked = True Then
            strDISMArguments = strDISMArguments & " /CheckIntegrity"
        End If

        'If ChkMountControl_ReadOnly.Checked = True Then
        ' DISM.StartInfo.Arguments = "/Mount-WIM /ReadOnly /WimFile:""" & strWIM & """" & " /Index:" & strIndex & " /MountDir:" & """" & strFolderName & """"
        'Else
        ' DISM.StartInfo.Arguments = "/Mount-WIM /WimFile:""" & strWIM & """" & " /Index:" & strIndex & " /MountDir:" & """" & strFolderName & """"
        'End If

        DISM.StartInfo.Arguments = strDISMArguments
        'txtOutput.Text = "Command line running is: dism.exe " & DISM.StartInfo.Arguments & vbCrLf
        strOutput = "Command line running is: " & vbCrLf & "Dism.exe " & DISM.StartInfo.Arguments & vbCrLf
        DISM.Start()
        'strOutput = strOutput & DISM.StandardOutput.ReadToEnd()
        strOutput = strOutput & DISM.StandardOutput.ReadToEnd()
        DISM.WaitForExit()
        strDISMExitCode = DISM.ExitCode         ' save return value of dism function
        strOutput = strOutput & "Exit code:" & strDISMExitCode
        'txtOutput.Text = txtOutput.Text & strOutput & vbCrLf & "Exit code processus: " & DISM.ExitCode
    End Sub
    '
    ' BackgroundWorkerMount_RunWorkerCompleted
    '
    ' Rev: 31/07/2022
    '
    Private Sub BackgroundWorkerMount_RunWorkerCompleted(ByVal sender As Object, ByVal e As System.ComponentModel.RunWorkerCompletedEventArgs) Handles BackgroundWorkerMount.RunWorkerCompleted

        'Check to see if WIM mounted correctly
        If strDISMExitCode = "0" Then
            'BtnMountControl_MountImage.Enabled = False
            BtnMountControl_MountImage.Enabled = True
            BtnMountControl_UnmountImage.Enabled = True
            ImageMounted = True
            If strMountedImageLocation = "" Then
                strMountedImageLocation = strFolderName
            Else
                'Do Nothing
            End If
            frmProgress.Close()
        Else
            frmProgress.Close()
        End If
    End Sub
    '
    ' Sub BackgroundWorkerDisMount_DoWork
    ' Use for dismount wim image
    ' 
    ' Rev: 31/07/2022
    '
    Private Sub BackgroundWorkerDisMount_DoWork(ByVal sender As System.Object, ByVal e As System.ComponentModel.DoWorkEventArgs) Handles BackgroundWorkerDisMount.DoWork

        strDISMExitCode = ""

        'If MessageBox.Show("Do you want to commit changes?", "WIM Mounted", MessageBoxButtons.YesNo, MessageBoxIcon.Question) = DialogResult.Yes Then
        ' blnDISMCommit = True
        'Else
        ' blnDISMCommit = False
        'End If

        Dim DISM As New Process()
        DISM.StartInfo.StandardOutputEncoding = Encoding.GetEncoding(CultureInfo.CurrentCulture.TextInfo.OEMCodePage)
        DISM.StartInfo.RedirectStandardOutput = True
        DISM.StartInfo.RedirectStandardError = True
        DISM.StartInfo.UseShellExecute = False
        DISM.StartInfo.CreateNoWindow = True
        DISM.StartInfo.FileName = "dism.exe"

        strDISMArguments = "/Unmount-Image /MountDir:" & """" & strFolderName & """"
        If RadBtnMountControl_Discard.Checked Then              ' /discard option is checked ?
            strDISMArguments = strDISMArguments & " /Discard"
        End If
        If RadBtnMountControl_Commit.Checked Then               ' /Commit option is checked ?
            strDISMArguments = strDISMArguments & " /Commit"
        End If
        If ChkBoxMountControl_Append.Checked Then               ' /Append option is checked ?
            strDISMArguments = strDISMArguments & " /Append"
        End If
        If ChkBoxMountControl_CheckIntegrity.Checked Then       ' /CheckIntegrity option is checked ?
            strDISMArguments = strDISMArguments & " /CheckIntegrity"
        End If

        'If blnDISMCommit = True Then
        ' DISM.StartInfo.Arguments = "/Unmount-wim /MountDir:""" & strFolderName & """ /Commit"
        'Else
        ' DISM.StartInfo.Arguments = "/Unmount-wim /MountDir:""" & strFolderName & """ /Discard"
        'End If

        DISM.StartInfo.Arguments = strDISMArguments
        txtOutput.Text = "Command line running is: dism.exe " & DISM.StartInfo.Arguments & vbCrLf
        DISM.Start()
        strOutput = DISM.StandardOutput.ReadToEnd()
        DISM.WaitForExit()
        strDISMExitCode = DISM.ExitCode
        txtOutput.Text = txtOutput.Text & strOutput & vbCrLf & "Exit code processus: " & DISM.ExitCode
    End Sub
    '
    ' Sub BackgroundWorkerDisMount_RunWorkerCompleted
    '
    ' Rev: 31/07/2022
    '
    Private Sub BackgroundWorkerDisMount_RunWorkerCompleted(ByVal sender As Object, ByVal e As System.ComponentModel.RunWorkerCompletedEventArgs) Handles BackgroundWorkerDisMount.RunWorkerCompleted
        'Verify DIM was dismounted
        If strDISMExitCode = "0" Then
            'BtnMountControl_MountImage.Enabled = True
            'BtnMountControl_UnmountImage.Enabled = False
            ImageMounted = False
            strMountedImageLocation = ""
            frmProgress.Close()
        Else
            frmProgress.Close()
        End If
    End Sub
    '
    ' Sub btnOpnDriverFolder_Click
    ' Rev: 31/07/2022
    '
    Private Sub btnOpnDriverFolder_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnDriverManagement_OpenDriverFolder.Click
        TxtBoxDriverManagement_DriverFolderLocation.Text = OpenFolder()
    End Sub
    '
    ' Sub btnAddDriver_Click
    ' Use to add drivers on offline image (not for online image)
    ' Rev: 31/07/2022
    '
    Private Sub btnAddDriver_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnDriverManagement_AddDrivers.Click

        txtOutput.Text = ""
        ' If ImageMounted = False Then
        If CmbBoxDriverManagement_UseImageMounted.Text = "" Then
            'MessageBox.Show("No WIM is mounted.  You must mount a WIM before running this command.")
            MessageBox.Show("No image selected.  You must selected an image before running this command (Offline mode) or use /Online option.")
        Else
            If TxtBoxDriverManagement_DriverFolderLocation.Text = "" Then
                MessageBox.Show("You must specify a folder where your drivers are located.")
            Else
                strDriverLocation = TxtBoxDriverManagement_DriverFolderLocation.Text
                If ChkDriverManagement_ForceUnsigned.Checked = True Then
                    'blnForceUnsigned = True
                    'strDISMArguments = "/Image:""" & strMountedImageLocation & """" & " /Add-Driver /driver:""" & strDriverLocation & """" & " /ForceUnsigned "
                    strDISMArguments = "/Image:""" & CmbBoxDriverManagement_UseImageMounted.Text & """" & " /Add-Driver /driver:""" & strDriverLocation & """" & " /ForceUnsigned "
                Else
                    'blnForceUnsigned = False
                    'strDISMArguments = "/Image:""" & strMountedImageLocation & """" & " /Add-Driver /driver:""" & strDriverLocation & """" & " "
                    strDISMArguments = "/Image:""" & CmbBoxDriverManagement_UseImageMounted.Text & """" & " /Add-Driver /driver:""" & strDriverLocation & """"
                End If

                If ChkDriverManagement_Recurse.Checked = True Then
                    strDISMArguments = strDISMArguments & " /Recurse"
                Else
                    'Do Nothing
                End If
                txtOutput.Text = "Command line that running is:" & vbCrLf & "Dism.exe " & strDISMArguments & vbCrLf
                BackgroundWorkerDISMCommand.RunWorkerAsync(strDISMArguments)
                frmProgress.ShowDialog()
                txtOutput.Text = txtOutput.Text & strOutput & vbCrLf & "Exit code:" & strDISMExitCode
            End If
        End If
        ' txtOutput.Text = txtOutput.Text & strOutput
    End Sub
    '
    ' Sub GetWIMInfoToolStripMenuItem_Click
    ' Rev: 31/07/2022
    '
    Private Sub GetWIMInfoToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GetWIMInfoToolStripMenuItem.Click

        txtOutput.Text = ""
        strDISMArguments = "/Get-MountedWIMInfo"
        txtOutput.Text = "Command line that running is:" & vbCrLf & "Dism.exe " & strDISMArguments & vbCrLf
        BackgroundWorkerDISMCommand.RunWorkerAsync(strDISMArguments)
        frmProgress.ShowDialog()
        txtOutput.Text = txtOutput.Text & strOutput & vbCrLf & "Exit code:" & strDISMExitCode
    End Sub
    ' 
    ' Run an async command processus DISM.exe
    ' display line argument of dism command, result and exit code of processus
    ' strInput is the command line argument
    ' Rev: 31/07/2022
    '
    Private Sub BackgroundWorkerDISMCommand_DoWork(ByVal sender As System.Object, ByVal e As System.ComponentModel.DoWorkEventArgs) Handles BackgroundWorkerDISMCommand.DoWork
        Dim strInput As String = e.Argument  ' retreive argument of dism command
        Dim DISM As New Process()            ' create new process for DISM processus

        strDISMExitCode = ""                 ' reset exit code for processus
        DISM.StartInfo.RedirectStandardOutput = True ' redirect output console enabled
        DISM.StartInfo.StandardOutputEncoding = Encoding.GetEncoding(CultureInfo.CurrentCulture.TextInfo.OEMCodePage) ' encodage OEM
        DISM.StartInfo.RedirectStandardError = True  ' redirect standard error
        DISM.StartInfo.UseShellExecute = False       ' no shell
        DISM.StartInfo.CreateNoWindow = True         ' no window

        If UseDismADK = True Then                    ' Check if use dism ADK
            DISM.StartInfo.FileName = "C:\Program Files (x86)\Windows Kits\10\Assessment and Deployment Kit\Deployment Tools\DandISetEnv.bat"         ' name of processus call
            DISM.StartInfo.Arguments = "&& DISM.EXE " & strInput ' arguments for command ligne
        Else
            DISM.StartInfo.FileName = "DISM.EXE"         ' name of processus call
            DISM.StartInfo.Arguments = strInput          ' arguments for command ligne
        End If
        'txtOutput.Text = "Command line that running is: dism.exe " & DISM.StartInfo.Arguments & vbCrLf ' show result command line
        'strOutput = "Command line that running is:" & vbCrLf & "dism.exe " & DISM.StartInfo.Arguments & vbCrLf 'save in global variable
        DISM.Start()                                 ' start async processus
        strOutput = DISM.StandardOutput.ReadToEnd()  ' save in global variable read console
        DISM.WaitForExit()                           ' wait for end of processus
        strDISMExitCode = DISM.ExitCode              ' store exit code of processus
        'strOutput = strOutput & "Exit code:" & strDISMExitCode      ' add exit return code
        ' txtOutput.Text = txtOutput.Text & strOutput & vbCrLf & "Exit code processus: " & DISM.ExitCode
        DISM.Close()                                 ' close processus
    End Sub
    ' 
    ' BackgroundWorkerDISMCommand_RunWorkerCompleted
    ' Rev: 31/07/2022
    '
    Private Sub BackgroundWorkerDISMCommand_RunWorkerCompleted(ByVal sender As Object, ByVal e As System.ComponentModel.RunWorkerCompletedEventArgs) Handles BackgroundWorkerDISMCommand.RunWorkerCompleted

        strDISMArguments = "" ' empty arguments string
        frmProgress.Close()   ' close progress bar
    End Sub
    ' 
    ' CleanupWIMToolStripMenuItem_Click
    ' Rev: 31/07/2022
    '
    Private Sub CleanupWIMToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CleanupWIMToolStripMenuItem.Click

        txtOutput.Text = ""
        strDISMArguments = "/Cleanup-WIM"
        txtOutput.Text = "Command line that running is:" & vbCrLf & "Dism.exe " & strDISMArguments & vbCrLf
        BackgroundWorkerDISMCommand.RunWorkerAsync(strDISMArguments)
        frmProgress.ShowDialog()
        txtOutput.Text = txtOutput.Text & strOutput & vbCrLf & "Exit code:" & strDISMExitCode
    End Sub
    '
    ' Sub btnDisplayWIMInfo_Click
    '
    ' Display Wim informations
    ' Rev: 31/07/2022
    '
    Private Sub btnDisplayWIMInfo_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

        txtOutput.Text = ""             ' reset console view
        If TxtMountControl_ImageFile.Text = "" Then
            MsgBox("You must select a WIM file first")
        Else
            strWIM = TxtMountControl_ImageFile.Text
            strDISMArguments = "/Get-WimInfo /WimFile:""" & strWIM & """"
            txtOutput.Text = "Command line that running is:" & vbCrLf & "Dism.exe " & strDISMArguments & vbCrLf
            BackgroundWorkerDISMCommand.RunWorkerAsync(strDISMArguments)
            frmProgress.ShowDialog()
            txtOutput.Text = txtOutput.Text & strOutput & vbCrLf & "Exit code:" & strDISMExitCode
        End If
    End Sub
    '
    ' Sub btnGetPackages_Click
    ' Use to Get-Packages from Offline / Online image
    ' Rev: 31/07/2022
    '
    Private Sub btnGetPackages_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnPackageManage_GetPackages.Click

        txtOutput.Text = ""
        If (CmbBoxPackageManagement_UseImageMounted.Text = "" And ChkBoxPackageManagement_Online.Checked = False) Then
            MessageBox.Show("No image selected.  You must selected an image before running this command (Offline mode) or use /Online option.")
        Else
            If (ChkBoxPackageManagement_Online.Checked = True) Then
                strDISMArguments = "/Online" & " /Get-Packages"
            Else
                strDISMArguments = "/Image:""" & CmbBoxPackageManagement_UseImageMounted.Text & """ /Get-Packages"
            End If
            If RadBtnPackageManagement_FormatTable.Checked Then strDISMArguments = strDISMArguments & " /Format:Table"
            If RadBtnPackageManagement_FormatList.Checked Then strDISMArguments = strDISMArguments & " /Format:List"
            txtOutput.Text = "Command line that running is:" & vbCrLf & "Dism.exe " & strDISMArguments & vbCrLf
            BackgroundWorkerDISMCommand.RunWorkerAsync(strDISMArguments)
            frmProgress.ShowDialog()
            txtOutput.Text = txtOutput.Text & strOutput & vbCrLf & "Exit code:" & strDISMExitCode
        End If
    End Sub
    '
    ' Sub btnOpenPackageFile_Click
    ' Rev: 31/07/2022
    '
    Private Sub btnOpenPackageFile_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnPackageManage_OpenPackageFile.Click

        txtPackageFile.Text = OpenFolder()
    End Sub
    '
    ' Sub btnAddPackages_Click
    ' Rev: 31/07/2022
    '
    Private Sub btnAddPackages_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnPackageManage_AddPackages.Click

        txtOutput.Text = ""
        If (CmbBoxPackageManagement_UseImageMounted.Text = "" And ChkBoxPackageManagement_Online.Checked = False) Then
            MessageBox.Show("No image selected.  You must selected an image before running this command.")
        Else
            If txtPackageFile.Text = "" Then
                MessageBox.Show("You must specify a folder where your package(s) are located.")
            Else
                strPackageLocation = txtPackageFile.Text
                If (ChkBoxPackageManagement_Online.Checked = True) Then
                    strDISMArguments = "/Online /Add-Package /PackagePath:""" & strPackageLocation & """"
                Else
                    strDISMArguments = "/Image:""" & CmbBoxPackageManagement_UseImageMounted.Text & """" & " /Add-Package /PackagePath:""" & strPackageLocation & """"
                End If

                If chkIgnoreCheck.Checked = True Then
                    blnIgnoreCheck = True
                    strDISMArguments = strDISMArguments & " /IgnoreCheck"
                Else
                    blnIgnoreCheck = False
                End If
                If ChkBoxPackageManagement_PreventPending.Checked = True Then
                    strDISMArguments = strDISMArguments & " /PreventPending"
                End If
                txtOutput.Text = "Command line that running is:" & vbCrLf & "Dism.exe " & strDISMArguments & vbCrLf
                BackgroundWorkerDISMCommand.RunWorkerAsync(strDISMArguments)
                frmProgress.ShowDialog()
                txtOutput.Text = txtOutput.Text & strOutput & vbCrLf & "Exit code:" & strDISMExitCode
            End If
        End If
    End Sub
    '
    ' Function OpenFolder
    ' Rev: 31/07/2022
    '
    Private Function OpenFolder()

        dlgOpenFolder.ShowNewFolderButton = False
        dlgOpenFolder.RootFolder = Environment.SpecialFolder.MyComputer
        Dim DidWork As Integer = dlgOpenFolder.ShowDialog
        If DidWork = DialogResult.Cancel Then
            strLocation = ""
            Return strLocation
        Else
            strLocation = dlgOpenFolder.SelectedPath
            Return strLocation
        End If
    End Function
    '
    ' Sub btnGetAllDriverInfo_Click
    ' Use to get all drivers information in offline or online mode
    '
    ' Rev: 31/07/2022
    '
    Private Sub btnGetAllDriverInfo_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnDriverManagement_GetAllDriverInfo.Click

        txtOutput.Text = ""
        'If (ImageMounted = False And ChkBoxDriverManagement_Online.Checked = False) Then
        If (CmbBoxDriverManagement_UseImageMounted.Text = "" And ChkBoxDriverManagement_Online.Checked = False) Then
            'MessageBox.Show("No WIM is mounted.  You must mount a WIM before running this command (Offline mode) or use /Online option.")
            MessageBox.Show("No image selected.  You must selected an image before running this command (Offline mode) or use /Online option.")
        Else
            If (ChkBoxDriverManagement_Online.Checked) Then
                strDISMArguments = "/Online" & " /Get-Drivers /All"
            Else
                'strDISMArguments = "/Image:""" & strMountedImageLocation & """" & " /Get-Drivers /All"
                strDISMArguments = "/Image:""" & CmbBoxDriverManagement_UseImageMounted.Text & """" & " /Get-Drivers /All"
            End If
            txtOutput.Text = "Command line that running is:" & vbCrLf & "Dism.exe " & strDISMArguments & vbCrLf
            BackgroundWorkerDISMCommand.RunWorkerAsync(strDISMArguments)
            'BackgroundGetDrivers.RunWorkerAsync()
            frmProgress.ShowDialog()
            txtOutput.Text = txtOutput.Text & strOutput & vbCrLf & "Exit code:" & strDISMExitCode
        End If
    End Sub
    '
    ' Sub btnDelDriver_Click
    ' Use to delete driver on offline image (not for online mode)
    ' Rev: 31/07/2022

    Private Sub btnDelDriver_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnDriverManagement_DelDriver.Click

        txtOutput.Text = ""
        'If ImageMounted = False Then
        If CmbBoxDriverManagement_UseImageMounted.Text = "" Then
            ' MessageBox.Show("No WIM is mounted.  You must mount a WIM before running this command.")
            MessageBox.Show("No image selected.  You must selected an image before running this command (Offline mode) or use /Online option.")
        Else
            If TxtBoxDriverManagement_DelDriverLocation.Text = "" Then
                'Or Microsoft.VisualBasic.Left(txtDelDriverLocation.Text, 3) <> "inf"
                MessageBox.Show("You must enter in a driver name before continuing.  The Driver name must end with inf")
            Else
                strDelDriverLocation = TxtBoxDriverManagement_DelDriverLocation.Text
                'strDISMArguments = "/Image:""" & strMountedImageLocation & """" & " /Remove-Driver /Driver:" & strDelDriverLocation
                strDISMArguments = "/Image:""" & CmbBoxDriverManagement_UseImageMounted.Text & """" & " /Remove-Driver /Driver:" & strDelDriverLocation
                txtOutput.Text = "Command line that running is:" & vbCrLf & "Dism.exe " & strDISMArguments & vbCrLf
                BackgroundWorkerDISMCommand.RunWorkerAsync(strDISMArguments)
                frmProgress.ShowDialog()
                txtOutput.Text = txtOutput.Text & strOutput & vbCrLf & "Exit code:" & strDISMExitCode
            End If
            'Do Nothing
        End If
    End Sub
    '
    ' Sub btnRemovePackageName_Click
    ' Rev: 31/07/2022
    '
    Private Sub btnRemovePackageName_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnPackageManage_RemovePackage.Click

        txtOutput.Text = ""
        If CmbBoxPackageManagement_UseImageMounted.Text = "" Then
            MessageBox.Show("No image selected.  You must selected an image before running this command.")
        Else
            If txtPackageName.Text = "" Then
                MessageBox.Show("You must enter in a package name before continuing.")
            Else
                strPackageName = txtPackageName.Text
                strDISMArguments = "/Image:""" & CmbBoxPackageManagement_UseImageMounted.Text & """" & " /Remove-Package /PackageName:" & """" & strPackageName & """"
                txtOutput.Text = "Command line that running is:" & vbCrLf & "Dism.exe " & strDISMArguments & vbCrLf
                BackgroundWorkerDISMCommand.RunWorkerAsync(strDISMArguments)
                frmProgress.ShowDialog()
                txtOutput.Text = txtOutput.Text & strOutput & vbCrLf & "Exit code:" & strDISMExitCode
            End If
            'Do Nothing
        End If
    End Sub
    '
    ' Sub btnRemovePackagePath_Click
    ' Rev: 31/07/2022
    '
    Private Sub btnRemovePackagePath_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnPackageManage_RemovePackagePath.Click

        txtOutput.Text = ""
        If CmbBoxPackageManagement_UseImageMounted.Text = "" Then
            MessageBox.Show("No image selected.  You must selected an image before running this command.")
        Else
            If txtPackagePath.Text = "" Then
                MessageBox.Show("You must enter in a package path before continuing.  The package path must point to a valid cab file.")
            Else
                strPackagePath = txtPackagePath.Text
                strDISMArguments = "/Image:""" & CmbBoxPackageManagement_UseImageMounted.Text & """" & " /Remove-Package /PackagePath:" & """" & strPackagePath & """"
                txtOutput.Text = "Command line that running is:" & vbCrLf & "Dism.exe " & strDISMArguments & vbCrLf
                BackgroundWorkerDISMCommand.RunWorkerAsync(strDISMArguments)
                frmProgress.ShowDialog()
                txtOutput.Text = txtOutput.Text & strOutput & vbCrLf & "Exit code:" & strDISMExitCode
            End If
            'Do Nothing
        End If
    End Sub
    '
    ' Sub btnGetFeatures_Click
    ' Rev: 31/07/2022
    '
    Private Sub btnGetFeatures_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnFeatureManage_GetFeatures.Click

        txtOutput.Text = ""
        If (CmbBoxFeatureManagement_UseImageMounted.Text = "" And ChkBoxFeatureManagement_Online.Checked = False) Then
            MessageBox.Show("No image selected.  You must selected an image before running this command (Offline mode) or use /Online option.")
        Else
            If (ChkBoxFeatureManagement_Online.Checked = True) Then
                strDISMArguments = "/Online /Get-Features"
            Else
                strDISMArguments = "/Image:""" & CmbBoxFeatureManagement_UseImageMounted.Text & """ /Get-Features"
            End If
            txtOutput.Text = "Command line that running is:" & vbCrLf & "Dism.exe " & strDISMArguments & vbCrLf
            BackgroundWorkerDISMCommand.RunWorkerAsync(strDISMArguments)
            frmProgress.ShowDialog()
            txtOutput.Text = txtOutput.Text & strOutput & vbCrLf & "Exit code:" & strDISMExitCode
        End If
    End Sub
    '
    ' Sub chkEnablePkgName_CheckedChanged
    ' Rev: 31/07/2022
    '
    Private Sub chkEnablePkgName_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkEnablePkgName.CheckedChanged

        If chkEnablePkgName.Checked = True Then
            txtFeatPackageName.Enabled = True
        ElseIf chkEnablePkgName.Checked = False Then
            txtFeatPackageName.Enabled = False
        End If
    End Sub
    '
    ' Sub chkEnablePkgPath_CheckedChanged
    ' Rev: 31/07/2022
    '
    Private Sub chkEnablePkgPath_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkEnablePkgPath.CheckedChanged

        If chkEnablePkgPath.Checked = True Then
            txtFeatPackagePath.Enabled = True
        ElseIf chkEnablePkgPath.Checked = False Then
            txtFeatPackagePath.Enabled = False
        End If
    End Sub
    '
    ' Sub btnEnableFeature_Click
    ' Rev: 31/07/2022
    '
    Private Sub btnEnableFeature_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnFeatureManage_EnableFeature.Click

        txtOutput.Text = ""
        If CmbBoxFeatureManagement_UseImageMounted.Text = "" And ChkBoxFeatureManagement_Online.Checked = False Then
            MessageBox.Show("No image selected.  You must selected an image before running this command (Offline mode) or use /Online option.")
            Exit Sub
        End If

        If txtFeatureName.Text = "" Then
            MessageBox.Show("Feature Name is required to continue.")
            Exit Sub
        End If

        If chkEnablePkgName.Checked = True And txtFeatPackageName.Text = "" Then
            MessageBox.Show("If you enable the Package Name field you must specify a Package Name")
            Exit Sub
        End If

        If chkEnablePkgPath.Checked = True And txtFeatPackagePath.Text = "" Then
            MessageBox.Show("If you enable the Package Path field you must specify a Package Path")
            Exit Sub
        End If

        strFeatureName = txtFeatureName.Text
        If ChkBoxFeatureManagement_Online.Checked Then
            strDISMArguments = "/Online /Enable-Feature /FeatureName:" & """" & strFeatureName & """"
        Else
            strDISMArguments = "/Image:" & """" & CmbBoxFeatureManagement_UseImageMounted.Text & """" & " /Enable-Feature /FeatureName:""" & strFeatureName & """"
        End If
        If TxtBoxFeatureManagement_Source.Text <> "" Then
            strDISMArguments = strDISMArguments & " /Source:" & """" & TxtBoxFeatureManagement_Source.Text & """"
        End If

        If chkEnablePkgName.Checked = True Then
            strDISMArguments = strDISMArguments & " /PackageName:" & """" & txtFeatPackageName.Text & """"
        End If

        If chkEnablePkgPath.Checked = True Then
            strDISMArguments = strDISMArguments & " /PackagePath:" & """" & txtFeatPackagePath.Text & """"
        End If

        If ChkBoxFeatureManagement_LimitAccess.Checked = True Then
            strDISMArguments = strDISMArguments & " /LimitAccess"
        End If

        If ChkBoxFeatureManagement_All.Checked = True Then
            strDISMArguments = strDISMArguments & " /All"
        End If
        txtOutput.Text = "Command line that running is:" & vbCrLf & "Dism.exe " & strDISMArguments & vbCrLf
        BackgroundWorkerDISMCommand.RunWorkerAsync(strDISMArguments)
        frmProgress.ShowDialog()
        txtOutput.Text = txtOutput.Text & strOutput & vbCrLf & "Exit code:" & strDISMExitCode
    End Sub
    '
    ' Sub btnDisableFeature_Click
    ' Rev: 31/07/2022
    '
    Private Sub btnDisableFeature_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnFeatureManage_DisableFeature.Click

        txtOutput.Text = ""
        If CmbBoxFeatureManagement_UseImageMounted.Text = "" And ChkBoxFeatureManagement_Online.Checked = False Then
            MessageBox.Show("No image selected.  You must selected an image before running this command (Offline mode) or use /Online option.")
            Exit Sub
        End If

        If txtFeatureName.Text = "" Then
            MessageBox.Show("Feature Name is required to continue.")
            Exit Sub
        End If

        If chkEnablePkgName.Checked = True And txtFeatPackageName.Text = "" Then
            MessageBox.Show("If you enable the Package Name field you must specify a Package Name")
            Exit Sub
        End If

        If chkEnablePkgPath.Checked = True Then
            MessageBox.Show("The PackagePath option cannot be used with disabling a feature.  Anything entered into that box will be ignored.")
        End If

        strFeatureName = txtFeatureName.Text

        If ChkBoxFeatureManagement_Online.Checked Then
            strDISMArguments = "/Online /Disable-Feature /FeatureName:" & """" & strFeatureName & """"
        Else
            strDISMArguments = "/Image:" & """" & CmbBoxFeatureManagement_UseImageMounted.Text & """" & " /Disable-Feature /FeatureName:" & """" & strFeatureName & """"
        End If

        If chkEnablePkgName.Checked = True Then
            strDISMArguments = strDISMArguments & " /PackageName:" & txtFeatPackageName.Text
        End If
        txtOutput.Text = "Command line that running is:" & vbCrLf & "Dism.exe " & strDISMArguments & vbCrLf
        BackgroundWorkerDISMCommand.RunWorkerAsync(strDISMArguments)
        frmProgress.ShowDialog()
        txtOutput.Text = txtOutput.Text & strOutput & vbCrLf & "Exit code:" & strDISMExitCode
    End Sub
    ' 
    ' Sub CleanupImageToolStripMenuItem_Click
    ' Rev: 31/07/2022
    '
    Private Sub CleanupImageToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CleanupImageToolStripMenuItem.Click

        txtOutput.Text = ""
        strDISMArguments = "/Image:""" & strMountedImageLocation & """" & " /Cleanup-Image /RevertPendingActions"
        txtOutput.Text = "Command line that running is:" & vbCrLf & "Dism.exe " & strDISMArguments & vbCrLf
        BackgroundWorkerDISMCommand.RunWorkerAsync(strDISMArguments)
        frmProgress.ShowDialog()
        txtOutput.Text = txtOutput.Text & strOutput & vbCrLf & "Exit code:" & strDISMExitCode
    End Sub
    '
    ' Sub frmMain_Load
    ' Rev: 31/07/2022
    '
    Private Sub frmMain_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load

        EnglishToolStripMenuItem.Checked = True         ' select english langue by default
        ResMan = New ResourceManager("DISM_GUI.resources", GetType(frmMain).Assembly)
        CultInfo = CultureInfo.CreateSpecificCulture("en-US") ' en-US by default
        RadBtnDiskpartWinPE_FAT32.Checked = True        ' Tab DiskpartWinPE (default value)
        RadBtnDiskpartWinPE_WinPEamd64.Checked = True
        RadBtnCustomWinPE_TypeAmd64.Checked = True      ' Tab CustomPE (default value)
        'CmbMountControl_Index.Text = "1"
        cmbCompression.Text = "Fast"
        'cmbApplyIndex.Text = "1"
        ExtractDismVersion_Windows()                     ' Extract dism version of Windows
        ExtractDismVersion_ADK()                         ' Extract dism version of ADK
    End Sub

    '
    ' btGetCurrentEdition_Click
    ' Rev: 31/07/2022
    '
    Private Sub btGetCurrentEdition_Click(sender As System.Object, e As System.EventArgs) Handles BtnEditionServicing_GetCurrentEdition.Click

        txtOutput.Text = ""
        If (CmbBoxEditionServicing_UseImageMounted.Text = "" And ChkBoxEditionServicing_Online.Checked = False) Then
            MessageBox.Show("No image selected.  You must selected an image before running this command (Offline mode) or use /Online option.")
        Else
            If (ChkBoxEditionServicing_Online.Checked = True) Then
                strDISMArguments = "/Online /Get-CurrentEdition"
            Else
                strDISMArguments = "/Image:""" & CmbBoxEditionServicing_UseImageMounted.Text & """" & " /Get-CurrentEdition"
            End If
            txtOutput.Text = "Command line that running is:" & vbCrLf & "Dism.exe " & strDISMArguments & vbCrLf
            BackgroundWorkerDISMCommand.RunWorkerAsync(strDISMArguments)
            frmProgress.ShowDialog()
            txtOutput.Text = txtOutput.Text & strOutput & vbCrLf & "Exit code:" & strDISMExitCode
        End If
    End Sub
    ' 
    ' Sub btnGetTargetEditions_Click
    ' Rev: 31/07/2022
    '
    Private Sub btnGetTargetEditions_Click(sender As System.Object, e As System.EventArgs) Handles BtnEditionServicing_GetTargetEditions.Click

        txtOutput.Text = ""
        If (CmbBoxEditionServicing_UseImageMounted.Text = "" And ChkBoxEditionServicing_Online.Checked = False) Then
            MessageBox.Show("No image selected.  You must selected an image before running this command (Offline mode) or use /Online option.")
        Else
            If (ChkBoxEditionServicing_Online.Checked = True) Then
                strDISMArguments = "/Online /Get-TargetEditions"
            Else
                strDISMArguments = "/Image:""" & CmbBoxEditionServicing_UseImageMounted.Text & """" & " /Get-TargetEditions"
            End If
            txtOutput.Text = "Command line that running is:" & vbCrLf & "Dism.exe " & strDISMArguments & vbCrLf
            BackgroundWorkerDISMCommand.RunWorkerAsync(strDISMArguments)
            frmProgress.ShowDialog()
            txtOutput.Text = txtOutput.Text & strOutput & vbCrLf & "Exit code:" & strDISMExitCode
        End If
    End Sub
    ' 
    ' Sub  btnSetProdKey_Click
    ' Rev: 31/07/2022
    '
    Private Sub btnSetProdKey_Click(sender As System.Object, e As System.EventArgs) Handles BtnEditionServicing_SetProductKey.Click

        txtOutput.Text = ""
        If CmbBoxEditionServicing_UseImageMounted.Text = "" Then
            MessageBox.Show("No image selected.  You must selected an image before running this command.")
            Exit Sub
        Else
            'Do Nothing
        End If

        If txtProdKey.Text = "" Then
            MessageBox.Show("Product Key is required to continue.")
            Exit Sub
        Else
            'Do Nothing
        End If

        strProductKey = txtProdKey.Text
        strDISMArguments = "/Image:""" & CmbBoxEditionServicing_UseImageMounted.Text & """" & " /Set-ProductKey:" & strProductKey
        txtOutput.Text = "Command line that running is:" & vbCrLf & "Dism.exe " & strDISMArguments & vbCrLf
        BackgroundWorkerDISMCommand.RunWorkerAsync(strDISMArguments)
        frmProgress.ShowDialog()
        txtOutput.Text = txtOutput.Text & strOutput & vbCrLf & "Exit code:" & strDISMExitCode
    End Sub
    ' 
    ' Sub  btnSetEdition_Click
    ' Rev: 31/07/2022
    '
    Private Sub btnSetEdition_Click(sender As System.Object, e As System.EventArgs) Handles BtnEditionServicing_SetEdition.Click

        txtOutput.Text = ""
        If CmbBoxEditionServicing_UseImageMounted.Text = "" Then
            MessageBox.Show("No image selected.  You must selected an image before running this command.")
            Exit Sub
        Else

        End If

        If txtEdition.Text = "" Then
            MessageBox.Show("Edition is required to continue.")
            Exit Sub
        Else
            'Do Nothing
        End If

        strEdition = txtEdition.Text
        strProductKey = txtProdKey.Text
        strDISMArguments = "/Image:""" & CmbBoxEditionServicing_UseImageMounted.Text & """" & " /Set-Edition:" & strEdition
        txtOutput.Text = "Command line that running is:" & vbCrLf & "Dism.exe " & strDISMArguments & vbCrLf
        BackgroundWorkerDISMCommand.RunWorkerAsync(strDISMArguments)
        frmProgress.ShowDialog()
        txtOutput.Text = txtOutput.Text & strOutput & vbCrLf & "Exit code:" & strDISMExitCode
    End Sub
    ' 
    ' Sub  btnChooseUnAttend_Click
    ' Rev:31/07/2022
    '
    Private Sub btnChooseUnAttend_Click(sender As System.Object, e As System.EventArgs) Handles BtnUnattendedServicing_ChooseUnAttend.Click
        Dim DidWork As Integer = dlgOpenXML.ShowDialog

        dlgOpenXML.InitialDirectory = Environment.SpecialFolder.MyComputer
        dlgOpenXML.Title = "Choose Unattend XML file to Open"
        dlgOpenXML.Filter = ("XML Files(*.xml)|*.xml|All Files (*.*)|*.*")

        If DidWork = DialogResult.Cancel Then
            'Do Nothing
        Else
            ' Dim strXMLFileName As String = dlgOpenXML.FileName
            strXMLFileName = dlgOpenXML.FileName
            TxtBoxUnattendedServicing_XMLFile.Text = strXMLFileName
        End If
    End Sub
    ' 
    ' Sub  btnApplyUnattend_Click
    ' Rev: 31/07/2022
    '
    Private Sub btnApplyUnattend_Click(sender As System.Object, e As System.EventArgs) Handles BtnUnattendedServicing_ApplyUnattend.Click

        txtOutput.Text = ""
        If (CmBoxUnattendedServicing_UseImageMounted.Text = "" And ChkBoxUnattendedServicing_Online.Checked = False) Then
            MessageBox.Show("No image selected.  You must selected an image before running this command (Offline mode) or use /Online option.")
        Else
            If TxtBoxUnattendedServicing_XMLFile.Text = "" Then
                MessageBox.Show("You must enter an XML file.")
            Else
                strXMLFileName = TxtBoxUnattendedServicing_XMLFile.Text
                If (ChkBoxUnattendedServicing_Online.Checked = True) Then
                    strDISMArguments = "/Online /Apply-Unattend:""" & strXMLFileName & """"
                Else
                    strDISMArguments = "/Image:""" & CmBoxUnattendedServicing_UseImageMounted.Text & """" & " /Apply-Unattend:""" & strXMLFileName & """"
                End If
                ' strXMLFileName = txtPatchLocation.Text
                txtOutput.Text = "Command line that running is:" & vbCrLf & "Dism.exe " & strDISMArguments & vbCrLf
                BackgroundWorkerDISMCommand.RunWorkerAsync(strDISMArguments)
                frmProgress.ShowDialog()
                txtOutput.Text = txtOutput.Text & strOutput & vbCrLf & "Exit code:" & strDISMExitCode
            End If
        End If
    End Sub
    ' 
    ' Sub  btnGetApps_Click
    ' Rev: 31/07/2022
    '
    Private Sub btnGetApps_Click(sender As System.Object, e As System.EventArgs) Handles BtnApplicationServicing_GetApps.Click

        txtOutput.Text = ""
        If CmbBoxApplicationServicing_UseImageMounted.Text = "" Then
            MessageBox.Show("No image selected.  You must selected an image before running this command.")
        Else
            strDISMArguments = "/Image:""" & CmbBoxApplicationServicing_UseImageMounted.Text & """" & " /Get-Apps"
            txtOutput.Text = "Command line that running is:" & vbCrLf & "Dism.exe " & strDISMArguments & vbCrLf
            BackgroundWorkerDISMCommand.RunWorkerAsync(strDISMArguments)
            frmProgress.ShowDialog()
            txtOutput.Text = txtOutput.Text & strOutput & vbCrLf & "Exit code:" & strDISMExitCode
        End If
    End Sub
    ' 
    ' Sub  btnGetAppInfo_Click
    ' Rev: 31/07/2022
    '
    Private Sub btnGetAppInfo_Click(sender As System.Object, e As System.EventArgs) Handles BtnApplicationServicing_GetAppInfo.Click

        txtOutput.Text = ""
        If CmbBoxApplicationServicing_UseImageMounted.Text = "" Then
            MessageBox.Show("No image selected.  You must selected an image before running this command.")
            Exit Sub
        Else
            'Do Nothing
        End If

        If txtProductCode.Text = "{        -    -    -    -            }" Then
            strProductCode = txtProductCode.Text
            strDISMArguments = "/Image:""" & CmbBoxApplicationServicing_UseImageMounted.Text & """" & " /Get-AppInfo"
            txtOutput.Text = "Command line that running is:" & vbCrLf & "Dism.exe " & strDISMArguments & vbCrLf
            BackgroundWorkerDISMCommand.RunWorkerAsync(strDISMArguments)
            frmProgress.ShowDialog()
            txtOutput.Text = txtOutput.Text & strOutput & vbCrLf & "Exit code:" & strDISMExitCode
        Else
            strProductCode = txtProductCode.Text
            strDISMArguments = "/Image:""" & CmbBoxApplicationServicing_UseImageMounted.Text & """" & " /Get-AppInfo /ProductCode:" & strProductCode
            txtOutput.Text = "Command line that running is:" & vbCrLf & "Dism.exe " & strDISMArguments & vbCrLf
            BackgroundWorkerDISMCommand.RunWorkerAsync(strDISMArguments)
            frmProgress.ShowDialog()
            txtOutput.Text = txtOutput.Text & strOutput & vbCrLf & "Exit code:" & strDISMExitCode
        End If
    End Sub
    ' 
    ' Sub  btnGetAppPatches_Click
    ' Rev: 31/07/2022
    '
    Private Sub btnGetAppPatches_Click(sender As System.Object, e As System.EventArgs) Handles BtnApplicationServicing_GetAppPatches.Click

        txtOutput.Text = ""
        If CmbBoxApplicationServicing_UseImageMounted.Text = "" Then
            MessageBox.Show("No image selected.  You must selected an image before running this command.")
            Exit Sub
        Else
            'Do Nothing
        End If

        If txtProductCode.Text = "{        -    -    -    -            }" Then
            strProductCode = txtProductCode.Text
            strDISMArguments = "/Image:""" & CmbBoxApplicationServicing_UseImageMounted.Text & """" & " /Get-AppPatches"
            txtOutput.Text = "Command line that running is:" & vbCrLf & "Dism.exe " & strDISMArguments & vbCrLf
            BackgroundWorkerDISMCommand.RunWorkerAsync(strDISMArguments)
            frmProgress.ShowDialog()
            txtOutput.Text = txtOutput.Text & strOutput & vbCrLf & "Exit code:" & strDISMExitCode
        Else
            strProductCode = txtProductCode.Text
            strDISMArguments = "/Image:""" & CmbBoxApplicationServicing_UseImageMounted.Text & """" & " /Get-AppPatches  /ProductCode:" & strProductCode
            txtOutput.Text = "Command line that running is:" & vbCrLf & "Dism.exe " & strDISMArguments & vbCrLf
            BackgroundWorkerDISMCommand.RunWorkerAsync(strDISMArguments)
            frmProgress.ShowDialog()
            txtOutput.Text = txtOutput.Text & strOutput & vbCrLf & "Exit code:" & strDISMExitCode
        End If
    End Sub
    ' 
    ' Sub  btnGetAppPatchInfo_Click
    ' Rev: 31/07/2022
    '
    Private Sub btnGetAppPatchInfo_Click(sender As System.Object, e As System.EventArgs) Handles BtnApplicationServicing_GetAppPatchInfo.Click

        txtOutput.Text = ""
        If CmbBoxApplicationServicing_UseImageMounted.Text = "" Then
            MessageBox.Show("No image selected.  You must selected an image before running this command.")
            Exit Sub
        Else
            'Do Nothing
        End If

        If txtPatchCode.Text = "{        -    -    -    -            }" And txtProductCode.Text = "{        -    -    -    -            }" Then
            strDISMArguments = "/Image:""" & CmbBoxApplicationServicing_UseImageMounted.Text & """" & " /Get-AppPatchInfo"
            txtOutput.Text = "Command line that running is:" & vbCrLf & "Dism.exe " & strDISMArguments & vbCrLf
            BackgroundWorkerDISMCommand.RunWorkerAsync(strDISMArguments)
            frmProgress.ShowDialog()
            txtOutput.Text = txtOutput.Text & strOutput & vbCrLf & "Exit code:" & strDISMExitCode
            Exit Sub
        Else
            'Do Nothing
        End If

        If txtPatchCode.Text <> "{        -    -    -    -            }" And txtProductCode.Text = "{        -    -    -    -            }" Then
            strPatchCode = txtPatchCode.Text
            strProductCode = txtProductCode.Text
            strDISMArguments = "/Image:""" & CmbBoxApplicationServicing_UseImageMounted.Text & """" & " /Get-AppPatchInfo /PatchCode:" & strPatchCode
            txtOutput.Text = "Command line that running is:" & vbCrLf & "Dism.exe " & strDISMArguments & vbCrLf
            BackgroundWorkerDISMCommand.RunWorkerAsync(strDISMArguments)
            frmProgress.ShowDialog()
            txtOutput.Text = txtOutput.Text & strOutput & vbCrLf & "Exit code:" & strDISMExitCode
            Exit Sub
        Else
            'Do Nothing
        End If

        If txtPatchCode.Text = "{        -    -    -    -            }" And txtProductCode.Text <> "{        -    -    -    -            }" Then
            strPatchCode = txtPatchCode.Text
            strProductCode = txtProductCode.Text
            strDISMArguments = "/Image:""" & CmbBoxApplicationServicing_UseImageMounted.Text & """" & " /Get-AppPatchInfo /ProductCode:" & strProductCode
            txtOutput.Text = "Command line that running is:" & vbCrLf & "Dism.exe " & strDISMArguments & vbCrLf
            BackgroundWorkerDISMCommand.RunWorkerAsync(strDISMArguments)
            frmProgress.ShowDialog()
            txtOutput.Text = txtOutput.Text & strOutput & vbCrLf & "Exit code:" & strDISMExitCode
            Exit Sub
        Else
            'Do Nothing
        End If

        If txtPatchCode.Text <> "{        -    -    -    -            }" And txtProductCode.Text <> "{        -    -    -    -            }" Then
            strPatchCode = txtPatchCode.Text
            strProductCode = txtProductCode.Text
            strDISMArguments = "/Image:""" & CmbBoxApplicationServicing_UseImageMounted.Text & """" & " /Get-AppPatchInfo /PatchCode:" & strPatchCode & " /ProductCode:" & strProductCode
            txtOutput.Text = "Command line that running is:" & vbCrLf & "Dism.exe " & strDISMArguments & vbCrLf
            BackgroundWorkerDISMCommand.RunWorkerAsync(strDISMArguments)
            frmProgress.ShowDialog()
            txtOutput.Text = txtOutput.Text & strOutput & vbCrLf & "Exit code:" & strDISMExitCode
            Exit Sub
        Else
            'Do Nothing
        End If
    End Sub
    ' 
    ' Sub  btnCheckAppPatch_Click
    ' Rev: 31/07/2022
    '
    Private Sub btnCheckAppPatch_Click(sender As System.Object, e As System.EventArgs) Handles BtnApplicationServicing_CheckAppPatch.Click

        txtOutput.Text = ""
        If CmbBoxApplicationServicing_UseImageMounted.Text = "" Then
            MessageBox.Show("No image selected.  You must selected an image before running this command.")
            Exit Sub
        Else
            'Do Nothing
        End If

        If txtPatchLocation.Text = "" Then
            MessageBox.Show("You must enter an MSP file.")
            Exit Sub
        Else
            'Do Nothing
        End If
        strMSPFileName = txtPatchLocation.Text
        strDISMArguments = "/Image:""" & CmbBoxApplicationServicing_UseImageMounted.Text & """" & " /Check-AppPatch /PatchLocation:""" & strMSPFileName & """"
        txtOutput.Text = "Command line that running is:" & vbCrLf & "Dism.exe " & strDISMArguments & vbCrLf
        BackgroundWorkerDISMCommand.RunWorkerAsync(strDISMArguments)
        frmProgress.ShowDialog()
        txtOutput.Text = txtOutput.Text & strOutput & vbCrLf & "Exit code:" & strDISMExitCode
    End Sub
    ' 
    ' Sub  btnChooseMSP_Click
    ' Rev: 31/07/2022
    '
    Private Sub btnChooseMSP_Click(sender As System.Object, e As System.EventArgs) Handles BtnApplicationServicing_ChooseMSP.Click

        dlgOpenMSP.InitialDirectory = Environment.SpecialFolder.MyComputer
        dlgOpenMSP.Title = "Choose Unattend XML file to Open"
        dlgOpenMSP.Filter = ("MSP Files(*.msp)|*.msp|All Files (*.*)|*.*")
        Dim DidWork As Integer = dlgOpenMSP.ShowDialog

        If DidWork = DialogResult.Cancel Then
            'Do Nothing
        Else
            Dim strMSPFileName As String = dlgOpenMSP.FileName
            txtPatchLocation.Text = strMSPFileName
        End If
    End Sub
    '
    ' Sub btnCreate_Click
    ' Rev: 14072022
    '
    Private Sub btnCreate_Click(sender As System.Object, e As System.EventArgs) Handles BtnCaptureImageWim_CreateWim.Click

        txtOutput.Text = ""
        If txtCaptureSource.Text = "" Then
            MessageBox.Show("You must select a source location.")
            Exit Sub
        End If

        If txtCaptureDest.Text = "" Then
            MessageBox.Show("You must set a destination file.")
            Exit Sub
        End If

        If TxtFileName.Text = "" Then
            MessageBox.Show("You must enter a filename for WIM file.")
            Exit Sub
        End If

        If TxtNameMetadata.Text = "" Then
            MessageBox.Show("You must enter a description for the WIM metadata.")
            Exit Sub
        End If

        strSource = txtCaptureSource.Text

        ' detect if logical drive only, no double quot on string preserv for error 87 or 123
        If (strSource.Length <> 3) Then
            strSource = """" + strSource + """" ' if not, style use double quot
        End If

        strDest = txtCaptureDest.Text
        strFilename = TxtFileName.Text
        strNameMetadata = TxtNameMetadata.Text
        strNameDescription = TxtBoxCaptureWIM_Description.Text
        strCompression = cmbCompression.Text

        ' add extension file automatically if forgotten
        If (Path.GetExtension(TxtFileName.Text.ToUpper()) <> ".WIM") Then
            TxtFileName.Text = TxtFileName.Text + ".wim"
            strFilename = TxtFileName.Text
        End If

        strDISMArguments = "/Capture-Image /ImageFile:""" + strDest + "\" + strFilename + """" + " /CaptureDir:" + strSource + " /Name:""" + strNameMetadata + """" + " /Description:" + """" + strNameDescription + """" + " /Compress:" + strCompression

        If ChkBoxCaptureImageWim_Verify.Checked = True Then
            strDISMArguments = strDISMArguments + " /Verify"
        End If

        txtOutput.Text = "Command line that running is:" & vbCrLf & "Dism.exe " & strDISMArguments & vbCrLf
        BackgroundWorkerDISMCommand.RunWorkerAsync(strDISMArguments)
        frmProgress.ShowDialog()
        txtOutput.Text = txtOutput.Text & strOutput & vbCrLf & "Exit code:" & strDISMExitCode
    End Sub
    ' 
    ' Sub  btnCaptureSrc_Click
    ' Rev: 31/07/2022
    Private Sub btnCaptureSrc_Click(sender As System.Object, e As System.EventArgs) Handles BtnCaptureImageWim_BrowseSource.Click

        dlgOpenFolder.ShowNewFolderButton = False
        dlgOpenFolder.RootFolder = Environment.SpecialFolder.MyComputer
        dlgOpenFolder.ShowDialog()
        Dim strFolderName As String = dlgOpenFolder.SelectedPath
        Dim dirs As String() = System.IO.Directory.GetDirectories(strFolderName)
        Dim files As String() = System.IO.Directory.GetFiles(strFolderName)
        If dirs.Length = 0 AndAlso files.Length = 0 Then
            If MessageBox.Show("You must choose a non-empty folder.") = DialogResult.OK Then
            Else
                'Do Nothing
            End If
        Else
            txtCaptureSource.Text = strFolderName
        End If
    End Sub
    ' 
    ' Sub  btnCaptureDest_Click
    ' Rev: 31/07/2022
    '
    Private Sub btnCaptureDest_Click(sender As System.Object, e As System.EventArgs) Handles BtnCaptureImageWim_BrowseDestination.Click

        dlgOpenFolder.ShowNewFolderButton = False
        dlgOpenFolder.RootFolder = Environment.SpecialFolder.MyComputer
        dlgOpenFolder.ShowDialog()
        Dim strFolderName As String = dlgOpenFolder.SelectedPath

        txtCaptureDest.Text = strFolderName
    End Sub
    '
    ' Sub btnAppend_Click
    ' Rev: 31/07/2022
    '
    Private Sub btnAppend_Click(sender As System.Object, e As System.EventArgs) Handles BtnCaptureImageWim_AppendWim.Click

        txtOutput.Text = ""
        If txtCaptureSource.Text = "" Then
            MessageBox.Show("You must select a source location.")
            Exit Sub
        Else
            'Do Nothing
        End If

        If txtCaptureDest.Text = "" Then
            MessageBox.Show("You must set a destination file.")
            Exit Sub
        Else
            'Do Nothing
        End If

        If TxtFileName.Text = "" Then
            MessageBox.Show("You must enter a Name for the WIM.")
            Exit Sub
        Else
            'Do Nothing
        End If

        strSource = txtCaptureSource.Text

        ' detect if logical drive only, no double quot on string preserv for error 87 or 123
        If (strSource.Length <> 3) Then
            strSource = """" + strSource + """" ' if not, style use double quot
        End If

        strDest = txtCaptureDest.Text
        strFilename = TxtFileName.Text
        strNameMetadata = TxtNameMetadata.Text
        strNameDescription = TxtBoxCaptureWIM_Description.Text
        strCompression = cmbCompression.Text

        If (Path.GetExtension(TxtFileName.Text.ToUpper()) <> ".WIM") Then
            TxtFileName.Text = TxtFileName.Text + ".wim"
            strFilename = TxtFileName.Text
        End If

        strDISMArguments = "/Append-Image /ImageFile:""" + strDest + "\" + strFilename + """ /CaptureDir:" + strSource + " /Name:""" + strNameMetadata + """" + " /Description:" + """" + strNameDescription + """"

        If (ChkBoxCaptureImageWim_Verify.Checked = True) Then
            strDISMArguments = strDISMArguments + " /Verify"
        End If

        txtOutput.Text = "Command line that running is:" & vbCrLf & "Dism.exe " & strDISMArguments & vbCrLf
        BackgroundWorkerDISMCommand.RunWorkerAsync(strDISMArguments)
        frmProgress.ShowDialog()
        txtOutput.Text = txtOutput.Text & strOutput & vbCrLf & "Exit code:" & strDISMExitCode
    End Sub
    ' 
    ' Sub  btnBrowseSource_Click
    ' Rev: 31/07/2022
    '
    Private Sub btnBrowseSource_Click(sender As System.Object, e As System.EventArgs) Handles BtnApplyWim_BrowseSource.Click

        'dlgOpenFile.InitialDirectory = Environment.SpecialFolder.MyComputer
        dlgOpenFile.InitialDirectory = "C:\"
        dlgOpenFile.Title = "Choose WIM file to Open"
        dlgOpenFile.Filter = ("WIM Files(*.wim)|*.wim|SWM Files(*.swm)|*.swm|All Files (*.*)|*.*")
        Dim DidWork As Integer = dlgOpenFile.ShowDialog

        If DidWork = DialogResult.Cancel Then
            'Do Nothing
        Else
            Dim strFileName As String = dlgOpenFile.FileName
            txtApplySource.Text = strFileName
            DisplayImageInfos("Tab_ApplyImage.txt", txtApplySource.Text)
            Me.cmbApplyIndex.Items.Clear()
            ListInfosWimApplyImage.Clear()
            UpdateListIndexWim("Tab_ApplyImage.txt", ListInfosWimApplyImage)
            For IdxFor As Integer = 1 To ListInfosWimApplyImage.Count
                Me.cmbApplyIndex.Items.Add(IdxFor.ToString)
            Next
            If (Path.GetExtension(txtApplySource.Text.ToUpper) = ".SWM") Then
                TxtBoxApplySource_PatternSWMFile.Text = txtApplySource.Text
                TxtBoxApplySource_PatternSWMFile.Text = Replace(TxtBoxApplySource_PatternSWMFile.Text, ".swm", "*.swm")
            End If
        End If
    End Sub
    ' 
    ' Sub  btnBrowseDest_Click
    ' Rev: 31/07/2022
    '
    Private Sub btnBrowseDest_Click(sender As System.Object, e As System.EventArgs) Handles BtnApplyWim_BrowseDestination.Click

        Dim strFolderName As String = dlgOpenFolder.SelectedPath
        Dim dirs As String() = System.IO.Directory.GetDirectories(strFolderName)
        Dim files As String() = System.IO.Directory.GetFiles(strFolderName)
        Dim DidWork As Integer

        dlgOpenFolder.ShowNewFolderButton = False
        dlgOpenFolder.RootFolder = Environment.SpecialFolder.MyComputer
        DidWork = dlgOpenFolder.ShowDialog()
        If DidWork = DialogResult.OK Then
            txtApplyDest.Text = dlgOpenFolder.SelectedPath
        End If

        'If dirs.Length = 0 AndAlso files.Length = 0 Then
        ' txtApplyDest.Text = strFolderName
        'Else
        'If MessageBox.Show("You must choose an empty folder to mount the WIM") = DialogResult.OK Then
        'Else
        'Do Nothing
        'End If
        'End If
    End Sub
    ' 
    ' Sub  btnApply_Click
    ' Rev: 31/07/2022
    '
    Private Sub btnApply_Click(sender As System.Object, e As System.EventArgs) Handles BtnApplyWim_ApplyWim.Click
        Dim StrExtension As String

        txtOutput.Text = ""
        If txtApplySource.Text = "" Then
            MessageBox.Show("You must select a source file WIM or SWM.")
            Exit Sub
        Else
            'Do Nothing
        End If

        If txtApplyDest.Text = "" Then
            MessageBox.Show("You must select a destination file.")
            Exit Sub
        Else
            'Do Nothing
        End If

        If cmbApplyIndex.Text = "" Then                               ' to review...
            MessageBox.Show("You must select an index number.")
            Exit Sub
        Else

        End If

        strSource = txtApplySource.Text
        strDest = txtApplyDest.Text
        If (strDest.Length <> 3) Then
            strDest = """" + strDest + """"          ' to skip dism error 123 or 87
        End If                                       ' no double quot on string if logical drive only

        strAppendIndex = cmbApplyIndex.Text
        'TxtBoxApplySource_PatternSWMFile.Text = txtApplySource.Text   ' prefix pattern

        StrExtension = Path.GetExtension(txtApplySource.Text.ToUpper) ' Extract extension file
        Select Case StrExtension
            Case ".WIM"
                strDISMArguments = "/Apply-Image /ImageFile:""" & strSource & """ /Index:" & strAppendIndex & " /ApplyDir:" & strDest
            Case ".SWM"
                strDISMArguments = "/Apply-Image /ImageFile:""" & strSource & """ /SWMFile:""" & TxtBoxApplySource_PatternSWMFile.Text & """ /Index:" & strAppendIndex & " /ApplyDir:" & strDest
        End Select


        If ChkBoxApplyWim_Verify.Checked = True Then
            strDISMArguments = strDISMArguments & " /Verify"
        End If

        txtOutput.Text = "Command line that running is:" & vbCrLf & "Dism.exe " & strDISMArguments & vbCrLf
        BackgroundWorkerDISMCommand.RunWorkerAsync(strDISMArguments)
        frmProgress.ShowDialog()
        txtOutput.Text = txtOutput.Text & strOutput & vbCrLf & "Exit code:" & strDISMExitCode
    End Sub
    '
    ' Refresh information from wim selected
    ' Rev: 31/07/2022
    '
    Private Sub cmbIndex_SelectedIndexChanged(sender As Object, e As EventArgs) Handles CmbMountControl_Index.SelectedIndexChanged

        TxtBoxMountControl_Name.Text = ListInfosWimGestionMontage.ElementAt(CmbMountControl_Index.SelectedIndex).Nom.ToString
        TxtBoxMountControl_Description.Text = ListInfosWimGestionMontage.ElementAt(CmbMountControl_Index.SelectedIndex).Description.ToString
        TxtBoxMountControl_Size.Text = ListInfosWimGestionMontage.ElementAt(CmbMountControl_Index.SelectedIndex).Taille.ToString
    End Sub
    '
    ' Sub BtnExportImage_BrowseSource_Click
    ' 
    ' Use for Open File dialog Box WIM/ESD
    ' save the result on TxtBoxExportImage_Source form variable
    ' "ExportImage_WimInfos.txt" is creating on the current application folder
    ' Rev: 31/07/2022
    '
    Private Sub BtnExportImage_BrowseSource_Click(sender As Object, e As EventArgs) Handles BtnExportImage_BrowseSource.Click
        Dim SourceFileName As String
        Dim MyDlgOpenFile = New System.Windows.Forms.OpenFileDialog() ' instance of dialog box

        txtOutput.Text = ""
        'MyDlgOpenFile.InitialDirectory = Environment.SpecialFolder.MyComputer     
        MyDlgOpenFile.InitialDirectory = "C:\" ' default root path
        MyDlgOpenFile.Title = "Choose WIM or ESD file to Open"    ' title of dialog box
        MyDlgOpenFile.Filter = ("WIM Files(*.wim)|*.wim|Fichier ESD (*.ESD)|*.ESD") ' filter extension

        If MyDlgOpenFile.ShowDialog = DialogResult.OK Then        ' user selected filename from dialog box ?
            SourceFileName = MyDlgOpenFile.FileName
            TxtBoxExportImage_Source.Text = SourceFileName        ' user choice filename

            strDISMArguments = "/Get-WimInfo /WimFile:""" & TxtBoxExportImage_Source.Text & """" ' arguments line for dism.exe
            txtOutput.Text = "Command line that running is:" & vbCrLf & "Dism.exe " & strDISMArguments & vbCrLf
            BackgroundWorkerDISMCommand.RunWorkerAsync(strDISMArguments) ' execute async dism command
            frmProgress.ShowDialog()                                     ' show speudo progress bar
            txtOutput.Text = txtOutput.Text & strOutput & vbCrLf & "Exit code:" & strDISMExitCode

            Try
                If System.IO.File.Exists("Tab_ExportImage.txt") = True Then ' delete old file (no append function)
                    System.IO.File.Create("Tab_ExportImage.txt").Dispose()
                End If
                ' creation new file on the current application directory
                Using sw As StreamWriter = New StreamWriter("Tab_ExportImage.txt", True, Encoding.UTF8)
                    sw.WriteLine(strOutput)
                    sw.Close()
                End Using
            Catch ex As Exception
                ' Let the user know what went wrong.
                'Console.WriteLine("The file could not be read:")
                'Console.WriteLine(e.Message)
                MessageBox.Show("DisplayImageInfos Error on created filename wiminfos.txt: " + ex.Message.ToString())
            End Try

            Me.CmbBoxExportImage_Index.Items.Clear()            ' clear index count in Form
            ListInfosWimExportImage.Clear()                     ' clear list<T> description index
            UpdateListIndexWim("Tab_ExportImage.txt", ListInfosWimExportImage) ' Mise à jour des index

            For IdxFor As Integer = 1 To ListInfosWimExportImage.Count ' update index
                Me.CmbBoxExportImage_Index.Items.Add(IdxFor.ToString)
            Next
        End If
    End Sub
    '
    ' Sub BtnExportImage_BrowseDestination_Click
    ' 
    ' Use for Open Folder dialog
    ' save the result on TxtBoxExportImage_Destination
    ' Rev: 31/07/2022
    '
    Private Sub BtnExportImage_BrowseDestination_Click(sender As Object, e As EventArgs) Handles BtnExportImage_BrowseDestination.Click

        Dim MyDlgOpenFolder As New System.Windows.Forms.FolderBrowserDialog()
        Dim StrFolderName As String

        MyDlgOpenFolder.ShowNewFolderButton = False
        MyDlgOpenFolder.RootFolder = Environment.SpecialFolder.MyComputer
        If MyDlgOpenFolder.ShowDialog() = DialogResult.OK Then
            StrFolderName = MyDlgOpenFolder.SelectedPath
            TxtBoxExportImage_Destination.Text = StrFolderName
        End If
    End Sub
    '
    ' Sub CmbBoxExportImage_Index_SelectedIndexChanged
    ' Rev: 31/07/2022
    '
    Private Sub CmbBoxExportImage_Index_SelectedIndexChanged(sender As Object, e As EventArgs) Handles CmbBoxExportImage_Index.SelectedIndexChanged

        TxtBoxExportImage_Name.Text = ListInfosWimExportImage.ElementAt(CmbBoxExportImage_Index.SelectedIndex).Nom.ToString
        TxtBoxExportImage_Description.Text = ListInfosWimExportImage.ElementAt(CmbBoxExportImage_Index.SelectedIndex).Description.ToString
        TxtBoxExportImage_Size.Text = ListInfosWimExportImage.ElementAt(CmbBoxExportImage_Index.SelectedIndex).Taille.ToString
    End Sub
    '
    ' Sub BtnExportImage_ExportImage_Click
    ' Rev: 31/07/2022
    '
    Private Sub BtnExportImage_ExportImage_Click(sender As Object, e As EventArgs) Handles BtnExportImage_ExportImage.Click
        Dim SrcFile, DstFolder, FileName As String
        Dim Index, Compression As String

        txtOutput.Text = ""
        If TxtBoxExportImage_Source.Text = "" Then
            MessageBox.Show("You must selected a source file ESD or WIM !")
        Else
            If TxtBoxExportImage_Destination.Text = "" Then
                MessageBox.Show("You must selected a folder destination !")
            Else
                If TxtBoxExportImage_Filename.Text = "" Then
                    MessageBox.Show("You must enter a destination filename !")
                Else
                    If CmbBoxExportImage_Index.Text = "" Then
                        MessageBox.Show("You must selected index on wim !")
                    Else
                        If CmbBoxExportImage_Compression.Text = "" Then
                            MessageBox.Show("You must selected a compression mode !")
                        Else
                            If (Path.GetExtension(TxtBoxExportImage_Filename.Text.ToUpper) <> ".WIM") Then
                                TxtBoxExportImage_Filename.Text = TxtBoxExportImage_Filename.Text & ".wim"
                            End If
                            SrcFile = TxtBoxExportImage_Source.Text
                            DstFolder = TxtBoxExportImage_Destination.Text
                            FileName = TxtBoxExportImage_Filename.Text
                            Index = CmbBoxExportImage_Index.Text
                            Compression = CmbBoxExportImage_Compression.Text
                            strDISMArguments = "/Export-Image /SourceImageFile:" + """" + SrcFile + """" + " /SourceIndex:" + Index + " /DestinationImageFile:" + """" + DstFolder + "\" + FileName + """" + " /Compress:" + Compression
                            If ChkBoxExportImage_Bootable.Checked = True Then
                                strDISMArguments = strDISMArguments + " /Bootable"
                            End If
                            If ChkBoxExportImage_WimBoot.Checked = True Then
                                strDISMArguments = strDISMArguments + " /WIMBoot"
                            End If
                            If ChkBoxExportImage_CheckIntegrity.Checked = True Then
                                strDISMArguments = strDISMArguments + " /CheckIntegrity"
                            End If

                            txtOutput.Text = "Command line that running is:" & vbCrLf & "Dism.exe " & strDISMArguments & vbCrLf
                            BackgroundWorkerDISMCommand.RunWorkerAsync(strDISMArguments)
                            frmProgress.ShowDialog()
                            txtOutput.Text = txtOutput.Text & strOutput & vbCrLf & "Exit code:" & strDISMExitCode
                        End If
                    End If
                End If
            End If
        End If
    End Sub
    '
    ' Sub BtnSetLanguage_Apply_Click
    ' Rev: 31/07/2022
    '
    Private Sub BtnLangAndInterServ_ApplyAllIntl_Click(sender As Object, e As EventArgs) Handles BtnLangAndInterServ_ApplyAllIntl.Click

        txtOutput.Text = ""
        If CmbBoxLangAndInterServ_UseImageMounted.Text = "" Then
            MessageBox.Show("No WIM is mounted.  You must mount a WIM before running this command (Offline mode only).")
        Else
            If CmbBoxLangAndInterServ_SetAllIntl.Text <> "" Then
                strDISMArguments = "/Image:" + """" + CmbBoxLangAndInterServ_UseImageMounted.Text + """" + " /Set-AllIntl:" + CmbBoxLangAndInterServ_SetAllIntl.Text

                txtOutput.Text = "Command line that running is:" & vbCrLf & "Dism.exe " & strDISMArguments & vbCrLf
                BackgroundWorkerDISMCommand.RunWorkerAsync(strDISMArguments)
                frmProgress.ShowDialog()
                txtOutput.Text = txtOutput.Text & strOutput & vbCrLf & "Exit code:" & strDISMExitCode
            Else
                MessageBox.Show("You must enter a value for /SetAllIntl !")
            End If
        End If
    End Sub
    '
    ' Sub BtnExportDriverOfflineFolderChoice_Click
    ' Rev: 31/07/2022
    '
    Private Sub BtnExportDriverOfflineFolderChoice_Click(sender As Object, e As EventArgs) Handles BtnExportDriver_SelectFolder.Click
        Dim MyDlgOpenFolder As New System.Windows.Forms.FolderBrowserDialog()
        Dim StrFolderName As String

        MyDlgOpenFolder.ShowNewFolderButton = False
        MyDlgOpenFolder.RootFolder = Environment.SpecialFolder.MyComputer
        If MyDlgOpenFolder.ShowDialog() = DialogResult.OK Then
            StrFolderName = MyDlgOpenFolder.SelectedPath
            TxtBoxExport_PathDriverFolder.Text = StrFolderName
        End If
    End Sub
    '
    ' Sub BtnExportDriverOffline_Click
    ' Rev: 31/07/2022
    '
    Private Sub BtnExportDriverOffline_Click(sender As Object, e As EventArgs) Handles BtnExportDriver_ExportDriver.Click

        txtOutput.Text = ""
        If (CmbBoxExportDriver_UseImageMounted.Text = "" And ChkBoxExportDriver_Online.Checked = False) Then
            MessageBox.Show("No image selected.  You must selected an image before running this command (Offline mode) or use /Online option.")
        Else
            If TxtBoxExport_PathDriverFolder.Text = "" Then
                MessageBox.Show("You must selected folder for export driver")
            Else
                If (ChkBoxExportDriver_Online.Checked = True) Then
                    strDISMArguments = " /Online /Export-Driver" + " /Destination:" + """" + TxtBoxExport_PathDriverFolder.Text + """"
                Else
                    strDISMArguments = "/Image:" + """" + CmbBoxExportDriver_UseImageMounted.Text + """" + " /Export-Driver" + " /Destination:" + """" + TxtBoxExport_PathDriverFolder.Text + """"
                End If

                txtOutput.Text = "Command line that running is:" & vbCrLf & "Dism.exe " & strDISMArguments & vbCrLf
                BackgroundWorkerDISMCommand.RunWorkerAsync(strDISMArguments)
                frmProgress.ShowDialog()
                txtOutput.Text = txtOutput.Text & strOutput & vbCrLf & "Exit code:" & strDISMExitCode
            End If
        End If
    End Sub
    '
    ' Sub BtnSplitImage_WIMChoice_Click
    ' Rev: 31/07/2022
    ' warning: you can't choose a compress Ffu file for split because it's not supported
    '
    Private Sub BtnSplitImage_WIMChoice_Click(sender As Object, e As EventArgs) Handles BtnSplitImage_WIMChoice.Click
        Dim MyDlgOpenFile = New System.Windows.Forms.OpenFileDialog() ' instance of dialog box

        'MyDlgOpenFile.InitialDirectory = Environment.SpecialFolder.MyComputer                    ' default root path
        MyDlgOpenFile.InitialDirectory = "C:\"
        MyDlgOpenFile.Title = "Choose WIM or Ffu file to Open"    ' title of dialog box
        MyDlgOpenFile.Filter = ("WIM Files(*.wim)|*.wim|Ffu Files(*.ffu)|*.ffu") ' filter extension

        If MyDlgOpenFile.ShowDialog = DialogResult.OK Then        ' user selected filename from dialog box ?
            TxtBoxSplitImage_WIMFilename.Text = MyDlgOpenFile.FileName
        End If
        If TxtBoxSplitImage_WIMFilename.Text = "" Then
            MessageBox.Show("You must selected a WIM or Ffu file", "Information WIM or Ffu", MessageBoxButtons.OK)
            Exit Sub
        End If

        If Path.GetExtension(TxtBoxSplitImage_WIMFilename.Text.ToUpper()) = ".WIM" Then
            TxtBoxSplitImage_SWMFilename.Text = Path.GetFileNameWithoutExtension(TxtBoxSplitImage_WIMFilename.Text) + ".swm"
        End If

        If Path.GetExtension(TxtBoxSplitImage_WIMFilename.Text.ToUpper()) = ".FFU" Then
            TxtBoxSplitImage_SWMFilename.Text = Path.GetFileNameWithoutExtension(TxtBoxSplitImage_WIMFilename.Text) + ".sfu"
        End If
    End Sub
    '
    ' Sub BtnSplitImage_TargetFolder_Click
    ' Rev: 31/07/2022
    '
    Private Sub BtnSplitImage_TargetFolder_Click(sender As Object, e As EventArgs) Handles BtnSplitImage_TargetFolder.Click
        Dim MyDlgOpenFolder As New System.Windows.Forms.FolderBrowserDialog()
        Dim StrFolderName As String

        MyDlgOpenFolder.ShowNewFolderButton = False
        MyDlgOpenFolder.RootFolder = Environment.SpecialFolder.MyComputer
        If MyDlgOpenFolder.ShowDialog() = DialogResult.OK Then
            StrFolderName = MyDlgOpenFolder.SelectedPath
            TxtBoxSplitImage_DestinationFolder.Text = StrFolderName
        End If
    End Sub
    '
    ' Sub BtnSplitImage_SplitImage_Click
    ' rev: 20062022
    ' warning: you can't choose a compress Ffu file for split because it's not supported
    '
    Private Sub BtnSplitImage_SplitImage_Click(sender As Object, e As EventArgs) Handles BtnSplitImage_SplitImage.Click

        txtOutput.Text = ""
        If (TxtBoxSplitImage_WIMFilename.Text = "" Or TxtBoxSplitImage_DestinationFolder.Text = "" Or TxtBoxSplitImage_Filesize.Text = "") Then
            MessageBox.Show("Wim or Ffu filename and destination folder and size of split file are required")
            Exit Sub
        End If

        If Path.GetExtension(TxtBoxSplitImage_WIMFilename.Text.ToUpper()) = ".WIM" Then
            strDISMArguments = "/Split-Image /ImageFile:" + """" + TxtBoxSplitImage_WIMFilename.Text + """" + " /SWMFile:" + """" + TxtBoxSplitImage_DestinationFolder.Text + "\" + TxtBoxSplitImage_SWMFilename.Text + """" + " /FileSize:" + TxtBoxSplitImage_Filesize.Text
        End If

        If Path.GetExtension(TxtBoxSplitImage_WIMFilename.Text.ToUpper()) = ".FFU" Then
            strDISMArguments = "/Split-Image /ImageFile:" + """" + TxtBoxSplitImage_WIMFilename.Text + """" + " /SFUFile:" + """" + TxtBoxSplitImage_DestinationFolder.Text + "\" + TxtBoxSplitImage_SWMFilename.Text + """" + " /FileSize:" + TxtBoxSplitImage_Filesize.Text
        End If

        If ChkBoxSplitImage_CheckIntegrity.Checked = True Then
            strDISMArguments = strDISMArguments + " /CheckIntegrity"
        End If

        txtOutput.Text = "Command line that running is:" & vbCrLf & "Dism.exe " & strDISMArguments & vbCrLf
        BackgroundWorkerDISMCommand.RunWorkerAsync(strDISMArguments)
        frmProgress.ShowDialog()
        txtOutput.Text = txtOutput.Text & strOutput & vbCrLf & "Exit code:" & strDISMExitCode
    End Sub
    '
    ' Sub LstBoxCaptureFfu_LogicalDrive_SelectedIndexChanged
    ' Rev: 31/07/2022
    '
    Private Sub LstBoxCaptureFfu_LogicalDrive_SelectedIndexChanged(sender As Object, e As EventArgs) Handles LstBoxCaptureFfu_LogicalDrive.SelectedIndexChanged
        Dim LogicalDiskID = LstBoxCaptureFfu_LogicalDrive.SelectedItem
        Dim DeviceID = String.Empty
        Dim Query As String
        Dim Partition, Drive

        Query = "ASSOCIATORS OF {Win32_LogicalDisk.DeviceID='" + LogicalDiskID + "'} WHERE AssocClass = Win32_LogicalDiskToPartition"
        Dim QueryResults As New ManagementObjectSearcher(Query)
        Dim Partitions = QueryResults.Get()

        For Each Partition In Partitions
            Query = "ASSOCIATORS OF {Win32_DiskPartition.DeviceID='" + Partition("DeviceID") + "'} WHERE AssocClass = Win32_DiskDriveToDiskPartition"
            QueryResults = New ManagementObjectSearcher(Query)
            Dim Drives = QueryResults.Get()

            For Each Drive In Drives
                DeviceID = Drive("DeviceID").ToString()
            Next
        Next
        TxtBoxCaptFfu_PhysicalDrive.Text = DeviceID
    End Sub
    '
    ' Sub BtnCaptureFfu_UpdateLogicalDrive_Click
    ' Rev: 31/07/2022
    '
    Private Sub BtnCaptureFfu_UpdateLogicalDrive_Click(sender As Object, e As EventArgs) Handles BtnCaptureFfu_UpdateLogicalDrive.Click
        Dim d As DriveInfo

        LstBoxCaptureFfu_LogicalDrive.Items.Clear()
        For Each d In DriveInfo.GetDrives()
            LstBoxCaptureFfu_LogicalDrive.Items.Add(d.Name.Substring(0, (d.Name.Length) - 1))
        Next
    End Sub
    '
    ' Sub BtnCaptureFfu_SetTargetFolder_Click
    ' Rev: 31/07/2022
    '
    Private Sub BtnCaptureFfu_SetTargetFolder_Click(sender As Object, e As EventArgs) Handles BtnCaptureFfu_SetTargetFolder.Click
        Dim MyDlgOpenFolder As New System.Windows.Forms.FolderBrowserDialog()
        Dim StrFolderName As String

        MyDlgOpenFolder.ShowNewFolderButton = False
        MyDlgOpenFolder.RootFolder = Environment.SpecialFolder.MyComputer
        If MyDlgOpenFolder.ShowDialog() = DialogResult.OK Then
            StrFolderName = MyDlgOpenFolder.SelectedPath
            TxtBoxCaptFfu_TargetFolder.Text = StrFolderName
        End If
    End Sub
    '
    ' Sub BtnCaptFfu_StartCapture_Click
    ' Rev: 29/08/2022
    ' warning name metadata and description metadata, platform ID are required
    ' microsoft say optionals but if not used, it create an error 87
    '
    Private Sub BtnCaptFfu_StartCapture_Click(sender As Object, e As EventArgs) Handles BtnCaptureFfu_StartCapture.Click
        Dim ExprBool As Boolean = False

        ExprBool = TxtBoxCaptFfu_PhysicalDrive.Text = "" Or TxtBoxCaptFfu_TargetFolder.Text = ""
        ExprBool = ExprBool Or TxtBoxCaptFfu_TargetFilename.Text = "" Or CmbBoxCaptureFfu_Compression.Text = ""
        ExprBool = ExprBool Or TxtBoxCaptFfu_Name.Text = "" Or TxtBoxCaptureFfu_Description.Text = ""

        If ExprBool = True Then
            MessageBox.Show("Physical drive, target folder, target filename, name (metadata), description (metadata) compression are required.")
            Exit Sub
        End If
        txtOutput.Text = ""
        If (Path.GetExtension(TxtBoxCaptFfu_TargetFilename.Text.ToUpper) = "") Then
            TxtBoxCaptFfu_TargetFilename.Text = TxtBoxCaptFfu_TargetFilename.Text + ".ffu"
        End If

        strDISMArguments = "/Capture-Ffu /ImageFile:" + """" + TxtBoxCaptFfu_TargetFolder.Text + "\" + TxtBoxCaptFfu_TargetFilename.Text + """" + " /CaptureDrive:" + """" + TxtBoxCaptFfu_PhysicalDrive.Text + """"

        If (TxtBoxCaptFfu_Name.Text <> "") Then
            strDISMArguments = strDISMArguments + " /Name:" + """" + TxtBoxCaptFfu_Name.Text + """"
        End If

        If (TxtBoxCaptureFfu_Description.Text <> "") Then
            strDISMArguments = strDISMArguments + " /Description:" + """" + TxtBoxCaptureFfu_Description.Text + """"
        End If

        If (TxtBoxCaptFfu_PlatformID.Text <> "") Then
            strDISMArguments = strDISMArguments + " /PlatformIds:" + """" + TxtBoxCaptFfu_PlatformID.Text + """"
        End If

        strDISMArguments = strDISMArguments + " /Compress:" + CmbBoxCaptureFfu_Compression.SelectedItem

        txtOutput.Text = "Command line that running is:" & vbCrLf & "Dism.exe " & strDISMArguments & vbCrLf
        BackgroundWorkerDISMCommand.RunWorkerAsync(strDISMArguments)
        frmProgress.ShowDialog()
        txtOutput.Text = txtOutput.Text & strOutput & vbCrLf & "Exit code:" & strDISMExitCode
    End Sub
    '
    ' Sub LstBoxApplyFfuImage_LogicalDrive_SelectedIndexChanged
    ' Rev: 31/07/2022
    '
    Private Sub LstBoxApplyFfuImage_LogicalDrive_SelectedIndexChanged(sender As Object, e As EventArgs) Handles LstBoxApplyFfuImage_LogicalDrive.SelectedIndexChanged
        Dim LogicalDiskID = LstBoxApplyFfuImage_LogicalDrive.SelectedItem
        Dim DeviceID = String.Empty
        Dim Query As String
        Dim Partition, Drive

        Query = "ASSOCIATORS OF {Win32_LogicalDisk.DeviceID='" + LogicalDiskID + "'} WHERE AssocClass = Win32_LogicalDiskToPartition"
        Dim QueryResults As New ManagementObjectSearcher(Query)
        Dim Partitions = QueryResults.Get()

        For Each Partition In Partitions
            Query = "ASSOCIATORS OF {Win32_DiskPartition.DeviceID='" + Partition("DeviceID") + "'} WHERE AssocClass = Win32_DiskDriveToDiskPartition"
            QueryResults = New ManagementObjectSearcher(Query)
            Dim Drives = QueryResults.Get()

            For Each Drive In Drives
                DeviceID = Drive("DeviceID").ToString()
            Next
        Next
        TxtBoxApplyFfuImage_PhysicalDrive.Text = DeviceID
    End Sub
    '
    ' Sub BtnApplyFfuImage_UpdateLogicalDrive_Click
    ' Rev: 31/07/2022
    '
    Private Sub BtnApplyFfuImage_UpdateLogicalDrive_Click(sender As Object, e As EventArgs) Handles BtnApplyFfuImage_UpdateLogicalDrive.Click
        Dim d As DriveInfo

        LstBoxApplyFfuImage_LogicalDrive.Items.Clear()
        For Each d In DriveInfo.GetDrives()
            LstBoxApplyFfuImage_LogicalDrive.Items.Add(d.Name.Substring(0, (d.Name.Length) - 1))
        Next
    End Sub
    '
    ' Sub BtnApplyFfuImage_SelectFfuFile_Click
    ' Rev: 31/07/2022
    '
    Private Sub BtnApplyFfuImage_SelectFfuFile_Click(sender As Object, e As EventArgs) Handles BtnApplyFfuImage_SelectFfuFile.Click
        Dim MyDlgOpenFile = New System.Windows.Forms.OpenFileDialog() ' instance of dialog box

        'MyDlgOpenFile.InitialDirectory = Environment.SpecialFolder.MyComputer    
        MyDlgOpenFile.InitialDirectory = "C:\"
        MyDlgOpenFile.Title = "Choose Ffu or SFU file to Open"    ' title of dialog box
        MyDlgOpenFile.Filter = ("Ffu Files(*.Ffu)|*.Ffu|Sfu Files(*.Sfu)|*.Sfu") ' filter extension

        If MyDlgOpenFile.ShowDialog = DialogResult.OK Then        ' user selected filename from dialog box ?
            TxtBoxApplyFfuImage_FfuSourceFilename.Text = MyDlgOpenFile.FileName
        End If

        If (Path.GetExtension(TxtBoxApplyFfuImage_FfuSourceFilename.Text.ToUpper) = ".SFU") Then
            TxtBoxApplyFfuImageFfu_MotifSFUFile.Text = TxtBoxApplyFfuImage_FfuSourceFilename.Text
            TxtBoxApplyFfuImageFfu_MotifSFUFile.Text = Replace(TxtBoxApplyFfuImageFfu_MotifSFUFile.Text, ".sfu", "*.sfu")
        End If

        If TxtBoxApplyFfuImage_FfuSourceFilename.Text = "" Then
            MessageBox.Show("You must selected a Ffu file", "Information Ffu", MessageBoxButtons.OK)
        End If
    End Sub
    '
    ' Sub BtnApplyFfuImage_ApplyFfuImage_Clic
    ' Rev: 31/07/2022
    ' warning: for Sfu files, you must use dism command /apply-image because /apply-Ffu is bugged (sfu file only)
    '
    Private Sub BtnApplyFfuImage_ApplyFfuImage_Click(sender As Object, e As EventArgs) Handles BtnApplyFfuImage_ApplyFfuImage.Click

        txtOutput.Text = ""
        If Path.GetExtension(TxtBoxApplyFfuImage_FfuSourceFilename.Text.ToUpper()) = ".FFU" Then
            strDISMArguments = "/Apply-Ffu /ImageFile:" + """" + TxtBoxApplyFfuImage_FfuSourceFilename.Text + """" + " /ApplyDrive:" + """" + TxtBoxApplyFfuImage_PhysicalDrive.Text + """"
        End If

        If Path.GetExtension(TxtBoxApplyFfuImage_FfuSourceFilename.Text.ToUpper()) = ".SFU" Then
            strDISMArguments = "/Apply-image /ImageFile:" + """" + TxtBoxApplyFfuImage_FfuSourceFilename.Text + """" + " /SFUFile:""" + TxtBoxApplyFfuImageFfu_MotifSFUFile.Text + """" + " /ApplyDrive:" + """" + TxtBoxApplyFfuImage_PhysicalDrive.Text + """"
        End If

        txtOutput.Text = "Command line that running is:" & vbCrLf & "Dism.exe " & strDISMArguments & vbCrLf
        BackgroundWorkerDISMCommand.RunWorkerAsync(strDISMArguments)
        frmProgress.ShowDialog()
        txtOutput.Text = txtOutput.Text & strOutput & vbCrLf & "Exit code:" & strDISMExitCode
    End Sub
    '
    ' Sub BtnSplitFfuImage_StartSplitImage_Click
    ' Rev: 31/07/2022
    '
    Private Sub BtnSplitFfuImage_StartSplitImage_Click(sender As Object, e As EventArgs) Handles BtnSplitFfuImage_StartSplitImage.Click
        Dim ExprBool As Boolean = False

        ExprBool = TxtBoxSplitFfu_FfuFilename.Text = "" Or TxtBoxSplitFfu_TargetFolder.Text = ""
        ExprBool = ExprBool Or TxtBoxSplitFfu_SFUFilename.Text = "" Or TxtBoxSplitFfu_SplitFileSize.Text = ""
        If ExprBool = True Then
            MessageBox.Show("Ffu Filename, Target Folder, SFU filemane, Split file size are required.")
            Exit Sub
        End If
        strDISMArguments = "/Split-Ffu /ImageFile:" + """" + TxtBoxSplitFfu_FfuFilename.Text + """" + " /SFUFile:" + """" + TxtBoxSplitFfu_TargetFolder.Text + "\" + TxtBoxSplitFfu_SFUFilename.Text + """" + " /FileSize:" + TxtBoxSplitFfu_SplitFileSize.Text
        If (ChkBoxSplitFfu_CheckIntegrity.Checked = True) Then
            strDISMArguments = strDISMArguments + " /CheckIntegrity"
        End If

        txtOutput.Text = "Command line that running is:" & vbCrLf & "Dism.exe " & strDISMArguments & vbCrLf
        BackgroundWorkerDISMCommand.RunWorkerAsync(strDISMArguments)
        frmProgress.ShowDialog()
        txtOutput.Text = txtOutput.Text & strOutput & vbCrLf & "Exit code:" & strDISMExitCode
    End Sub
    '
    ' Sub BtnSplitFfuImage_StartSplitImage_Click
    ' Rev: 31/07/2022
    '
    Private Sub cmbApplyIndex_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbApplyIndex.SelectedIndexChanged

        TxtBoxApplyWim_Name.Text = ListInfosWimApplyImage.ElementAt(cmbApplyIndex.SelectedIndex).Nom.ToString()
        TxtBoxApplyWim_Description.Text = ListInfosWimApplyImage.ElementAt(cmbApplyIndex.SelectedIndex).Description.ToString()
        TxtBoxApplyWim_Size.Text = ListInfosWimApplyImage.ElementAt(cmbApplyIndex.SelectedIndex).Taille.ToString()
    End Sub
    '
    ' Sub Btn_ClearConsole_Click
    ' Rev: 31/07/2022
    '
    Private Sub Btn_ClearConsole_Click(sender As Object, e As EventArgs) Handles BtnMountControl_ClearConsole.Click

        txtOutput.Text = ""
    End Sub
    '
    ' Sub ExtractDismVersion
    ' Extract DISM version of windows
    ' Rev: 25/08/2022
    '
    Private Sub ExtractDismVersion_Windows()
        Dim IdxStart, IdxEnd As Integer

        strDISMArguments = ""
        BackgroundWorkerDISMCommand.RunWorkerAsync(strDISMArguments)
        frmProgress.ShowDialog()
        txtOutput.Text = strOutput   ' Affiche la version de la commande
        IdxStart = txtOutput.Text.IndexOf(" : ")
        IdxEnd = txtOutput.Text.IndexOf("DISM")
        TxtBox_DismVersionWindows.Text = txtOutput.Text.Substring(IdxStart + 2, IdxEnd - (IdxStart + 2))
        txtOutput.Text = ""          ' clear console to mask dism help command
    End Sub
    '
    ' Sub ExtractDismVersion
    ' Extract DISM version of ADK
    ' Rev: 25/08/2022
    '
    Private Sub ExtractDismVersion_ADK()
        Dim IdxStart, IdxEnd As Integer

        strDISMArguments = "&& Dism.exe"
        BackgroundWorkerDismCommand2.RunWorkerAsync(strDISMArguments)
        frmProgress.ShowDialog()
        txtOutput.Text = strOutput   ' Affiche la version de la commande
        IdxStart = txtOutput.Text.IndexOf(" : ")
        IdxEnd = txtOutput.Text.IndexOf("DISM")
        TxtBox_DismVersionADK.Text = txtOutput.Text.Substring(IdxStart + 2, IdxEnd - (IdxStart + 2))
        txtOutput.Text = ""          ' clear console to mask dism help command
    End Sub
    '
    ' Sub ExtractADKDismVersion
    ' Rev: 24/08/2022
    '
    Private Sub ExtractADKDismVersion()
        Dim IdxStart, IdxEnd As Integer

        strDISMArguments = ""

        frmProgress.ShowDialog()
        txtOutput.Text = strOutput   ' Affiche la version de la commande
        IdxStart = txtOutput.Text.IndexOf(" : ")
        IdxEnd = txtOutput.Text.IndexOf("DISM")
        TxtBox_DismVersionWindows.Text = txtOutput.Text.Substring(IdxStart + 2, IdxEnd - (IdxStart + 2))
        txtOutput.Text = ""          ' clear console to mask dism help command
    End Sub
    '
    ' Sub BtnSplitFfu_SelectFfuFile_Click
    ' Rev: 31/07/2022
    '
    Private Sub BtnSplitFfu_SelectFfuFile_Click(sender As Object, e As EventArgs) Handles BtnSplitFfu_SelectFfuFile.Click
        Dim MyDlgOpenFile = New System.Windows.Forms.OpenFileDialog() ' instance of dialog box

        ' MyDlgOpenFile.InitialDirectory = Environment.SpecialFolder.MyComputer                    ' default root path
        MyDlgOpenFile.InitialDirectory = "C:\"
        MyDlgOpenFile.Title = "Choose Ffu file to Open"    ' title of dialog box
        MyDlgOpenFile.Filter = ("Ffu Files(*.Ffu)|*.Ffu")  ' filter extension

        If MyDlgOpenFile.ShowDialog = DialogResult.OK Then ' user selected filename from dialog box ?
            TxtBoxSplitFfu_FfuFilename.Text = MyDlgOpenFile.FileName
        End If
        If TxtBoxSplitFfu_FfuFilename.Text = "" Then       ' check Ffu filename
            MessageBox.Show("You must selected a Ffu file", "Information Ffu", MessageBoxButtons.OK)
        End If
    End Sub
    '
    ' Sub BtnSplitFfu_SelectTargetFolder_Click
    ' Rev: 31/07/2022
    '
    Private Sub BtnSplitFfu_SelectTargetFolder_Click(sender As Object, e As EventArgs) Handles BtnSplitFfu_SelectTargetFolder.Click
        Dim MyDlgOpenFolder As New System.Windows.Forms.FolderBrowserDialog()
        Dim StrFolderName As String

        MyDlgOpenFolder.ShowNewFolderButton = False
        MyDlgOpenFolder.RootFolder = Environment.SpecialFolder.MyComputer
        If MyDlgOpenFolder.ShowDialog() = DialogResult.OK Then
            StrFolderName = MyDlgOpenFolder.SelectedPath
            TxtBoxSplitFfu_TargetFolder.Text = StrFolderName
        End If
    End Sub
    '
    ' Sub BtnMountControl_DisplayImageInfo_Click
    ' Rev: 31/07/2022
    '
    Private Sub BtnMountControl_DisplayImageInfo_Click(sender As Object, e As EventArgs) Handles BtnMountControl_DisplayImageInfo.Click

        txtOutput.Text = ""
        If TxtMountControl_ImageFile.Text = "" Then
            MsgBox("You must select a WIM file first")
        Else
            strWIM = TxtMountControl_ImageFile.Text
            strDISMArguments = "/Get-ImageInfo /ImageFile:""" & strWIM & """"
            txtOutput.Text = "Command line that running is:" & vbCrLf & "Dism.exe " & strDISMArguments & vbCrLf
            BackgroundWorkerDISMCommand.RunWorkerAsync(strDISMArguments)
            frmProgress.ShowDialog()
            txtOutput.Text = txtOutput.Text & strOutput & vbCrLf & "Exit code:" & strDISMExitCode
        End If
    End Sub
    '
    ' Sub BtnGetPackageInfo_Click
    ' Rev: 31/07/2022
    '
    Private Sub BtnGetPackageInfo_Click(sender As Object, e As EventArgs) Handles BtnPackageManage_GetPackageInfo.Click

        txtOutput.Text = ""
        If (CmbBoxPackageManagement_UseImageMounted.Text = "" And ChkBoxPackageManagement_Online.Checked = False) Then
            MessageBox.Show("No image selected.  You must selected an image before running this command (Offline mode) or use /Online option.")
        Else
            If (txtPackageName.Text = "" And txtPackagePath.Text = "") Then
                MessageBox.Show("Package Name or Package Path are require to continue.")
                Exit Sub
            End If
            If (ChkBoxPackageManagement_Online.Checked = True) Then
                strDISMArguments = "/Online" & " /Get-PackageInfo"
                If txtPackageName.Text <> "" Then strDISMArguments = strDISMArguments & " /PackageName:""" & txtPackageName.Text & """"
                If txtPackagePath.Text <> "" Then strDISMArguments = strDISMArguments & " /PackagePath:""" & txtPackagePath.Text & """"
            Else
                strDISMArguments = "/Image:""" & CmbBoxPackageManagement_UseImageMounted.Text & """ /Get-PackageInfo"
                If txtPackageName.Text <> "" Then strDISMArguments = strDISMArguments & " /PackageName:""" & txtPackageName.Text & """"
                If txtPackagePath.Text <> "" Then strDISMArguments = strDISMArguments & " /PackagePath:""" & txtPackagePath.Text & """"
            End If
            txtOutput.Text = "Command line that running is:" & vbCrLf & "Dism.exe " & strDISMArguments & vbCrLf
            BackgroundWorkerDISMCommand.RunWorkerAsync(strDISMArguments)
            frmProgress.ShowDialog()
            txtOutput.Text = txtOutput.Text & strOutput & vbCrLf & "Exit code:" & strDISMExitCode
        End If
        txtOutput.Text = "Command line that running is:" & vbCrLf & "Dism.exe " & strDISMArguments & vbCrLf
        BackgroundWorkerDISMCommand.RunWorkerAsync(strDISMArguments)
        frmProgress.ShowDialog()
        txtOutput.Text = txtOutput.Text & strOutput & vbCrLf & "Exit code:" & strDISMExitCode
    End Sub
    '
    ' Sub BtnDefaultAppAssocServ_GetDefaultAppAssoc_Click
    ' Rev: 31/07/2022
    '
    Private Sub BtnDefaultAppAssocServ_GetDefaultAppAssoc_Click(sender As Object, e As EventArgs) Handles BtnDefaultAppAssocServ_GetDefaultAppAssoc.Click

        txtOutput.Text = ""
        If (CmbBoxDefaultAppAssocServicing_UseImageMounted.Text = "" And ChkBoxDefaultAppAssocServ_Online.Checked = False) Then
            MessageBox.Show("No WIM is mounted.  You must mount a WIM before running this command (Offline mode) or use /Online option.")
        Else
            If (ChkBoxDefaultAppAssocServ_Online.Checked = True) Then
                strDISMArguments = "/Online" & " /Get-DefaultAppAssociations"
            Else
                strDISMArguments = "/Image:""" & CmbBoxDefaultAppAssocServicing_UseImageMounted.Text & """ /Get-DefaultAppAssociations"
            End If
            txtOutput.Text = "Command line that running is:" & vbCrLf & "Dism.exe " & strDISMArguments & vbCrLf
            BackgroundWorkerDISMCommand.RunWorkerAsync(strDISMArguments)
            frmProgress.ShowDialog()
            txtOutput.Text = txtOutput.Text & strOutput & vbCrLf & "Exit code:" & strDISMExitCode
        End If
    End Sub
    '
    ' Sub BtnDefaultAppAssocServ_ChooseFolder_Click
    ' Rev: 31/07/2022
    '
    Private Sub BtnDefaultAppAssocServ_ChooseFolder_Click(sender As Object, e As EventArgs) Handles BtnDefaultAppAssocServ_ChooseFile.Click
        Dim DidWork As Integer = dlgOpenXML.ShowDialog

        dlgOpenXML.InitialDirectory = Environment.SpecialFolder.MyComputer
        dlgOpenXML.Title = "Choose XML file to Open"
        dlgOpenXML.Filter = ("XML Files(*.xml)|*.xml|All Files (*.*)|*.*")

        If DidWork = DialogResult.Cancel Then
            'Do Nothing
        Else
            ' Dim strXMLFileName As String = dlgOpenXML.FileName
            strXMLFileName = dlgOpenXML.FileName
            TxtBoxDefaultAppAssocServ_ImportFilenameXML.Text = strXMLFileName
        End If
    End Sub
    '
    ' Sub BtnDefaultAppAssocServ_ChooseFolder_Click
    ' Rev: 31/07/2022
    '
    Private Sub BtnDefaultAppAssocServ_ChooseFolder_Click_1(sender As Object, e As EventArgs) Handles BtnDefaultAppAssocServ_ChooseFolder.Click

        dlgOpenFolder.ShowNewFolderButton = False
        dlgOpenFolder.RootFolder = Environment.SpecialFolder.MyComputer
        dlgOpenFolder.ShowDialog()
        Dim strFolderName As String = dlgOpenFolder.SelectedPath

        TxtBoxDefaultAppAssocServ_ExportFolder.Text = strFolderName
    End Sub
    '
    ' Sub BtnDefaultAppAssocServ_Export_Click
    ' Rev: 31/07/2022
    '
    Private Sub BtnDefaultAppAssocServ_Export_Click(sender As Object, e As EventArgs) Handles BtnDefaultAppAssocServ_Export.Click

        txtOutput.Text = ""
        If (TxtBoxDefaultAppAssocServ_ExportFolder.Text = "" Or TxtBoxDefaultAppAssocServ_ExportFilenameXML.Text = "") Then
            MessageBox.Show("Items export folder and export filename must be enter")
            Exit Sub
        End If

        ' add extension filename automatically if forgotten
        If (Path.GetExtension(TxtBoxDefaultAppAssocServ_ExportFilenameXML.Text.ToUpper()) <> ".XML") Then
            TxtBoxDefaultAppAssocServ_ExportFilenameXML.Text = TxtBoxDefaultAppAssocServ_ExportFilenameXML.Text + ".xml"
        End If

        If (CmbBoxDefaultAppAssocServicing_UseImageMounted.Text = "" And ChkBoxDefaultAppAssocServ_Online.Checked = False) Then
            MessageBox.Show("No WIM is mounted.  You must mount a WIM before running this command (Offline mode) or use /Online option.")
        Else
            If (ChkBoxDefaultAppAssocServ_Online.Checked = True) Then
                strDISMArguments = "/Online" & " /Export-DefaultAppAssociations:""" & TxtBoxDefaultAppAssocServ_ExportFolder.Text & "\" & TxtBoxDefaultAppAssocServ_ExportFilenameXML.Text & """"
            Else
                strDISMArguments = "/Image:""" & CmbBoxDefaultAppAssocServicing_UseImageMounted.Text & """ /Export-DefaultAppAssociations:""" & TxtBoxDefaultAppAssocServ_ExportFolder.Text & "\" & TxtBoxDefaultAppAssocServ_ExportFilenameXML.Text & """"
            End If

            txtOutput.Text = "Command line that running is:" & vbCrLf & "Dism.exe " & strDISMArguments & vbCrLf
            BackgroundWorkerDISMCommand.RunWorkerAsync(strDISMArguments)
            frmProgress.ShowDialog()
            txtOutput.Text = txtOutput.Text & strOutput & vbCrLf & "Exit code:" & strDISMExitCode
        End If
    End Sub
    '
    ' BtnDefaultAppAssocServ_Import_Click
    ' Rev: 31/07/2022
    '
    Private Sub BtnDefaultAppAssocServ_Import_Click(sender As Object, e As EventArgs) Handles BtnDefaultAppAssocServ_Import.Click

        txtOutput.Text = ""
        If (TxtBoxDefaultAppAssocServ_ImportFilenameXML.Text = "") Then
            MessageBox.Show("Item Import Filename filename must be enter")
            Exit Sub
        End If

        ' add extension filename automatically if forgotten
        If (Path.GetExtension(TxtBoxDefaultAppAssocServ_ExportFilenameXML.Text.ToUpper()) <> ".XML") Then
            TxtBoxDefaultAppAssocServ_ExportFilenameXML.Text = TxtBoxDefaultAppAssocServ_ExportFilenameXML.Text + ".xml"
        End If

        If (CmbBoxDefaultAppAssocServicing_UseImageMounted.Text = "" And ChkBoxDefaultAppAssocServ_Online.Checked = False) Then
            MessageBox.Show("No WIM is mounted.  You must mount a WIM before running this command (Offline mode) or use /Online option.")
        Else
            If (ChkBoxDefaultAppAssocServ_Online.Checked = True) Then
                strDISMArguments = "/Online /Import-DefaultAppAssociations:" & """" & TxtBoxDefaultAppAssocServ_ImportFilenameXML.Text & """"
            Else
                strDISMArguments = "/Image:""" & CmbBoxDefaultAppAssocServicing_UseImageMounted.Text & """ /Import-DefaultAppAssociations:" & """" & TxtBoxDefaultAppAssocServ_ImportFilenameXML.Text & """"
            End If

            txtOutput.Text = "Command line that running is:" & vbCrLf & "Dism.exe " & strDISMArguments & vbCrLf
            BackgroundWorkerDISMCommand.RunWorkerAsync(strDISMArguments)
            frmProgress.ShowDialog()
            txtOutput.Text = txtOutput.Text & strOutput & vbCrLf & "Exit code:" & strDISMExitCode
        End If
    End Sub
    '
    ' BtnSetLanguage_DisplayInfo_Click
    ' Rev: 31/07/2022
    '
    Private Sub BtnSetLanguage_DisplayInfo_Click(sender As Object, e As EventArgs) Handles BtnLangAndInterServicing_DisplayInfo.Click

        txtOutput.Text = ""
        If (CmbBoxLangAndInterServ_UseImageMounted.Text = "" And ChkBoxLangAndInterServ_Online.Checked = False) Then
            MessageBox.Show("No WIM is mounted.  You must mount a WIM before running this command (Offline mode) or use /Online option.")
        Else
            If ChkBoxLangAndInterServ_Online.Checked Then
                strDISMArguments = "/Online /Get-Intl"
            Else
                strDISMArguments = "/Image:" + """" + CmbBoxLangAndInterServ_UseImageMounted.Text + """" + " /Get-Intl"
            End If

            txtOutput.Text = "Command line that running is:" & vbCrLf & "Dism.exe " & strDISMArguments & vbCrLf
            BackgroundWorkerDISMCommand.RunWorkerAsync(strDISMArguments)
            frmProgress.ShowDialog()
            txtOutput.Text = txtOutput.Text & strOutput & vbCrLf & "Exit code:" & strDISMExitCode
        End If
    End Sub
    '
    ' BtnLangAndInterServ_ApplyUILang_Click
    ' Rev: 31/07/2022
    '
    Private Sub BtnLangAndInterServ_ApplyUILang_Click(sender As Object, e As EventArgs) Handles BtnLangAndInterServ_ApplyUILang.Click

        txtOutput.Text = ""
        If CmbBoxLangAndInterServ_UseImageMounted.Text = "" Then
            MessageBox.Show("No WIM is mounted.  You must mount a WIM before running this command (Offline mode only).")
        Else
            If CmbBoxLangAndInterServ_SetUILang.Text <> "" Then
                strDISMArguments = "/Image:" + """" + CmbBoxLangAndInterServ_UseImageMounted.Text + """" + " /Set-UILang:" + CmbBoxLangAndInterServ_SetUILang.Text

                txtOutput.Text = "Command line that running is:" & vbCrLf & "Dism.exe " & strDISMArguments & vbCrLf
                BackgroundWorkerDISMCommand.RunWorkerAsync(strDISMArguments)
                frmProgress.ShowDialog()
                txtOutput.Text = txtOutput.Text & strOutput & vbCrLf & "Exit code:" & strDISMExitCode
            Else
                MessageBox.Show("You must enter a value for /Set-UILang option !")
            End If
        End If
    End Sub
    '
    ' BtnLangAndInterServ_ApplyUILangFallback_Click
    ' Rev: 31/07/2022
    '
    Private Sub BtnLangAndInterServ_ApplyUILangFallback_Click(sender As Object, e As EventArgs) Handles BtnLangAndInterServ_ApplyUILangFallback.Click

        txtOutput.Text = ""
        If CmbBoxLangAndInterServ_UseImageMounted.Text = "" Then
            MessageBox.Show("No WIM is mounted.  You must mount a WIM before running this command (Offline mode only).")
        Else
            If CmbBoxLangAndInterServ_SetUILangFallback.Text <> "" Then
                strDISMArguments = "/Image:" + """" + CmbBoxLangAndInterServ_UseImageMounted.Text + """" + " /Set-UILangFallback:" + CmbBoxLangAndInterServ_SetUILangFallback.Text

                txtOutput.Text = "Command line that running is:" & vbCrLf & "Dism.exe " & strDISMArguments & vbCrLf
                BackgroundWorkerDISMCommand.RunWorkerAsync(strDISMArguments)
                frmProgress.ShowDialog()
                txtOutput.Text = txtOutput.Text & strOutput & vbCrLf & "Exit code:" & strDISMExitCode
            Else
                MessageBox.Show("You must enter a value for /Set-UILangFallback option !")
            End If
        End If
    End Sub
    '
    ' BtnLangAndInterServ_ApplySysUILang_Click
    ' Rev: 31/07/2022
    '
    Private Sub BtnLangAndInterServ_ApplySysUILang_Click(sender As Object, e As EventArgs) Handles BtnLangAndInterServ_ApplySysUILang.Click

        txtOutput.Text = ""
        If CmbBoxLangAndInterServ_UseImageMounted.Text = "" Then
            MessageBox.Show("No WIM is mounted.  You must mount a WIM before running this command (Offline mode only).")
        Else
            If CmbBoxLangAndInterServ_SetSysUILang.Text <> "" Then
                strDISMArguments = "/Image:" + """" + CmbBoxLangAndInterServ_UseImageMounted.Text + """" + " /Set-SysUILang:" + CmbBoxLangAndInterServ_SetSysUILang.Text

                txtOutput.Text = "Command line that running is:" & vbCrLf & "Dism.exe " & strDISMArguments & vbCrLf
                BackgroundWorkerDISMCommand.RunWorkerAsync(strDISMArguments)
                frmProgress.ShowDialog()
                txtOutput.Text = txtOutput.Text & strOutput & vbCrLf & "Exit code:" & strDISMExitCode
            Else
                MessageBox.Show("You must enter a value for /Set-SysUILang option !")
            End If
        End If
    End Sub
    '
    ' BtnLangAndInterServ_ApplySysLocale_Click
    ' Rev: 31/07/2022
    '
    Private Sub BtnLangAndInterServ_ApplySysLocale_Click(sender As Object, e As EventArgs) Handles BtnLangAndInterServ_ApplySysLocale.Click

        txtOutput.Text = ""
        If CmbBoxLangAndInterServ_UseImageMounted.Text = "" Then
            MessageBox.Show("No WIM is mounted.  You must mount a WIM before running this command (Offline mode only).")
        Else
            If CmbBoxLangAndInterServ_SetUILang_SysLocale.Text <> "" Then
                strDISMArguments = "/Image:" + """" + CmbBoxLangAndInterServ_UseImageMounted.Text + """" + " /Set-SysLocale:" + CmbBoxLangAndInterServ_SetUILang_SysLocale.Text

                txtOutput.Text = "Command line that running is:" & vbCrLf & "Dism.exe " & strDISMArguments & vbCrLf
                BackgroundWorkerDISMCommand.RunWorkerAsync(strDISMArguments)
                frmProgress.ShowDialog()
                txtOutput.Text = txtOutput.Text & strOutput & vbCrLf & "Exit code:" & strDISMExitCode
            Else
                MessageBox.Show("You must enter a value for /Set-SysLocale option !")
            End If
        End If
    End Sub
    '
    ' BtnLangAndInterServ_ApplyUserLocale_Click
    ' Rev: 31/07/2022
    '
    Private Sub BtnLangAndInterServ_ApplyUserLocale_Click(sender As Object, e As EventArgs) Handles BtnLangAndInterServ_ApplyUserLocale.Click

        txtOutput.Text = ""
        If CmbBoxLangAndInterServ_UseImageMounted.Text = "" Then
            MessageBox.Show("No WIM is mounted.  You must mount a WIM before running this command (Offline mode only).")
        Else
            If CmbBoxLangAndInterServ_SetUserLocale.Text <> "" Then
                strDISMArguments = "/Image:" + """" + CmbBoxLangAndInterServ_UseImageMounted.Text + """" + " /Set-UserLocale:" + CmbBoxLangAndInterServ_SetUserLocale.Text

                txtOutput.Text = "Command line that running is:" & vbCrLf & "Dism.exe " & strDISMArguments & vbCrLf
                BackgroundWorkerDISMCommand.RunWorkerAsync(strDISMArguments)
                frmProgress.ShowDialog()
                txtOutput.Text = txtOutput.Text & strOutput & vbCrLf & "Exit code:" & strDISMExitCode
            Else
                MessageBox.Show("You must enter a value for /Set-UserLocale option !")
            End If
        End If
    End Sub
    '
    ' BtnLangAndInterServ_ApplySKUIntlDefaults_Click
    ' Rev: 31/07/2022
    '
    Private Sub BtnLangAndInterServ_ApplySKUIntlDefaults_Click(sender As Object, e As EventArgs) Handles BtnLangAndInterServ_ApplySKUIntlDefaults.Click

        txtOutput.Text = ""
        If CmbBoxLangAndInterServ_UseImageMounted.Text = "" Then
            MessageBox.Show("No WIM is mounted.  You must mount a WIM before running this command (Offline mode only).")
        Else
            If CmbBoxLangAndInterServ_SetSKUIntlDefaults.Text <> "" Then
                strDISMArguments = "/Image:" + """" + CmbBoxLangAndInterServ_UseImageMounted.Text + """" + " /Set-SKUIntlDefaults:" + CmbBoxLangAndInterServ_SetSKUIntlDefaults.Text

                txtOutput.Text = "Command line that running is:" & vbCrLf & "Dism.exe " & strDISMArguments & vbCrLf
                BackgroundWorkerDISMCommand.RunWorkerAsync(strDISMArguments)
                frmProgress.ShowDialog()
                txtOutput.Text = txtOutput.Text & strOutput & vbCrLf & "Exit code:" & strDISMExitCode
            Else
                MessageBox.Show("You must enter a value for /Set-SKUIntlDefaults option !")
            End If
        End If
    End Sub
    '
    ' BtnLangAndInterServ_LayeredDriver_Click
    ' Rev: 31/07/2022
    '
    Private Sub BtnLangAndInterServ_LayeredDriver_Click(sender As Object, e As EventArgs) Handles BtnLangAndInterServ_LayeredDriver.Click

        txtOutput.Text = ""
        If CmbBoxLangAndInterServ_UseImageMounted.Text = "" Then
            MessageBox.Show("No WIM is mounted.  You must mount a WIM before running this command (Offline mode only).")
        Else
            If CmbBoxLangAndInterServ_SetLayeredDriver.Text <> "" Then
                strDISMArguments = "/Image:" + """" + CmbBoxLangAndInterServ_UseImageMounted.Text + """" + " /Set-LayeredDriver:" + CmbBoxLangAndInterServ_SetLayeredDriver.Text

                txtOutput.Text = "Command line that running is:" & vbCrLf & "Dism.exe " & strDISMArguments & vbCrLf
                BackgroundWorkerDISMCommand.RunWorkerAsync(strDISMArguments)
                frmProgress.ShowDialog()
                txtOutput.Text = txtOutput.Text & strOutput & vbCrLf & "Exit code:" & strDISMExitCode
            Else
                MessageBox.Show("You must enter a value for /Set-LayeredDriver option !")
            End If
        End If
    End Sub
    '
    ' BtnLangAndInterServ_ApplyGenLangINI_Click
    ' Rev: 31/07/2022 
    '
    Private Sub BtnLangAndInterServ_ApplyGenLangINI_Click(sender As Object, e As EventArgs) Handles BtnLangAndInterServ_ApplyGenLangINI.Click

        ' to do...

    End Sub
    '
    ' BtnLangAndInterServ_ApplyDistribution_Click
    ' Rev: 31/07/2022
    '
    Private Sub BtnLangAndInterServ_ApplyDistribution_Click(sender As Object, e As EventArgs) Handles BtnLangAndInterServ_ApplyDistribution.Click

        ' to do...

    End Sub
    '
    ' BtnCapPackServ_GetCap_Click
    ' Rev: 31/07/2022
    '
    Private Sub BtnCapPackServ_GetCap_Click(sender As Object, e As EventArgs) Handles BtnCapPackServ_GetCap.Click

        txtOutput.Text = ""
        If (CmbBoxCapPackServicing_UseImageMounted.Text = "" And ChkBoxCapPackServ_Online.Checked = False) Then
            MessageBox.Show("No WIM is mounted.  You must mount a WIM before running this command (Offline mode) or use /Online option.")
        Else
            If ChkBoxCapPackServ_Online.Checked Then
                strDISMArguments = "/Online /Get-Capabilities"
            Else
                strDISMArguments = "/Image:" + """" + CmbBoxCapPackServicing_UseImageMounted.Text + """" + " /Get-Capabilities"
            End If

            txtOutput.Text = "Command line that running is:" & vbCrLf & "Dism.exe " & strDISMArguments & vbCrLf
            BackgroundWorkerDISMCommand.RunWorkerAsync(strDISMArguments)
            frmProgress.ShowDialog()
            txtOutput.Text = txtOutput.Text & strOutput & vbCrLf & "Exit code:" & strDISMExitCode
        End If
    End Sub
    '
    ' BtnCapPackServ_GetCapInfo_Click
    ' Rev: 31/07/2022
    '
    Private Sub BtnCapPackServ_GetCapInfo_Click(sender As Object, e As EventArgs) Handles BtnCapPackServ_GetCapInfo.Click

        txtOutput.Text = ""
        If (CmbBoxCapPackServicing_UseImageMounted.Text = "" And ChkBoxCapPackServ_Online.Checked = False) Then
            MessageBox.Show("No WIM is mounted.  You must mount a WIM before running this command (Offline mode) or use /Online option.")
        Else
            If ChkBoxCapPackServ_Online.Checked Then
                strDISMArguments = "/Online /Get-CapabilityInfo /CapabilityName:" + """" + TxtBoxCapPackServ_CapabilityName.Text + """"
            Else
                strDISMArguments = "/Image:" + """" + CmbBoxCapPackServicing_UseImageMounted.Text + """" + " /Get-CapabilityInfo /CapabilityName:" + """" + TxtBoxCapPackServ_CapabilityName.Text + """"
            End If

            txtOutput.Text = "Command line that running is:" & vbCrLf & "Dism.exe " & strDISMArguments & vbCrLf
            BackgroundWorkerDISMCommand.RunWorkerAsync(strDISMArguments)
            frmProgress.ShowDialog()
            txtOutput.Text = txtOutput.Text & strOutput & vbCrLf & "Exit code:" & strDISMExitCode
        End If
    End Sub
    '
    ' BtnCapPackServ_RemoveCap_Click
    ' Rev: 31/07/2022
    '
    Private Sub BtnCapPackServ_RemoveCap_Click(sender As Object, e As EventArgs) Handles BtnCapPackServ_RemoveCap.Click

        txtOutput.Text = ""
        If (CmbBoxCapPackServicing_UseImageMounted.Text = "" And ChkBoxCapPackServ_Online.Checked = False) Then
            MessageBox.Show("No WIM is mounted.  You must mount a WIM before running this command (Offline mode) or use /Online option.")
        Else
            If ChkBoxCapPackServ_Online.Checked Then
                strDISMArguments = "/Online /Remove-Capability /CapabilityName:" + """" + TxtBoxCapPackServ_CapabilityName.Text + """"
            Else
                strDISMArguments = "/Image:" + """" + CmbBoxCapPackServicing_UseImageMounted.Text + """" + " /Remove-Capability /CapabilityName:" + """" + TxtBoxCapPackServ_CapabilityName.Text + """"
            End If

            txtOutput.Text = "Command line that running is:" & vbCrLf & "Dism.exe " & strDISMArguments & vbCrLf
            BackgroundWorkerDISMCommand.RunWorkerAsync(strDISMArguments)
            frmProgress.ShowDialog()
            txtOutput.Text = txtOutput.Text & strOutput & vbCrLf & "Exit code:" & strDISMExitCode
        End If
    End Sub
    '
    ' BtnCapPackServ_AddCapability_Click
    ' Rev: 31/07/2022
    '
    Private Sub BtnCapPackServ_AddCapability_Click(sender As Object, e As EventArgs) Handles BtnCapPackServ_AddCapability.Click

        txtOutput.Text = ""
        If (CmbBoxCapPackServicing_UseImageMounted.Text = "" And ChkBoxCapPackServ_Online.Checked = False) Then
            MessageBox.Show("No WIM is mounted.  You must mount a WIM before running this command (Offline mode) or use /Online option.")
        Else
            If ChkBoxCapPackServ_Online.Checked Then
                strDISMArguments = "/Online /Add-Capability /CapabilityName:" + """" + TxtBoxCapPackServ_CapabilityName.Text + """"
            Else
                strDISMArguments = "/Image:" + """" + CmbBoxCapPackServicing_UseImageMounted.Text + """" + " /Add-Capability /CapabilityName:" + """" + TxtBoxCapPackServ_CapabilityName.Text + """"
            End If

            txtOutput.Text = "Command line that running is:" & vbCrLf & "Dism.exe " & strDISMArguments & vbCrLf
            BackgroundWorkerDISMCommand.RunWorkerAsync(strDISMArguments)
            frmProgress.ShowDialog()
            txtOutput.Text = txtOutput.Text & strOutput & vbCrLf & "Exit code:" & strDISMExitCode
        End If

    End Sub
    '
    ' BtnCapPackServ_ExportSource_Click
    ' Rev: 31/07/2022
    '
    Private Sub BtnCapPackServ_ExportSource_Click(sender As Object, e As EventArgs) Handles BtnCapPackServ_ExportSource.Click

        txtOutput.Text = ""
        If (CmbBoxCapPackServicing_UseImageMounted.Text = "" And ChkBoxCapPackServ_Online.Checked = False) Then
            MessageBox.Show("No WIM is mounted.  You must mount a WIM before running this command (Offline mode) or use /Online option.")
        Else
            If ChkBoxCapPackServ_Online.Checked Then
                strDISMArguments = "/Online /Export-Source /CapabilityName:" + """" + TxtBoxCapPackServ_CapabilityName.Text + """" + " /Source: " + """" + TxtBoxCapPackServ_Source.Text + """" + " /Target: " + """" + TxtBoxCapPackServ_Target.Text + """"
            Else
                strDISMArguments = "/Image:" + """" + CmbBoxCapPackServicing_UseImageMounted.Text + """" + " /Export-Source /CapabilityName:" + """" + TxtBoxCapPackServ_CapabilityName.Text + """" + " /Source: " + """" + TxtBoxCapPackServ_Source.Text + """" + " /Target: " + """" + TxtBoxCapPackServ_Target.Text + """"
            End If
            If ChkBoxCapPackServ_IncludeImageCapabilities.Checked Then
                strDISMArguments = strDISMArguments + " /IncludeImageCapabilities"
            End If
            txtOutput.Text = "Command line that running is:" & vbCrLf & "Dism.exe " & strDISMArguments & vbCrLf
            BackgroundWorkerDISMCommand.RunWorkerAsync(strDISMArguments)
            frmProgress.ShowDialog()
            txtOutput.Text = txtOutput.Text & strOutput & vbCrLf & "Exit code:" & strDISMExitCode
        End If
    End Sub
    '
    ' BtnCleanupImage_RevertPendingActions_Click
    ' Rev: 31/07/2022
    '
    Private Sub BtnCleanupImage_RevertPendingActions_Click(sender As Object, e As EventArgs) Handles BtnCleanupImage_RevertPendingActions.Click

        txtOutput.Text = ""
        If (CmbBoxCleanupImage_UseImageMounted.Text = "" And ChkBoxCleanupImage_Online.Checked = False) Then
            MessageBox.Show("No WIM is mounted.  You must mount a WIM before running this command (Offline mode) or use /Online option.")
        Else
            If ChkBoxCleanupImage_Online.Checked Then
                strDISMArguments = "/Online /Cleanup-Image /RevertPendingActions"
            Else
                strDISMArguments = "/Image:" + """" + CmbBoxCleanupImage_UseImageMounted.Text + """" + " /Cleanup-Image /RevertPendingActions"
            End If

            txtOutput.Text = "Command line that running is:" & vbCrLf & "Dism.exe " & strDISMArguments & vbCrLf
            BackgroundWorkerDISMCommand.RunWorkerAsync(strDISMArguments)
            frmProgress.ShowDialog()
            txtOutput.Text = txtOutput.Text & strOutput & vbCrLf & "Exit code:" & strDISMExitCode
        End If
    End Sub
    '
    ' BtnCleanupImage_Superseded_Click
    ' Rev: 31/07/2022
    '
    Private Sub BtnCleanupImage_Superseded_Click(sender As Object, e As EventArgs) Handles BtnCleanupImage_Superseded.Click

        txtOutput.Text = ""
        If (CmbBoxCleanupImage_UseImageMounted.Text = "" And ChkBoxCleanupImage_Online.Checked = False) Then
            MessageBox.Show("No WIM is mounted.  You must mount a WIM before running this command (Offline mode) or use /Online option.")
        Else
            If ChkBoxCleanupImage_Online.Checked Then
                strDISMArguments = "/Online /Cleanup-Image /SPSuperseded"
            Else
                strDISMArguments = "/Image:" + """" + CmbBoxCleanupImage_UseImageMounted.Text + """" + " /Cleanup-Image /SPSuperseded"
            End If
            If ChkBoxCleanupImage_HideSP.Checked = True Then
                strDISMArguments = strDISMArguments + " /HideSP"
            End If

            txtOutput.Text = "Command line that running is:" & vbCrLf & "Dism.exe " & strDISMArguments & vbCrLf
            BackgroundWorkerDISMCommand.RunWorkerAsync(strDISMArguments)
            frmProgress.ShowDialog()
            txtOutput.Text = txtOutput.Text & strOutput & vbCrLf & "Exit code:" & strDISMExitCode
        End If
    End Sub
    '
    ' BtnCleanupImage_StartComponentCleanup_Click
    ' Rev: 31/07/2022
    '
    Private Sub BtnCleanupImage_StartComponentCleanup_Click(sender As Object, e As EventArgs) Handles BtnCleanupImage_StartComponentCleanup.Click

        txtOutput.Text = ""
        If (CmbBoxCleanupImage_UseImageMounted.Text = "" And ChkBoxCleanupImage_Online.Checked = False) Then
            MessageBox.Show("No WIM is mounted.  You must mount a WIM before running this command (Offline mode) or use /Online option.")
        Else
            If ChkBoxCleanupImage_Online.Checked Then
                strDISMArguments = "/Online /Cleanup-Image /StartComponentCleanup"
            Else
                strDISMArguments = "/Image:" + """" + CmbBoxCleanupImage_UseImageMounted.Text + """" + " /Cleanup-Image /StartComponentCleanup"
            End If
            If ChkBoxCleanupImage_ResetBase.Checked = True Then
                strDISMArguments = strDISMArguments + " /ResetBase"
            End If
            If ChkBoxCleanupImage_Defer.Checked = True Then
                strDISMArguments = strDISMArguments + " /Defer"
            End If

            txtOutput.Text = "Command line that running is:" & vbCrLf & "Dism.exe " & strDISMArguments & vbCrLf
            BackgroundWorkerDISMCommand.RunWorkerAsync(strDISMArguments)
            frmProgress.ShowDialog()
            txtOutput.Text = txtOutput.Text & strOutput & vbCrLf & "Exit code:" & strDISMExitCode
        End If
    End Sub
    '
    ' BtnCleanupImage_AnalyzeComponentStore_Click
    ' Rev: 31/07/2022
    '
    Private Sub BtnCleanupImage_AnalyzeComponentStore_Click(sender As Object, e As EventArgs) Handles BtnCleanupImage_AnalyzeComponentStore.Click

        txtOutput.Text = ""
        If (CmbBoxCleanupImage_UseImageMounted.Text = "" And ChkBoxCleanupImage_Online.Checked = False) Then
            MessageBox.Show("No WIM is mounted.  You must mount a WIM before running this command (Offline mode) or use /Online option.")
        Else
            If ChkBoxCleanupImage_Online.Checked Then
                strDISMArguments = "/Online /Cleanup-Image /AnalyzeComponentStore"
            Else
                strDISMArguments = "/Image:" + """" + CmbBoxCleanupImage_UseImageMounted.Text + """" + " /Cleanup-Image /AnalyzeComponentStore"
            End If

            txtOutput.Text = "Command line that running is:" & vbCrLf & "Dism.exe " & strDISMArguments & vbCrLf
            BackgroundWorkerDISMCommand.RunWorkerAsync(strDISMArguments)
            frmProgress.ShowDialog()
            txtOutput.Text = txtOutput.Text & strOutput & vbCrLf & "Exit code:" & strDISMExitCode
        End If
    End Sub
    '
    ' BtnCleanupImage_CheckHealth_Click
    ' Rev: 31/07/2022
    '
    Private Sub BtnCleanupImage_CheckHealth_Click(sender As Object, e As EventArgs) Handles BtnCleanupImage_CheckHealth.Click

        txtOutput.Text = ""
        If (CmbBoxCleanupImage_UseImageMounted.Text = "" And ChkBoxCleanupImage_Online.Checked = False) Then
            MessageBox.Show("No WIM is mounted.  You must mount a WIM before running this command (Offline mode) or use /Online option.")
        Else
            If ChkBoxCleanupImage_Online.Checked Then
                strDISMArguments = "/Online /Cleanup-Image /CheckHealth"
            Else
                strDISMArguments = "/Image:" + """" + CmbBoxCleanupImage_UseImageMounted.Text + """" + " /Cleanup-Image /CheckHealth"
            End If

            txtOutput.Text = "Command line that running is:" & vbCrLf & "Dism.exe " & strDISMArguments & vbCrLf
            BackgroundWorkerDISMCommand.RunWorkerAsync(strDISMArguments)
            frmProgress.ShowDialog()
            txtOutput.Text = txtOutput.Text & strOutput & vbCrLf & "Exit code:" & strDISMExitCode
        End If
    End Sub
    '
    ' BtnCleanupImage_ScanHealth_Click
    ' Rev: 31/07/2022
    '
    Private Sub BtnCleanupImage_ScanHealth_Click(sender As Object, e As EventArgs) Handles BtnCleanupImage_ScanHealth.Click

        txtOutput.Text = ""
        If (CmbBoxCleanupImage_UseImageMounted.Text = "" And ChkBoxCleanupImage_Online.Checked = False) Then
            MessageBox.Show("No WIM is mounted.  You must mount a WIM before running this command (Offline mode) or use /Online option.")
        Else
            If ChkBoxCleanupImage_Online.Checked Then
                strDISMArguments = "/Online /Cleanup-Image /ScanHealth"
            Else
                strDISMArguments = "/Image:" + """" + CmbBoxCleanupImage_UseImageMounted.Text + """" + " /Cleanup-Image /ScanHealth"
            End If

            txtOutput.Text = "Command line that running is:" & vbCrLf & "Dism.exe " & strDISMArguments & vbCrLf
            BackgroundWorkerDISMCommand.RunWorkerAsync(strDISMArguments)
            frmProgress.ShowDialog()
            txtOutput.Text = txtOutput.Text & strOutput & vbCrLf & "Exit code:" & strDISMExitCode
        End If
    End Sub
    '
    ' BtnCleanupImage_RestoreHealth_Click
    ' Rev: 31/07/2022
    '
    Private Sub BtnCleanupImage_RestoreHealth_Click(sender As Object, e As EventArgs) Handles BtnCleanupImage_RestoreHealth.Click
        Dim StrTmp As String

        txtOutput.Text = ""
        If (CmbBoxCleanupImage_UseImageMounted.Text = "" And ChkBoxCleanupImage_Online.Checked = False) Then
            MessageBox.Show("No WIM is mounted.  You must mount a WIM before running this command (Offline mode) or use /Online option.")
        Else
            StrTmp = TxtBoxCleanupImage_SourceRestoreHealth.Text
            ' detect if logical drive only, no double quot on string preserv for error 87
            If (StrTmp.Length <> 3) Then
                StrTmp = """" + StrTmp + """" ' if not, style use double quot
            End If

            If ChkBoxCleanupImage_Online.Checked Then
                strDISMArguments = "/Online /Cleanup-Image /RestoreHealth"
            Else
                strDISMArguments = "/Image:" + """" + CmbBoxCleanupImage_UseImageMounted.Text + """" + " /Cleanup-Image /RestoreHealth"
            End If
            If Path.GetExtension(TxtBoxCleanupImage_SourceRestoreHealth.Text.ToUpper()) = ".WIM" And cmbCleanupImage_IndexSource.Text <> "" Then
                strDISMArguments = strDISMArguments + " /Source:wim:" + StrTmp + ":" + cmbCleanupImage_IndexSource.Text
            End If
            If Path.GetExtension(TxtBoxCleanupImage_SourceRestoreHealth.Text.ToUpper()) = ".ESD" And cmbCleanupImage_IndexSource.Text <> "" Then
                strDISMArguments = strDISMArguments + " /Source:esd:" + StrTmp + ":" + cmbCleanupImage_IndexSource.Text
            End If
            If ChkBoxCleanupImage_LimitAccessRestoreHealth.Checked = True Then
                strDISMArguments = strDISMArguments + " /LimitAccess"
            End If

            txtOutput.Text = "Command line that running is:" & vbCrLf & "Dism.exe " & strDISMArguments & vbCrLf
            BackgroundWorkerDISMCommand.RunWorkerAsync(strDISMArguments)
            frmProgress.ShowDialog()
            txtOutput.Text = txtOutput.Text & strOutput & vbCrLf & "Exit code:" & strDISMExitCode
        End If
    End Sub
    '
    ' BtnCleanupImage_ChooseSourceRestoreHealth_Click
    ' Rev: 31/07/2022
    '
    Private Sub BtnCleanupImage_ChooseSourceRestoreHealth_Click(sender As Object, e As EventArgs) Handles BtnCleanupImage_ChooseSourceRestoreHealth.Click
        Dim MyDlgOpenFile = New System.Windows.Forms.OpenFileDialog() ' instance of dialog box

        'MyDlgOpenFile.InitialDirectory = Environment.SpecialFolder.MyComputer     
        MyDlgOpenFile.InitialDirectory = "C:\" ' default root path
        MyDlgOpenFile.Title = "Choose WIM or ESD file to Open"    ' title of dialog box
        MyDlgOpenFile.Filter = ("WIM Files(*.wim)|*.wim|Fichier ESD (*.ESD)|*.ESD") ' filter extension

        If MyDlgOpenFile.ShowDialog = DialogResult.OK Then        ' user selected filename from dialog box ?
            TxtBoxCleanupImage_SourceRestoreHealth.Text = MyDlgOpenFile.FileName
        End If
        DisplayImageInfos("Tab_CleanupImage.txt", TxtBoxCleanupImage_SourceRestoreHealth.Text)
        Me.cmbCleanupImage_IndexSource.Items.Clear()
        Me.cmbCleanupImage_IndexSource.Text = Nothing
        ListInfosWimCleanupImage.Clear()
        UpdateListIndexWim("Tab_CleanupImage.txt", ListInfosWimCleanupImage)
        For IdxFor As Integer = 1 To ListInfosWimCleanupImage.Count
            Me.cmbCleanupImage_IndexSource.Items.Add(IdxFor.ToString)
        Next
    End Sub
    '
    ' BtnDefaultAppAssocServ_Remove_Click
    ' Rev: 31/07/2022
    '
    Private Sub BtnDefaultAppAssocServ_Remove_Click(sender As Object, e As EventArgs) Handles BtnDefaultAppAssocServ_Remove.Click

        ' To Do....

    End Sub
    '
    ' BtnMountControl_GetMountedImageInfo_Click
    ' Rev: 31/07/2022
    '
    Private Sub BtnMountControl_GetMountedImageInfo_Click(sender As Object, e As EventArgs) Handles BtnMountControl_GetMountedImageInfo.Click, BtnDriverManagement_GetMountedImageInfo.Click

        txtOutput.Text = ""
        strDISMArguments = "/Get-MountedImageInfo"

        txtOutput.Text = "Command line that running is:" & vbCrLf & "Dism.exe " & strDISMArguments & vbCrLf
        BackgroundWorkerDISMCommand.RunWorkerAsync(strDISMArguments)
        frmProgress.ShowDialog()
        txtOutput.Text = txtOutput.Text & strOutput & vbCrLf & "Exit code:" & strDISMExitCode
    End Sub
    '
    ' BtnMountControl_CommitImage_Click
    ' Rev: 31/07/2022
    '
    Private Sub BtnMountControl_CommitImage_Click(sender As Object, e As EventArgs) Handles BtnMountControl_CommitImage.Click

        txtOutput.Text = ""
        If ImageMounted = True Then
            strDISMArguments = "/Commit-Image /MountDir:" + strFolderName
            If ChkBoxMountControl_Append.Checked = True Then
                strDISMArguments = strDISMArguments & " /Append"
            End If
            If ChkBoxMountControl_CheckIntegrity.Checked = True Then
                strDISMArguments = strDISMArguments & " /CheckIntegrity"
            End If

            txtOutput.Text = "Command line that running is:" & vbCrLf & "Dism.exe " & strDISMArguments & vbCrLf
            BackgroundWorkerDISMCommand.RunWorkerAsync(strDISMArguments)
            frmProgress.ShowDialog()
            txtOutput.Text = txtOutput.Text & strOutput & vbCrLf & "Exit code:" & strDISMExitCode
        Else
            MessageBox.Show("No WIM is mounted.  You must mount a WIM before running this command.")
        End If
    End Sub
    '
    ' BtnMountControl_CleanupMountPoints_Click
    ' Rev: 31/07/2022
    '
    Private Sub BtnMountControl_CleanupMountPoints_Click(sender As Object, e As EventArgs) Handles BtnMountControl_CleanupMountPoints.Click

        txtOutput.Text = ""
        strDISMArguments = "/Cleanup-MountPoints"

        txtOutput.Text = "Command line that running is:" & vbCrLf & "Dism.exe " & strDISMArguments & vbCrLf
        BackgroundWorkerDISMCommand.RunWorkerAsync(strDISMArguments)
        frmProgress.ShowDialog()
        txtOutput.Text = txtOutput.Text & strOutput & vbCrLf & "Exit code:" & strDISMExitCode
    End Sub
    '
    ' BtnMountControl_RemountWim_Click
    ' Rev: 31/07/2022
    '
    Private Sub BtnMountControl_RemountWim_Click(sender As Object, e As EventArgs) Handles BtnMountControl_RemountWim.Click

        txtOutput.Text = ""
        If (TxtMountControl_MountLocation.Text = "") Then
            MessageBox.Show("Mount localtion is required to use this command.")
            Exit Sub
        End If
        strDISMArguments = "/Remount-Image /MountDir:" + TxtMountControl_MountLocation.Text
        txtOutput.Text = "Command line that running is:" & vbCrLf & "Dism.exe " & strDISMArguments & vbCrLf
        BackgroundWorkerDISMCommand.RunWorkerAsync(strDISMArguments)
        frmProgress.ShowDialog()
        txtOutput.Text = txtOutput.Text & strOutput & vbCrLf & "Exit code:" & strDISMExitCode
    End Sub
    '
    ' BtnDriverManagement_RefreshMountedImage_Click
    ' Display on console and create output file "MountedImageInfo.txt"
    ' Rev: 31/07/2022
    '
    Private Sub BtnDriverManagement_RefreshMountedImage_Click(sender As Object, e As EventArgs) Handles BtnDriverManagement_RefreshMountedImage.Click

        DisplayMountedImageInfo("Tab_DriverManagement.txt")     ' on console and create file "MountedImageInfo.txt" 
        UpdateForMountedImageInfo("Tab_DriverManagement.txt", CmbBoxDriverManagement_UseImageMounted)
    End Sub
    '
    ' BtnPackageManagement_GetMountedImageInfo_Click
    ' Display on console and create output file "MountedImageInfo.txt"
    ' Rev: 31/07/2022
    '
    Private Sub BtnPackageManagement_GetMountedImageInfo_Click(sender As Object, e As EventArgs) Handles BtnPackageManagement_GetMountedImageInfo.Click

        txtOutput.Text = ""
        strDISMArguments = "/Get-MountedImageInfo"

        txtOutput.Text = "Command line that running is:" & vbCrLf & "Dism.exe " & strDISMArguments & vbCrLf
        BackgroundWorkerDISMCommand.RunWorkerAsync(strDISMArguments)
        frmProgress.ShowDialog()
        txtOutput.Text = txtOutput.Text & strOutput & vbCrLf & "Exit code:" & strDISMExitCode
    End Sub
    '
    ' BtnPackageManagement_RefreshMountedImage_Click
    ' Display on console and create output file "MountedImageInfo.txt"
    ' Rev: 31/07/2022
    '
    Private Sub BtnPackageManagement_RefreshMountedImage_Click(sender As Object, e As EventArgs) Handles BtnPackageManagement_RefreshMountedImage.Click

        DisplayMountedImageInfo("Tab_PackageManagement.txt")     ' on console and create file "MountedImageInfo.txt" 
        UpdateForMountedImageInfo("Tab_PackageManagement.txt", CmbBoxPackageManagement_UseImageMounted)
    End Sub
    '
    ' BtnFeatureManagement_GetMountedImageInfo_Click
    ' Display on console and create output file "MountedImageInfo.txt"
    ' Rev: 31/07/2022
    '
    Private Sub BtnFeatureManagement_GetMountedImageInfo_Click(sender As Object, e As EventArgs) Handles BtnFeatureManagement_GetMountedImageInfo.Click

        txtOutput.Text = ""
        strDISMArguments = "/Get-MountedImageInfo"

        txtOutput.Text = "Command line that running is:" & vbCrLf & "Dism.exe " & strDISMArguments & vbCrLf
        BackgroundWorkerDISMCommand.RunWorkerAsync(strDISMArguments)
        frmProgress.ShowDialog()
        txtOutput.Text = txtOutput.Text & strOutput & vbCrLf & "Exit code:" & strDISMExitCode
    End Sub
    '
    ' BtnFeatureManagement_RefreshMountedImage_Click
    ' Display on console and create output file "MountedImageInfo.txt"
    ' Rev: 31/07/2022
    '
    Private Sub BtnFeatureManagement_RefreshMountedImage_Click(sender As Object, e As EventArgs) Handles BtnFeatureManagement_RefreshMountedImage.Click

        DisplayMountedImageInfo("Tab_FeatureManagement.txt")     ' on console and create file "MountedImageInfo.txt" 
        UpdateForMountedImageInfo("Tab_FeatureManagement.txt", CmbBoxFeatureManagement_UseImageMounted)
    End Sub
    '
    ' BtnEditionServicing_RefreshMountedImage_Click
    ' Display on console and create output file "MountedImageInfo.txt"
    ' Rev: 31/07/2022
    '
    Private Sub BtnEditionServicing_RefreshMountedImage_Click(sender As Object, e As EventArgs) Handles BtnEditionServicing_RefreshMountedImage.Click

        DisplayMountedImageInfo("Tab_EditionServicing.txt")     ' on console and create file "MountedImageInfo.txt" 
        UpdateForMountedImageInfo("Tab_EditionServicing.txt", CmbBoxEditionServicing_UseImageMounted)
    End Sub
    '
    ' BtnEditionServicing_GetMountedImageInfo_Click
    ' Display on console and create output file "MountedImageInfo.txt"
    ' Rev: 31/07/2022
    '
    Private Sub BtnEditionServicing_GetMountedImageInfo_Click(sender As Object, e As EventArgs) Handles BtnEditionServicing_GetMountedImageInfo.Click

        txtOutput.Text = ""
        strDISMArguments = "/Get-MountedImageInfo"

        txtOutput.Text = "Command line that running is:" & vbCrLf & "Dism.exe " & strDISMArguments & vbCrLf
        BackgroundWorkerDISMCommand.RunWorkerAsync(strDISMArguments)
        frmProgress.ShowDialog()
        txtOutput.Text = txtOutput.Text & strOutput & vbCrLf & "Exit code:" & strDISMExitCode
    End Sub
    '
    ' BtnUnattendedServicing_RefreshMountedImage_Click
    ' Display on console and create output file "MountedImageInfo.txt"
    ' Rev: 31/07/2022
    '
    Private Sub BtnUnattendedServicing_RefreshMountedImage_Click(sender As Object, e As EventArgs) Handles BtnUnattendedServicing_RefreshMountedImage.Click

        DisplayMountedImageInfo("Tab_UnattendedServicing.txt")     ' on console and create file "MountedImageInfo.txt" 
        UpdateForMountedImageInfo("Tab_UnattendedServicing.txt", CmBoxUnattendedServicing_UseImageMounted)
    End Sub
    '
    ' BtnUnattendedServicing_GetMountedImageInfo_Click
    ' Display on console and create output file "MountedImageInfo.txt"
    ' Rev: 31/07/2022
    '
    Private Sub BtnUnattendedServicing_GetMountedImageInfo_Click(sender As Object, e As EventArgs) Handles BtnUnattendedServicing_GetMountedImageInfo.Click

        txtOutput.Text = ""
        strDISMArguments = "/Get-MountedImageInfo"

        txtOutput.Text = "Command line that running is:" & vbCrLf & "Dism.exe " & strDISMArguments & vbCrLf
        BackgroundWorkerDISMCommand.RunWorkerAsync(strDISMArguments)
        frmProgress.ShowDialog()
        txtOutput.Text = txtOutput.Text & strOutput & vbCrLf & "Exit code:" & strDISMExitCode
    End Sub
    '
    ' BtnApplicationServicing_GetMountedImageInfo_Click
    ' Display on console and create output file "MountedImageInfo.txt"
    ' Rev: 31/07/2022
    '
    Private Sub BtnApplicationServicing_GetMountedImageInfo_Click(sender As Object, e As EventArgs) Handles BtnApplicationServicing_GetMountedImageInfo.Click

        txtOutput.Text = ""
        strDISMArguments = "/Get-MountedImageInfo"

        txtOutput.Text = "Command line that running is:" & vbCrLf & "Dism.exe " & strDISMArguments & vbCrLf
        BackgroundWorkerDISMCommand.RunWorkerAsync(strDISMArguments)
        frmProgress.ShowDialog()
        txtOutput.Text = txtOutput.Text & strOutput & vbCrLf & "Exit code:" & strDISMExitCode
    End Sub
    '
    ' BtnApplicationServicing_RefreshMountedImage_Click
    ' Display on console and create output file "MountedImageInfo.txt"
    ' Rev: 31/07/2022
    '
    Private Sub BtnApplicationServicing_RefreshMountedImage_Click(sender As Object, e As EventArgs) Handles BtnApplicationServicing_RefreshMountedImage.Click

        DisplayMountedImageInfo("Tab_ApplicationServicing.txt")     ' on console and create file "MountedImageInfo.txt" 
        UpdateForMountedImageInfo("Tab_ApplicationServicing.txt", CmbBoxApplicationServicing_UseImageMounted)

    End Sub
    '
    ' BtnExportDriver_RefreshMountedImage_Click
    ' Display on console and create output file "MountedImageInfo.txt"
    ' Rev: 31/07/2022
    '
    Private Sub BtnExportDriver_RefreshMountedImage_Click(sender As Object, e As EventArgs) Handles BtnExportDriver_RefreshMountedImage.Click

        DisplayMountedImageInfo("Tab_ExportDriver.txt")     ' on console and create file "MountedImageInfo.txt" 
        UpdateForMountedImageInfo("Tab_ExportDriver.txt", CmbBoxExportDriver_UseImageMounted)
    End Sub
    '
    ' BtnExportDriver_GetMountedImageInfo_Click
    ' Display on console and create output file "MountedImageInfo.txt"
    ' Rev: 31/07/2022
    '
    Private Sub BtnExportDriver_GetMountedImageInfo_Click(sender As Object, e As EventArgs) Handles BtnExportDriver_GetMountedImageInfo.Click

        txtOutput.Text = ""
        strDISMArguments = "/Get-MountedImageInfo"

        txtOutput.Text = "Command line that running is:" & vbCrLf & "Dism.exe " & strDISMArguments & vbCrLf
        BackgroundWorkerDISMCommand.RunWorkerAsync(strDISMArguments)
        frmProgress.ShowDialog()
        txtOutput.Text = txtOutput.Text & strOutput & vbCrLf & "Exit code:" & strDISMExitCode
    End Sub
    '
    ' BtnMountControl_RefreshMountedImage_Click
    ' Display on console-gui and create output file "MountedImageInfo.txt"
    ' Rev: 31/07/2022
    '
    Private Sub BtnMountControl_RefreshMountedImage_Click(sender As Object, e As EventArgs) Handles BtnMountControl_RefreshMountedImage.Click

        DisplayMountedImageInfo("Tab_MountUnmountControl.txt")     ' on console and create file "MountedImageInfo.txt" 
        UpdateForMountedImageInfo("Tab_MountUnmountControl.txt", CmbBoxMountControl_AlreadyMounted)
    End Sub
    '
    ' BtnFeatureManagement_GetFeatureInfo_Click
    ' Display on console-gui and create output file "MountedImageInfo.txt"
    ' Rev: 31/07/2022
    '
    Private Sub BtnFeatureManagement_GetFeatureInfo_Click(sender As Object, e As EventArgs) Handles BtnFeatureManage_GetFeatureInfo.Click

        txtOutput.Text = ""
        If (CmbBoxFeatureManagement_UseImageMounted.Text = "" And ChkBoxFeatureManagement_Online.Checked = False) Then
            MessageBox.Show("No image selected.  You must selected an image before running this command (Offline mode) or use /Online option.")
        Else
            If txtFeatureName.Text = "" Then
                MessageBox.Show("Feature Name is required to continue.")
                Exit Sub
            End If
            If (ChkBoxFeatureManagement_Online.Checked = True) Then
                strDISMArguments = "/Online /Get-FeatureInfo /FeatureName:" & """" & txtFeatureName.Text & """"
            Else
                strDISMArguments = "/Image:""" & CmbBoxFeatureManagement_UseImageMounted.Text & """ /Get-FeatureInfo  /FeatureName:" & """" & txtFeatureName.Text & """"
            End If
            If (txtFeatPackageName.Text <> "") Then
                strDISMArguments = strDISMArguments & " /PackageName:" & """" & txtFeatPackageName.Text & """"
            End If
            If (txtFeatPackagePath.Text <> "") Then
                strDISMArguments = strDISMArguments & " /PackagePath:" & """" & txtFeatPackagePath.Text & """"
            End If
            txtOutput.Text = "Command line that running is:" & vbCrLf & "Dism.exe " & strDISMArguments & vbCrLf
            BackgroundWorkerDISMCommand.RunWorkerAsync(strDISMArguments)
            frmProgress.ShowDialog()
            txtOutput.Text = txtOutput.Text & strOutput & vbCrLf & "Exit code:" & strDISMExitCode
        End If
    End Sub
    '
    ' ChkBoxFeatureManagement_Source_CheckedChanged
    ' 
    ' Rev: 31/07/2022
    '
    Private Sub ChkBoxFeatureManagement_Source_CheckedChanged(sender As Object, e As EventArgs) Handles ChkBoxFeatureManagement_Source.CheckedChanged

        If ChkBoxFeatureManagement_Source.Checked = True Then
            TxtBoxFeatureManagement_Source.Enabled = True
        ElseIf ChkBoxFeatureManagement_Source.Checked = False Then
            TxtBoxFeatureManagement_Source.Enabled = False
        End If
    End Sub
    '
    ' BtnCleanupImage_GetMountedImageInfo_Click
    ' 
    ' Rev: 31/07/2022
    '
    Private Sub BtnCleanupImage_GetMountedImageInfo_Click(sender As Object, e As EventArgs) Handles BtnCleanupImage_GetMountedImageInfo.Click

        txtOutput.Text = ""
        strDISMArguments = "/Get-MountedImageInfo"

        txtOutput.Text = "Command line that running is:" & vbCrLf & "Dism.exe " & strDISMArguments & vbCrLf
        BackgroundWorkerDISMCommand.RunWorkerAsync(strDISMArguments)
        frmProgress.ShowDialog()
        txtOutput.Text = txtOutput.Text & strOutput & vbCrLf & "Exit code:" & strDISMExitCode
    End Sub
    '
    ' BtnCleanupImage_RefreshMountedImage_Click
    ' 
    ' Rev: 31/07/2022
    '
    Private Sub BtnCleanupImage_RefreshMountedImage_Click(sender As Object, e As EventArgs) Handles BtnCleanupImage_RefreshMountedImage.Click

        DisplayMountedImageInfo("Tab_CleanupImage.txt")     ' on console and create file "MountedImageInfo.txt" 
        UpdateForMountedImageInfo("Tab_CleanupImage.txt", CmbBoxCleanupImage_UseImageMounted)
    End Sub
    '
    ' BtnCapPackServicing_GetMountedImageInfo_Click
    ' 
    ' Rev: 31/07/2022
    '
    Private Sub BtnCapPackServicing_GetMountedImageInfo_Click(sender As Object, e As EventArgs) Handles BtnCapPackServ_GetMountedImageInfo.Click

        txtOutput.Text = ""
        strDISMArguments = "/Get-MountedImageInfo"

        txtOutput.Text = "Command line that running is:" & vbCrLf & "Dism.exe " & strDISMArguments & vbCrLf
        BackgroundWorkerDISMCommand.RunWorkerAsync(strDISMArguments)
        frmProgress.ShowDialog()
        txtOutput.Text = txtOutput.Text & strOutput & vbCrLf & "Exit code:" & strDISMExitCode
    End Sub
    '
    ' BtnCapPackServicing_RefreshMountedImage_Click
    ' 
    ' Rev: 31/07/2022
    '
    Private Sub BtnCapPackServicing_RefreshMountedImage_Click(sender As Object, e As EventArgs) Handles BtnCapPackServ_RefreshMountedImage.Click

        DisplayMountedImageInfo("Tab_CapabilitiesPackageServicing.txt")     ' on console and create file "MountedImageInfo.txt" 
        UpdateForMountedImageInfo("Tab_CapabilitiesPackageServicing.txt", CmbBoxCapPackServicing_UseImageMounted)
    End Sub
    '
    ' BtnAppAssocServicing_GetMountedImageInfo_Click
    ' 
    ' Rev: 31/07/2022
    '
    Private Sub BtnAppAssocServicing_GetMountedImageInfo_Click(sender As Object, e As EventArgs) Handles BtnAppAssocServ_GetMountedImageInfo.Click

        txtOutput.Text = ""
        strDISMArguments = "/Get-MountedImageInfo"

        txtOutput.Text = "Command line that running is:" & vbCrLf & "Dism.exe " & strDISMArguments & vbCrLf
        BackgroundWorkerDISMCommand.RunWorkerAsync(strDISMArguments)
        frmProgress.ShowDialog()
        txtOutput.Text = txtOutput.Text & strOutput & vbCrLf & "Exit code:" & strDISMExitCode
    End Sub
    '
    ' BtnDefaultAppAssocServicing_RefreshMountedImage_Click
    ' 
    ' Rev: 31/07/2022
    '
    Private Sub BtnDefaultAppAssocServicing_RefreshMountedImage_Click(sender As Object, e As EventArgs) Handles BtnDefaultAppAssocServ_RefreshMountedImage.Click

        DisplayMountedImageInfo("Tab_DefaultAppAssocServicing.txt")     ' on console and create file "MountedImageInfo.txt" 
        UpdateForMountedImageInfo("Tab_DefaultAppAssocServicing.txt", CmbBoxDefaultAppAssocServicing_UseImageMounted)
    End Sub
    '
    ' BtnLangAndInterServ_GetMountedImageInfo_Click
    ' 
    ' Rev: 31/07/2022
    '
    Private Sub BtnLangAndInterServ_GetMountedImageInfo_Click(sender As Object, e As EventArgs) Handles BtnLangAndInterServicing_GetMountedImageInfo.Click

        txtOutput.Text = ""
        strDISMArguments = "/Get-MountedImageInfo"

        txtOutput.Text = "Command line that running is:" & vbCrLf & "Dism.exe " & strDISMArguments & vbCrLf
        BackgroundWorkerDISMCommand.RunWorkerAsync(strDISMArguments)
        frmProgress.ShowDialog()
        txtOutput.Text = txtOutput.Text & strOutput & vbCrLf & "Exit code:" & strDISMExitCode
    End Sub
    '
    ' BtnLangAndInterServicing_RefreshMountedImage_Click
    ' 
    ' Rev: 31/07/2022
    '
    Private Sub BtnLangAndInterServicing_RefreshMountedImage_Click(sender As Object, e As EventArgs) Handles BtnLangAndInterServicing_RefreshMountedImage.Click

        DisplayMountedImageInfo("Tab_LangAndInterServicing.txt")     ' on console and create file "MountedImageInfo.txt" 
        UpdateForMountedImageInfo("Tab_LangAndInterServicing.txt", CmbBoxLangAndInterServ_UseImageMounted)
    End Sub
    '
    ' BtnLangAndInterServ_ApplyInputLocale_Click
    ' 
    ' Rev: 31/07/2022
    '
    Private Sub BtnLangAndInterServ_ApplyInputLocale_Click(sender As Object, e As EventArgs) Handles BtnLangAndInterServ_ApplyInputLocale.Click

        ' to do...
    End Sub
    '
    ' BtnLangAndInterServ_ApplyTimeZone_Click
    ' 
    ' Rev: 31/07/2022
    '
    Private Sub BtnLangAndInterServ_ApplyTimeZone_Click(sender As Object, e As EventArgs) Handles BtnLangAndInterServ_ApplyTimeZone.Click

        ' to do...
    End Sub
    '
    ' BtnLangAndInterServ_ApplySetupUILang_Click
    ' 
    ' Rev: 31/07/2022
    '
    Private Sub BtnLangAndInterServ_ApplySetupUILang_Click(sender As Object, e As EventArgs) Handles BtnLangAndInterServ_ApplySetupUILang.Click

        ' to do...
    End Sub
    '
    ' BtnDiskpartWinPE_InfosDisk_Click
    ' 
    ' Rev: 31/07/2022
    ' To do: optimization with stringbuilder
    '
    Private Sub BtnDiskpartWinPE_InfosDisk_Click(sender As Object, e As EventArgs) Handles BtnDiskpartWinPE_RefreshListDisk.Click

        Dim Query As String

        TxtBoxDispartWinPE_InfosDisk.Text = ""
        Query = "SELECT * FROM Win32_DiskDrive"
        Dim QueryResults As New ManagementObjectSearcher(Query)
        Dim Disk As ManagementObject

        CmbBoxDiskpartWinpe_SelectDrive.Items.Clear()

        For Each Disk In QueryResults.Get()                 ' read disk information
            TxtBoxDispartWinPE_InfosDisk.Text = TxtBoxDispartWinPE_InfosDisk.Text & "Drive: " & vbTab & vbTab & Disk.Item("Index").ToString & vbCrLf
            TxtBoxDispartWinPE_InfosDisk.Text = TxtBoxDispartWinPE_InfosDisk.Text & "Interface Type: " & vbTab & Disk.Item("InterfaceType").ToString & vbCrLf
            TxtBoxDispartWinPE_InfosDisk.Text = TxtBoxDispartWinPE_InfosDisk.Text & "MediaType: " & vbTab & Disk.Item("MediaType").ToString & vbCrLf
            TxtBoxDispartWinPE_InfosDisk.Text = TxtBoxDispartWinPE_InfosDisk.Text & "Size: " & vbTab & vbTab & Disk.Item("Size").ToString & vbCrLf
            TxtBoxDispartWinPE_InfosDisk.Text = TxtBoxDispartWinPE_InfosDisk.Text & "Caption: " & vbTab & vbTab & Disk.Item("Caption").ToString & vbCrLf
            TxtBoxDispartWinPE_InfosDisk.Text = TxtBoxDispartWinPE_InfosDisk.Text & "Partitions: " & vbTab & Disk.Item("Partitions").ToString & vbCrLf
            TxtBoxDispartWinPE_InfosDisk.Text = TxtBoxDispartWinPE_InfosDisk.Text & "Status: " & vbTab & vbTab & Disk.Item("Status").ToString & vbCrLf
            TxtBoxDispartWinPE_InfosDisk.Text = TxtBoxDispartWinPE_InfosDisk.Text & vbCrLf
            CmbBoxDiskpartWinpe_SelectDrive.Items.Add(Disk.Item("Index").ToString) ' update disk selector index
        Next
    End Sub
    '
    ' RadBtnDiskpartWinPE_FAT32_CheckedChanged
    ' 
    ' Rev: 03/08/2022
    '
    Private Sub RadBtnDiskpartWinPE_FAT32_CheckedChanged(sender As Object, e As EventArgs) Handles RadBtnDiskpartWinPE_FAT32.CheckedChanged

        LblDiskpartWinPE_FAT32Size.Visible = True
        TxtBoxDiskpartWinPE_FAT32Size.Visible = True
        LblDiskpartWinPE_NTFSSize.Visible = False
        TxtBoxDiskpartWinPE_NTFSSize.Visible = False

        LblDiskpartWinPE_System.Visible = False
        TxtBoxDiskpartWinPE_System.Visible = False
        LblDiskpartWinPE_MSR.Visible = False
        TxtBoxDiskpartWinPE_MSR.Visible = False
        LblDiskpartWinPE_Windows.Visible = False
        TxtBoxDiskpartWinPE_Windows.Visible = False
        LblDiskpartWinPE_Recovery.Visible = False
        TxtBoxDiskpartWinPE_Recovery.Visible = False
        PictBoxDiskpartWinPE_Picture.Load("USB_FAT32.PNG")
    End Sub
    '
    ' RadBtnDiskpartWinPE_NTFS_CheckedChanged
    ' 
    ' Rev: 03/08/2022
    '
    Private Sub RadBtnDiskpartWinPE_NTFS_CheckedChanged(sender As Object, e As EventArgs) Handles RadBtnDiskpartWinPE_NTFS.CheckedChanged

        LblDiskpartWinPE_FAT32Size.Visible = False
        TxtBoxDiskpartWinPE_FAT32Size.Visible = False
        LblDiskpartWinPE_NTFSSize.Visible = True
        TxtBoxDiskpartWinPE_NTFSSize.Visible = True

        LblDiskpartWinPE_System.Visible = False
        TxtBoxDiskpartWinPE_System.Visible = False
        LblDiskpartWinPE_MSR.Visible = False
        TxtBoxDiskpartWinPE_MSR.Visible = False
        LblDiskpartWinPE_Windows.Visible = False
        TxtBoxDiskpartWinPE_Windows.Visible = False
        LblDiskpartWinPE_Recovery.Visible = False
        TxtBoxDiskpartWinPE_Recovery.Visible = False
        PictBoxDiskpartWinPE_Picture.Load("USB_NTFS.PNG")
    End Sub
    '
    ' RadBtnDiskparWinPE_FAT32NTFS_CheckedChanged
    ' 
    ' Rev: 03/08/2022
    '
    Private Sub RadBtnDiskparWinPE_FAT32NTFS_CheckedChanged(sender As Object, e As EventArgs) Handles RadBtnDiskparWinPE_FAT32NTFS.CheckedChanged

        LblDiskpartWinPE_FAT32Size.Visible = True
        TxtBoxDiskpartWinPE_FAT32Size.Visible = True
        LblDiskpartWinPE_NTFSSize.Visible = True
        TxtBoxDiskpartWinPE_NTFSSize.Visible = True

        LblDiskpartWinPE_System.Visible = False
        TxtBoxDiskpartWinPE_System.Visible = False
        LblDiskpartWinPE_MSR.Visible = False
        TxtBoxDiskpartWinPE_MSR.Visible = False
        LblDiskpartWinPE_Windows.Visible = False
        TxtBoxDiskpartWinPE_Windows.Visible = False
        LblDiskpartWinPE_Recovery.Visible = False
        TxtBoxDiskpartWinPE_Recovery.Visible = False
        PictBoxDiskpartWinPE_Picture.Load("USB_FAT32NTFS.PNG")
    End Sub
    '
    ' RadBtnDiskpartWinPE_HardDriveBIOS_CheckedChanged
    ' 
    ' Rev: 03/08/2022
    '
    Private Sub RadBtnDiskpartWinPE_HardDriveBIOS_CheckedChanged(sender As Object, e As EventArgs) Handles RadBtnDiskpartWinPE_HardDriveBIOS.CheckedChanged

        LblDiskpartWinPE_System.Visible = True
        TxtBoxDiskpartWinPE_System.Visible = True
        LblDiskpartWinPE_MSR.Visible = False
        TxtBoxDiskpartWinPE_MSR.Visible = False
        LblDiskpartWinPE_Windows.Visible = False
        TxtBoxDiskpartWinPE_Windows.Visible = False
        LblDiskpartWinPE_Recovery.Visible = True
        TxtBoxDiskpartWinPE_Recovery.Visible = True
        PictBoxDiskpartWinPE_Picture.Load("DefaultPartitionBIOS.PNG")
    End Sub
    '
    ' RadBtnDiskpartWinPE_HardDriveBIOS_CheckedChanged
    ' 
    ' Rev: 03/08/2022
    '
    Private Sub RadBtnDiskpartWinPE_HardDiskUEFI_CheckedChanged(sender As Object, e As EventArgs) Handles RadBtnDiskpartWinPE_HardDriveUEFI.CheckedChanged

        LblDiskpartWinPE_System.Visible = True
        TxtBoxDiskpartWinPE_System.Visible = True
        LblDiskpartWinPE_MSR.Visible = True
        TxtBoxDiskpartWinPE_MSR.Visible = True
        LblDiskpartWinPE_Windows.Visible = False
        TxtBoxDiskpartWinPE_Windows.Visible = False
        LblDiskpartWinPE_Recovery.Visible = True
        TxtBoxDiskpartWinPE_Recovery.Visible = True
        PictBoxDiskpartWinPE_Picture.Load("DefaultPartitionUEFI.PNG")
    End Sub
    '
    ' btnDiskpartWinPE_FormatDisk_Click
    ' 
    ' Rev: 03/08/2022
    '
    Private Sub btnDiskpartWinPE_FormatDisk_Click(sender As Object, e As EventArgs) Handles BtnDiskpartWinPE_FormatDisk.Click
        Dim Choice As DialogResult
        Dim ValueFAT32, ValueNTFS As ULong

        If CmbBoxDiskpartWinpe_SelectDrive.Text = "" Then
            MessageBox.Show("You must selected a disk drive before use this command")
            Exit Sub
        End If

        If RadBtnDiskpartWinPE_FAT32.Checked = True Then
            ULong.TryParse(TxtBoxDiskpartWinPE_FAT32Size.Text, ValueFAT32)
            If ValueFAT32 = 0 Then
                MessageBox.Show("Invalide FAT32 item !")
                Exit Sub
            Else
                If ValueFAT32 > 32768 Then
                    MessageBox.Show("FAT32 partition is limited at 32768 Mo !")
                    Exit Sub
                End If
            End If

            Try
                If System.IO.File.Exists("Script_USB_FAT32.txt") = True Then ' delete old file if exist
                    System.IO.File.Create("Script_USB_FAT32.txt").Dispose()
                End If
                ' creation new file on the current application directory
                Using sw As StreamWriter = New StreamWriter("Script_USB_FAT32.txt", True, Encoding.GetEncoding(CultureInfo.CurrentCulture.TextInfo.OEMCodePage))
                    sw.WriteLine("List Disk")
                    sw.WriteLine("Select Disk " & CmbBoxDiskpartWinpe_SelectDrive.Text)
                    sw.WriteLine("Clean")
                    sw.WriteLine("Rem === Create the Windows PE partition. ===")
                    sw.WriteLine("Create Partition Primary Size=" & TxtBoxDiskpartWinPE_FAT32Size.Text)
                    sw.WriteLine("Format Quick FS=FAT32 Label=""Windows PE""")
                    sw.WriteLine("Assign Letter=P")
                    sw.WriteLine("Active")
                    sw.WriteLine("List Vol")
                    sw.WriteLine("Exit")
                    sw.Close()
                End Using
            Catch ex As Exception
                MessageBox.Show("btnDiskpartWinPE_FormatDisk_Click Error on created filename Script_USB_FAT32.txt: " + ex.Message.ToString())
            End Try

            Choice = MessageBox.Show("Are you sure you want to format disk " & CmbBoxDiskpartWinpe_SelectDrive.Text & " ?", "Exit ?", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
            If Choice = DialogResult.Yes Then
                RunDosCommand("Diskpart", "/s Script_USB_FAT32.txt", True)
            End If
        End If

        If RadBtnDiskpartWinPE_NTFS.Checked = True Then
            ULong.TryParse(TxtBoxDiskpartWinPE_NTFSSize.Text, ValueNTFS)
            If ValueNTFS = 0 Then
                MessageBox.Show("Invalide NTFS item !")
                Exit Sub
            Else
                ' To do, check limite of support media
            End If
            Try
                If System.IO.File.Exists("Script_USB_NTFS.txt") = True Then ' delete old file if exist
                    System.IO.File.Create("Script_USB_NTFS.txt").Dispose()
                End If
                ' creation new file on the current application directory
                Using sw As StreamWriter = New StreamWriter("Script_USB_NTFS.txt", True, Encoding.GetEncoding(CultureInfo.CurrentCulture.TextInfo.OEMCodePage))
                    sw.WriteLine("List Disk")
                    sw.WriteLine("Select Disk " & CmbBoxDiskpartWinpe_SelectDrive.Text)
                    sw.WriteLine("Clean")
                    sw.WriteLine("Rem === Create the Windows PE partition. ===")
                    sw.WriteLine("Create Partition Primary Size=" & TxtBoxDiskpartWinPE_NTFSSize.Text)
                    sw.WriteLine("Format Quick FS=NTFS Label=""Windows PE""")
                    sw.WriteLine("Assign Letter=P")
                    sw.WriteLine("Active")
                    sw.WriteLine("List Vol")
                    sw.WriteLine("Exit")
                    sw.Close()
                End Using
            Catch ex As Exception
                ' Let the user know what went wrong.
                'Console.WriteLine("The file could not be read:")
                'Console.WriteLine(e.Message)
                MessageBox.Show("btnDiskpartWinPE_FormatDisk_Click Error on created filename Script_USB_NTFS.txt: " + ex.Message.ToString())
            End Try
            Choice = MessageBox.Show("Are you sure you want to format disk " & CmbBoxDiskpartWinpe_SelectDrive.Text & " ?", "Exit ?", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
            If Choice = DialogResult.Yes Then
                RunDosCommand("Diskpart", "/s Script_USB_NTFS.txt", True)
            End If
        End If

        If RadBtnDiskparWinPE_FAT32NTFS.Checked = True Then
            ULong.TryParse(TxtBoxDiskpartWinPE_FAT32Size.Text, ValueFAT32)
            If ValueFAT32 = 0 Then
                MessageBox.Show("Invalide FAT32 item !")
                Exit Sub
            Else
                If ValueFAT32 > 32768 Then
                    MessageBox.Show("FAT32 partition is limited at 32768 Mo !")
                    Exit Sub
                End If
            End If
            ULong.TryParse(TxtBoxDiskpartWinPE_NTFSSize.Text, ValueNTFS)
            If ValueNTFS = 0 Then
                MessageBox.Show("Invalide NTFS item !")
                Exit Sub
            Else
                ' To do, check limite of support media
            End If
            Try
                If System.IO.File.Exists("Script_USB_FAT32NTFS.txt") = True Then ' delete old file if exist
                    System.IO.File.Create("Script_USB_FAT32NTFS.txt").Dispose()
                End If
                ' creation new file on the current application directory
                Using sw As StreamWriter = New StreamWriter("Script_USB_FAT32NTFS.txt", True, Encoding.GetEncoding(CultureInfo.CurrentCulture.TextInfo.OEMCodePage))
                    sw.WriteLine("List Disk")
                    sw.WriteLine("Select disk " & CmbBoxDiskpartWinpe_SelectDrive.Text)
                    sw.WriteLine("Clean")
                    sw.WriteLine("Rem === Create the Windows PE partition. ===")
                    sw.WriteLine("Create Partition Primary Size=" & TxtBoxDiskpartWinPE_FAT32Size.Text)
                    sw.WriteLine("Format Quick FS=FAT32 Label=""Windows PE""")
                    sw.WriteLine("Assign Letter=P")
                    sw.WriteLine("Active")
                    sw.WriteLine("Rem === Create partition for images ===")
                    sw.WriteLine("Create Partition Primary Size=" & TxtBoxDiskpartWinPE_NTFSSize.Text)
                    sw.WriteLine("Format Quick FS=NTFS Label=Images")
                    sw.WriteLine("Assign Letter=I")
                    sw.WriteLine("List Vol")
                    sw.WriteLine("Exit")
                    sw.Close()
                End Using
            Catch ex As Exception
                ' Let the user know what went wrong.
                'Console.WriteLine("The file could not be read:")
                'Console.WriteLine(e.Message)
                MessageBox.Show("btnDiskpartWinPE_FormatDisk_Click Error on created filename Script_USB_FAT32NTFS.txt: " + ex.Message.ToString())
            End Try
            Choice = MessageBox.Show("Are you sure you want to format disk " & CmbBoxDiskpartWinpe_SelectDrive.Text & " ?", "Exit ?", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
            If Choice = DialogResult.Yes Then
                RunDosCommand("Diskpart", "/s Script_USB_FAT32NTFS.txt", True)
            End If
        End If

        If RadBtnDiskpartWinPE_HardDriveBIOS.Checked = True Then
            Try
                If System.IO.File.Exists("Script_HardDiskBIOS.txt") = True Then ' delete old file if exist
                    System.IO.File.Create("Script_HardDiskBIOS.txt").Dispose()
                End If
                ' creation new file on the current application directory
                Using sw As StreamWriter = New StreamWriter("Script_HardDiskBIOS.txt", True, Encoding.GetEncoding(CultureInfo.CurrentCulture.TextInfo.OEMCodePage))
                    sw.WriteLine("List Disk")
                    sw.WriteLine("Select Disk " & CmbBoxDiskpartWinpe_SelectDrive.Text)
                    sw.WriteLine("Clean")
                    sw.WriteLine("Rem == 1. System partition ==")
                    sw.WriteLine("Create Partition Primary Size=" & TxtBoxDiskpartWinPE_System.Text)
                    sw.WriteLine("Format Quick FS=NTFS Label=System")
                    sw.WriteLine("Assign Letter=""S""")
                    sw.WriteLine("Active")
                    sw.WriteLine("Rem == 2. Windows partition ==")
                    sw.WriteLine("Create Partition Primary")
                    sw.WriteLine("Shrink Minimum=" & TxtBoxDiskpartWinPE_Recovery.Text)
                    sw.WriteLine("Format Quick FS=NTFS Label=Windows")
                    sw.WriteLine("Assign letter=""W""")
                    sw.WriteLine("Rem == 3. Recovery partition ==")
                    sw.WriteLine("Create Partition Primary")
                    sw.WriteLine("Format Quick FS=NTFS Label=Recovery")
                    sw.WriteLine("Assign Letter=""R""")
                    sw.WriteLine("Set Id=27")
                    sw.WriteLine("List Vol")
                    sw.WriteLine("Exit")
                    sw.Close()
                End Using
            Catch ex As Exception
                ' Let the user know what went wrong.
                'Console.WriteLine("The file could not be read:")
                'Console.WriteLine(e.Message)
                MessageBox.Show("btnDiskpartWinPE_FormatDisk_Click Error on created filename Script_HardDiskBIOS.txt: " + ex.Message.ToString())
            End Try
            Choice = MessageBox.Show("Are you sure you want to format disk " & CmbBoxDiskpartWinpe_SelectDrive.Text & " ?", "Exit ?", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
            If Choice = DialogResult.Yes Then
                RunDosCommand("Diskpart", "/s Script_HardDiskBIOS.txt", True)
            End If
        End If

        If RadBtnDiskpartWinPE_HardDriveUEFI.Checked = True Then
            Try
                If System.IO.File.Exists("Script_HardDiskUEFI.txt") = True Then ' delete old file if exist
                    System.IO.File.Create("Script_HardDiskUEFI.txt").Dispose()
                End If
                ' creation new file on the current application directory
                Using sw As StreamWriter = New StreamWriter("Script_HardDiskUEFI.txt", True, Encoding.GetEncoding(CultureInfo.CurrentCulture.TextInfo.OEMCodePage))
                    sw.WriteLine("Select Disk " & CmbBoxDiskpartWinpe_SelectDrive.Text)
                    sw.WriteLine("Clean")
                    sw.WriteLine("Convert GPT")
                    sw.WriteLine("Rem == 1. System Partition ==")
                    sw.WriteLine("Create Partition EFI Size=" & TxtBoxDiskpartWinPE_System.Text)
                    sw.WriteLine("Format Quick FS=FAT32 Label=System")
                    sw.WriteLine("Assign Letter=""S""")
                    sw.WriteLine("Rem == 2. Microsoft Reserved (MSR) partition ==")
                    sw.WriteLine("Create Partition MSR Size=" & TxtBoxDiskpartWinPE_MSR.Text)
                    sw.WriteLine("Rem == 3. Windows Partition ==")
                    sw.WriteLine("Create Partition Primary")
                    sw.WriteLine("Shrink Minimum=" & TxtBoxDiskpartWinPE_Recovery.Text)
                    sw.WriteLine("Format Quick FS=NTFS Label=Windows")
                    sw.WriteLine("Assign Letter=""W""")
                    sw.WriteLine("Create Partition Primary")
                    sw.WriteLine("Format Quick FS=NTFS Label=Recovery")
                    sw.WriteLine("Assign Letter=""R""")
                    sw.WriteLine("Set ID=de94bba4-06d1-4d40-a16a-bfd50179d6ac")
                    sw.WriteLine("Gpt Attributes=0x8000000000000001")
                    sw.WriteLine("Exit")
                    sw.Close()
                End Using
            Catch ex As Exception
                ' Let the user know what went wrong.
                'Console.WriteLine("The file could not be read:")
                'Console.WriteLine(e.Message)
                MessageBox.Show("btnDiskpartWinPE_FormatDisk_Click Error on created filename Script_HardDiskUEFI.txt: " + ex.Message.ToString())
            End Try
            Choice = MessageBox.Show("Are you sure you want to format disk " & CmbBoxDiskpartWinpe_SelectDrive.Text & " ?", "Exit ?", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
            If Choice = DialogResult.Yes Then
                RunDosCommand("Diskpart", "/s Script_HardDiskUEFI.txt", True)
            End If
        End If
    End Sub
    '
    ' RunDosCommand
    ' Launch an asynchrone processus in a dos windows
    ' permanent True for cmd /k
    ' permanent False for cmd /c (close windows when finish command)
    ' Rev: 06/08/2022
    '
    Public Sub RunDosCommand(Command As String, Arguments As String, Permanent As Boolean)
        Dim Proc As Process = New Process()
        Dim ProcInfo As ProcessStartInfo = New ProcessStartInfo()
        Dim ExitCode As Integer

        Try
            ProcInfo.Arguments = " " + If(Permanent = True, "/K", "/C") + " " + Command + " " + Arguments
            'MessageBox.Show(ProcInfo.Arguments)
            ProcInfo.FileName = "cmd.exe"
            Proc.StartInfo = ProcInfo
            Proc.Start()
            Proc.WaitForExit()
            ExitCode = Proc.ExitCode
            Proc.Close()
        Catch ex As Exception
            MessageBox.Show(ex.Message.ToString())
        End Try
    End Sub
    '
    ' RunDosCommand
    ' Launch an asynchrone processus in a dos windows
    ' Rev: 14/08/2022
    ' Note: procInfo.Verb = "runas" is important to made bcdboot correctly
    ' to see (check with whoami /all advanced options)
    ' but user is not explicitly referenced and in this case i'm a standard admin.
    '
    Public Sub RunDosCommand2()
        Dim Proc As Process = New Process()
        Dim ProcInfo As ProcessStartInfo = New ProcessStartInfo()
        Dim ExitCode As Integer
        Try
            ProcInfo.UseShellExecute = True
            ProcInfo.FileName = System.IO.Directory.GetCurrentDirectory() & "\updatebcdboot.bat"
            ProcInfo.WorkingDirectory = System.IO.Directory.GetCurrentDirectory()
            ProcInfo.Verb = "runas"
            Proc.StartInfo = ProcInfo
            Proc.Start()
            Proc.WaitForExit()
            ExitCode = Proc.ExitCode
            Proc.Close()
        Catch ex As Exception
            MessageBox.Show(ex.Message.ToString())
        End Try
    End Sub

    '
    ' RunAsDosCommand
    ' Launch an asynchrone processus in a dos windows
    ' permanent True for cmd /k
    ' permanent False for cmd /c (close windows when finish command)
    ' Rev: 06/08/2022
    '
    Public Sub RunAsDosCommand(Utilisateur As String, Command As String, Arguments As String, Permanent As Boolean)
        Dim Proc As Process = New Process()
        Dim ProcInfo As ProcessStartInfo = New ProcessStartInfo()
        Dim ExitCode As Integer

        Try
            ProcInfo.Arguments = "/User:" + """" + Utilisateur + """" + " ""cmd.exe " + If(Permanent = True, "/K", "/C") + " " + Command + " " + Arguments + """"
            ' MessageBox.Show(ProcInfo.Arguments)
            ProcInfo.FileName = "RunAs"
            Proc.StartInfo = ProcInfo
            Proc.Start()
            Proc.WaitForExit()
            ExitCode = Proc.ExitCode
            Proc.Close()
        Catch ex As Exception
            MessageBox.Show(ex.Message.ToString())
        End Try
    End Sub
    '
    ' BtnDiskpartWinPE_CreateWinPETemplate_Click
    ' Warning: WinPE require
    ' Create a template of WinPE on drive C: (C:\WinPE_x86 or C:\Winpe_amd64)
    ' To do check ADK install and find ADK path automaticaly
    ' Rev: 06/08/2022
    '
    Private Sub BtnDiskpartWinPE_CreateWinPETemplate_Click(sender As Object, e As EventArgs) Handles BtnDiskpartWinPE_CreateWinPETemplate.Click
        Dim DeleteFolder As IEnumerable
        Dim DeleteFile As String
        Dim Choice As DialogResult

        If RadBtnDiskpartWinPE_WinPEx86.Checked = True Then
            If System.IO.Directory.Exists("C:\WinPE_x86") = True Then
                MessageBox.Show("C:\WinPE_x86 folder already exist !")
                Try
                    Choice = MessageBox.Show("Are you sure you want to delete all files in folder C:\WinPE_x86 ?", "Delete Files ?", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
                    If Choice = DialogResult.Yes Then
                        For Each DeleteFile In Directory.GetFiles("C:\WinPE_x86", "*.*", SearchOption.AllDirectories)
                            File.Delete(DeleteFile)
                        Next
                        For Each DeleteFolder In Directory.EnumerateDirectories("C:\WinPE_x86", "*", SearchOption.AllDirectories).OrderByDescending(Function(p) p.Length)
                            System.IO.Directory.Delete(DeleteFolder.ToString)
                        Next
                        System.IO.Directory.Delete("C:\WinPE_x86")
                        txtOutput.Text = "Folder C:\WinPE_x86 is deleted !" & vbCrLf
                        txtOutput.AppendText("You can regenerate it by clic on button ""Create WinPE template  on drive C:""")
                    End If
                Catch ex As Exception
                    MessageBox.Show("Error when deleting C:\WinPE_x86: " + ex.Message.ToString())
                End Try
            Else
                RunDosCommand("""C:\Program Files (x86)\Windows Kits\10\Assessment and Deployment Kit\Deployment Tools\DandISetEnv.bat""", "&&copype x86 C:\WinPE_x86", True)
                txtOutput.Text = "C:\WinPE_x86 is created !"
            End If
        End If

        If RadBtnDiskpartWinPE_WinPEamd64.Checked = True Then
            If System.IO.Directory.Exists("C:\WinPE_amd64") = True Then
                MessageBox.Show("C:\WinPE_amd64 folder already exist !")
                Try
                    Choice = MessageBox.Show("Are you sure you want to delete all files in folder C:\WinPE_amd64 ?", "Delete Files ?", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
                    If Choice = DialogResult.Yes Then
                        For Each DeleteFile In Directory.GetFiles("C:\WinPE_amd64", "*.*", SearchOption.AllDirectories)
                            File.Delete(DeleteFile)
                        Next
                        For Each DeleteFolder In Directory.EnumerateDirectories("C:\WinPE_amd64", "*", SearchOption.AllDirectories).OrderByDescending(Function(p) p.Length)
                            System.IO.Directory.Delete(DeleteFolder.ToString)
                        Next
                        System.IO.Directory.Delete("C:\WinPE_amd64")
                        txtOutput.Text = "Folder C:\WinPE_amd64 is deleted !" & vbCrLf
                        txtOutput.AppendText("You can regenerate it by clic on button ""Create WinPE template  on drive C:""")
                    End If
                Catch ex As Exception
                    MessageBox.Show("Error when deleting C:\WinPE_amd64: " + ex.Message.ToString())
                End Try
            Else
                RunDosCommand("""C:\Program Files (x86)\Windows Kits\10\Assessment and Deployment Kit\Deployment Tools\DandISetEnv.bat""", "&&copype amd64 C:\WinPE_amd64", True)
                txtOutput.Text = "C:\WinPE_amd64 is created !"
            End If
        End If
    End Sub
    '
    ' BtnDiskpartWinPE_BootDiskWinPE_Click
    ' Apply WinPE (customized or not), on logical P: drive
    ' These options are used for USB media only
    '
    ' Rev: 06/08/2022
    '
    Private Sub BtnDiskpartWinPE_BootDiskWinPE_Click(sender As Object, e As EventArgs) Handles BtnDiskpartWinPE_BootDiskWinPE.Click

        If RadBtnDiskpartWinPE_WinPEx86.Checked = True And System.IO.Directory.Exists("C:\WinPE_x86") = True Then
            'RunDosCommand("Dism", "/Apply-Image /ImageFile:C:\WinPE_x86\media\sources\boot.wim /Index:1 /ApplyDir:P:\", False)
            WriteWinPEOnUSB("C:\WinPE_x86\media", "P:")
            txtOutput.AppendText("WinPE x86 is on USB media !" & vbCrLf)
            'RunDosCommand("cmd_k.cmd", "BCDBoot P:\Windows /s P: /f All", False)
            'txtOutput.AppendText("BCDBoot (BCDBoot P:\Windows /s P: /f ALL) is updated on USB media" & vbCrLf)

        End If

        If RadBtnDiskpartWinPE_WinPEamd64.Checked = True And System.IO.Directory.Exists("C:\WinPE_amd64") = True Then
            'RunDosCommand("Dism", "/Apply-Image /ImageFile:C:\WinPE_amd64\media\sources\boot.wim /Index:1 /ApplyDir:P:\", False)
            WriteWinPEOnUSB("C:\WinPE_amd64\media", "P:")
            txtOutput.AppendText("WinPE amd64 is on USB media !" & vbCrLf)
            'RunDosCommand("cmd_k.cmd", "BCDBoot P:\Windows /s P: /f All", False)
            'txtOutput.AppendText("BCDBoot (BCDBoot P:\Windows /s P: /f ALL) is updated on USB media" & vbCrLf)
        End If
    End Sub
    '
    ' Clone template WinPE media on USB key
    ' Another way to do this is commands: xcopy or robocopy
    ' Rev: 22/03/2023
    Private Sub WriteWinPEOnUSB(SourcePath As String, TargetPath As String)
        Dim ListFiles() As String
        Dim ListDir() As String
        Dim DirToCreate As String
        Dim StartTime As DateTime
        Dim EndTime As DateTime

        Try
            StartTime = DateTime.Now
            txtOutput.AppendText("At " & StartTime & ": Start copying WinPE on USB key (Volume P:), waiting..." & vbCrLf)
            ListDir = Directory.GetDirectories(SourcePath, "*", SearchOption.AllDirectories)
            For Each Dir As String In ListDir
                DirToCreate = Dir.Replace(SourcePath, TargetPath)
                Directory.CreateDirectory(DirToCreate)
            Next

            ListFiles = Directory.GetFiles(SourcePath, "*.*", SearchOption.AllDirectories)
            For Each Filename As String In ListFiles
                File.Copy(Filename, Filename.Replace(SourcePath, TargetPath), True)
            Next
            EndTime = DateTime.Now
            txtOutput.AppendText("At " & EndTime & ": Copy is terminated !" & vbCrLf)
            txtOutput.AppendText("Duration: " & EndTime.Subtract(StartTime).ToString & vbCrLf)
        Catch ex As Exception
            MessageBox.Show(ex.Message.ToString())
        End Try
    End Sub
    '
    ' BtnPackageManagement_ChoosePackagePath_Click
    '
    ' Rev: 15/08/2022
    '
    Private Sub BtnPackageManagement_ChoosePackagePath_Click(sender As Object, e As EventArgs) Handles BtnPackageManagement_ChoosePackagePath.Click
        txtPackagePath.Text = OpenFolder()
    End Sub
    '
    ' BtnCustomWinPE_RefreshMountedImage_Click
    '
    ' Rev: 15/08/2022
    '
    Private Sub BtnCustomWinPE_RefreshMountedImage_Click(sender As Object, e As EventArgs) Handles BtnCustomWinPE_RefreshMountedImage.Click

        DisplayMountedImageInfo("Tab_CustomWinPE.txt")     ' on console and create file "MountedImageInfo.txt" 
        UpdateForMountedImageInfo("Tab_CustomWinPE.txt", CmbBoxCustomWinPE_UseImageMounted)
    End Sub
    '
    ' BtnCustomWinPE_GetMountedImageInfo_Click
    '
    ' Rev: 15/08/2022
    '
    Private Sub BtnCustomWinPE_GetMountedImageInfo_Click(sender As Object, e As EventArgs) Handles BtnCustomWinPE_GetMountedImageInfo.Click


        txtOutput.Text = ""
        strDISMArguments = "/Get-MountedImageInfo"

        txtOutput.Text = "Command line that running is:" & vbCrLf & "Dism.exe " & strDISMArguments & vbCrLf
        BackgroundWorkerDISMCommand.RunWorkerAsync(strDISMArguments)
        frmProgress.ShowDialog()
        txtOutput.Text = txtOutput.Text & strOutput & vbCrLf & "Exit code:" & strDISMExitCode
    End Sub
    '
    ' BtnCustomWinPE_DetectADK_Click
    ' User can change the constant value of the Deployment Tools Kits if microsoft change it !
    ' Rev: 17/04/2023
    '
    Private Sub BtnCustomWinPE_DetectADK_Click(sender As Object, e As EventArgs) Handles BtnCustomWinPE_DetectADK.Click
        Const KitsRootRegValueName As String = "KitsRoot10"
        Dim ReadValue, ReadValueWOW6432 As String

        ReadValue = My.Computer.Registry.GetValue("HKEY_LOCAL_MACHINE\Software\Microsoft\Windows Kits\Installed Roots", KitsRootRegValueName, Nothing)
        ReadValueWOW6432 = My.Computer.Registry.GetValue("HKEY_LOCAL_MACHINE\SOFTWARE\WOW6432Node\Microsoft\Windows Kits\Installed Roots", KitsRootRegValueName, Nothing)
        If (IsNothing(ReadValue) And IsNothing(ReadValueWOW6432)) Then
            MessageBox.Show("KitsRoot not found, can't set common path for Deployment Tools.")
            Exit Sub
        End If
        If (ReadValueWOW6432 <> "") Then
            ' MessageBox.Show("ReadValueWOW6432: " & ReadValueWOW6432)
            TxtBoxCustomWinPE_DetectADKPath.Text = ReadValueWOW6432
        Else
            ' MessageBox.Show("ReadValue: " & ReadValue)
            TxtBoxCustomWinPE_DetectADKPath.Text = ReadValue
        End If
    End Sub
    '
    ' BtnCustomWinPE_DetectADK_Click
    '
    ' Rev: 29/08/2022
    '
    Private Sub BtnCustomWinPE_Apply_Click(sender As Object, e As EventArgs) Handles BtnCustomWinPE_Apply.Click
        Dim ADK_Path As String = Nothing

        txtOutput.Text = ""

        If (CmbBoxCustomWinPE_UseImageMounted.Text = "") Then
            MessageBox.Show("You must Select a mounted image To use this command.")
            Exit Sub
        End If

        If TxtBoxCustomWinPE_DetectADKPath.Text <> "" Then
            ADK_Path = TxtBoxCustomWinPE_DetectADKPath.Text & "Assessment And Deployment Kit\Windows Preinstallation Environment\"
        Else
            MessageBox.Show("ADK Path Is Not valide, check your system")
            Exit Sub
        End If

        If CmbBoxCustomWinPE_Language.Text = "" Then
            MessageBox.Show("Language Is require To use this command, check your system")
            Exit Sub
        End If
        If RadBtnCustomWinPE_TypeAmd64.Checked = True Then
            ADK_Path = ADK_Path & "amd64\WinPE_OCs\"
        Else
            ADK_Path = ADK_Path & "x86\WinPE_OCs\"
        End If

        strDISMArguments = "/Add-Package /Image:" & """" & CmbBoxCustomWinPE_UseImageMounted.Text & """" & " /PackagePath:" & """" & ADK_Path & CmbBoxCustomWinPE_Language.Text & "\" & "lp.cab"""
        txtOutput.Text = txtOutput.Text & "Command line that running is:" & vbCrLf & "Dism.exe " & strDISMArguments & vbCrLf
        BackgroundWorkerDISMCommand.RunWorkerAsync(strDISMArguments)
        frmProgress.ShowDialog()
        txtOutput.Text = txtOutput.Text & strOutput & vbCrLf & "Exit code:" & strDISMExitCode & vbCrLf & vbCrLf

        strDISMArguments = "/Image:" + """" + CmbBoxCustomWinPE_UseImageMounted.Text + """" + " /Set-AllIntl:" + CmbBoxCustomWinPE_Language.Text
        txtOutput.Text = txtOutput.Text & "Command line that running is:" & vbCrLf & "Dism.exe " & strDISMArguments & vbCrLf
        BackgroundWorkerDISMCommand.RunWorkerAsync(strDISMArguments)
        frmProgress.ShowDialog()
        txtOutput.Text = txtOutput.Text & strOutput & vbCrLf & "Exit code:" & strDISMExitCode & vbCrLf & vbCrLf

        If ChkboxCustomWinPE_HTA.Checked = True Then

            strDISMArguments = "/Add-Package /Image:" & """" & CmbBoxCustomWinPE_UseImageMounted.Text & """" & " /PackagePath:" & """" & ADK_Path & "WinPE-HTA.cab"""
            txtOutput.Text = txtOutput.Text & "Command line that running is:" & vbCrLf & "Dism.exe " & strDISMArguments & vbCrLf
            BackgroundWorkerDISMCommand.RunWorkerAsync(strDISMArguments)
            frmProgress.ShowDialog()
            txtOutput.Text = txtOutput.Text & strOutput & vbCrLf & "Exit code:" & strDISMExitCode & vbCrLf & vbCrLf

            strDISMArguments = "/Add-Package /Image:" & """" & CmbBoxCustomWinPE_UseImageMounted.Text & """" & " /PackagePath:" & """" & ADK_Path & CmbBoxCustomWinPE_Language.Text & "\" & "WinPE-HTA_fr-fr.cab"""
            txtOutput.Text = txtOutput.Text & "Command line that running is:" & vbCrLf & "Dism.exe " & strDISMArguments & vbCrLf
            BackgroundWorkerDISMCommand.RunWorkerAsync(strDISMArguments)
            frmProgress.ShowDialog()
            txtOutput.Text = txtOutput.Text & strOutput & vbCrLf & "Exit code:" & strDISMExitCode
        End If

        If ChkboxCustomWinPE_MDAC.Checked = True Then

            strDISMArguments = "/Add-Package /Image:" & """" & CmbBoxCustomWinPE_UseImageMounted.Text & """" & " /PackagePath:" & """" & ADK_Path & "WinPE-MDAC.cab"""
            txtOutput.Text = txtOutput.Text & "Command line that running is:" & vbCrLf & "Dism.exe " & strDISMArguments & vbCrLf
            BackgroundWorkerDISMCommand.RunWorkerAsync(strDISMArguments)
            frmProgress.ShowDialog()
            txtOutput.Text = txtOutput.Text & strOutput & vbCrLf & "Exit code:" & strDISMExitCode & vbCrLf & vbCrLf

            strDISMArguments = "/Add-Package /Image:" & """" & CmbBoxCustomWinPE_UseImageMounted.Text & """" & " /PackagePath:" & """" & ADK_Path & CmbBoxCustomWinPE_Language.Text & "\" & "WinPE-MDAC_fr-fr.cab"""
            txtOutput.Text = txtOutput.Text & "Command line that running is:" & vbCrLf & "Dism.exe " & strDISMArguments & vbCrLf
            BackgroundWorkerDISMCommand.RunWorkerAsync(strDISMArguments)
            frmProgress.ShowDialog()
            txtOutput.Text = txtOutput.Text & strOutput & vbCrLf & "Exit code:" & strDISMExitCode
        End If

        If ChkboxCustomWinPE_WMI.Checked = True Then

            strDISMArguments = "/Add-Package /Image:" & """" & CmbBoxCustomWinPE_UseImageMounted.Text & """" & " /PackagePath:" & """" & ADK_Path & "WinPE-WMI.cab"""
            txtOutput.Text = txtOutput.Text & "Command line that running is:" & vbCrLf & "Dism.exe " & strDISMArguments & vbCrLf
            BackgroundWorkerDISMCommand.RunWorkerAsync(strDISMArguments)
            frmProgress.ShowDialog()
            txtOutput.Text = txtOutput.Text & strOutput & vbCrLf & "Exit code:" & strDISMExitCode & vbCrLf & vbCrLf

            strDISMArguments = "/Add-Package /Image:" & """" & CmbBoxCustomWinPE_UseImageMounted.Text & """" & " /PackagePath:" & """" & ADK_Path & CmbBoxCustomWinPE_Language.Text & "\" & "WinPE-WMI_fr-fr.cab"""
            txtOutput.Text = txtOutput.Text & "Command line that running is:" & vbCrLf & "Dism.exe " & strDISMArguments & vbCrLf
            BackgroundWorkerDISMCommand.RunWorkerAsync(strDISMArguments)
            frmProgress.ShowDialog()
            txtOutput.Text = txtOutput.Text & strOutput & vbCrLf & "Exit code:" & strDISMExitCode
        End If

        If ChkboxCustomWinPE_NetFx.Checked = True Then

            strDISMArguments = "/Add-Package /Image:" & """" & CmbBoxCustomWinPE_UseImageMounted.Text & """" & " /PackagePath:" & """" & ADK_Path & "WinPE-NetFx.cab"""
            txtOutput.Text = txtOutput.Text & "Command line that running is:" & vbCrLf & "Dism.exe " & strDISMArguments & vbCrLf
            BackgroundWorkerDISMCommand.RunWorkerAsync(strDISMArguments)
            frmProgress.ShowDialog()
            txtOutput.Text = txtOutput.Text & strOutput & vbCrLf & "Exit code:" & strDISMExitCode & vbCrLf & vbCrLf

            strDISMArguments = "/Add-Package /Image:" & """" & CmbBoxCustomWinPE_UseImageMounted.Text & """" & " /PackagePath:" & """" & ADK_Path & CmbBoxCustomWinPE_Language.Text & "\" & "WinPE-NetFx_fr-fr.cab"""
            txtOutput.Text = txtOutput.Text & "Command line that running is:" & vbCrLf & "Dism.exe " & strDISMArguments & vbCrLf
            BackgroundWorkerDISMCommand.RunWorkerAsync(strDISMArguments)
            frmProgress.ShowDialog()
            txtOutput.Text = txtOutput.Text & strOutput & vbCrLf & "Exit code:" & strDISMExitCode
        End If

        If ChkboxCustomWinPE_PowerShell.Checked = True Then

            strDISMArguments = "/Add-Package /Image:" & """" & CmbBoxCustomWinPE_UseImageMounted.Text & """" & " /PackagePath:" & """" & ADK_Path & "WinPE-PowerShell.cab"""
            txtOutput.Text = txtOutput.Text & "Command line that running is:" & vbCrLf & "Dism.exe " & strDISMArguments & vbCrLf
            BackgroundWorkerDISMCommand.RunWorkerAsync(strDISMArguments)
            frmProgress.ShowDialog()
            txtOutput.Text = txtOutput.Text & strOutput & vbCrLf & "Exit code:" & strDISMExitCode & vbCrLf & vbCrLf

            strDISMArguments = "/Add-Package /Image:" & """" & CmbBoxCustomWinPE_UseImageMounted.Text & """" & " /PackagePath:" & """" & ADK_Path & CmbBoxCustomWinPE_Language.Text & "\" & "WinPE-PowerShell_fr-fr.cab"""
            txtOutput.Text = txtOutput.Text & "Command line that running is:" & vbCrLf & "Dism.exe " & strDISMArguments & vbCrLf
            BackgroundWorkerDISMCommand.RunWorkerAsync(strDISMArguments)
            frmProgress.ShowDialog()
            txtOutput.Text = txtOutput.Text & strOutput & vbCrLf & "Exit code:" & strDISMExitCode
        End If

        If ChkboxCustomWinPE_Scripting.Checked = True Then

            strDISMArguments = "/Add-Package /Image:" & """" & CmbBoxCustomWinPE_UseImageMounted.Text & """" & " /PackagePath:" & """" & ADK_Path & "WinPE-Scripting.cab"""
            txtOutput.Text = txtOutput.Text & "Command line that running is:" & vbCrLf & "Dism.exe " & strDISMArguments & vbCrLf
            BackgroundWorkerDISMCommand.RunWorkerAsync(strDISMArguments)
            frmProgress.ShowDialog()
            txtOutput.Text = txtOutput.Text & strOutput & vbCrLf & "Exit code:" & strDISMExitCode & vbCrLf & vbCrLf

            strDISMArguments = "/Add-Package /Image:" & """" & CmbBoxCustomWinPE_UseImageMounted.Text & """" & " /PackagePath:" & """" & ADK_Path & CmbBoxCustomWinPE_Language.Text & "\" & "WinPE-Scripting_fr-fr.cab"""
            txtOutput.Text = txtOutput.Text & "Command line that running is:" & vbCrLf & "Dism.exe " & strDISMArguments & vbCrLf
            BackgroundWorkerDISMCommand.RunWorkerAsync(strDISMArguments)
            frmProgress.ShowDialog()
            txtOutput.Text = txtOutput.Text & strOutput & vbCrLf & "Exit code:" & strDISMExitCode
        End If

        If ChkboxCustomWinPE_StorageWMI.Checked = True Then

            strDISMArguments = "/Add-Package /Image:" & """" & CmbBoxCustomWinPE_UseImageMounted.Text & """" & " /PackagePath:" & """" & ADK_Path & "WinPE-StorageWMI.cab"""
            txtOutput.Text = txtOutput.Text & "Command line that running is:" & vbCrLf & "Dism.exe " & strDISMArguments & vbCrLf
            BackgroundWorkerDISMCommand.RunWorkerAsync(strDISMArguments)
            frmProgress.ShowDialog()
            txtOutput.Text = txtOutput.Text & strOutput & vbCrLf & "Exit code:" & strDISMExitCode & vbCrLf & vbCrLf

            strDISMArguments = "/Add-Package /Image:" & """" & CmbBoxCustomWinPE_UseImageMounted.Text & """" & " /PackagePath:" & """" & ADK_Path & CmbBoxCustomWinPE_Language.Text & "\" & "WinPE-StorageWMI_fr-fr.cab"""
            txtOutput.Text = txtOutput.Text & "Command line that running is:" & vbCrLf & "Dism.exe " & strDISMArguments & vbCrLf
            BackgroundWorkerDISMCommand.RunWorkerAsync(strDISMArguments)
            frmProgress.ShowDialog()
            txtOutput.Text = txtOutput.Text & strOutput & vbCrLf & "Exit code:" & strDISMExitCode
        End If
    End Sub
    ' 
    ' Run an async command processus DISM.exe
    ' display line argument of dism command, result and exit code of processus
    ' strInput is the command line argument
    ' Rev: 31/07/2022
    '
    Private Sub BackgroundWorkerDismCommand2_DoWork(sender As Object, e As System.ComponentModel.DoWorkEventArgs) Handles BackgroundWorkerDismCommand2.DoWork
        Dim strInput As String = e.Argument  ' retreive argument of dism command
        Dim DISM As New Process()            ' create new process for DISM processus

        strDISMExitCode = ""                 ' reset exit code for processus
        DISM.StartInfo.RedirectStandardOutput = True ' redirect output console enabled
        DISM.StartInfo.StandardOutputEncoding = Encoding.GetEncoding(CultureInfo.CurrentCulture.TextInfo.OEMCodePage) ' encodage OEM
        DISM.StartInfo.RedirectStandardError = True  ' redirect standard error
        DISM.StartInfo.UseShellExecute = False       ' no shell
        DISM.StartInfo.CreateNoWindow = True         ' no window
        DISM.StartInfo.FileName = "C:\Program Files (x86)\Windows Kits\10\Assessment and Deployment Kit\Deployment Tools\DandISetEnv.bat"         ' name of processus call
        DISM.StartInfo.Arguments = strInput          ' arguments for command ligne
        'txtOutput.Text = "Command line that running is: dism.exe " & DISM.StartInfo.Arguments & vbCrLf ' show result command line
        'strOutput = "Command line that running is:" & vbCrLf & "dism.exe " & DISM.StartInfo.Arguments & vbCrLf 'save in global variable
        DISM.Start()                                 ' start async processus
        strOutput = DISM.StandardOutput.ReadToEnd()  ' save in global variable read console
        DISM.WaitForExit()                           ' wait for end of processus
        strDISMExitCode = DISM.ExitCode              ' store exit code of processus
        'strOutput = strOutput & "Exit code:" & strDISMExitCode      ' add exit return code
        ' txtOutput.Text = txtOutput.Text & strOutput & vbCrLf & "Exit code processus: " & DISM.ExitCode
        DISM.Close()                                 ' close processus
    End Sub
    Private Sub BackgroundWorkerDismCommand2_RunWorkerCompleted(sender As Object, e As System.ComponentModel.RunWorkerCompletedEventArgs) Handles BackgroundWorkerDismCommand2.RunWorkerCompleted

        strDISMArguments = "" ' empty arguments string
        frmProgress.Close()   ' close progress bar
    End Sub
    ' 
    ' UseDismADKToolStripMenuItem_Click
    ' Toggle dism windows to dism ADK
    '
    ' Rev: 26/08/2022
    '
    Private Sub UseDismADKToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles UseDismADKToolStripMenuItem.Click

        If UseDismADK = False Then
            UseDismADK = True
            MessageBox.Show("Dism from ADK is selected")
        Else
            UseDismADK = False
            MessageBox.Show("Dism from Windows is selected")
        End If
    End Sub
    '
    ' Set language to fr-FR
    ' Rev: 26/08/2022
    ' 

    Private Sub FrenchToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles FrenchToolStripMenuItem.Click

        If FrenchToolStripMenuItem.Checked = True Then
            CultInfo = CultureInfo.CreateSpecificCulture("fr-FR")
            EnglishToolStripMenuItem.Checked = False
            Switch_Langage()
        End If
    End Sub
    '
    ' Set language to en-US
    ' Rev: 26/08/2022
    '
    Private Sub EnglishToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles EnglishToolStripMenuItem.Click

        If EnglishToolStripMenuItem.Checked = True Then
            CultInfo = CultureInfo.CreateSpecificCulture("en-US")
            FrenchToolStripMenuItem.Checked = False
            Switch_Langage()
        End If
    End Sub
    '
    ' Switch_Langage()
    ' Rev: 26/08/2022
    '
    Private Sub Switch_Langage()

        Me.Text = ResMan.GetString("frmMain_text", CultInfo)
        Me.TabPage1.Text = ResMan.GetString("TabPage1.Text", CultInfo)
        Me.TabPage2.Text = ResMan.GetString("TabPage2.Text", CultInfo)
        Me.TabPage3.Text = ResMan.GetString("TabPage3.Text", CultInfo)
        Me.TabPage4.Text = ResMan.GetString("TabPage4.Text", CultInfo)
        Me.TabPage5.Text = ResMan.GetString("TabPage5.Text", CultInfo)
        Me.TabPage6.Text = ResMan.GetString("TabPage6.Text", CultInfo)
        Me.TabPage7.Text = ResMan.GetString("TabPage7.Text", CultInfo)
        Me.TabPage8.Text = ResMan.GetString("TabPage8.Text", CultInfo)
        Me.TabPage9.Text = ResMan.GetString("TabPage9.Text", CultInfo)
        Me.TabPage10.Text = ResMan.GetString("TabPage10.Text", CultInfo)
        Me.TabPage11.Text = ResMan.GetString("TabPage11.Text", CultInfo)
        Me.TabPage12.Text = ResMan.GetString("TabPage12.Text", CultInfo)
        Me.TabPage13.Text = ResMan.GetString("TabPage13.Text", CultInfo)
        Me.TabPage14.Text = ResMan.GetString("TabPage14.Text", CultInfo)
        Me.TabPage15.Text = ResMan.GetString("TabPage15.Text", CultInfo)
        Me.TabPage16.Text = ResMan.GetString("TabPage16.Text", CultInfo)
        Me.TabPage17.Text = ResMan.GetString("TabPage17.Text", CultInfo)
        Me.TabPage18.Text = ResMan.GetString("TabPage18.Text", CultInfo)
        Me.TabPage19.Text = ResMan.GetString("TabPage19.Text", CultInfo)
        Me.TabPage20.Text = ResMan.GetString("TabPage20.Text", CultInfo)
        Me.TabPage21.Text = ResMan.GetString("TabPage21.Text", CultInfo)

        Me.ToolsToolStripMenuItem.Text = ResMan.GetString("ToolsToolStripMenuItem.Text", CultInfo)
        Me.OpenDISMLogToolStripMenuItem.Text = ResMan.GetString("OpenDISMLogToolStripMenuItem.Text", CultInfo)
        Me.GetWIMInfoToolStripMenuItem.Text = ResMan.GetString("GetWIMInfoToolStripMenuItem.Text", CultInfo)
        Me.CleanupWIMToolStripMenuItem.Text = ResMan.GetString("CleanupWIMToolStripMenuItem.Text", CultInfo)
        Me.CleanupImageToolStripMenuItem.Text = ResMan.GetString("CleanupImageToolStripMenuItem.Text", CultInfo)
        Me.UseDismADKToolStripMenuItem.Text = ResMan.GetString("UseDismADKToolStripMenuItem.Text", CultInfo)
        Me.AboutToolStripMenuItem.Text = ResMan.GetString("AboutToolStripMenuItem.Text", CultInfo)
        Me.LanguageToolStripMenuItem.Text = ResMan.GetString("LanguageToolStripMenuItem.Text", CultInfo)
        Me.FrenchToolStripMenuItem.Text = ResMan.GetString("FrenchToolStripMenuItem.Text", CultInfo)
        Me.EnglishToolStripMenuItem.Text = ResMan.GetString("EnglishToolStripMenuItem.Text", CultInfo)

        Me.LblMountControl_WimFile.Text = ResMan.GetString("LblMountControl_WimFile.Text", CultInfo)
        Me.BtnMountControl_OpenWIM.Text = ResMan.GetString("BtnMountControl_OpenWIM.Text", CultInfo)
        Me.BtnMountControl_DisplayImageInfo.Text = ResMan.GetString("BtnMountControl_DisplayImageInfo.Text", CultInfo)
        Me.BtnMountControl_GetMountedImageInfo.Text = ResMan.GetString("BtnMountControl_GetMountedImageInfo.Text", CultInfo)
        Me.LblMountControl_MountLocation.Text = ResMan.GetString("LblMountControl_MountLocation.Text", CultInfo)
        Me.BtnMountControl_OpenMount.Text = ResMan.GetString("BtnMountControl_OpenMount.Text", CultInfo)
        Me.BtnMountControl_RemountWim.Text = ResMan.GetString("BtnMountControl_RemountWim.Text", CultInfo)
        Me.LblMountControl_AlreadyMounted.Text = ResMan.GetString("LblMountControl_AlreadyMounted.Text", CultInfo)
        Me.BtnMountControl_RefreshMountedImage.Text = ResMan.GetString("BtnMountControl_RefreshMountedImage.Text", CultInfo)
        Me.BtnMountControl_CommitImage.Text = ResMan.GetString("BtnMountControl_CommitImage.Text", CultInfo)
        Me.BtnMountControl_MountImage.Text = ResMan.GetString("BtnMountControl_MountImage.Text", CultInfo)
        Me.BtnMountControl_UnmountImage.Text = ResMan.GetString("BtnMountControl_UnmountImage.Text", CultInfo)
        Me.BtnMountControl_OpenMountedFolder.Text = ResMan.GetString("BtnMountControl_OpenMountedFolder.Text", CultInfo)
        Me.BtnMountControl_CleanupMountPoints.Text = ResMan.GetString("BtnMountControl_CleanupMountPoints.Text", CultInfo)
        Me.LblMountControl_DISMOutput.Text = ResMan.GetString("LblMountControl_DISMOutput.Text", CultInfo)
        Me.BtnMountControl_ClearConsole.Text = ResMan.GetString("BtnMountControl_ClearConsole.Text", CultInfo)

        Me.BtnDriverManagement_RefreshMountedImage.Text = ResMan.GetString("BtnDriverManagement_RefreshMountedImage.Text", CultInfo)
        Me.LblDriverManagement_UseMountedImage.Text = ResMan.GetString("LblDriverManagement_UseMountedImage.Text", CultInfo)
        Me.BtnDriverManagement_GetDrivers.Text = ResMan.GetString("BtnDriverManagement_GetDrivers.Text", CultInfo)
        Me.BtnDriverManagement_GetMountedImageInfo.Text = ResMan.GetString("BtnDriverManagement_GetMountedImageInfo.Text", CultInfo)
        Me.GroupBoxDriverManagement_AddDrivers.Text = ResMan.GetString("GroupBoxDriverManagement_AddDrivers.Text", CultInfo)
        Me.LblDriverManagement_DriversFolderLocation.Text = ResMan.GetString("LblDriverManagement_DriversFolderLocation.Text", CultInfo)
        Me.BtnDriverManagement_OpenDriverFolder.Text = ResMan.GetString("BtnDriverManagement_OpenDriverFolder.Text", CultInfo)
        Me.BtnDriverManagement_AddDrivers.Text = ResMan.GetString("BtnDriverManagement_AddDrivers.Text", CultInfo)
        Me.BtnDriverManagement_GetAllDriverInfo.Text = ResMan.GetString("BtnDriverManagement_GetAllDriverInfo.Text", CultInfo)
        Me.GroupBoxDriverManagement_DeleteDrivers.Text = ResMan.GetString("GroupBoxDriverManagement_DeleteDrivers.Text", CultInfo)
        Me.LblDriverManagement_DriverName.Text = ResMan.GetString("LblDriverManagement_DriverName.Text", CultInfo)
        Me.BtnDriverManagement_DelDriver.Text = ResMan.GetString("BtnDriverManagement_DelDriver.Text", CultInfo)

        Me.BtnPackageManagement_RefreshMountedImage.Text = ResMan.GetString("BtnPackageManagement_RefreshMountedImage.Text", CultInfo)
        Me.LblPackageManagement_UseMountedImage.Text = ResMan.GetString("LblPackageManagement_UseMountedImage.Text", CultInfo)
        Me.BtnPackageManagement_GetMountedImageInfo.Text = ResMan.GetString("BtnPackageManagement_GetMountedImageInfo.Text", CultInfo)
        Me.GrpBoxPackageManage_AddPackage.Text = ResMan.GetString("GrpBoxPackageManage_AddPackage.Text", CultInfo)
        Me.LblPackageManage_PackageFolder.Text = ResMan.GetString("LblPackageManage_PackageFolder.Text", CultInfo)
        Me.BtnPackageManage_OpenPackageFile.Text = ResMan.GetString("BtnPackageManage_OpenPackageFile.Text", CultInfo)
        Me.BtnPackageManage_AddPackages.Text = ResMan.GetString("BtnPackageManage_AddPackages.Text", CultInfo)
        Me.BtnPackageManage_GetPackages.Text = ResMan.GetString("BtnPackageManage_GetPackages.Text", CultInfo)
        Me.GrpBoxPackageManage_RemovePackages.Text = ResMan.GetString("GrpBoxPackageManage_RemovePackages.Text", CultInfo)
        Me.LblPackageManage_PackageName.Text = ResMan.GetString("LblPackageManage_PackageName.Text", CultInfo)
        Me.BtnPackageManage_RemovePackage.Text = ResMan.GetString("BtnPackageManage_RemovePackage.Text", CultInfo)
        Me.BtnPackageManage_GetPackageInfo.Text = ResMan.GetString("BtnPackageManage_GetPackageInfo.Text", CultInfo)
        Me.LblPackageManage_PackagePath.Text = ResMan.GetString("LblPackageManage_PackagePath.Text", CultInfo)
        Me.BtnPackageManagement_ChoosePackagePath.Text = ResMan.GetString("BtnPackageManagement_ChoosePackagePath.Text", CultInfo)
        Me.BtnPackageManage_RemovePackagePath.Text = ResMan.GetString("BtnPackageManage_RemovePackagePath.Text", CultInfo)

        Me.BtnFeatureManagement_RefreshMountedImage.Text = ResMan.GetString("BtnFeatureManagement_RefreshMountedImage.Text", CultInfo)
        Me.LblFeatureManage_UseMountedImage.Text = ResMan.GetString("LblFeatureManage_UseMountedImage.Text", CultInfo)
        Me.BtnFeatureManagement_GetMountedImageInfo.Text = ResMan.GetString("BtnFeatureManagement_GetMountedImageInfo.Text", CultInfo)
        Me.LblFeatureManage_FeatureName.Text = ResMan.GetString("LblFeatureManage_FeatureName.Text", CultInfo)
        Me.BtnFeatureManage_GetFeatures.Text = ResMan.GetString("BtnFeatureManage_GetFeatures.Text", CultInfo)
        Me.BtnFeatureManage_GetFeatureInfo.Text = ResMan.GetString("BtnFeatureManage_GetFeatureInfo.Text", CultInfo)
        Me.LblFeatureManage_PackageName.Text = ResMan.GetString("LblFeatureManage_PackageName.Text", CultInfo)
        Me.LblFeatureManage_PackagePath.Text = ResMan.GetString("LblFeatureManage_PackagePath.Text", CultInfo)
        Me.BtnFeatureManage_EnableFeature.Text = ResMan.GetString("BtnFeatureManage_EnableFeature.Text", CultInfo)
        Me.BtnFeatureManage_DisableFeature.Text = ResMan.GetString("BtnFeatureManage_DisableFeature.Text", CultInfo)
        Me.LblFeatureManage_Source.Text = ResMan.GetString("LblFeatureManage_Source.Text", CultInfo)

        Me.BtnEditionServicing_RefreshMountedImage.Text = ResMan.GetString("BtnEditionServicing_RefreshMountedImage.Text", CultInfo)
        Me.LblEditionServicing_UseMountedImage.Text = ResMan.GetString("LblEditionServicing_UseMountedImage.Text", CultInfo)
        Me.BtnEditionServicing_GetMountedImageInfo.Text = ResMan.GetString("BtnEditionServicing_GetMountedImageInfo.Text", CultInfo)
        Me.LblEditionServicing_ProductKey.Text = ResMan.GetString("LblEditionServicing_ProductKey.Text", CultInfo)
        Me.BtnEditionServicing_SetProductKey.Text = ResMan.GetString("BtnEditionServicing_SetProductKey.Text", CultInfo)
        Me.BtnEditionServicing_GetCurrentEdition.Text = ResMan.GetString("BtnEditionServicing_GetCurrentEdition.Text", CultInfo)
        Me.LblEditionServicing_Edition.Text = ResMan.GetString("LblEditionServicing_Edition.Text", CultInfo)
        Me.BtnEditionServicing_SetEdition.Text = ResMan.GetString("BtnEditionServicing_SetEdition.Text", CultInfo)
        Me.BtnEditionServicing_GetTargetEditions.Text = ResMan.GetString("BtnEditionServicing_GetTargetEditions.Text", CultInfo)

        Me.BtnUnattendedServicing_RefreshMountedImage.Text = ResMan.GetString("BtnUnattendedServicing_RefreshMountedImage.Text", CultInfo)
        Me.LblUnattendedServicing_UseMountedImage.Text = ResMan.GetString("LblUnattendedServicing_UseMountedImage.Text", CultInfo)
        Me.BtnUnattendedServicing_GetMountedImageInfo.Text = ResMan.GetString("BtnUnattendedServicing_GetMountedImageInfo.Text", CultInfo)
        Me.LblUnattendedServicing_XMLFile.Text = ResMan.GetString("LblUnattendedServicing_XMLFile.Text", CultInfo)
        Me.BtnUnattendedServicing_ChooseUnAttend.Text = ResMan.GetString("BtnUnattendedServicing_ChooseUnAttend.Text", CultInfo)
        Me.BtnUnattendedServicing_ApplyUnattend.Text = ResMan.GetString("BtnUnattendedServicing_ApplyUnattend.Text", CultInfo)

        Me.BtnApplicationServicing_RefreshMountedImage.Text = ResMan.GetString("BtnApplicationServicing_RefreshMountedImage.Text", CultInfo)
        Me.LblApplicationServicing_UseMountedImage.Text = ResMan.GetString("LblApplicationServicing_UseMountedImage.Text", CultInfo)
        Me.BtnApplicationServicing_GetMountedImageInfo.Text = ResMan.GetString("BtnApplicationServicing_GetMountedImageInfo.Text", CultInfo)
        Me.LblApplicationServicing_ProductCode.Text = ResMan.GetString("LblApplicationServicing_ProductCode.Text", CultInfo)
        Me.BtnApplicationServicing_GetApps.Text = ResMan.GetString("BtnApplicationServicing_GetApps.Text", CultInfo)
        Me.BtnApplicationServicing_GetAppInfo.Text = ResMan.GetString("BtnApplicationServicing_GetAppInfo.Text", CultInfo)
        Me.LblApplicationServicing_PathCode.Text = ResMan.GetString("LblApplicationServicing_PathCode.Text", CultInfo)
        Me.BtnApplicationServicing_GetAppPatches.Text = ResMan.GetString("BtnApplicationServicing_GetAppPatches.Text", CultInfo)
        Me.BtnApplicationServicing_GetAppPatchInfo.Text = ResMan.GetString("BtnApplicationServicing_GetAppPatchInfo.Text", CultInfo)
        Me.LblApplicationServicing_MSPFile.Text = ResMan.GetString("LblApplicationServicing_MSPFile.Text", CultInfo)
        Me.BtnApplicationServicing_ChooseMSP.Text = ResMan.GetString("BtnApplicationServicing_ChooseMSP.Text", CultInfo)
        Me.BtnApplicationServicing_CheckAppPatch.Text = ResMan.GetString("BtnApplicationServicing_CheckAppPatch.Text", CultInfo)

        Me.BtnCaptureImageWim_BrowseSource.Text = ResMan.GetString("BtnCaptureImageWim_BrowseSource.Text", CultInfo)
        Me.LblCaptureImageWim_Destination.Text = ResMan.GetString("LblCaptureImageWim_Destination.Text", CultInfo)
        Me.BtnCaptureImageWim_BrowseDestination.Text = ResMan.GetString("BtnCaptureImageWim_BrowseDestination.Text", CultInfo)
        Me.BtnCaptureImageWim_CreateWim.Text = ResMan.GetString("BtnCaptureImageWim_CreateWim.Text", CultInfo)
        Me.BtnCaptureImageWim_AppendWim.Text = ResMan.GetString("BtnCaptureImageWim_AppendWim.Text", CultInfo)
        Me.LblCaptureImageWim_FileName.Text = ResMan.GetString("LblCaptureImageWim_FileName.Text", CultInfo)
        Me.LblCaptureImageWim_NameMetadata.Text = ResMan.GetString("LblCaptureImageWim_NameMetadata.Text", CultInfo)
        Me.LblCaptureImageWim_DescriptionMetadata.Text = ResMan.GetString("LblCaptureImageWim_DescriptionMetadata.Text", CultInfo)
        Me.LblCaptureImageWim_Compression.Text = ResMan.GetString("LblCaptureImageWim_Compression.Text", CultInfo)

        Me.LblApplyWim_Source.Text = ResMan.GetString("LblApplyWim_Source.Text", CultInfo)
        Me.BtnApplyWim_BrowseSource.Text = ResMan.GetString("BtnApplyWim_BrowseSource.Text", CultInfo)
        Me.BtnApplyWim_ApplyWim.Text = ResMan.GetString("BtnApplyWim_ApplyWim.Text", CultInfo)
        Me.LblApplyWim_Destination.Text = ResMan.GetString("LblApplyWim_Destination.Text", CultInfo)
        Me.BtnApplyWim_BrowseDestination.Text = ResMan.GetString("BtnApplyWim_BrowseDestination.Text", CultInfo)
        Me.LblApplyWim_PatternSWMFile.Text = ResMan.GetString("LblApplyWim_PatternSWMFile.Text", CultInfo)
        Me.LblApplyWim_Name.Text = ResMan.GetString("LblApplyWim_Name.Text", CultInfo)
        Me.LblApplyWim_Description.Text = ResMan.GetString("LblApplyWim_Description.Text", CultInfo)
        Me.LblApplyWim_Size.Text = ResMan.GetString("LblApplyWim_Size.Text", CultInfo)

        Me.LblExportImage_Source.Text = ResMan.GetString("LblExportImage_Source.Text", CultInfo)
        Me.BtnExportImage_BrowseSource.Text = ResMan.GetString("BtnExportImage_BrowseSource.Text", CultInfo)
        Me.BtnExportImage_ExportImage.Text = ResMan.GetString("BtnExportImage_ExportImage.Text", CultInfo)
        Me.LblExportImage_Destination.Text = ResMan.GetString("LblExportImage_Destination.Text", CultInfo)
        Me.BtnExportImage_BrowseDestination.Text = ResMan.GetString("BtnExportImage_BrowseDestination.Text", CultInfo)
        Me.LblExportImage_Filename.Text = ResMan.GetString("LblExportImage_Filename.Text", CultInfo)
        Me.LblExportImage_Name.Text = ResMan.GetString("LblExportImage_Name.Text", CultInfo)
        Me.LblExportImage_Description.Text = ResMan.GetString("LblExportImage_Description.Text", CultInfo)
        Me.LblExportImage_Size.Text = ResMan.GetString("LblExportImage_Size.Text", CultInfo)

        Me.BtnLangAndInterServicing_RefreshMountedImage.Text = ResMan.GetString("BtnLangAndInterServicing_RefreshMountedImage.Text", CultInfo)
        Me.LblLangAndInterServicing_UseMountedImage.Text = ResMan.GetString("LblLangAndInterServicing_UseMountedImage.Text", CultInfo)
        Me.BtnLangAndInterServicing_GetMountedImageInfo.Text = ResMan.GetString("BtnLangAndInterServicing_GetMountedImageInfo.Text", CultInfo)
        Me.BtnLangAndInterServicing_DisplayInfo.Text = ResMan.GetString("BtnLangAndInterServicing_DisplayInfo.Text", CultInfo)

        Me.BtnExportDriver_RefreshMountedImage.Text = ResMan.GetString("BtnExportDriver_RefreshMountedImage.Text", CultInfo)
        Me.LblExportDriver_UseMountedImage.Text = ResMan.GetString("LblExportDriver_UseMountedImage.Text", CultInfo)
        Me.BtnExportDriver_GetMountedImageInfo.Text = ResMan.GetString("BtnExportDriver_GetMountedImageInfo.Text", CultInfo)
        Me.LblExportDriver_Folder.Text = ResMan.GetString("LblExportDriver_Folder.Text", CultInfo)
        Me.BtnExportDriver_SelectFolder.Text = ResMan.GetString("BtnExportDriver_SelectFolder.Text", CultInfo)
        Me.BtnExportDriver_ExportDriver.Text = ResMan.GetString("BtnExportDriver_ExportDriver.Text", CultInfo)

        Me.LblSplitImage_WIMFilename.Text = ResMan.GetString("LblSplitImage_WIMFilename.Text", CultInfo)
        Me.BtnSplitImage_WIMChoice.Text = ResMan.GetString("BtnSplitImage_WIMChoice.Text", CultInfo)
        Me.BtnSplitImage_SplitImage.Text = ResMan.GetString("BtnSplitImage_SplitImage.Text", CultInfo)
        Me.LblSplitImage_DestinationFolder.Text = ResMan.GetString("LblSplitImage_DestinationFolder.Text", CultInfo)
        Me.BtnSplitImage_TargetFolder.Text = ResMan.GetString("BtnSplitImage_TargetFolder.Text", CultInfo)
        Me.LblSplitImage_SWMFilename.Text = ResMan.GetString("LblSplitImage_SWMFilename.Text", CultInfo)
        Me.LblSplitImage_SplitSize.Text = ResMan.GetString("LblSplitImage_SplitSize.Text", CultInfo)
        Me.LblSplitImage_Warning.Text = ResMan.GetString("LblSplitImage_Warning.Text", CultInfo)

        Me.LblCaptureFfu_Warning.Text = ResMan.GetString("LblCaptureFfu_Warning.Text", CultInfo)
        Me.LblCaptureFfu_LogicalDrive.Text = ResMan.GetString("LblCaptureFfu_LogicalDrive.Text", CultInfo)
        Me.BtnCaptureFfu_UpdateLogicalDrive.Text = ResMan.GetString("BtnCaptureFfu_UpdateLogicalDrive.Text", CultInfo)
        Me.BtnCaptureFfu_StartCapture.Text = ResMan.GetString("BtnCaptureFfu_StartCapture.Text", CultInfo)
        Me.LblCaptureFfu_PhysicalDrive.Text = ResMan.GetString("LblCaptureFfu_PhysicalDrive.Text", CultInfo)
        Me.LblCaptureFfu_TargetFolder.Text = ResMan.GetString("LblCaptureFfu_TargetFolder.Text", CultInfo)
        Me.LblCaptureFfu_TargetFilename.Text = ResMan.GetString("LblCaptureFfu_TargetFilename.Text", CultInfo)
        Me.LblCaptureFfu_Name.Text = ResMan.GetString("LblCaptureFfu_Name.Text", CultInfo)
        Me.LblCaptureFfu_Description.Text = ResMan.GetString("LblCaptureFfu_Description.Text", CultInfo)
        Me.LblCaptureFfu_PlatformID.Text = ResMan.GetString("LblCaptureFfu_PlatformID.Text", CultInfo)
        Me.BtnCaptureFfu_SetTargetFolder.Text = ResMan.GetString("BtnCaptureFfu_SetTargetFolder.Text", CultInfo)

        Me.LblApplyFfuImage_LogicalDrive.Text = ResMan.GetString("LblApplyFfuImage_LogicalDrive.Text", CultInfo)
        Me.BtnApplyFfuImage_UpdateLogicalDrive.Text = ResMan.GetString("BtnApplyFfuImage_UpdateLogicalDrive.Text", CultInfo)
        Me.LblApplyFfuImage_PhysicalDrive.Text = ResMan.GetString("LblApplyFfuImage_PhysicalDrive.Text", CultInfo)
        Me.LblApplyFfuImage_SourceFilename.Text = ResMan.GetString("LblApplyFfuImage_SourceFilename.Text", CultInfo)
        Me.LblApplyFfuImage_MotifSFUFile.Text = ResMan.GetString("LblApplyFfuImage_MotifSFUFile.Text", CultInfo)
        Me.BtnApplyFfuImage_SelectFfuFile.Text = ResMan.GetString("BtnApplyFfuImage_SelectFfuFile.Text", CultInfo)
        Me.BtnApplyFfuImage_ApplyFfuImage.Text = ResMan.GetString("BtnApplyFfuImage_ApplyFfuImage.Text", CultInfo)

        Me.LblSplitFfu_FfuFilename.Text = ResMan.GetString("LblSplitFfu_FfuFilename.Text", CultInfo)
        Me.BtnSplitFfu_SelectFfuFile.Text = ResMan.GetString("BtnSplitFfu_SelectFfuFile.Text", CultInfo)
        Me.BtnSplitFfuImage_StartSplitImage.Text = ResMan.GetString("BtnSplitFfuImage_StartSplitImage.Text", CultInfo)
        Me.LblSplitFfu_TargetFolder.Text = ResMan.GetString("LblSplitFfu_TargetFolder.Text", CultInfo)
        Me.BtnSplitFfu_SelectTargetFolder.Text = ResMan.GetString("BtnSplitFfu_SelectTargetFolder.Text", CultInfo)
        Me.LblSplitFfu_SFUFilename.Text = ResMan.GetString("LblSplitFfu_SFUFilename.Text", CultInfo)
        Me.LblSplitFfu_SplitFileSize.Text = ResMan.GetString("LblSplitFfu_SplitFileSize.Text", CultInfo)
        Me.LblSplitFfu_Warning.Text = ResMan.GetString("LblSplitFfu_Warning.Text", CultInfo)

        Me.BtnDefaultAppAssocServ_RefreshMountedImage.Text = ResMan.GetString("BtnDefaultAppAssocServ_RefreshMountedImage.Text", CultInfo)
        Me.LblBtnDefaultAppAssocServ_UseMountedImage.Text = ResMan.GetString("LblBtnDefaultAppAssocServ_UseMountedImage.Text", CultInfo)
        Me.BtnAppAssocServ_GetMountedImageInfo.Text = ResMan.GetString("BtnAppAssocServ_GetMountedImageInfo.Text", CultInfo)
        Me.LblDefaultAppAssocServ_ExportFolder.Text = ResMan.GetString("LblDefaultAppAssocServ_ExportFolder.Text", CultInfo)
        Me.BtnDefaultAppAssocServ_GetDefaultAppAssoc.Text = ResMan.GetString("BtnDefaultAppAssocServ_GetDefaultAppAssoc.Text", CultInfo)
        Me.BtnDefaultAppAssocServ_ChooseFolder.Text = ResMan.GetString("BtnDefaultAppAssocServ_ChooseFolder.Text", CultInfo)
        Me.BtnDefaultAppAssocServ_Export.Text = ResMan.GetString("BtnDefaultAppAssocServ_Export.Text", CultInfo)
        Me.LblLblDefaultAppAssocServ_ExportFilename.Text = ResMan.GetString("LblLblDefaultAppAssocServ_ExportFilename.Text", CultInfo)
        Me.LblDefaultAppAssocServ_Warning.Text = ResMan.GetString("LblDefaultAppAssocServ_Warning.Text", CultInfo)
        Me.LblDefaultAppAssocServ_ImportFilename.Text = ResMan.GetString("LblDefaultAppAssocServ_ImportFilename.Text", CultInfo)
        Me.BtnDefaultAppAssocServ_ChooseFile.Text = ResMan.GetString("BtnDefaultAppAssocServ_ChooseFile.Text", CultInfo)
        Me.BtnDefaultAppAssocServ_Import.Text = ResMan.GetString("BtnDefaultAppAssocServ_Import.Text", CultInfo)
        Me.BtnDefaultAppAssocServ_Remove.Text = ResMan.GetString("BtnDefaultAppAssocServ_Remove.Text", CultInfo)

        Me.BtnCapPackServ_RefreshMountedImage.Text = ResMan.GetString("BtnCapPackServ_RefreshMountedImage.Text", CultInfo)
        Me.LblCapPackServ_UseMountedImage.Text = ResMan.GetString("LblCapPackServ_UseMountedImage.Text", CultInfo)
        Me.BtnCapPackServ_GetMountedImageInfo.Text = ResMan.GetString("BtnCapPackServ_GetMountedImageInfo.Text", CultInfo)
        Me.BtnCapPackServ_AddCapability.Text = ResMan.GetString("BtnCapPackServ_AddCapability.Text", CultInfo)
        Me.BtnCapPackServ_GetCap.Text = ResMan.GetString("BtnCapPackServ_GetCap.Text", CultInfo)
        Me.BtnCapPackServ_ExportSource.Text = ResMan.GetString("BtnCapPackServ_ExportSource.Text", CultInfo)
        Me.BtnCapPackServ_GetCapInfo.Text = ResMan.GetString("BtnCapPackServ_GetCapInfo.Text", CultInfo)
        Me.BtnCapPackServ_RemoveCap.Text = ResMan.GetString("BtnCapPackServ_RemoveCap.Text", CultInfo)

        Me.BtnCleanupImage_RefreshMountedImage.Text = ResMan.GetString("BtnCleanupImage_RefreshMountedImage.Text", CultInfo)
        Me.LblCleanupImage_UseMountedImage.Text = ResMan.GetString("LblCleanupImage_UseMountedImage.Text", CultInfo)
        Me.BtnCleanupImage_GetMountedImageInfo.Text = ResMan.GetString("BtnCleanupImage_GetMountedImageInfo.Text", CultInfo)
        Me.BtnCleanupImage_Superseded.Text = ResMan.GetString("BtnCleanupImage_Superseded.Text", CultInfo)
        Me.BtnCleanupImage_StartComponentCleanup.Text = ResMan.GetString("BtnCleanupImage_StartComponentCleanup.Text", CultInfo)
        Me.BtnCleanupImage_RevertPendingActions.Text = ResMan.GetString("BtnCleanupImage_RevertPendingActions.Text", CultInfo)
        Me.BtnCleanupImage_AnalyzeComponentStore.Text = ResMan.GetString("BtnCleanupImage_AnalyzeComponentStore.Text", CultInfo)
        Me.BtnCleanupImage_CheckHealth.Text = ResMan.GetString("BtnCleanupImage_CheckHealth.Text", CultInfo)
        Me.BtnCleanupImage_ScanHealth.Text = ResMan.GetString("BtnCleanupImage_ScanHealth.Text", CultInfo)
        Me.BtnCleanupImage_RestoreHealth.Text = ResMan.GetString("BtnCleanupImage_RestoreHealth.Text", CultInfo)
        Me.BtnCleanupImage_ChooseSourceRestoreHealth.Text = ResMan.GetString("BtnCleanupImage_ChooseSourceRestoreHealth.Text", CultInfo)

        Me.BtnDiskpartWinPE_RefreshListDisk.Text = ResMan.GetString("BtnDiskpartWinPE_RefreshListDisk.Text", CultInfo)
        Me.LblDiskpartWinPE_SelectDrive.Text = ResMan.GetString("LblDiskpartWinPE_SelectDrive.Text", CultInfo)
        Me.BtnDiskpartWinPE_FormatDisk.Text = ResMan.GetString("BtnDiskpartWinPE_FormatDisk.Text", CultInfo)
        Me.BtnDiskpartWinPE_CreateWinPETemplate.Text = ResMan.GetString("BtnDiskpartWinPE_CreateWinPETemplate.Text", CultInfo)
        Me.BtnDiskpartWinPE_BootDiskWinPE.Text = ResMan.GetString("BtnDiskpartWinPE_BootDiskWinPE.Text", CultInfo)

        Me.BtnCustomWinPE_RefreshMountedImage.Text = ResMan.GetString("BtnCustomWinPE_RefreshMountedImage.Text", CultInfo)
        Me.LblCustomWinPE_UseImageMounted.Text = ResMan.GetString("LblCustomWinPE_UseImageMounted.Text", CultInfo)
        Me.BtnCustomWinPE_GetMountedImageInfo.Text = ResMan.GetString("BtnCustomWinPE_GetMountedImageInfo.Text", CultInfo)
        Me.LblCustomWinPE_DetectADKPath.Text = ResMan.GetString("LblCustomWinPE_DetectADKPath.Text", CultInfo)
        Me.BtnCustomWinPE_DetectADK.Text = ResMan.GetString("BtnCustomWinPE_DetectADK.Text", CultInfo)
        Me.LblCustomWinPE_Language.Text = ResMan.GetString("LblCustomWinPE_Language.Text", CultInfo)
        Me.BtnCustomWinPE_Apply.Text = ResMan.GetString("BtnCustomWinPE_Apply.Text", CultInfo)
        Me.LblCustomWinPE_SystemType.Text = ResMan.GetString("LblCustomWinPE_SystemType.Text", CultInfo)

    End Sub
    '
    ' BtnCapPackServ_SelectSource_Click
    ' Rev: 17/09/2022
    '
    Private Sub BtnCapPackServ_SelectSource_Click(sender As Object, e As EventArgs) Handles BtnCapPackServ_SelectSource.Click

        dlgOpenFolder.ShowNewFolderButton = False
        dlgOpenFolder.RootFolder = Environment.SpecialFolder.MyComputer
        dlgOpenFolder.ShowDialog()
        Dim strFolderName As String = dlgOpenFolder.SelectedPath
        TxtBoxCapPackServ_Source.Text = strFolderName
    End Sub
    '
    ' BtnCapPackServ_SelectTarget_Click
    ' Rev: 17/09/2022
    '
    Private Sub BtnCapPackServ_SelectTarget_Click(sender As Object, e As EventArgs) Handles BtnCapPackServ_SelectTarget.Click

        dlgOpenFolder.ShowNewFolderButton = False
        dlgOpenFolder.RootFolder = Environment.SpecialFolder.MyComputer
        dlgOpenFolder.ShowDialog()
        Dim strFolderName As String = dlgOpenFolder.SelectedPath
        TxtBoxCapPackServ_Target.Text = strFolderName
    End Sub
    '
    ' Btn_MakeWinPEISO_Click
    ' Rev: 25/03/2023
    '
    Private Sub BtnMakeWinPEISO_Click(sender As Object, e As EventArgs) Handles BtnMakeWinPEISO.Click


        If RadBtnDiskpartWinPE_WinPEamd64.Checked = True Then
            RunDosCommand("""C:\Program Files (x86)\Windows Kits\10\Assessment and Deployment Kit\Deployment Tools\DandISetEnv.bat""", "&&MakeWinPEMedia /ISO C:\WinPE_amd64 C:\WinPE_amd64\WinPE_amd64.iso", True)
            txtOutput.Text = "C:\WinPE_amd64\WinPE_amd64.iso is created !"
        Else
            RunDosCommand("""C:\Program Files (x86)\Windows Kits\10\Assessment and Deployment Kit\Deployment Tools\DandISetEnv.bat""", "&&MakeWinPEMedia /ISO C:\WinPE_x86 C:\WinPE_x86\WinPE_x86.iso", True)
            txtOutput.Text = "C:\WinPE_x86\WinPE_x86.iso is created !"
        End If


    End Sub
    '
    ' BtnCustomWinPE_ApplyMaxPerf_Click
    ' Rev: 25/03/2023
    '
    Private Sub BtnCustomWinPE_ApplyMaxPerf_Click(sender As Object, e As EventArgs) Handles BtnCustomWinPE_ApplyMaxPerf.Click

        If CmbBoxCustomWinPE_UseImageMounted.Text = "" Then
            MessageBox.Show("You must selected WinPE image before use this command !.")
            Exit Sub
        End If

        If ChkboxCustomWinPE_AddMaxPowerPerf.Checked = True Then
            RunDosCommand("echo powercfg.exe /s 8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c >> " & CmbBoxCustomWinPE_UseImageMounted.Text & "\Windows\System32\StartNet.cmd", "", True)
            txtOutput.Text = "powercfg.exe /s 8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c is set on startnet.cmd file"
        End If
    End Sub
    '
    ' BtnCustomWinPE_ApplyDetectTypeBios_Click
    ' Rev: 25/03/2023
    '
    Private Sub BtnCustomWinPE_ApplyDetectTypeBios_Click(sender As Object, e As EventArgs) Handles BtnCustomWinPE_ApplyDetectTypeBios.Click

        If CmbBoxCustomWinPE_UseImageMounted.Text = "" Then
            MessageBox.Show("You must selected WinPE image before use this command !.")
            Exit Sub
        End If

        If ChkboxCustomWinPE_AddScriptWinPEDetectTypeBios.Checked Then
            Try
                ' open file startnet.cmd (on WinPE image) in append mode
                Using sw As StreamWriter = New StreamWriter(CmbBoxCustomWinPE_UseImageMounted.Text & "\Windows\system32\startnet.cmd", True, Encoding.GetEncoding(CultureInfo.CurrentCulture.TextInfo.OEMCodePage))
                    sw.WriteLine("wpeutil UpdateBootInfo")
                    sw.WriteLine("@for /f ""tokens=2* delims=	 "" %%A in ('reg query HKLM\System\CurrentControlSet\Control /v PEFirmwareType') DO @SET Firmware=%%B")
                    sw.WriteLine("@if %Firmware%==0x1 echo The PC is booted in BIOS mode.")
                    sw.WriteLine("@if %Firmware%==0x2 echo The PC is booted in UEFI mode.")
                    sw.Close()
                End Using
            Catch ex As Exception
                ' Let the user know what went wrong.
                'Console.WriteLine("The file startnet.cmd could not be appended:")
                'Console.WriteLine(e.Message)
                MessageBox.Show("BtnCustomWinPE_ApplyDetectTypeBios_Click Error on append filename startnet.cmd: " + ex.Message.ToString())
            End Try
        End If
    End Sub
End Class

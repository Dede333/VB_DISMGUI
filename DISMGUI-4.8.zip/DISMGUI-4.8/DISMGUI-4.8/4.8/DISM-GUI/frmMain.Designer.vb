﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.TxtMountControl_ImageFile = New System.Windows.Forms.TextBox()
        Me.LblMountControl_WimFile = New System.Windows.Forms.Label()
        Me.LblMountControl_MountLocation = New System.Windows.Forms.Label()
        Me.TxtMountControl_MountLocation = New System.Windows.Forms.TextBox()
        Me.dlgOpenFolder = New System.Windows.Forms.FolderBrowserDialog()
        Me.dlgOpenFile = New System.Windows.Forms.OpenFileDialog()
        Me.BtnMountControl_OpenWIM = New System.Windows.Forms.Button()
        Me.BtnMountControl_OpenMount = New System.Windows.Forms.Button()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.ToolsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.OpenDISMLogToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.GetWIMInfoToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CleanupWIMToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CleanupImageToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.UseDismADKToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AboutToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LanguageToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.FrenchToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.EnglishToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.BtnMountControl_MountImage = New System.Windows.Forms.Button()
        Me.CmbMountControl_Index = New System.Windows.Forms.ComboBox()
        Me.BtnMountControl_UnmountImage = New System.Windows.Forms.Button()
        Me.txtOutput = New System.Windows.Forms.TextBox()
        Me.LblMountControl_DISMOutput = New System.Windows.Forms.Label()
        Me.BtnMountControl_OpenMountedFolder = New System.Windows.Forms.Button()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.BackgroundWorkerMount = New System.ComponentModel.BackgroundWorker()
        Me.BackgroundWorkerDisMount = New System.ComponentModel.BackgroundWorker()
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.LblMountControl_AlreadyMounted = New System.Windows.Forms.Label()
        Me.BtnMountControl_RefreshMountedImage = New System.Windows.Forms.Button()
        Me.CmbBoxMountControl_AlreadyMounted = New System.Windows.Forms.ComboBox()
        Me.RadBtnMountControl_Commit = New System.Windows.Forms.RadioButton()
        Me.RadBtnMountControl_Discard = New System.Windows.Forms.RadioButton()
        Me.ChkBoxMountControl_Append = New System.Windows.Forms.CheckBox()
        Me.ChkBoxMountControl_CheckIntegrity = New System.Windows.Forms.CheckBox()
        Me.ChkBoxMountControl_Optimize = New System.Windows.Forms.CheckBox()
        Me.BtnMountControl_RemountWim = New System.Windows.Forms.Button()
        Me.BtnMountControl_CleanupMountPoints = New System.Windows.Forms.Button()
        Me.BtnMountControl_CommitImage = New System.Windows.Forms.Button()
        Me.BtnMountControl_GetMountedImageInfo = New System.Windows.Forms.Button()
        Me.BtnMountControl_DisplayImageInfo = New System.Windows.Forms.Button()
        Me.LblMountControl_Size = New System.Windows.Forms.Label()
        Me.LblMountControl_Description = New System.Windows.Forms.Label()
        Me.LblMountControl_Name = New System.Windows.Forms.Label()
        Me.TxtBoxMountControl_Size = New System.Windows.Forms.TextBox()
        Me.TxtBoxMountControl_Description = New System.Windows.Forms.TextBox()
        Me.TxtBoxMountControl_Name = New System.Windows.Forms.TextBox()
        Me.ChkMountControl_ReadOnly = New System.Windows.Forms.CheckBox()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.BtnDriverManagement_RefreshMountedImage = New System.Windows.Forms.Button()
        Me.BtnDriverManagement_GetMountedImageInfo = New System.Windows.Forms.Button()
        Me.LblDriverManagement_UseMountedImage = New System.Windows.Forms.Label()
        Me.CmbBoxDriverManagement_UseImageMounted = New System.Windows.Forms.ComboBox()
        Me.ChkBoxDriverManagement_Online = New System.Windows.Forms.CheckBox()
        Me.BtnDriverManagement_GetAllDriverInfo = New System.Windows.Forms.Button()
        Me.GroupBoxDriverManagement_DeleteDrivers = New System.Windows.Forms.GroupBox()
        Me.LblDriverManagement_DriverName = New System.Windows.Forms.Label()
        Me.BtnDriverManagement_DelDriver = New System.Windows.Forms.Button()
        Me.TxtBoxDriverManagement_DelDriverLocation = New System.Windows.Forms.TextBox()
        Me.BtnDriverManagement_GetDrivers = New System.Windows.Forms.Button()
        Me.GroupBoxDriverManagement_AddDrivers = New System.Windows.Forms.GroupBox()
        Me.ChkDriverManagement_Recurse = New System.Windows.Forms.CheckBox()
        Me.BtnDriverManagement_AddDrivers = New System.Windows.Forms.Button()
        Me.BtnDriverManagement_OpenDriverFolder = New System.Windows.Forms.Button()
        Me.LblDriverManagement_DriversFolderLocation = New System.Windows.Forms.Label()
        Me.ChkDriverManagement_ForceUnsigned = New System.Windows.Forms.CheckBox()
        Me.TxtBoxDriverManagement_DriverFolderLocation = New System.Windows.Forms.TextBox()
        Me.TabPage3 = New System.Windows.Forms.TabPage()
        Me.LblPackageManagement_Format = New System.Windows.Forms.Label()
        Me.RadBtnPackageManagement_FormatList = New System.Windows.Forms.RadioButton()
        Me.RadBtnPackageManagement_FormatTable = New System.Windows.Forms.RadioButton()
        Me.BtnPackageManagement_GetMountedImageInfo = New System.Windows.Forms.Button()
        Me.BtnPackageManagement_RefreshMountedImage = New System.Windows.Forms.Button()
        Me.LblPackageManagement_UseMountedImage = New System.Windows.Forms.Label()
        Me.CmbBoxPackageManagement_UseImageMounted = New System.Windows.Forms.ComboBox()
        Me.ChkBoxPackageManagement_Online = New System.Windows.Forms.CheckBox()
        Me.GrpBoxPackageManage_RemovePackages = New System.Windows.Forms.GroupBox()
        Me.BtnPackageManagement_ChoosePackagePath = New System.Windows.Forms.Button()
        Me.LblPackageManage_PackageName = New System.Windows.Forms.Label()
        Me.LblPackageManage_PackagePath = New System.Windows.Forms.Label()
        Me.BtnPackageManage_RemovePackagePath = New System.Windows.Forms.Button()
        Me.BtnPackageManage_RemovePackage = New System.Windows.Forms.Button()
        Me.BtnPackageManage_GetPackageInfo = New System.Windows.Forms.Button()
        Me.txtPackagePath = New System.Windows.Forms.TextBox()
        Me.txtPackageName = New System.Windows.Forms.TextBox()
        Me.BtnPackageManage_GetPackages = New System.Windows.Forms.Button()
        Me.GrpBoxPackageManage_AddPackage = New System.Windows.Forms.GroupBox()
        Me.ChkBoxPackageManagement_PreventPending = New System.Windows.Forms.CheckBox()
        Me.BtnPackageManage_AddPackages = New System.Windows.Forms.Button()
        Me.LblPackageManage_PackageFolder = New System.Windows.Forms.Label()
        Me.chkIgnoreCheck = New System.Windows.Forms.CheckBox()
        Me.txtPackageFile = New System.Windows.Forms.TextBox()
        Me.BtnPackageManage_OpenPackageFile = New System.Windows.Forms.Button()
        Me.TabPage4 = New System.Windows.Forms.TabPage()
        Me.ChkBoxFeatureManagement_Source = New System.Windows.Forms.CheckBox()
        Me.ChkBoxFeatureManagement_All = New System.Windows.Forms.CheckBox()
        Me.ChkBoxFeatureManagement_LimitAccess = New System.Windows.Forms.CheckBox()
        Me.LblFeatureManage_Source = New System.Windows.Forms.Label()
        Me.TxtBoxFeatureManagement_Source = New System.Windows.Forms.TextBox()
        Me.BtnFeatureManage_GetFeatureInfo = New System.Windows.Forms.Button()
        Me.BtnFeatureManagement_GetMountedImageInfo = New System.Windows.Forms.Button()
        Me.BtnFeatureManagement_RefreshMountedImage = New System.Windows.Forms.Button()
        Me.LblFeatureManage_UseMountedImage = New System.Windows.Forms.Label()
        Me.CmbBoxFeatureManagement_UseImageMounted = New System.Windows.Forms.ComboBox()
        Me.ChkBoxFeatureManagement_Online = New System.Windows.Forms.CheckBox()
        Me.BtnFeatureManage_DisableFeature = New System.Windows.Forms.Button()
        Me.chkEnablePkgPath = New System.Windows.Forms.CheckBox()
        Me.chkEnablePkgName = New System.Windows.Forms.CheckBox()
        Me.BtnFeatureManage_EnableFeature = New System.Windows.Forms.Button()
        Me.LblFeatureManage_PackagePath = New System.Windows.Forms.Label()
        Me.LblFeatureManage_PackageName = New System.Windows.Forms.Label()
        Me.LblFeatureManage_FeatureName = New System.Windows.Forms.Label()
        Me.txtFeatPackagePath = New System.Windows.Forms.TextBox()
        Me.txtFeatPackageName = New System.Windows.Forms.TextBox()
        Me.txtFeatureName = New System.Windows.Forms.TextBox()
        Me.BtnFeatureManage_GetFeatures = New System.Windows.Forms.Button()
        Me.TabPage5 = New System.Windows.Forms.TabPage()
        Me.CmbBoxEditionServicing_GLVKKeys = New System.Windows.Forms.ComboBox()
        Me.LblEditionServicing_GLVKKeys = New System.Windows.Forms.Label()
        Me.CmbBoxEditionServicing_AVMAKeys = New System.Windows.Forms.ComboBox()
        Me.LblEditionServicing_AVMAKeys = New System.Windows.Forms.Label()
        Me.BtnEditionServicing_GetMountedImageInfo = New System.Windows.Forms.Button()
        Me.BtnEditionServicing_RefreshMountedImage = New System.Windows.Forms.Button()
        Me.LblEditionServicing_UseMountedImage = New System.Windows.Forms.Label()
        Me.CmbBoxEditionServicing_UseImageMounted = New System.Windows.Forms.ComboBox()
        Me.ChkBoxEditionServicing_Online = New System.Windows.Forms.CheckBox()
        Me.LblEditionServicing_Edition = New System.Windows.Forms.Label()
        Me.BtnEditionServicing_SetEdition = New System.Windows.Forms.Button()
        Me.txtEdition = New System.Windows.Forms.TextBox()
        Me.txtProdKey = New System.Windows.Forms.MaskedTextBox()
        Me.BtnEditionServicing_SetProductKey = New System.Windows.Forms.Button()
        Me.LblEditionServicing_ProductKey = New System.Windows.Forms.Label()
        Me.BtnEditionServicing_GetTargetEditions = New System.Windows.Forms.Button()
        Me.BtnEditionServicing_GetCurrentEdition = New System.Windows.Forms.Button()
        Me.TabPage6 = New System.Windows.Forms.TabPage()
        Me.BtnUnattendedServicing_GetMountedImageInfo = New System.Windows.Forms.Button()
        Me.BtnUnattendedServicing_RefreshMountedImage = New System.Windows.Forms.Button()
        Me.LblUnattendedServicing_UseMountedImage = New System.Windows.Forms.Label()
        Me.CmBoxUnattendedServicing_UseImageMounted = New System.Windows.Forms.ComboBox()
        Me.ChkBoxUnattendedServicing_Online = New System.Windows.Forms.CheckBox()
        Me.BtnUnattendedServicing_ChooseUnAttend = New System.Windows.Forms.Button()
        Me.TxtBoxUnattendedServicing_XMLFile = New System.Windows.Forms.TextBox()
        Me.LblUnattendedServicing_XMLFile = New System.Windows.Forms.Label()
        Me.BtnUnattendedServicing_ApplyUnattend = New System.Windows.Forms.Button()
        Me.TabPage7 = New System.Windows.Forms.TabPage()
        Me.BtnApplicationServicing_GetMountedImageInfo = New System.Windows.Forms.Button()
        Me.BtnApplicationServicing_RefreshMountedImage = New System.Windows.Forms.Button()
        Me.LblApplicationServicing_UseMountedImage = New System.Windows.Forms.Label()
        Me.CmbBoxApplicationServicing_UseImageMounted = New System.Windows.Forms.ComboBox()
        Me.BtnApplicationServicing_ChooseMSP = New System.Windows.Forms.Button()
        Me.txtPatchLocation = New System.Windows.Forms.TextBox()
        Me.LblApplicationServicing_MSPFile = New System.Windows.Forms.Label()
        Me.txtPatchCode = New System.Windows.Forms.MaskedTextBox()
        Me.txtProductCode = New System.Windows.Forms.MaskedTextBox()
        Me.BtnApplicationServicing_CheckAppPatch = New System.Windows.Forms.Button()
        Me.BtnApplicationServicing_GetAppPatchInfo = New System.Windows.Forms.Button()
        Me.BtnApplicationServicing_GetAppPatches = New System.Windows.Forms.Button()
        Me.BtnApplicationServicing_GetAppInfo = New System.Windows.Forms.Button()
        Me.LblApplicationServicing_PathCode = New System.Windows.Forms.Label()
        Me.LblApplicationServicing_ProductCode = New System.Windows.Forms.Label()
        Me.BtnApplicationServicing_GetApps = New System.Windows.Forms.Button()
        Me.TabPage8 = New System.Windows.Forms.TabPage()
        Me.LblCaptureImageWim_DescriptionMetadata = New System.Windows.Forms.Label()
        Me.TxtBoxCaptureWIM_Description = New System.Windows.Forms.TextBox()
        Me.LblCaptureImageWim_NameMetadata = New System.Windows.Forms.Label()
        Me.TxtNameMetadata = New System.Windows.Forms.TextBox()
        Me.ChkBoxCaptureImageWim_Verify = New System.Windows.Forms.CheckBox()
        Me.BtnCaptureImageWim_AppendWim = New System.Windows.Forms.Button()
        Me.cmbCompression = New System.Windows.Forms.ComboBox()
        Me.LblCaptureImageWim_Compression = New System.Windows.Forms.Label()
        Me.LblCaptureImageWim_FileName = New System.Windows.Forms.Label()
        Me.TxtFileName = New System.Windows.Forms.TextBox()
        Me.BtnCaptureImageWim_CreateWim = New System.Windows.Forms.Button()
        Me.LblCaptureImageWim_Destination = New System.Windows.Forms.Label()
        Me.LblCaptureImageWim_Source = New System.Windows.Forms.Label()
        Me.BtnCaptureImageWim_BrowseDestination = New System.Windows.Forms.Button()
        Me.txtCaptureDest = New System.Windows.Forms.TextBox()
        Me.txtCaptureSource = New System.Windows.Forms.TextBox()
        Me.BtnCaptureImageWim_BrowseSource = New System.Windows.Forms.Button()
        Me.TabPage9 = New System.Windows.Forms.TabPage()
        Me.LblApplyWim_PatternSWMFile = New System.Windows.Forms.Label()
        Me.TxtBoxApplySource_PatternSWMFile = New System.Windows.Forms.TextBox()
        Me.LblApplyWim_Size = New System.Windows.Forms.Label()
        Me.TxtBoxApplyWim_Size = New System.Windows.Forms.TextBox()
        Me.LblApplyWim_Description = New System.Windows.Forms.Label()
        Me.LblApplyWim_Name = New System.Windows.Forms.Label()
        Me.TxtBoxApplyWim_Description = New System.Windows.Forms.TextBox()
        Me.TxtBoxApplyWim_Name = New System.Windows.Forms.TextBox()
        Me.ChkBoxApplyWim_Verify = New System.Windows.Forms.CheckBox()
        Me.cmbApplyIndex = New System.Windows.Forms.ComboBox()
        Me.LblApplyWim_Index = New System.Windows.Forms.Label()
        Me.BtnApplyWim_ApplyWim = New System.Windows.Forms.Button()
        Me.LblApplyWim_Destination = New System.Windows.Forms.Label()
        Me.LblApplyWim_Source = New System.Windows.Forms.Label()
        Me.BtnApplyWim_BrowseDestination = New System.Windows.Forms.Button()
        Me.txtApplyDest = New System.Windows.Forms.TextBox()
        Me.txtApplySource = New System.Windows.Forms.TextBox()
        Me.BtnApplyWim_BrowseSource = New System.Windows.Forms.Button()
        Me.TabPage10 = New System.Windows.Forms.TabPage()
        Me.ChkBoxExportImage_WimBoot = New System.Windows.Forms.CheckBox()
        Me.ChkBoxExportImage_CheckIntegrity = New System.Windows.Forms.CheckBox()
        Me.CmbBoxExportImage_Compression = New System.Windows.Forms.ComboBox()
        Me.LblExportImage_LevelCompression = New System.Windows.Forms.Label()
        Me.ChkBoxExportImage_Bootable = New System.Windows.Forms.CheckBox()
        Me.CmbBoxExportImage_Index = New System.Windows.Forms.ComboBox()
        Me.LblExportImage_Index = New System.Windows.Forms.Label()
        Me.BtnExportImage_ExportImage = New System.Windows.Forms.Button()
        Me.BtnExportImage_BrowseDestination = New System.Windows.Forms.Button()
        Me.BtnExportImage_BrowseSource = New System.Windows.Forms.Button()
        Me.LblExportImage_Size = New System.Windows.Forms.Label()
        Me.TxtBoxExportImage_Size = New System.Windows.Forms.TextBox()
        Me.LblExportImage_Description = New System.Windows.Forms.Label()
        Me.LblExportImage_Name = New System.Windows.Forms.Label()
        Me.TxtBoxExportImage_Description = New System.Windows.Forms.TextBox()
        Me.TxtBoxExportImage_Name = New System.Windows.Forms.TextBox()
        Me.LblExportImage_Filename = New System.Windows.Forms.Label()
        Me.TxtBoxExportImage_Filename = New System.Windows.Forms.TextBox()
        Me.LblExportImage_Destination = New System.Windows.Forms.Label()
        Me.LblExportImage_Source = New System.Windows.Forms.Label()
        Me.TxtBoxExportImage_Destination = New System.Windows.Forms.TextBox()
        Me.TxtBoxExportImage_Source = New System.Windows.Forms.TextBox()
        Me.TabPage11 = New System.Windows.Forms.TabPage()
        Me.BtnLangAndInterServicing_GetMountedImageInfo = New System.Windows.Forms.Button()
        Me.BtnLangAndInterServicing_RefreshMountedImage = New System.Windows.Forms.Button()
        Me.LblLangAndInterServicing_UseMountedImage = New System.Windows.Forms.Label()
        Me.CmbBoxLangAndInterServ_UseImageMounted = New System.Windows.Forms.ComboBox()
        Me.TxtBoxLangAndInterServ_Distribution = New System.Windows.Forms.TextBox()
        Me.TxtBoxLangAndInterServ_DistributionSetupUILang = New System.Windows.Forms.TextBox()
        Me.LblLangAndInterServ_SetupUILangDistribution = New System.Windows.Forms.Label()
        Me.TxtBoxLangAndInterServ_PathDistribution = New System.Windows.Forms.TextBox()
        Me.BtnLangAndInterServ_LayeredDriver = New System.Windows.Forms.Button()
        Me.CmbBoxLangAndInterServ_SetLayeredDriver = New System.Windows.Forms.ComboBox()
        Me.LblLangAndInterServ_SetLayeredDriver = New System.Windows.Forms.Label()
        Me.ChkBoxLangAndInterServ_Online = New System.Windows.Forms.CheckBox()
        Me.BtnLangAndInterServ_ApplyDistribution = New System.Windows.Forms.Button()
        Me.BtnLangAndInterServ_ApplySetupUILang = New System.Windows.Forms.Button()
        Me.BtnLangAndInterServ_ApplyGenLangINI = New System.Windows.Forms.Button()
        Me.BtnLangAndInterServ_ApplySKUIntlDefaults = New System.Windows.Forms.Button()
        Me.LblLangAndInterServ_Distribution = New System.Windows.Forms.Label()
        Me.CmbBoxLangAndInterServ_SetSetupUILang = New System.Windows.Forms.ComboBox()
        Me.LblLangAndInterServ_SetupUILang = New System.Windows.Forms.Label()
        Me.Button9 = New System.Windows.Forms.Button()
        Me.LblLangAndInterServ_GenLanINI = New System.Windows.Forms.Label()
        Me.CmbBoxLangAndInterServ_SetSKUIntlDefaults = New System.Windows.Forms.ComboBox()
        Me.Button8 = New System.Windows.Forms.Button()
        Me.LblLangAndInterServ_SetSKUIntlDefaults = New System.Windows.Forms.Label()
        Me.CmbBoxLangAndInterServ_SetTimeZone = New System.Windows.Forms.ComboBox()
        Me.BtnLangAndInterServ_ApplyTimeZone = New System.Windows.Forms.Button()
        Me.LblLangAndInterServ_SetTimeZone = New System.Windows.Forms.Label()
        Me.CmbBoxLangAndInterServ_SetInputLocal = New System.Windows.Forms.ComboBox()
        Me.BtnLangAndInterServ_ApplyInputLocale = New System.Windows.Forms.Button()
        Me.LblLangAndInterServ_SetInputLocale = New System.Windows.Forms.Label()
        Me.CmbBoxLangAndInterServ_SetUserLocale = New System.Windows.Forms.ComboBox()
        Me.BtnLangAndInterServ_ApplyUserLocale = New System.Windows.Forms.Button()
        Me.LblLangAndInterServ_SetUserLocale = New System.Windows.Forms.Label()
        Me.CmbBoxLangAndInterServ_SetUILang_SysLocale = New System.Windows.Forms.ComboBox()
        Me.BtnLangAndInterServ_ApplySysLocale = New System.Windows.Forms.Button()
        Me.LblLangAndInterServ_SetSysLocale = New System.Windows.Forms.Label()
        Me.CmbBoxLangAndInterServ_SetSysUILang = New System.Windows.Forms.ComboBox()
        Me.BtnLangAndInterServ_ApplySysUILang = New System.Windows.Forms.Button()
        Me.LblLangAndInterServ_SetSysUILang = New System.Windows.Forms.Label()
        Me.CmbBoxLangAndInterServ_SetUILangFallback = New System.Windows.Forms.ComboBox()
        Me.BtnLangAndInterServ_ApplyUILangFallback = New System.Windows.Forms.Button()
        Me.LblLangAndInterServ_SetUILangFallback = New System.Windows.Forms.Label()
        Me.CmbBoxLangAndInterServ_SetUILang = New System.Windows.Forms.ComboBox()
        Me.BtnLangAndInterServ_ApplyUILang = New System.Windows.Forms.Button()
        Me.LblLangAndInterServ_SetUILang = New System.Windows.Forms.Label()
        Me.CmbBoxLangAndInterServ_SetAllIntl = New System.Windows.Forms.ComboBox()
        Me.BtnLangAndInterServ_ApplyAllIntl = New System.Windows.Forms.Button()
        Me.LblLangAndInterServ_SetAllIntl = New System.Windows.Forms.Label()
        Me.BtnLangAndInterServicing_DisplayInfo = New System.Windows.Forms.Button()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.TabPage12 = New System.Windows.Forms.TabPage()
        Me.BtnExportDriver_GetMountedImageInfo = New System.Windows.Forms.Button()
        Me.BtnExportDriver_RefreshMountedImage = New System.Windows.Forms.Button()
        Me.LblExportDriver_UseMountedImage = New System.Windows.Forms.Label()
        Me.CmbBoxExportDriver_UseImageMounted = New System.Windows.Forms.ComboBox()
        Me.ChkBoxExportDriver_Online = New System.Windows.Forms.CheckBox()
        Me.BtnExportDriver_ExportDriver = New System.Windows.Forms.Button()
        Me.LblExportDriver_Folder = New System.Windows.Forms.Label()
        Me.TxtBoxExport_PathDriverFolder = New System.Windows.Forms.TextBox()
        Me.BtnExportDriver_SelectFolder = New System.Windows.Forms.Button()
        Me.TabPage13 = New System.Windows.Forms.TabPage()
        Me.LblSplitImage_Warning = New System.Windows.Forms.Label()
        Me.BtnSplitImage_WIMChoice = New System.Windows.Forms.Button()
        Me.BtnSplitImage_TargetFolder = New System.Windows.Forms.Button()
        Me.LblSplitImage_DestinationFolder = New System.Windows.Forms.Label()
        Me.TxtBoxSplitImage_DestinationFolder = New System.Windows.Forms.TextBox()
        Me.BtnSplitImage_SplitImage = New System.Windows.Forms.Button()
        Me.ChkBoxSplitImage_CheckIntegrity = New System.Windows.Forms.CheckBox()
        Me.LblSplitImage_SplitSize = New System.Windows.Forms.Label()
        Me.TxtBoxSplitImage_Filesize = New System.Windows.Forms.TextBox()
        Me.LblSplitImage_SWMFilename = New System.Windows.Forms.Label()
        Me.LblSplitImage_WIMFilename = New System.Windows.Forms.Label()
        Me.TxtBoxSplitImage_SWMFilename = New System.Windows.Forms.TextBox()
        Me.TxtBoxSplitImage_WIMFilename = New System.Windows.Forms.TextBox()
        Me.TabPage14 = New System.Windows.Forms.TabPage()
        Me.LblCaptureFfu_Warning = New System.Windows.Forms.Label()
        Me.LblCaptureFfu_Description = New System.Windows.Forms.Label()
        Me.TxtBoxCaptureFfu_Description = New System.Windows.Forms.TextBox()
        Me.LstBoxCaptureFfu_LogicalDrive = New System.Windows.Forms.ListBox()
        Me.LblCaptureFfu_LogicalDrive = New System.Windows.Forms.Label()
        Me.LblCaptureFfu_Name = New System.Windows.Forms.Label()
        Me.TxtBoxCaptFfu_Name = New System.Windows.Forms.TextBox()
        Me.LblCaptureFfu_PlatformID = New System.Windows.Forms.Label()
        Me.TxtBoxCaptFfu_PlatformID = New System.Windows.Forms.TextBox()
        Me.LblCaptureFfu_Compression = New System.Windows.Forms.Label()
        Me.LblCaptureFfu_TargetFilename = New System.Windows.Forms.Label()
        Me.LblCaptureFfu_TargetFolder = New System.Windows.Forms.Label()
        Me.LblCaptureFfu_PhysicalDrive = New System.Windows.Forms.Label()
        Me.CmbBoxCaptureFfu_Compression = New System.Windows.Forms.ComboBox()
        Me.TxtBoxCaptFfu_TargetFilename = New System.Windows.Forms.TextBox()
        Me.TxtBoxCaptFfu_TargetFolder = New System.Windows.Forms.TextBox()
        Me.TxtBoxCaptFfu_PhysicalDrive = New System.Windows.Forms.TextBox()
        Me.BtnCaptureFfu_StartCapture = New System.Windows.Forms.Button()
        Me.BtnCaptureFfu_SetTargetFolder = New System.Windows.Forms.Button()
        Me.BtnCaptureFfu_UpdateLogicalDrive = New System.Windows.Forms.Button()
        Me.TabPage15 = New System.Windows.Forms.TabPage()
        Me.LstBoxApplyFfuImage_LogicalDrive = New System.Windows.Forms.ListBox()
        Me.LblApplyFfuImage_LogicalDrive = New System.Windows.Forms.Label()
        Me.LblApplyFfuImage_MotifSFUFile = New System.Windows.Forms.Label()
        Me.LblApplyFfuImage_SourceFilename = New System.Windows.Forms.Label()
        Me.LblApplyFfuImage_PhysicalDrive = New System.Windows.Forms.Label()
        Me.TxtBoxApplyFfuImageFfu_MotifSFUFile = New System.Windows.Forms.TextBox()
        Me.TxtBoxApplyFfuImage_FfuSourceFilename = New System.Windows.Forms.TextBox()
        Me.TxtBoxApplyFfuImage_PhysicalDrive = New System.Windows.Forms.TextBox()
        Me.BtnApplyFfuImage_ApplyFfuImage = New System.Windows.Forms.Button()
        Me.BtnApplyFfuImage_SelectFfuFile = New System.Windows.Forms.Button()
        Me.BtnApplyFfuImage_UpdateLogicalDrive = New System.Windows.Forms.Button()
        Me.TabPage16 = New System.Windows.Forms.TabPage()
        Me.LblSplitFfu_Warning = New System.Windows.Forms.Label()
        Me.BtnSplitFfu_SelectFfuFile = New System.Windows.Forms.Button()
        Me.BtnSplitFfu_SelectTargetFolder = New System.Windows.Forms.Button()
        Me.LblSplitFfu_TargetFolder = New System.Windows.Forms.Label()
        Me.TxtBoxSplitFfu_TargetFolder = New System.Windows.Forms.TextBox()
        Me.BtnSplitFfuImage_StartSplitImage = New System.Windows.Forms.Button()
        Me.ChkBoxSplitFfu_CheckIntegrity = New System.Windows.Forms.CheckBox()
        Me.LblSplitFfu_SplitFileSize = New System.Windows.Forms.Label()
        Me.TxtBoxSplitFfu_SplitFileSize = New System.Windows.Forms.TextBox()
        Me.LblSplitFfu_SFUFilename = New System.Windows.Forms.Label()
        Me.LblSplitFfu_FfuFilename = New System.Windows.Forms.Label()
        Me.TxtBoxSplitFfu_SFUFilename = New System.Windows.Forms.TextBox()
        Me.TxtBoxSplitFfu_FfuFilename = New System.Windows.Forms.TextBox()
        Me.TabPage17 = New System.Windows.Forms.TabPage()
        Me.BtnAppAssocServ_GetMountedImageInfo = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.BtnDefaultAppAssocServ_RefreshMountedImage = New System.Windows.Forms.Button()
        Me.LblBtnDefaultAppAssocServ_UseMountedImage = New System.Windows.Forms.Label()
        Me.CmbBoxDefaultAppAssocServicing_UseImageMounted = New System.Windows.Forms.ComboBox()
        Me.LblDefaultAppAssocServ_Warning = New System.Windows.Forms.Label()
        Me.LblLblDefaultAppAssocServ_ExportFilename = New System.Windows.Forms.Label()
        Me.TxtBoxDefaultAppAssocServ_ExportFilenameXML = New System.Windows.Forms.TextBox()
        Me.BtnDefaultAppAssocServ_ChooseFolder = New System.Windows.Forms.Button()
        Me.LblDefaultAppAssocServ_ExportFolder = New System.Windows.Forms.Label()
        Me.TxtBoxDefaultAppAssocServ_ExportFolder = New System.Windows.Forms.TextBox()
        Me.BtnDefaultAppAssocServ_ChooseFile = New System.Windows.Forms.Button()
        Me.LblDefaultAppAssocServ_ImportFilename = New System.Windows.Forms.Label()
        Me.TxtBoxDefaultAppAssocServ_ImportFilenameXML = New System.Windows.Forms.TextBox()
        Me.BtnDefaultAppAssocServ_Remove = New System.Windows.Forms.Button()
        Me.BtnDefaultAppAssocServ_Export = New System.Windows.Forms.Button()
        Me.BtnDefaultAppAssocServ_Import = New System.Windows.Forms.Button()
        Me.ChkBoxDefaultAppAssocServ_Online = New System.Windows.Forms.CheckBox()
        Me.BtnDefaultAppAssocServ_GetDefaultAppAssoc = New System.Windows.Forms.Button()
        Me.TabPage18 = New System.Windows.Forms.TabPage()
        Me.ChkBoxCapPackServ_IncludeImageCapabilities = New System.Windows.Forms.CheckBox()
        Me.BtnCapPackServ_SelectTarget = New System.Windows.Forms.Button()
        Me.BtnCapPackServ_SelectSource = New System.Windows.Forms.Button()
        Me.BtnCapPackServ_GetMountedImageInfo = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.BtnCapPackServ_RefreshMountedImage = New System.Windows.Forms.Button()
        Me.LblCapPackServ_UseMountedImage = New System.Windows.Forms.Label()
        Me.CmbBoxCapPackServicing_UseImageMounted = New System.Windows.Forms.ComboBox()
        Me.ChkBoxCapPackServ_Online = New System.Windows.Forms.CheckBox()
        Me.BtnCapPackServ_GetCap = New System.Windows.Forms.Button()
        Me.BtnCapPackServ_RemoveCap = New System.Windows.Forms.Button()
        Me.BtnCapPackServ_GetCapInfo = New System.Windows.Forms.Button()
        Me.BtnCapPackServ_ExportSource = New System.Windows.Forms.Button()
        Me.LblCapPackServ_TargetExportSource = New System.Windows.Forms.Label()
        Me.TxtBoxCapPackServ_Target = New System.Windows.Forms.TextBox()
        Me.LblCapPackServ_SourceExportSource = New System.Windows.Forms.Label()
        Me.TxtBoxCapPackServ_Source = New System.Windows.Forms.TextBox()
        Me.ChkBoxCapPackServ_LimitAccess = New System.Windows.Forms.CheckBox()
        Me.BtnCapPackServ_AddCapability = New System.Windows.Forms.Button()
        Me.LblCapPackServ_CapabilityNameAddCap = New System.Windows.Forms.Label()
        Me.TxtBoxCapPackServ_CapabilityName = New System.Windows.Forms.TextBox()
        Me.TabPage19 = New System.Windows.Forms.TabPage()
        Me.BtnCleanupImage_GetMountedImageInfo = New System.Windows.Forms.Button()
        Me.BtnCleanupImage_RefreshMountedImage = New System.Windows.Forms.Button()
        Me.LblCleanupImage_UseMountedImage = New System.Windows.Forms.Label()
        Me.CmbBoxCleanupImage_UseImageMounted = New System.Windows.Forms.ComboBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.cmbCleanupImage_IndexSource = New System.Windows.Forms.ComboBox()
        Me.BtnCleanupImage_ChooseSourceRestoreHealth = New System.Windows.Forms.Button()
        Me.BtnCleanupImage_RestoreHealth = New System.Windows.Forms.Button()
        Me.BtnCleanupImage_ScanHealth = New System.Windows.Forms.Button()
        Me.BtnCleanupImage_StartComponentCleanup = New System.Windows.Forms.Button()
        Me.BtnCleanupImage_Superseded = New System.Windows.Forms.Button()
        Me.BtnCleanupImage_RevertPendingActions = New System.Windows.Forms.Button()
        Me.BtnCleanupImage_CheckHealth = New System.Windows.Forms.Button()
        Me.ChkBoxCleanupImage_Online = New System.Windows.Forms.CheckBox()
        Me.ChkBoxCleanupImage_LimitAccessRestoreHealth = New System.Windows.Forms.CheckBox()
        Me.ChkBoxCleanupImage_Defer = New System.Windows.Forms.CheckBox()
        Me.ChkBoxCleanupImage_ResetBase = New System.Windows.Forms.CheckBox()
        Me.ChkBoxCleanupImage_HideSP = New System.Windows.Forms.CheckBox()
        Me.BtnCleanupImage_AnalyzeComponentStore = New System.Windows.Forms.Button()
        Me.LblCleanupImage_SourceRestoreHealth = New System.Windows.Forms.Label()
        Me.TxtBoxCleanupImage_SourceRestoreHealth = New System.Windows.Forms.TextBox()
        Me.TabPage20 = New System.Windows.Forms.TabPage()
        Me.BtnMakeWinPEISO = New System.Windows.Forms.Button()
        Me.GrpBoxDiskpartWinPE_HardwareType = New System.Windows.Forms.GroupBox()
        Me.RadBtnDiskpartWinPE_WinPEx86 = New System.Windows.Forms.RadioButton()
        Me.RadBtnDiskpartWinPE_WinPEamd64 = New System.Windows.Forms.RadioButton()
        Me.BtnDiskpartWinPE_BootDiskWinPE = New System.Windows.Forms.Button()
        Me.BtnDiskpartWinPE_CreateWinPETemplate = New System.Windows.Forms.Button()
        Me.PictBoxDiskpartWinPE_Picture = New System.Windows.Forms.PictureBox()
        Me.TxtBoxDiskpartWinPE_Recovery = New System.Windows.Forms.TextBox()
        Me.LblDiskpartWinPE_Recovery = New System.Windows.Forms.Label()
        Me.TxtBoxDiskpartWinPE_Windows = New System.Windows.Forms.TextBox()
        Me.LblDiskpartWinPE_Windows = New System.Windows.Forms.Label()
        Me.TxtBoxDiskpartWinPE_MSR = New System.Windows.Forms.TextBox()
        Me.LblDiskpartWinPE_MSR = New System.Windows.Forms.Label()
        Me.TxtBoxDiskpartWinPE_System = New System.Windows.Forms.TextBox()
        Me.LblDiskpartWinPE_System = New System.Windows.Forms.Label()
        Me.TxtBoxDiskpartWinPE_NTFSSize = New System.Windows.Forms.TextBox()
        Me.LblDiskpartWinPE_NTFSSize = New System.Windows.Forms.Label()
        Me.TxtBoxDiskpartWinPE_FAT32Size = New System.Windows.Forms.TextBox()
        Me.LblDiskpartWinPE_FAT32Size = New System.Windows.Forms.Label()
        Me.RadBtnDiskpartWinPE_HardDriveUEFI = New System.Windows.Forms.RadioButton()
        Me.RadBtnDiskpartWinPE_HardDriveBIOS = New System.Windows.Forms.RadioButton()
        Me.RadBtnDiskparWinPE_FAT32NTFS = New System.Windows.Forms.RadioButton()
        Me.RadBtnDiskpartWinPE_NTFS = New System.Windows.Forms.RadioButton()
        Me.RadBtnDiskpartWinPE_FAT32 = New System.Windows.Forms.RadioButton()
        Me.BtnDiskpartWinPE_FormatDisk = New System.Windows.Forms.Button()
        Me.LblDiskpartWinPE_SelectDrive = New System.Windows.Forms.Label()
        Me.CmbBoxDiskpartWinpe_SelectDrive = New System.Windows.Forms.ComboBox()
        Me.TxtBoxDispartWinPE_InfosDisk = New System.Windows.Forms.TextBox()
        Me.BtnDiskpartWinPE_RefreshListDisk = New System.Windows.Forms.Button()
        Me.TabPage21 = New System.Windows.Forms.TabPage()
        Me.BtnCustomWinPE_ApplyDetectTypeBios = New System.Windows.Forms.Button()
        Me.BtnCustomWinPE_ApplyMaxPerf = New System.Windows.Forms.Button()
        Me.ChkboxCustomWinPE_AddMaxPowerPerf = New System.Windows.Forms.CheckBox()
        Me.ChkboxCustomWinPE_AddScriptWinPEDetectTypeBios = New System.Windows.Forms.CheckBox()
        Me.LblCustomWinPE_Packages = New System.Windows.Forms.Label()
        Me.CmbBoxCustomWinPE_Language = New System.Windows.Forms.ComboBox()
        Me.LblCustomWinPE_Language = New System.Windows.Forms.Label()
        Me.RadBtnCustomWinPE_TypeAmd64 = New System.Windows.Forms.RadioButton()
        Me.RadBtnCustomWinPE_TypeX86 = New System.Windows.Forms.RadioButton()
        Me.LblCustomWinPE_SystemType = New System.Windows.Forms.Label()
        Me.BtnCustomWinPE_DetectADK = New System.Windows.Forms.Button()
        Me.TxtBoxCustomWinPE_DetectADKPath = New System.Windows.Forms.TextBox()
        Me.LblCustomWinPE_DetectADKPath = New System.Windows.Forms.Label()
        Me.BtnCustomWinPE_Apply = New System.Windows.Forms.Button()
        Me.ChkboxCustomWinPE_StorageWMI = New System.Windows.Forms.CheckBox()
        Me.ChkboxCustomWinPE_Scripting = New System.Windows.Forms.CheckBox()
        Me.ChkboxCustomWinPE_PowerShell = New System.Windows.Forms.CheckBox()
        Me.ChkboxCustomWinPE_NetFx = New System.Windows.Forms.CheckBox()
        Me.ChkboxCustomWinPE_WMI = New System.Windows.Forms.CheckBox()
        Me.ChkboxCustomWinPE_MDAC = New System.Windows.Forms.CheckBox()
        Me.ChkboxCustomWinPE_HTA = New System.Windows.Forms.CheckBox()
        Me.BtnCustomWinPE_GetMountedImageInfo = New System.Windows.Forms.Button()
        Me.BtnCustomWinPE_RefreshMountedImage = New System.Windows.Forms.Button()
        Me.LblCustomWinPE_UseImageMounted = New System.Windows.Forms.Label()
        Me.CmbBoxCustomWinPE_UseImageMounted = New System.Windows.Forms.ComboBox()
        Me.BackgroundWorkerDISMCommand = New System.ComponentModel.BackgroundWorker()
        Me.dlgOpenXML = New System.Windows.Forms.OpenFileDialog()
        Me.dlgOpenMSP = New System.Windows.Forms.OpenFileDialog()
        Me.BtnMountControl_ClearConsole = New System.Windows.Forms.Button()
        Me.TxtBox_DismVersionWindows = New System.Windows.Forms.TextBox()
        Me.LblMountUnmount_DismVersion = New System.Windows.Forms.Label()
        Me.LblMountUnmount_DismADKVersion = New System.Windows.Forms.Label()
        Me.TxtBox_DismVersionADK = New System.Windows.Forms.TextBox()
        Me.BackgroundWorkerDismCommand2 = New System.ComponentModel.BackgroundWorker()
        Me.MenuStrip1.SuspendLayout()
        Me.TabControl1.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.TabPage2.SuspendLayout()
        Me.GroupBoxDriverManagement_DeleteDrivers.SuspendLayout()
        Me.GroupBoxDriverManagement_AddDrivers.SuspendLayout()
        Me.TabPage3.SuspendLayout()
        Me.GrpBoxPackageManage_RemovePackages.SuspendLayout()
        Me.GrpBoxPackageManage_AddPackage.SuspendLayout()
        Me.TabPage4.SuspendLayout()
        Me.TabPage5.SuspendLayout()
        Me.TabPage6.SuspendLayout()
        Me.TabPage7.SuspendLayout()
        Me.TabPage8.SuspendLayout()
        Me.TabPage9.SuspendLayout()
        Me.TabPage10.SuspendLayout()
        Me.TabPage11.SuspendLayout()
        Me.TabPage12.SuspendLayout()
        Me.TabPage13.SuspendLayout()
        Me.TabPage14.SuspendLayout()
        Me.TabPage15.SuspendLayout()
        Me.TabPage16.SuspendLayout()
        Me.TabPage17.SuspendLayout()
        Me.TabPage18.SuspendLayout()
        Me.TabPage19.SuspendLayout()
        Me.TabPage20.SuspendLayout()
        Me.GrpBoxDiskpartWinPE_HardwareType.SuspendLayout()
        CType(Me.PictBoxDiskpartWinPE_Picture, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage21.SuspendLayout()
        Me.SuspendLayout()
        '
        'TxtMountControl_ImageFile
        '
        Me.TxtMountControl_ImageFile.Location = New System.Drawing.Point(143, 17)
        Me.TxtMountControl_ImageFile.Name = "TxtMountControl_ImageFile"
        Me.TxtMountControl_ImageFile.Size = New System.Drawing.Size(339, 26)
        Me.TxtMountControl_ImageFile.TabIndex = 0
        '
        'LblMountControl_WimFile
        '
        Me.LblMountControl_WimFile.AutoSize = True
        Me.LblMountControl_WimFile.Location = New System.Drawing.Point(10, 20)
        Me.LblMountControl_WimFile.Name = "LblMountControl_WimFile"
        Me.LblMountControl_WimFile.Size = New System.Drawing.Size(127, 20)
        Me.LblMountControl_WimFile.TabIndex = 1
        Me.LblMountControl_WimFile.Text = "Image Filename:"
        '
        'LblMountControl_MountLocation
        '
        Me.LblMountControl_MountLocation.AutoSize = True
        Me.LblMountControl_MountLocation.Location = New System.Drawing.Point(9, 91)
        Me.LblMountControl_MountLocation.Name = "LblMountControl_MountLocation"
        Me.LblMountControl_MountLocation.Size = New System.Drawing.Size(123, 20)
        Me.LblMountControl_MountLocation.TabIndex = 2
        Me.LblMountControl_MountLocation.Text = "Mount Location:"
        '
        'TxtMountControl_MountLocation
        '
        Me.TxtMountControl_MountLocation.Location = New System.Drawing.Point(143, 88)
        Me.TxtMountControl_MountLocation.Name = "TxtMountControl_MountLocation"
        Me.TxtMountControl_MountLocation.Size = New System.Drawing.Size(339, 26)
        Me.TxtMountControl_MountLocation.TabIndex = 3
        '
        'dlgOpenFolder
        '
        Me.dlgOpenFolder.SelectedPath = "c:\"
        '
        'BtnMountControl_OpenWIM
        '
        Me.BtnMountControl_OpenWIM.Location = New System.Drawing.Point(519, 17)
        Me.BtnMountControl_OpenWIM.Name = "BtnMountControl_OpenWIM"
        Me.BtnMountControl_OpenWIM.Size = New System.Drawing.Size(135, 28)
        Me.BtnMountControl_OpenWIM.TabIndex = 4
        Me.BtnMountControl_OpenWIM.Text = "Choose Image"
        Me.BtnMountControl_OpenWIM.UseVisualStyleBackColor = True
        '
        'BtnMountControl_OpenMount
        '
        Me.BtnMountControl_OpenMount.Location = New System.Drawing.Point(519, 87)
        Me.BtnMountControl_OpenMount.Name = "BtnMountControl_OpenMount"
        Me.BtnMountControl_OpenMount.Size = New System.Drawing.Size(135, 29)
        Me.BtnMountControl_OpenMount.TabIndex = 5
        Me.BtnMountControl_OpenMount.Text = "Choose Folder"
        Me.BtnMountControl_OpenMount.UseVisualStyleBackColor = True
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolsToolStripMenuItem, Me.LanguageToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(955, 29)
        Me.MenuStrip1.TabIndex = 6
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'ToolsToolStripMenuItem
        '
        Me.ToolsToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.OpenDISMLogToolStripMenuItem, Me.GetWIMInfoToolStripMenuItem, Me.CleanupWIMToolStripMenuItem, Me.CleanupImageToolStripMenuItem, Me.UseDismADKToolStripMenuItem, Me.AboutToolStripMenuItem})
        Me.ToolsToolStripMenuItem.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ToolsToolStripMenuItem.Name = "ToolsToolStripMenuItem"
        Me.ToolsToolStripMenuItem.Size = New System.Drawing.Size(57, 25)
        Me.ToolsToolStripMenuItem.Text = "Tools"
        '
        'OpenDISMLogToolStripMenuItem
        '
        Me.OpenDISMLogToolStripMenuItem.Name = "OpenDISMLogToolStripMenuItem"
        Me.OpenDISMLogToolStripMenuItem.Size = New System.Drawing.Size(346, 26)
        Me.OpenDISMLogToolStripMenuItem.Text = "Open DISM Log"
        '
        'GetWIMInfoToolStripMenuItem
        '
        Me.GetWIMInfoToolStripMenuItem.Name = "GetWIMInfoToolStripMenuItem"
        Me.GetWIMInfoToolStripMenuItem.Size = New System.Drawing.Size(346, 26)
        Me.GetWIMInfoToolStripMenuItem.Text = "Get Mounted WIM Info"
        '
        'CleanupWIMToolStripMenuItem
        '
        Me.CleanupWIMToolStripMenuItem.Name = "CleanupWIMToolStripMenuItem"
        Me.CleanupWIMToolStripMenuItem.Size = New System.Drawing.Size(346, 26)
        Me.CleanupWIMToolStripMenuItem.Text = "Cleanup WIM"
        '
        'CleanupImageToolStripMenuItem
        '
        Me.CleanupImageToolStripMenuItem.Name = "CleanupImageToolStripMenuItem"
        Me.CleanupImageToolStripMenuItem.Size = New System.Drawing.Size(346, 26)
        Me.CleanupImageToolStripMenuItem.Text = "Cleanup Image /RevertPendingActions"
        '
        'UseDismADKToolStripMenuItem
        '
        Me.UseDismADKToolStripMenuItem.CheckOnClick = True
        Me.UseDismADKToolStripMenuItem.Name = "UseDismADKToolStripMenuItem"
        Me.UseDismADKToolStripMenuItem.Size = New System.Drawing.Size(346, 26)
        Me.UseDismADKToolStripMenuItem.Text = "Use Dism ADK"
        '
        'AboutToolStripMenuItem
        '
        Me.AboutToolStripMenuItem.Name = "AboutToolStripMenuItem"
        Me.AboutToolStripMenuItem.Size = New System.Drawing.Size(346, 26)
        Me.AboutToolStripMenuItem.Text = "About"
        '
        'LanguageToolStripMenuItem
        '
        Me.LanguageToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FrenchToolStripMenuItem, Me.EnglishToolStripMenuItem})
        Me.LanguageToolStripMenuItem.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LanguageToolStripMenuItem.Name = "LanguageToolStripMenuItem"
        Me.LanguageToolStripMenuItem.Size = New System.Drawing.Size(90, 25)
        Me.LanguageToolStripMenuItem.Text = "Language"
        '
        'FrenchToolStripMenuItem
        '
        Me.FrenchToolStripMenuItem.CheckOnClick = True
        Me.FrenchToolStripMenuItem.Name = "FrenchToolStripMenuItem"
        Me.FrenchToolStripMenuItem.Size = New System.Drawing.Size(130, 26)
        Me.FrenchToolStripMenuItem.Text = "French"
        '
        'EnglishToolStripMenuItem
        '
        Me.EnglishToolStripMenuItem.CheckOnClick = True
        Me.EnglishToolStripMenuItem.Name = "EnglishToolStripMenuItem"
        Me.EnglishToolStripMenuItem.Size = New System.Drawing.Size(130, 26)
        Me.EnglishToolStripMenuItem.Text = "English"
        '
        'BtnMountControl_MountImage
        '
        Me.BtnMountControl_MountImage.Location = New System.Drawing.Point(423, 181)
        Me.BtnMountControl_MountImage.Name = "BtnMountControl_MountImage"
        Me.BtnMountControl_MountImage.Size = New System.Drawing.Size(135, 33)
        Me.BtnMountControl_MountImage.TabIndex = 7
        Me.BtnMountControl_MountImage.Text = "Mount Image"
        Me.BtnMountControl_MountImage.UseVisualStyleBackColor = True
        '
        'CmbMountControl_Index
        '
        Me.CmbMountControl_Index.FormattingEnabled = True
        Me.CmbMountControl_Index.Location = New System.Drawing.Point(401, 52)
        Me.CmbMountControl_Index.Name = "CmbMountControl_Index"
        Me.CmbMountControl_Index.Size = New System.Drawing.Size(81, 28)
        Me.CmbMountControl_Index.TabIndex = 8
        '
        'BtnMountControl_UnmountImage
        '
        Me.BtnMountControl_UnmountImage.Location = New System.Drawing.Point(423, 314)
        Me.BtnMountControl_UnmountImage.Name = "BtnMountControl_UnmountImage"
        Me.BtnMountControl_UnmountImage.Size = New System.Drawing.Size(135, 33)
        Me.BtnMountControl_UnmountImage.TabIndex = 10
        Me.BtnMountControl_UnmountImage.Text = "Unmount Image"
        Me.BtnMountControl_UnmountImage.UseVisualStyleBackColor = True
        '
        'txtOutput
        '
        Me.txtOutput.Location = New System.Drawing.Point(11, 443)
        Me.txtOutput.Multiline = True
        Me.txtOutput.Name = "txtOutput"
        Me.txtOutput.ScrollBars = System.Windows.Forms.ScrollBars.Both
        Me.txtOutput.Size = New System.Drawing.Size(890, 225)
        Me.txtOutput.TabIndex = 13
        Me.txtOutput.WordWrap = False
        '
        'LblMountControl_DISMOutput
        '
        Me.LblMountControl_DISMOutput.AutoSize = True
        Me.LblMountControl_DISMOutput.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblMountControl_DISMOutput.Location = New System.Drawing.Point(7, 416)
        Me.LblMountControl_DISMOutput.Name = "LblMountControl_DISMOutput"
        Me.LblMountControl_DISMOutput.Size = New System.Drawing.Size(107, 20)
        Me.LblMountControl_DISMOutput.TabIndex = 14
        Me.LblMountControl_DISMOutput.Text = "DISM Output:"
        '
        'BtnMountControl_OpenMountedFolder
        '
        Me.BtnMountControl_OpenMountedFolder.Location = New System.Drawing.Point(593, 278)
        Me.BtnMountControl_OpenMountedFolder.Name = "BtnMountControl_OpenMountedFolder"
        Me.BtnMountControl_OpenMountedFolder.Size = New System.Drawing.Size(135, 64)
        Me.BtnMountControl_OpenMountedFolder.TabIndex = 15
        Me.BtnMountControl_OpenMountedFolder.Text = "Open Mounted Folder"
        Me.BtnMountControl_OpenMountedFolder.UseVisualStyleBackColor = True
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(343, 55)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(52, 20)
        Me.Label3.TabIndex = 17
        Me.Label3.Text = "Index:"
        '
        'BackgroundWorkerMount
        '
        Me.BackgroundWorkerMount.WorkerReportsProgress = True
        Me.BackgroundWorkerMount.WorkerSupportsCancellation = True
        '
        'BackgroundWorkerDisMount
        '
        Me.BackgroundWorkerDisMount.WorkerReportsProgress = True
        Me.BackgroundWorkerDisMount.WorkerSupportsCancellation = True
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Controls.Add(Me.TabPage3)
        Me.TabControl1.Controls.Add(Me.TabPage4)
        Me.TabControl1.Controls.Add(Me.TabPage5)
        Me.TabControl1.Controls.Add(Me.TabPage6)
        Me.TabControl1.Controls.Add(Me.TabPage7)
        Me.TabControl1.Controls.Add(Me.TabPage8)
        Me.TabControl1.Controls.Add(Me.TabPage9)
        Me.TabControl1.Controls.Add(Me.TabPage10)
        Me.TabControl1.Controls.Add(Me.TabPage11)
        Me.TabControl1.Controls.Add(Me.TabPage12)
        Me.TabControl1.Controls.Add(Me.TabPage13)
        Me.TabControl1.Controls.Add(Me.TabPage14)
        Me.TabControl1.Controls.Add(Me.TabPage15)
        Me.TabControl1.Controls.Add(Me.TabPage16)
        Me.TabControl1.Controls.Add(Me.TabPage17)
        Me.TabControl1.Controls.Add(Me.TabPage18)
        Me.TabControl1.Controls.Add(Me.TabPage19)
        Me.TabControl1.Controls.Add(Me.TabPage20)
        Me.TabControl1.Controls.Add(Me.TabPage21)
        Me.TabControl1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TabControl1.Location = New System.Drawing.Point(11, 27)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(894, 383)
        Me.TabControl1.TabIndex = 18
        '
        'TabPage1
        '
        Me.TabPage1.Controls.Add(Me.LblMountControl_AlreadyMounted)
        Me.TabPage1.Controls.Add(Me.BtnMountControl_RefreshMountedImage)
        Me.TabPage1.Controls.Add(Me.CmbBoxMountControl_AlreadyMounted)
        Me.TabPage1.Controls.Add(Me.RadBtnMountControl_Commit)
        Me.TabPage1.Controls.Add(Me.RadBtnMountControl_Discard)
        Me.TabPage1.Controls.Add(Me.ChkBoxMountControl_Append)
        Me.TabPage1.Controls.Add(Me.ChkBoxMountControl_CheckIntegrity)
        Me.TabPage1.Controls.Add(Me.ChkBoxMountControl_Optimize)
        Me.TabPage1.Controls.Add(Me.BtnMountControl_RemountWim)
        Me.TabPage1.Controls.Add(Me.BtnMountControl_CleanupMountPoints)
        Me.TabPage1.Controls.Add(Me.BtnMountControl_CommitImage)
        Me.TabPage1.Controls.Add(Me.BtnMountControl_GetMountedImageInfo)
        Me.TabPage1.Controls.Add(Me.BtnMountControl_DisplayImageInfo)
        Me.TabPage1.Controls.Add(Me.LblMountControl_Size)
        Me.TabPage1.Controls.Add(Me.LblMountControl_Description)
        Me.TabPage1.Controls.Add(Me.LblMountControl_Name)
        Me.TabPage1.Controls.Add(Me.TxtBoxMountControl_Size)
        Me.TabPage1.Controls.Add(Me.TxtBoxMountControl_Description)
        Me.TabPage1.Controls.Add(Me.TxtBoxMountControl_Name)
        Me.TabPage1.Controls.Add(Me.ChkMountControl_ReadOnly)
        Me.TabPage1.Controls.Add(Me.BtnMountControl_OpenWIM)
        Me.TabPage1.Controls.Add(Me.Label3)
        Me.TabPage1.Controls.Add(Me.TxtMountControl_ImageFile)
        Me.TabPage1.Controls.Add(Me.LblMountControl_WimFile)
        Me.TabPage1.Controls.Add(Me.BtnMountControl_OpenMountedFolder)
        Me.TabPage1.Controls.Add(Me.LblMountControl_MountLocation)
        Me.TabPage1.Controls.Add(Me.TxtMountControl_MountLocation)
        Me.TabPage1.Controls.Add(Me.BtnMountControl_OpenMount)
        Me.TabPage1.Controls.Add(Me.BtnMountControl_UnmountImage)
        Me.TabPage1.Controls.Add(Me.BtnMountControl_MountImage)
        Me.TabPage1.Controls.Add(Me.CmbMountControl_Index)
        Me.TabPage1.Location = New System.Drawing.Point(4, 29)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(886, 350)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "Mount / Unmount Control"
        Me.TabPage1.UseVisualStyleBackColor = True
        '
        'LblMountControl_AlreadyMounted
        '
        Me.LblMountControl_AlreadyMounted.AutoSize = True
        Me.LblMountControl_AlreadyMounted.Location = New System.Drawing.Point(9, 133)
        Me.LblMountControl_AlreadyMounted.Name = "LblMountControl_AlreadyMounted"
        Me.LblMountControl_AlreadyMounted.Size = New System.Drawing.Size(133, 20)
        Me.LblMountControl_AlreadyMounted.TabIndex = 40
        Me.LblMountControl_AlreadyMounted.Text = "Already Mounted:"
        '
        'BtnMountControl_RefreshMountedImage
        '
        Me.BtnMountControl_RefreshMountedImage.Location = New System.Drawing.Point(488, 127)
        Me.BtnMountControl_RefreshMountedImage.Name = "BtnMountControl_RefreshMountedImage"
        Me.BtnMountControl_RefreshMountedImage.Size = New System.Drawing.Size(190, 32)
        Me.BtnMountControl_RefreshMountedImage.TabIndex = 39
        Me.BtnMountControl_RefreshMountedImage.Text = "Refresh mounted image"
        Me.BtnMountControl_RefreshMountedImage.UseVisualStyleBackColor = True
        '
        'CmbBoxMountControl_AlreadyMounted
        '
        Me.CmbBoxMountControl_AlreadyMounted.FormattingEnabled = True
        Me.CmbBoxMountControl_AlreadyMounted.Location = New System.Drawing.Point(143, 130)
        Me.CmbBoxMountControl_AlreadyMounted.Name = "CmbBoxMountControl_AlreadyMounted"
        Me.CmbBoxMountControl_AlreadyMounted.Size = New System.Drawing.Size(339, 28)
        Me.CmbBoxMountControl_AlreadyMounted.TabIndex = 38
        '
        'RadBtnMountControl_Commit
        '
        Me.RadBtnMountControl_Commit.AutoSize = True
        Me.RadBtnMountControl_Commit.Location = New System.Drawing.Point(126, 319)
        Me.RadBtnMountControl_Commit.Name = "RadBtnMountControl_Commit"
        Me.RadBtnMountControl_Commit.Size = New System.Drawing.Size(85, 24)
        Me.RadBtnMountControl_Commit.TabIndex = 37
        Me.RadBtnMountControl_Commit.Text = "/Commit"
        Me.RadBtnMountControl_Commit.UseVisualStyleBackColor = True
        '
        'RadBtnMountControl_Discard
        '
        Me.RadBtnMountControl_Discard.AutoSize = True
        Me.RadBtnMountControl_Discard.Checked = True
        Me.RadBtnMountControl_Discard.Location = New System.Drawing.Point(10, 318)
        Me.RadBtnMountControl_Discard.Name = "RadBtnMountControl_Discard"
        Me.RadBtnMountControl_Discard.Size = New System.Drawing.Size(85, 24)
        Me.RadBtnMountControl_Discard.TabIndex = 36
        Me.RadBtnMountControl_Discard.TabStop = True
        Me.RadBtnMountControl_Discard.Text = "/Discard"
        Me.RadBtnMountControl_Discard.UseVisualStyleBackColor = True
        '
        'ChkBoxMountControl_Append
        '
        Me.ChkBoxMountControl_Append.AutoSize = True
        Me.ChkBoxMountControl_Append.Location = New System.Drawing.Point(238, 320)
        Me.ChkBoxMountControl_Append.Name = "ChkBoxMountControl_Append"
        Me.ChkBoxMountControl_Append.Size = New System.Drawing.Size(88, 24)
        Me.ChkBoxMountControl_Append.TabIndex = 35
        Me.ChkBoxMountControl_Append.Text = "/Append"
        Me.ChkBoxMountControl_Append.UseVisualStyleBackColor = True
        '
        'ChkBoxMountControl_CheckIntegrity
        '
        Me.ChkBoxMountControl_CheckIntegrity.AutoSize = True
        Me.ChkBoxMountControl_CheckIntegrity.Location = New System.Drawing.Point(217, 186)
        Me.ChkBoxMountControl_CheckIntegrity.Name = "ChkBoxMountControl_CheckIntegrity"
        Me.ChkBoxMountControl_CheckIntegrity.Size = New System.Drawing.Size(200, 24)
        Me.ChkBoxMountControl_CheckIntegrity.TabIndex = 32
        Me.ChkBoxMountControl_CheckIntegrity.Text = "/CheckIntegrity (not vhd)"
        Me.ChkBoxMountControl_CheckIntegrity.UseVisualStyleBackColor = True
        '
        'ChkBoxMountControl_Optimize
        '
        Me.ChkBoxMountControl_Optimize.AutoSize = True
        Me.ChkBoxMountControl_Optimize.Location = New System.Drawing.Point(124, 186)
        Me.ChkBoxMountControl_Optimize.Name = "ChkBoxMountControl_Optimize"
        Me.ChkBoxMountControl_Optimize.Size = New System.Drawing.Size(94, 24)
        Me.ChkBoxMountControl_Optimize.TabIndex = 31
        Me.ChkBoxMountControl_Optimize.Text = "/Optimize"
        Me.ChkBoxMountControl_Optimize.UseVisualStyleBackColor = True
        '
        'BtnMountControl_RemountWim
        '
        Me.BtnMountControl_RemountWim.Location = New System.Drawing.Point(710, 91)
        Me.BtnMountControl_RemountWim.Name = "BtnMountControl_RemountWim"
        Me.BtnMountControl_RemountWim.Size = New System.Drawing.Size(160, 68)
        Me.BtnMountControl_RemountWim.TabIndex = 30
        Me.BtnMountControl_RemountWim.Text = "Remount Wim"
        Me.BtnMountControl_RemountWim.UseVisualStyleBackColor = True
        '
        'BtnMountControl_CleanupMountPoints
        '
        Me.BtnMountControl_CleanupMountPoints.Location = New System.Drawing.Point(743, 278)
        Me.BtnMountControl_CleanupMountPoints.Name = "BtnMountControl_CleanupMountPoints"
        Me.BtnMountControl_CleanupMountPoints.Size = New System.Drawing.Size(127, 64)
        Me.BtnMountControl_CleanupMountPoints.TabIndex = 29
        Me.BtnMountControl_CleanupMountPoints.Text = "Cleanup Mount Points"
        Me.BtnMountControl_CleanupMountPoints.UseVisualStyleBackColor = True
        '
        'BtnMountControl_CommitImage
        '
        Me.BtnMountControl_CommitImage.Location = New System.Drawing.Point(710, 165)
        Me.BtnMountControl_CommitImage.Name = "BtnMountControl_CommitImage"
        Me.BtnMountControl_CommitImage.Size = New System.Drawing.Size(160, 64)
        Me.BtnMountControl_CommitImage.TabIndex = 28
        Me.BtnMountControl_CommitImage.Text = "Commit Image"
        Me.BtnMountControl_CommitImage.UseVisualStyleBackColor = True
        '
        'BtnMountControl_GetMountedImageInfo
        '
        Me.BtnMountControl_GetMountedImageInfo.Location = New System.Drawing.Point(710, 21)
        Me.BtnMountControl_GetMountedImageInfo.Name = "BtnMountControl_GetMountedImageInfo"
        Me.BtnMountControl_GetMountedImageInfo.Size = New System.Drawing.Size(160, 64)
        Me.BtnMountControl_GetMountedImageInfo.TabIndex = 27
        Me.BtnMountControl_GetMountedImageInfo.Text = "Get Mounted Image Info"
        Me.BtnMountControl_GetMountedImageInfo.UseVisualStyleBackColor = True
        '
        'BtnMountControl_DisplayImageInfo
        '
        Me.BtnMountControl_DisplayImageInfo.Location = New System.Drawing.Point(143, 49)
        Me.BtnMountControl_DisplayImageInfo.Name = "BtnMountControl_DisplayImageInfo"
        Me.BtnMountControl_DisplayImageInfo.Size = New System.Drawing.Size(194, 33)
        Me.BtnMountControl_DisplayImageInfo.TabIndex = 25
        Me.BtnMountControl_DisplayImageInfo.Text = "Display Image Info"
        Me.BtnMountControl_DisplayImageInfo.UseVisualStyleBackColor = True
        '
        'LblMountControl_Size
        '
        Me.LblMountControl_Size.AutoSize = True
        Me.LblMountControl_Size.Location = New System.Drawing.Point(8, 285)
        Me.LblMountControl_Size.Name = "LblMountControl_Size"
        Me.LblMountControl_Size.Size = New System.Drawing.Size(44, 20)
        Me.LblMountControl_Size.TabIndex = 24
        Me.LblMountControl_Size.Text = "Size:"
        '
        'LblMountControl_Description
        '
        Me.LblMountControl_Description.AutoSize = True
        Me.LblMountControl_Description.Location = New System.Drawing.Point(8, 253)
        Me.LblMountControl_Description.Name = "LblMountControl_Description"
        Me.LblMountControl_Description.Size = New System.Drawing.Size(93, 20)
        Me.LblMountControl_Description.TabIndex = 23
        Me.LblMountControl_Description.Text = "Description:"
        '
        'LblMountControl_Name
        '
        Me.LblMountControl_Name.AutoSize = True
        Me.LblMountControl_Name.Location = New System.Drawing.Point(8, 221)
        Me.LblMountControl_Name.Name = "LblMountControl_Name"
        Me.LblMountControl_Name.Size = New System.Drawing.Size(55, 20)
        Me.LblMountControl_Name.TabIndex = 22
        Me.LblMountControl_Name.Text = "Name:"
        '
        'TxtBoxMountControl_Size
        '
        Me.TxtBoxMountControl_Size.Location = New System.Drawing.Point(103, 282)
        Me.TxtBoxMountControl_Size.Name = "TxtBoxMountControl_Size"
        Me.TxtBoxMountControl_Size.Size = New System.Drawing.Size(455, 26)
        Me.TxtBoxMountControl_Size.TabIndex = 21
        '
        'TxtBoxMountControl_Description
        '
        Me.TxtBoxMountControl_Description.Location = New System.Drawing.Point(103, 250)
        Me.TxtBoxMountControl_Description.Name = "TxtBoxMountControl_Description"
        Me.TxtBoxMountControl_Description.Size = New System.Drawing.Size(455, 26)
        Me.TxtBoxMountControl_Description.TabIndex = 20
        '
        'TxtBoxMountControl_Name
        '
        Me.TxtBoxMountControl_Name.Location = New System.Drawing.Point(103, 218)
        Me.TxtBoxMountControl_Name.Name = "TxtBoxMountControl_Name"
        Me.TxtBoxMountControl_Name.Size = New System.Drawing.Size(455, 26)
        Me.TxtBoxMountControl_Name.TabIndex = 19
        '
        'ChkMountControl_ReadOnly
        '
        Me.ChkMountControl_ReadOnly.AutoSize = True
        Me.ChkMountControl_ReadOnly.Location = New System.Drawing.Point(12, 186)
        Me.ChkMountControl_ReadOnly.Name = "ChkMountControl_ReadOnly"
        Me.ChkMountControl_ReadOnly.Size = New System.Drawing.Size(106, 24)
        Me.ChkMountControl_ReadOnly.TabIndex = 19
        Me.ChkMountControl_ReadOnly.Text = "/Read Only"
        Me.ChkMountControl_ReadOnly.UseVisualStyleBackColor = True
        '
        'TabPage2
        '
        Me.TabPage2.Controls.Add(Me.BtnDriverManagement_RefreshMountedImage)
        Me.TabPage2.Controls.Add(Me.BtnDriverManagement_GetMountedImageInfo)
        Me.TabPage2.Controls.Add(Me.LblDriverManagement_UseMountedImage)
        Me.TabPage2.Controls.Add(Me.CmbBoxDriverManagement_UseImageMounted)
        Me.TabPage2.Controls.Add(Me.ChkBoxDriverManagement_Online)
        Me.TabPage2.Controls.Add(Me.BtnDriverManagement_GetAllDriverInfo)
        Me.TabPage2.Controls.Add(Me.GroupBoxDriverManagement_DeleteDrivers)
        Me.TabPage2.Controls.Add(Me.BtnDriverManagement_GetDrivers)
        Me.TabPage2.Controls.Add(Me.GroupBoxDriverManagement_AddDrivers)
        Me.TabPage2.Location = New System.Drawing.Point(4, 29)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(886, 350)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "Driver Management"
        Me.TabPage2.UseVisualStyleBackColor = True
        '
        'BtnDriverManagement_RefreshMountedImage
        '
        Me.BtnDriverManagement_RefreshMountedImage.Location = New System.Drawing.Point(251, 4)
        Me.BtnDriverManagement_RefreshMountedImage.Name = "BtnDriverManagement_RefreshMountedImage"
        Me.BtnDriverManagement_RefreshMountedImage.Size = New System.Drawing.Size(221, 32)
        Me.BtnDriverManagement_RefreshMountedImage.TabIndex = 29
        Me.BtnDriverManagement_RefreshMountedImage.Text = "Refresh mounted image"
        Me.BtnDriverManagement_RefreshMountedImage.UseVisualStyleBackColor = True
        '
        'BtnDriverManagement_GetMountedImageInfo
        '
        Me.BtnDriverManagement_GetMountedImageInfo.Location = New System.Drawing.Point(727, 14)
        Me.BtnDriverManagement_GetMountedImageInfo.Name = "BtnDriverManagement_GetMountedImageInfo"
        Me.BtnDriverManagement_GetMountedImageInfo.Size = New System.Drawing.Size(153, 77)
        Me.BtnDriverManagement_GetMountedImageInfo.TabIndex = 28
        Me.BtnDriverManagement_GetMountedImageInfo.Text = "Get Mounted Image Info"
        Me.BtnDriverManagement_GetMountedImageInfo.UseVisualStyleBackColor = True
        '
        'LblDriverManagement_UseMountedImage
        '
        Me.LblDriverManagement_UseMountedImage.AutoSize = True
        Me.LblDriverManagement_UseMountedImage.Location = New System.Drawing.Point(6, 45)
        Me.LblDriverManagement_UseMountedImage.Name = "LblDriverManagement_UseMountedImage"
        Me.LblDriverManagement_UseMountedImage.Size = New System.Drawing.Size(158, 20)
        Me.LblDriverManagement_UseMountedImage.TabIndex = 17
        Me.LblDriverManagement_UseMountedImage.Text = "Use Mounted Image:"
        '
        'CmbBoxDriverManagement_UseImageMounted
        '
        Me.CmbBoxDriverManagement_UseImageMounted.FormattingEnabled = True
        Me.CmbBoxDriverManagement_UseImageMounted.Location = New System.Drawing.Point(182, 42)
        Me.CmbBoxDriverManagement_UseImageMounted.Name = "CmbBoxDriverManagement_UseImageMounted"
        Me.CmbBoxDriverManagement_UseImageMounted.Size = New System.Drawing.Size(349, 28)
        Me.CmbBoxDriverManagement_UseImageMounted.TabIndex = 16
        '
        'ChkBoxDriverManagement_Online
        '
        Me.ChkBoxDriverManagement_Online.AutoSize = True
        Me.ChkBoxDriverManagement_Online.Location = New System.Drawing.Point(758, 323)
        Me.ChkBoxDriverManagement_Online.Name = "ChkBoxDriverManagement_Online"
        Me.ChkBoxDriverManagement_Online.Size = New System.Drawing.Size(125, 24)
        Me.ChkBoxDriverManagement_Online.TabIndex = 15
        Me.ChkBoxDriverManagement_Online.Text = "/Online option"
        Me.ChkBoxDriverManagement_Online.UseVisualStyleBackColor = False
        '
        'BtnDriverManagement_GetAllDriverInfo
        '
        Me.BtnDriverManagement_GetAllDriverInfo.Location = New System.Drawing.Point(546, 117)
        Me.BtnDriverManagement_GetAllDriverInfo.Name = "BtnDriverManagement_GetAllDriverInfo"
        Me.BtnDriverManagement_GetAllDriverInfo.Size = New System.Drawing.Size(158, 77)
        Me.BtnDriverManagement_GetAllDriverInfo.TabIndex = 14
        Me.BtnDriverManagement_GetAllDriverInfo.Text = "Get All Driver information from WIM"
        Me.BtnDriverManagement_GetAllDriverInfo.UseVisualStyleBackColor = True
        '
        'GroupBoxDriverManagement_DeleteDrivers
        '
        Me.GroupBoxDriverManagement_DeleteDrivers.Controls.Add(Me.LblDriverManagement_DriverName)
        Me.GroupBoxDriverManagement_DeleteDrivers.Controls.Add(Me.BtnDriverManagement_DelDriver)
        Me.GroupBoxDriverManagement_DeleteDrivers.Controls.Add(Me.TxtBoxDriverManagement_DelDriverLocation)
        Me.GroupBoxDriverManagement_DeleteDrivers.Location = New System.Drawing.Point(6, 231)
        Me.GroupBoxDriverManagement_DeleteDrivers.Name = "GroupBoxDriverManagement_DeleteDrivers"
        Me.GroupBoxDriverManagement_DeleteDrivers.Size = New System.Drawing.Size(513, 86)
        Me.GroupBoxDriverManagement_DeleteDrivers.TabIndex = 13
        Me.GroupBoxDriverManagement_DeleteDrivers.TabStop = False
        Me.GroupBoxDriverManagement_DeleteDrivers.Text = "Delete Drivers (Offline Only)"
        '
        'LblDriverManagement_DriverName
        '
        Me.LblDriverManagement_DriverName.AutoSize = True
        Me.LblDriverManagement_DriverName.Location = New System.Drawing.Point(9, 25)
        Me.LblDriverManagement_DriverName.Name = "LblDriverManagement_DriverName"
        Me.LblDriverManagement_DriverName.Size = New System.Drawing.Size(96, 20)
        Me.LblDriverManagement_DriverName.TabIndex = 2
        Me.LblDriverManagement_DriverName.Text = "Driver Name"
        '
        'BtnDriverManagement_DelDriver
        '
        Me.BtnDriverManagement_DelDriver.Location = New System.Drawing.Point(319, 44)
        Me.BtnDriverManagement_DelDriver.Name = "BtnDriverManagement_DelDriver"
        Me.BtnDriverManagement_DelDriver.Size = New System.Drawing.Size(124, 29)
        Me.BtnDriverManagement_DelDriver.TabIndex = 1
        Me.BtnDriverManagement_DelDriver.Text = "Delete Driver"
        Me.BtnDriverManagement_DelDriver.UseVisualStyleBackColor = True
        '
        'TxtBoxDriverManagement_DelDriverLocation
        '
        Me.TxtBoxDriverManagement_DelDriverLocation.Location = New System.Drawing.Point(7, 48)
        Me.TxtBoxDriverManagement_DelDriverLocation.Name = "TxtBoxDriverManagement_DelDriverLocation"
        Me.TxtBoxDriverManagement_DelDriverLocation.Size = New System.Drawing.Size(305, 26)
        Me.TxtBoxDriverManagement_DelDriverLocation.TabIndex = 0
        '
        'BtnDriverManagement_GetDrivers
        '
        Me.BtnDriverManagement_GetDrivers.Location = New System.Drawing.Point(546, 14)
        Me.BtnDriverManagement_GetDrivers.Name = "BtnDriverManagement_GetDrivers"
        Me.BtnDriverManagement_GetDrivers.Size = New System.Drawing.Size(158, 77)
        Me.BtnDriverManagement_GetDrivers.TabIndex = 1
        Me.BtnDriverManagement_GetDrivers.Text = "Get 3rd Party Driver information from WIM"
        Me.BtnDriverManagement_GetDrivers.UseVisualStyleBackColor = True
        '
        'GroupBoxDriverManagement_AddDrivers
        '
        Me.GroupBoxDriverManagement_AddDrivers.Controls.Add(Me.ChkDriverManagement_Recurse)
        Me.GroupBoxDriverManagement_AddDrivers.Controls.Add(Me.BtnDriverManagement_AddDrivers)
        Me.GroupBoxDriverManagement_AddDrivers.Controls.Add(Me.BtnDriverManagement_OpenDriverFolder)
        Me.GroupBoxDriverManagement_AddDrivers.Controls.Add(Me.LblDriverManagement_DriversFolderLocation)
        Me.GroupBoxDriverManagement_AddDrivers.Controls.Add(Me.ChkDriverManagement_ForceUnsigned)
        Me.GroupBoxDriverManagement_AddDrivers.Controls.Add(Me.TxtBoxDriverManagement_DriverFolderLocation)
        Me.GroupBoxDriverManagement_AddDrivers.Location = New System.Drawing.Point(6, 106)
        Me.GroupBoxDriverManagement_AddDrivers.Name = "GroupBoxDriverManagement_AddDrivers"
        Me.GroupBoxDriverManagement_AddDrivers.Size = New System.Drawing.Size(513, 119)
        Me.GroupBoxDriverManagement_AddDrivers.TabIndex = 11
        Me.GroupBoxDriverManagement_AddDrivers.TabStop = False
        Me.GroupBoxDriverManagement_AddDrivers.Text = "Add Drivers (Offline Only)"
        '
        'ChkDriverManagement_Recurse
        '
        Me.ChkDriverManagement_Recurse.AutoSize = True
        Me.ChkDriverManagement_Recurse.Checked = True
        Me.ChkDriverManagement_Recurse.CheckState = System.Windows.Forms.CheckState.Checked
        Me.ChkDriverManagement_Recurse.Location = New System.Drawing.Point(151, 89)
        Me.ChkDriverManagement_Recurse.Name = "ChkDriverManagement_Recurse"
        Me.ChkDriverManagement_Recurse.Size = New System.Drawing.Size(88, 24)
        Me.ChkDriverManagement_Recurse.TabIndex = 9
        Me.ChkDriverManagement_Recurse.Text = "Recurse"
        Me.ChkDriverManagement_Recurse.UseVisualStyleBackColor = True
        '
        'BtnDriverManagement_AddDrivers
        '
        Me.BtnDriverManagement_AddDrivers.Location = New System.Drawing.Point(316, 89)
        Me.BtnDriverManagement_AddDrivers.Name = "BtnDriverManagement_AddDrivers"
        Me.BtnDriverManagement_AddDrivers.Size = New System.Drawing.Size(127, 24)
        Me.BtnDriverManagement_AddDrivers.TabIndex = 8
        Me.BtnDriverManagement_AddDrivers.Text = "Add Drivers"
        Me.BtnDriverManagement_AddDrivers.UseVisualStyleBackColor = True
        '
        'BtnDriverManagement_OpenDriverFolder
        '
        Me.BtnDriverManagement_OpenDriverFolder.Location = New System.Drawing.Point(318, 49)
        Me.BtnDriverManagement_OpenDriverFolder.Name = "BtnDriverManagement_OpenDriverFolder"
        Me.BtnDriverManagement_OpenDriverFolder.Size = New System.Drawing.Size(125, 26)
        Me.BtnDriverManagement_OpenDriverFolder.TabIndex = 3
        Me.BtnDriverManagement_OpenDriverFolder.Text = "Choose Driver Folder"
        Me.BtnDriverManagement_OpenDriverFolder.UseVisualStyleBackColor = True
        '
        'LblDriverManagement_DriversFolderLocation
        '
        Me.LblDriverManagement_DriversFolderLocation.AutoSize = True
        Me.LblDriverManagement_DriversFolderLocation.Location = New System.Drawing.Point(0, 22)
        Me.LblDriverManagement_DriversFolderLocation.Name = "LblDriverManagement_DriversFolderLocation"
        Me.LblDriverManagement_DriversFolderLocation.Size = New System.Drawing.Size(172, 20)
        Me.LblDriverManagement_DriversFolderLocation.TabIndex = 0
        Me.LblDriverManagement_DriversFolderLocation.Text = "Drivers Folder Location"
        '
        'ChkDriverManagement_ForceUnsigned
        '
        Me.ChkDriverManagement_ForceUnsigned.AutoSize = True
        Me.ChkDriverManagement_ForceUnsigned.Location = New System.Drawing.Point(4, 89)
        Me.ChkDriverManagement_ForceUnsigned.Name = "ChkDriverManagement_ForceUnsigned"
        Me.ChkDriverManagement_ForceUnsigned.Size = New System.Drawing.Size(141, 24)
        Me.ChkDriverManagement_ForceUnsigned.TabIndex = 10
        Me.ChkDriverManagement_ForceUnsigned.Text = "Force Unsigned"
        Me.ChkDriverManagement_ForceUnsigned.UseVisualStyleBackColor = True
        '
        'TxtBoxDriverManagement_DriverFolderLocation
        '
        Me.TxtBoxDriverManagement_DriverFolderLocation.Location = New System.Drawing.Point(5, 49)
        Me.TxtBoxDriverManagement_DriverFolderLocation.Name = "TxtBoxDriverManagement_DriverFolderLocation"
        Me.TxtBoxDriverManagement_DriverFolderLocation.Size = New System.Drawing.Size(307, 26)
        Me.TxtBoxDriverManagement_DriverFolderLocation.TabIndex = 2
        '
        'TabPage3
        '
        Me.TabPage3.Controls.Add(Me.LblPackageManagement_Format)
        Me.TabPage3.Controls.Add(Me.RadBtnPackageManagement_FormatList)
        Me.TabPage3.Controls.Add(Me.RadBtnPackageManagement_FormatTable)
        Me.TabPage3.Controls.Add(Me.BtnPackageManagement_GetMountedImageInfo)
        Me.TabPage3.Controls.Add(Me.BtnPackageManagement_RefreshMountedImage)
        Me.TabPage3.Controls.Add(Me.LblPackageManagement_UseMountedImage)
        Me.TabPage3.Controls.Add(Me.CmbBoxPackageManagement_UseImageMounted)
        Me.TabPage3.Controls.Add(Me.ChkBoxPackageManagement_Online)
        Me.TabPage3.Controls.Add(Me.GrpBoxPackageManage_RemovePackages)
        Me.TabPage3.Controls.Add(Me.BtnPackageManage_GetPackages)
        Me.TabPage3.Controls.Add(Me.GrpBoxPackageManage_AddPackage)
        Me.TabPage3.Location = New System.Drawing.Point(4, 29)
        Me.TabPage3.Name = "TabPage3"
        Me.TabPage3.Size = New System.Drawing.Size(886, 350)
        Me.TabPage3.TabIndex = 2
        Me.TabPage3.Text = "Package Management"
        Me.TabPage3.UseVisualStyleBackColor = True
        '
        'LblPackageManagement_Format
        '
        Me.LblPackageManagement_Format.AutoSize = True
        Me.LblPackageManagement_Format.Location = New System.Drawing.Point(733, 170)
        Me.LblPackageManagement_Format.Name = "LblPackageManagement_Format"
        Me.LblPackageManagement_Format.Size = New System.Drawing.Size(68, 20)
        Me.LblPackageManagement_Format.TabIndex = 36
        Me.LblPackageManagement_Format.Text = "/Format:"
        '
        'RadBtnPackageManagement_FormatList
        '
        Me.RadBtnPackageManagement_FormatList.AutoSize = True
        Me.RadBtnPackageManagement_FormatList.Location = New System.Drawing.Point(805, 198)
        Me.RadBtnPackageManagement_FormatList.Name = "RadBtnPackageManagement_FormatList"
        Me.RadBtnPackageManagement_FormatList.Size = New System.Drawing.Size(52, 24)
        Me.RadBtnPackageManagement_FormatList.TabIndex = 35
        Me.RadBtnPackageManagement_FormatList.TabStop = True
        Me.RadBtnPackageManagement_FormatList.Text = "List"
        Me.RadBtnPackageManagement_FormatList.UseVisualStyleBackColor = True
        '
        'RadBtnPackageManagement_FormatTable
        '
        Me.RadBtnPackageManagement_FormatTable.AutoSize = True
        Me.RadBtnPackageManagement_FormatTable.Location = New System.Drawing.Point(805, 168)
        Me.RadBtnPackageManagement_FormatTable.Name = "RadBtnPackageManagement_FormatTable"
        Me.RadBtnPackageManagement_FormatTable.Size = New System.Drawing.Size(66, 24)
        Me.RadBtnPackageManagement_FormatTable.TabIndex = 34
        Me.RadBtnPackageManagement_FormatTable.TabStop = True
        Me.RadBtnPackageManagement_FormatTable.Text = "Table"
        Me.RadBtnPackageManagement_FormatTable.UseVisualStyleBackColor = True
        '
        'BtnPackageManagement_GetMountedImageInfo
        '
        Me.BtnPackageManagement_GetMountedImageInfo.Location = New System.Drawing.Point(719, 12)
        Me.BtnPackageManagement_GetMountedImageInfo.Name = "BtnPackageManagement_GetMountedImageInfo"
        Me.BtnPackageManagement_GetMountedImageInfo.Size = New System.Drawing.Size(143, 64)
        Me.BtnPackageManagement_GetMountedImageInfo.TabIndex = 33
        Me.BtnPackageManagement_GetMountedImageInfo.Text = "Get Mounted Image Info"
        Me.BtnPackageManagement_GetMountedImageInfo.UseVisualStyleBackColor = True
        '
        'BtnPackageManagement_RefreshMountedImage
        '
        Me.BtnPackageManagement_RefreshMountedImage.Location = New System.Drawing.Point(248, 10)
        Me.BtnPackageManagement_RefreshMountedImage.Name = "BtnPackageManagement_RefreshMountedImage"
        Me.BtnPackageManagement_RefreshMountedImage.Size = New System.Drawing.Size(221, 32)
        Me.BtnPackageManagement_RefreshMountedImage.TabIndex = 32
        Me.BtnPackageManagement_RefreshMountedImage.Text = "Refresh mounted image"
        Me.BtnPackageManagement_RefreshMountedImage.UseVisualStyleBackColor = True
        '
        'LblPackageManagement_UseMountedImage
        '
        Me.LblPackageManagement_UseMountedImage.AutoSize = True
        Me.LblPackageManagement_UseMountedImage.Location = New System.Drawing.Point(10, 51)
        Me.LblPackageManagement_UseMountedImage.Name = "LblPackageManagement_UseMountedImage"
        Me.LblPackageManagement_UseMountedImage.Size = New System.Drawing.Size(158, 20)
        Me.LblPackageManagement_UseMountedImage.TabIndex = 31
        Me.LblPackageManagement_UseMountedImage.Text = "Use Image Mounted:"
        '
        'CmbBoxPackageManagement_UseImageMounted
        '
        Me.CmbBoxPackageManagement_UseImageMounted.FormattingEnabled = True
        Me.CmbBoxPackageManagement_UseImageMounted.Location = New System.Drawing.Point(190, 48)
        Me.CmbBoxPackageManagement_UseImageMounted.Name = "CmbBoxPackageManagement_UseImageMounted"
        Me.CmbBoxPackageManagement_UseImageMounted.Size = New System.Drawing.Size(349, 28)
        Me.CmbBoxPackageManagement_UseImageMounted.TabIndex = 30
        '
        'ChkBoxPackageManagement_Online
        '
        Me.ChkBoxPackageManagement_Online.AutoSize = True
        Me.ChkBoxPackageManagement_Online.Location = New System.Drawing.Point(758, 323)
        Me.ChkBoxPackageManagement_Online.Name = "ChkBoxPackageManagement_Online"
        Me.ChkBoxPackageManagement_Online.Size = New System.Drawing.Size(125, 24)
        Me.ChkBoxPackageManagement_Online.TabIndex = 17
        Me.ChkBoxPackageManagement_Online.Text = "/Online option"
        Me.ChkBoxPackageManagement_Online.UseVisualStyleBackColor = False
        '
        'GrpBoxPackageManage_RemovePackages
        '
        Me.GrpBoxPackageManage_RemovePackages.Controls.Add(Me.BtnPackageManagement_ChoosePackagePath)
        Me.GrpBoxPackageManage_RemovePackages.Controls.Add(Me.LblPackageManage_PackageName)
        Me.GrpBoxPackageManage_RemovePackages.Controls.Add(Me.LblPackageManage_PackagePath)
        Me.GrpBoxPackageManage_RemovePackages.Controls.Add(Me.BtnPackageManage_RemovePackagePath)
        Me.GrpBoxPackageManage_RemovePackages.Controls.Add(Me.BtnPackageManage_RemovePackage)
        Me.GrpBoxPackageManage_RemovePackages.Controls.Add(Me.BtnPackageManage_GetPackageInfo)
        Me.GrpBoxPackageManage_RemovePackages.Controls.Add(Me.txtPackagePath)
        Me.GrpBoxPackageManage_RemovePackages.Controls.Add(Me.txtPackageName)
        Me.GrpBoxPackageManage_RemovePackages.Location = New System.Drawing.Point(4, 213)
        Me.GrpBoxPackageManage_RemovePackages.Name = "GrpBoxPackageManage_RemovePackages"
        Me.GrpBoxPackageManage_RemovePackages.Size = New System.Drawing.Size(621, 134)
        Me.GrpBoxPackageManage_RemovePackages.TabIndex = 16
        Me.GrpBoxPackageManage_RemovePackages.TabStop = False
        Me.GrpBoxPackageManage_RemovePackages.Text = "Remove Packages (not msu package):"
        '
        'BtnPackageManagement_ChoosePackagePath
        '
        Me.BtnPackageManagement_ChoosePackagePath.Location = New System.Drawing.Point(318, 97)
        Me.BtnPackageManagement_ChoosePackagePath.Name = "BtnPackageManagement_ChoosePackagePath"
        Me.BtnPackageManagement_ChoosePackagePath.Size = New System.Drawing.Size(131, 26)
        Me.BtnPackageManagement_ChoosePackagePath.TabIndex = 19
        Me.BtnPackageManagement_ChoosePackagePath.Text = "Choose Package Folder"
        Me.BtnPackageManagement_ChoosePackagePath.UseVisualStyleBackColor = True
        '
        'LblPackageManage_PackageName
        '
        Me.LblPackageManage_PackageName.AutoSize = True
        Me.LblPackageManage_PackageName.Location = New System.Drawing.Point(3, 22)
        Me.LblPackageManage_PackageName.Name = "LblPackageManage_PackageName"
        Me.LblPackageManage_PackageName.Size = New System.Drawing.Size(121, 20)
        Me.LblPackageManage_PackageName.TabIndex = 5
        Me.LblPackageManage_PackageName.Text = "Package Name:"
        '
        'LblPackageManage_PackagePath
        '
        Me.LblPackageManage_PackagePath.AutoSize = True
        Me.LblPackageManage_PackagePath.Location = New System.Drawing.Point(3, 74)
        Me.LblPackageManage_PackagePath.Name = "LblPackageManage_PackagePath"
        Me.LblPackageManage_PackagePath.Size = New System.Drawing.Size(223, 20)
        Me.LblPackageManage_PackagePath.TabIndex = 4
        Me.LblPackageManage_PackagePath.Text = "Package Path: (Folder or .cab)"
        '
        'BtnPackageManage_RemovePackagePath
        '
        Me.BtnPackageManage_RemovePackagePath.Location = New System.Drawing.Point(476, 97)
        Me.BtnPackageManage_RemovePackagePath.Name = "BtnPackageManage_RemovePackagePath"
        Me.BtnPackageManage_RemovePackagePath.Size = New System.Drawing.Size(131, 26)
        Me.BtnPackageManage_RemovePackagePath.TabIndex = 3
        Me.BtnPackageManage_RemovePackagePath.Text = "Remove Package"
        Me.BtnPackageManage_RemovePackagePath.UseVisualStyleBackColor = True
        '
        'BtnPackageManage_RemovePackage
        '
        Me.BtnPackageManage_RemovePackage.Location = New System.Drawing.Point(317, 45)
        Me.BtnPackageManage_RemovePackage.Name = "BtnPackageManage_RemovePackage"
        Me.BtnPackageManage_RemovePackage.Size = New System.Drawing.Size(131, 26)
        Me.BtnPackageManage_RemovePackage.TabIndex = 2
        Me.BtnPackageManage_RemovePackage.Text = "Remove Package"
        Me.BtnPackageManage_RemovePackage.UseVisualStyleBackColor = True
        '
        'BtnPackageManage_GetPackageInfo
        '
        Me.BtnPackageManage_GetPackageInfo.Location = New System.Drawing.Point(476, 22)
        Me.BtnPackageManage_GetPackageInfo.Name = "BtnPackageManage_GetPackageInfo"
        Me.BtnPackageManage_GetPackageInfo.Size = New System.Drawing.Size(131, 64)
        Me.BtnPackageManage_GetPackageInfo.TabIndex = 18
        Me.BtnPackageManage_GetPackageInfo.Text = "Get Package Info"
        Me.BtnPackageManage_GetPackageInfo.UseVisualStyleBackColor = True
        '
        'txtPackagePath
        '
        Me.txtPackagePath.Location = New System.Drawing.Point(3, 97)
        Me.txtPackagePath.Name = "txtPackagePath"
        Me.txtPackagePath.Size = New System.Drawing.Size(307, 26)
        Me.txtPackagePath.TabIndex = 1
        '
        'txtPackageName
        '
        Me.txtPackageName.Location = New System.Drawing.Point(3, 45)
        Me.txtPackageName.Name = "txtPackageName"
        Me.txtPackageName.Size = New System.Drawing.Size(307, 26)
        Me.txtPackageName.TabIndex = 0
        '
        'BtnPackageManage_GetPackages
        '
        Me.BtnPackageManage_GetPackages.Location = New System.Drawing.Point(719, 99)
        Me.BtnPackageManage_GetPackages.Name = "BtnPackageManage_GetPackages"
        Me.BtnPackageManage_GetPackages.Size = New System.Drawing.Size(143, 64)
        Me.BtnPackageManage_GetPackages.TabIndex = 9
        Me.BtnPackageManage_GetPackages.Text = "Get Packages"
        Me.BtnPackageManage_GetPackages.UseVisualStyleBackColor = True
        '
        'GrpBoxPackageManage_AddPackage
        '
        Me.GrpBoxPackageManage_AddPackage.Controls.Add(Me.ChkBoxPackageManagement_PreventPending)
        Me.GrpBoxPackageManage_AddPackage.Controls.Add(Me.BtnPackageManage_AddPackages)
        Me.GrpBoxPackageManage_AddPackage.Controls.Add(Me.LblPackageManage_PackageFolder)
        Me.GrpBoxPackageManage_AddPackage.Controls.Add(Me.chkIgnoreCheck)
        Me.GrpBoxPackageManage_AddPackage.Controls.Add(Me.txtPackageFile)
        Me.GrpBoxPackageManage_AddPackage.Controls.Add(Me.BtnPackageManage_OpenPackageFile)
        Me.GrpBoxPackageManage_AddPackage.Location = New System.Drawing.Point(7, 82)
        Me.GrpBoxPackageManage_AddPackage.Name = "GrpBoxPackageManage_AddPackage"
        Me.GrpBoxPackageManage_AddPackage.Size = New System.Drawing.Size(516, 125)
        Me.GrpBoxPackageManage_AddPackage.TabIndex = 15
        Me.GrpBoxPackageManage_AddPackage.TabStop = False
        Me.GrpBoxPackageManage_AddPackage.Text = "Add Packages"
        '
        'ChkBoxPackageManagement_PreventPending
        '
        Me.ChkBoxPackageManagement_PreventPending.AutoSize = True
        Me.ChkBoxPackageManagement_PreventPending.Location = New System.Drawing.Point(137, 87)
        Me.ChkBoxPackageManagement_PreventPending.Name = "ChkBoxPackageManagement_PreventPending"
        Me.ChkBoxPackageManagement_PreventPending.Size = New System.Drawing.Size(144, 24)
        Me.ChkBoxPackageManagement_PreventPending.TabIndex = 15
        Me.ChkBoxPackageManagement_PreventPending.Text = "/PreventPending"
        Me.ChkBoxPackageManagement_PreventPending.UseVisualStyleBackColor = True
        '
        'BtnPackageManage_AddPackages
        '
        Me.BtnPackageManage_AddPackages.Location = New System.Drawing.Point(342, 87)
        Me.BtnPackageManage_AddPackages.Name = "BtnPackageManage_AddPackages"
        Me.BtnPackageManage_AddPackages.Size = New System.Drawing.Size(131, 32)
        Me.BtnPackageManage_AddPackages.TabIndex = 14
        Me.BtnPackageManage_AddPackages.Text = "Add Packages"
        Me.BtnPackageManage_AddPackages.UseVisualStyleBackColor = True
        '
        'LblPackageManage_PackageFolder
        '
        Me.LblPackageManage_PackageFolder.AutoSize = True
        Me.LblPackageManage_PackageFolder.Location = New System.Drawing.Point(7, 25)
        Me.LblPackageManage_PackageFolder.Name = "LblPackageManage_PackageFolder"
        Me.LblPackageManage_PackageFolder.Size = New System.Drawing.Size(286, 20)
        Me.LblPackageManage_PackageFolder.TabIndex = 11
        Me.LblPackageManage_PackageFolder.Text = "Package Folder (.cab or .msu or folder):"
        '
        'chkIgnoreCheck
        '
        Me.chkIgnoreCheck.AutoSize = True
        Me.chkIgnoreCheck.Location = New System.Drawing.Point(8, 87)
        Me.chkIgnoreCheck.Name = "chkIgnoreCheck"
        Me.chkIgnoreCheck.Size = New System.Drawing.Size(123, 24)
        Me.chkIgnoreCheck.TabIndex = 13
        Me.chkIgnoreCheck.Text = "/IgnoreCheck"
        Me.chkIgnoreCheck.UseVisualStyleBackColor = True
        '
        'txtPackageFile
        '
        Me.txtPackageFile.Location = New System.Drawing.Point(8, 55)
        Me.txtPackageFile.Name = "txtPackageFile"
        Me.txtPackageFile.Size = New System.Drawing.Size(307, 26)
        Me.txtPackageFile.TabIndex = 10
        '
        'BtnPackageManage_OpenPackageFile
        '
        Me.BtnPackageManage_OpenPackageFile.Location = New System.Drawing.Point(342, 55)
        Me.BtnPackageManage_OpenPackageFile.Name = "BtnPackageManage_OpenPackageFile"
        Me.BtnPackageManage_OpenPackageFile.Size = New System.Drawing.Size(131, 26)
        Me.BtnPackageManage_OpenPackageFile.TabIndex = 12
        Me.BtnPackageManage_OpenPackageFile.Text = "Choose Package Folder"
        Me.BtnPackageManage_OpenPackageFile.UseVisualStyleBackColor = True
        '
        'TabPage4
        '
        Me.TabPage4.Controls.Add(Me.ChkBoxFeatureManagement_Source)
        Me.TabPage4.Controls.Add(Me.ChkBoxFeatureManagement_All)
        Me.TabPage4.Controls.Add(Me.ChkBoxFeatureManagement_LimitAccess)
        Me.TabPage4.Controls.Add(Me.LblFeatureManage_Source)
        Me.TabPage4.Controls.Add(Me.TxtBoxFeatureManagement_Source)
        Me.TabPage4.Controls.Add(Me.BtnFeatureManage_GetFeatureInfo)
        Me.TabPage4.Controls.Add(Me.BtnFeatureManagement_GetMountedImageInfo)
        Me.TabPage4.Controls.Add(Me.BtnFeatureManagement_RefreshMountedImage)
        Me.TabPage4.Controls.Add(Me.LblFeatureManage_UseMountedImage)
        Me.TabPage4.Controls.Add(Me.CmbBoxFeatureManagement_UseImageMounted)
        Me.TabPage4.Controls.Add(Me.ChkBoxFeatureManagement_Online)
        Me.TabPage4.Controls.Add(Me.BtnFeatureManage_DisableFeature)
        Me.TabPage4.Controls.Add(Me.chkEnablePkgPath)
        Me.TabPage4.Controls.Add(Me.chkEnablePkgName)
        Me.TabPage4.Controls.Add(Me.BtnFeatureManage_EnableFeature)
        Me.TabPage4.Controls.Add(Me.LblFeatureManage_PackagePath)
        Me.TabPage4.Controls.Add(Me.LblFeatureManage_PackageName)
        Me.TabPage4.Controls.Add(Me.LblFeatureManage_FeatureName)
        Me.TabPage4.Controls.Add(Me.txtFeatPackagePath)
        Me.TabPage4.Controls.Add(Me.txtFeatPackageName)
        Me.TabPage4.Controls.Add(Me.txtFeatureName)
        Me.TabPage4.Controls.Add(Me.BtnFeatureManage_GetFeatures)
        Me.TabPage4.Location = New System.Drawing.Point(4, 29)
        Me.TabPage4.Name = "TabPage4"
        Me.TabPage4.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage4.Size = New System.Drawing.Size(886, 350)
        Me.TabPage4.TabIndex = 3
        Me.TabPage4.Text = "Feature Management"
        Me.TabPage4.UseVisualStyleBackColor = True
        '
        'ChkBoxFeatureManagement_Source
        '
        Me.ChkBoxFeatureManagement_Source.AutoSize = True
        Me.ChkBoxFeatureManagement_Source.Location = New System.Drawing.Point(6, 300)
        Me.ChkBoxFeatureManagement_Source.Name = "ChkBoxFeatureManagement_Source"
        Me.ChkBoxFeatureManagement_Source.Size = New System.Drawing.Size(15, 14)
        Me.ChkBoxFeatureManagement_Source.TabIndex = 42
        Me.ChkBoxFeatureManagement_Source.UseVisualStyleBackColor = True
        '
        'ChkBoxFeatureManagement_All
        '
        Me.ChkBoxFeatureManagement_All.AutoSize = True
        Me.ChkBoxFeatureManagement_All.Location = New System.Drawing.Point(321, 326)
        Me.ChkBoxFeatureManagement_All.Name = "ChkBoxFeatureManagement_All"
        Me.ChkBoxFeatureManagement_All.Size = New System.Drawing.Size(49, 24)
        Me.ChkBoxFeatureManagement_All.TabIndex = 41
        Me.ChkBoxFeatureManagement_All.Text = "/All"
        Me.ChkBoxFeatureManagement_All.UseVisualStyleBackColor = True
        '
        'ChkBoxFeatureManagement_LimitAccess
        '
        Me.ChkBoxFeatureManagement_LimitAccess.AutoSize = True
        Me.ChkBoxFeatureManagement_LimitAccess.Location = New System.Drawing.Point(50, 325)
        Me.ChkBoxFeatureManagement_LimitAccess.Name = "ChkBoxFeatureManagement_LimitAccess"
        Me.ChkBoxFeatureManagement_LimitAccess.Size = New System.Drawing.Size(241, 24)
        Me.ChkBoxFeatureManagement_LimitAccess.TabIndex = 40
        Me.ChkBoxFeatureManagement_LimitAccess.Text = "/LimitAccess (no WU / WSUS)"
        Me.ChkBoxFeatureManagement_LimitAccess.UseVisualStyleBackColor = True
        '
        'LblFeatureManage_Source
        '
        Me.LblFeatureManage_Source.AutoSize = True
        Me.LblFeatureManage_Source.Location = New System.Drawing.Point(23, 270)
        Me.LblFeatureManage_Source.Name = "LblFeatureManage_Source"
        Me.LblFeatureManage_Source.Size = New System.Drawing.Size(64, 20)
        Me.LblFeatureManage_Source.TabIndex = 39
        Me.LblFeatureManage_Source.Text = "Source:"
        '
        'TxtBoxFeatureManagement_Source
        '
        Me.TxtBoxFeatureManagement_Source.Enabled = False
        Me.TxtBoxFeatureManagement_Source.Location = New System.Drawing.Point(27, 293)
        Me.TxtBoxFeatureManagement_Source.Name = "TxtBoxFeatureManagement_Source"
        Me.TxtBoxFeatureManagement_Source.Size = New System.Drawing.Size(494, 26)
        Me.TxtBoxFeatureManagement_Source.TabIndex = 38
        '
        'BtnFeatureManage_GetFeatureInfo
        '
        Me.BtnFeatureManage_GetFeatureInfo.Location = New System.Drawing.Point(737, 118)
        Me.BtnFeatureManage_GetFeatureInfo.Name = "BtnFeatureManage_GetFeatureInfo"
        Me.BtnFeatureManage_GetFeatureInfo.Size = New System.Drawing.Size(127, 64)
        Me.BtnFeatureManage_GetFeatureInfo.TabIndex = 37
        Me.BtnFeatureManage_GetFeatureInfo.Text = "Get Feature Info"
        Me.BtnFeatureManage_GetFeatureInfo.UseVisualStyleBackColor = True
        '
        'BtnFeatureManagement_GetMountedImageInfo
        '
        Me.BtnFeatureManagement_GetMountedImageInfo.Location = New System.Drawing.Point(713, 8)
        Me.BtnFeatureManagement_GetMountedImageInfo.Name = "BtnFeatureManagement_GetMountedImageInfo"
        Me.BtnFeatureManagement_GetMountedImageInfo.Size = New System.Drawing.Size(151, 64)
        Me.BtnFeatureManagement_GetMountedImageInfo.TabIndex = 36
        Me.BtnFeatureManagement_GetMountedImageInfo.Text = "Get Mounted Image Info"
        Me.BtnFeatureManagement_GetMountedImageInfo.UseVisualStyleBackColor = True
        '
        'BtnFeatureManagement_RefreshMountedImage
        '
        Me.BtnFeatureManagement_RefreshMountedImage.Location = New System.Drawing.Point(240, 6)
        Me.BtnFeatureManagement_RefreshMountedImage.Name = "BtnFeatureManagement_RefreshMountedImage"
        Me.BtnFeatureManagement_RefreshMountedImage.Size = New System.Drawing.Size(221, 32)
        Me.BtnFeatureManagement_RefreshMountedImage.TabIndex = 35
        Me.BtnFeatureManagement_RefreshMountedImage.Text = "Refresh mounted image"
        Me.BtnFeatureManagement_RefreshMountedImage.UseVisualStyleBackColor = True
        '
        'LblFeatureManage_UseMountedImage
        '
        Me.LblFeatureManage_UseMountedImage.AutoSize = True
        Me.LblFeatureManage_UseMountedImage.Location = New System.Drawing.Point(8, 47)
        Me.LblFeatureManage_UseMountedImage.Name = "LblFeatureManage_UseMountedImage"
        Me.LblFeatureManage_UseMountedImage.Size = New System.Drawing.Size(158, 20)
        Me.LblFeatureManage_UseMountedImage.TabIndex = 34
        Me.LblFeatureManage_UseMountedImage.Text = "Use Image Mounted:"
        '
        'CmbBoxFeatureManagement_UseImageMounted
        '
        Me.CmbBoxFeatureManagement_UseImageMounted.FormattingEnabled = True
        Me.CmbBoxFeatureManagement_UseImageMounted.Location = New System.Drawing.Point(182, 44)
        Me.CmbBoxFeatureManagement_UseImageMounted.Name = "CmbBoxFeatureManagement_UseImageMounted"
        Me.CmbBoxFeatureManagement_UseImageMounted.Size = New System.Drawing.Size(349, 28)
        Me.CmbBoxFeatureManagement_UseImageMounted.TabIndex = 33
        '
        'ChkBoxFeatureManagement_Online
        '
        Me.ChkBoxFeatureManagement_Online.AutoSize = True
        Me.ChkBoxFeatureManagement_Online.Location = New System.Drawing.Point(758, 324)
        Me.ChkBoxFeatureManagement_Online.Name = "ChkBoxFeatureManagement_Online"
        Me.ChkBoxFeatureManagement_Online.Size = New System.Drawing.Size(125, 24)
        Me.ChkBoxFeatureManagement_Online.TabIndex = 23
        Me.ChkBoxFeatureManagement_Online.Text = "/Online option"
        Me.ChkBoxFeatureManagement_Online.UseVisualStyleBackColor = False
        '
        'BtnFeatureManage_DisableFeature
        '
        Me.BtnFeatureManage_DisableFeature.Location = New System.Drawing.Point(737, 197)
        Me.BtnFeatureManage_DisableFeature.Name = "BtnFeatureManage_DisableFeature"
        Me.BtnFeatureManage_DisableFeature.Size = New System.Drawing.Size(127, 64)
        Me.BtnFeatureManage_DisableFeature.TabIndex = 22
        Me.BtnFeatureManage_DisableFeature.Text = "Disable Feature"
        Me.BtnFeatureManage_DisableFeature.UseVisualStyleBackColor = True
        '
        'chkEnablePkgPath
        '
        Me.chkEnablePkgPath.AutoSize = True
        Me.chkEnablePkgPath.Location = New System.Drawing.Point(6, 247)
        Me.chkEnablePkgPath.Name = "chkEnablePkgPath"
        Me.chkEnablePkgPath.Size = New System.Drawing.Size(15, 14)
        Me.chkEnablePkgPath.TabIndex = 21
        Me.chkEnablePkgPath.UseVisualStyleBackColor = True
        '
        'chkEnablePkgName
        '
        Me.chkEnablePkgName.AutoSize = True
        Me.chkEnablePkgName.Location = New System.Drawing.Point(6, 183)
        Me.chkEnablePkgName.Name = "chkEnablePkgName"
        Me.chkEnablePkgName.Size = New System.Drawing.Size(15, 14)
        Me.chkEnablePkgName.TabIndex = 20
        Me.chkEnablePkgName.UseVisualStyleBackColor = True
        '
        'BtnFeatureManage_EnableFeature
        '
        Me.BtnFeatureManage_EnableFeature.Location = New System.Drawing.Point(590, 197)
        Me.BtnFeatureManage_EnableFeature.Name = "BtnFeatureManage_EnableFeature"
        Me.BtnFeatureManage_EnableFeature.Size = New System.Drawing.Size(127, 64)
        Me.BtnFeatureManage_EnableFeature.TabIndex = 19
        Me.BtnFeatureManage_EnableFeature.Text = "Enable Feature"
        Me.BtnFeatureManage_EnableFeature.UseVisualStyleBackColor = True
        '
        'LblFeatureManage_PackagePath
        '
        Me.LblFeatureManage_PackagePath.AutoSize = True
        Me.LblFeatureManage_PackagePath.Location = New System.Drawing.Point(28, 218)
        Me.LblFeatureManage_PackagePath.Name = "LblFeatureManage_PackagePath"
        Me.LblFeatureManage_PackagePath.Size = New System.Drawing.Size(112, 20)
        Me.LblFeatureManage_PackagePath.TabIndex = 18
        Me.LblFeatureManage_PackagePath.Text = "Package Path:"
        '
        'LblFeatureManage_PackageName
        '
        Me.LblFeatureManage_PackageName.AutoSize = True
        Me.LblFeatureManage_PackageName.Location = New System.Drawing.Point(28, 152)
        Me.LblFeatureManage_PackageName.Name = "LblFeatureManage_PackageName"
        Me.LblFeatureManage_PackageName.Size = New System.Drawing.Size(346, 20)
        Me.LblFeatureManage_PackageName.TabIndex = 17
        Me.LblFeatureManage_PackageName.Text = "Package Name: (parent package of the feature)"
        '
        'LblFeatureManage_FeatureName
        '
        Me.LblFeatureManage_FeatureName.AutoSize = True
        Me.LblFeatureManage_FeatureName.Location = New System.Drawing.Point(28, 95)
        Me.LblFeatureManage_FeatureName.Name = "LblFeatureManage_FeatureName"
        Me.LblFeatureManage_FeatureName.Size = New System.Drawing.Size(115, 20)
        Me.LblFeatureManage_FeatureName.TabIndex = 16
        Me.LblFeatureManage_FeatureName.Text = "Feature Name:"
        '
        'txtFeatPackagePath
        '
        Me.txtFeatPackagePath.Enabled = False
        Me.txtFeatPackagePath.Location = New System.Drawing.Point(27, 241)
        Me.txtFeatPackagePath.Name = "txtFeatPackagePath"
        Me.txtFeatPackagePath.Size = New System.Drawing.Size(494, 26)
        Me.txtFeatPackagePath.TabIndex = 15
        '
        'txtFeatPackageName
        '
        Me.txtFeatPackageName.Enabled = False
        Me.txtFeatPackageName.Location = New System.Drawing.Point(27, 177)
        Me.txtFeatPackageName.Name = "txtFeatPackageName"
        Me.txtFeatPackageName.Size = New System.Drawing.Size(494, 26)
        Me.txtFeatPackageName.TabIndex = 12
        '
        'txtFeatureName
        '
        Me.txtFeatureName.Location = New System.Drawing.Point(27, 118)
        Me.txtFeatureName.Name = "txtFeatureName"
        Me.txtFeatureName.Size = New System.Drawing.Size(494, 26)
        Me.txtFeatureName.TabIndex = 11
        '
        'BtnFeatureManage_GetFeatures
        '
        Me.BtnFeatureManage_GetFeatures.Location = New System.Drawing.Point(590, 118)
        Me.BtnFeatureManage_GetFeatures.Name = "BtnFeatureManage_GetFeatures"
        Me.BtnFeatureManage_GetFeatures.Size = New System.Drawing.Size(127, 64)
        Me.BtnFeatureManage_GetFeatures.TabIndex = 10
        Me.BtnFeatureManage_GetFeatures.Text = "Get Features"
        Me.BtnFeatureManage_GetFeatures.UseVisualStyleBackColor = True
        '
        'TabPage5
        '
        Me.TabPage5.Controls.Add(Me.CmbBoxEditionServicing_GLVKKeys)
        Me.TabPage5.Controls.Add(Me.LblEditionServicing_GLVKKeys)
        Me.TabPage5.Controls.Add(Me.CmbBoxEditionServicing_AVMAKeys)
        Me.TabPage5.Controls.Add(Me.LblEditionServicing_AVMAKeys)
        Me.TabPage5.Controls.Add(Me.BtnEditionServicing_GetMountedImageInfo)
        Me.TabPage5.Controls.Add(Me.BtnEditionServicing_RefreshMountedImage)
        Me.TabPage5.Controls.Add(Me.LblEditionServicing_UseMountedImage)
        Me.TabPage5.Controls.Add(Me.CmbBoxEditionServicing_UseImageMounted)
        Me.TabPage5.Controls.Add(Me.ChkBoxEditionServicing_Online)
        Me.TabPage5.Controls.Add(Me.LblEditionServicing_Edition)
        Me.TabPage5.Controls.Add(Me.BtnEditionServicing_SetEdition)
        Me.TabPage5.Controls.Add(Me.txtEdition)
        Me.TabPage5.Controls.Add(Me.txtProdKey)
        Me.TabPage5.Controls.Add(Me.BtnEditionServicing_SetProductKey)
        Me.TabPage5.Controls.Add(Me.LblEditionServicing_ProductKey)
        Me.TabPage5.Controls.Add(Me.BtnEditionServicing_GetTargetEditions)
        Me.TabPage5.Controls.Add(Me.BtnEditionServicing_GetCurrentEdition)
        Me.TabPage5.Location = New System.Drawing.Point(4, 29)
        Me.TabPage5.Name = "TabPage5"
        Me.TabPage5.Size = New System.Drawing.Size(886, 350)
        Me.TabPage5.TabIndex = 4
        Me.TabPage5.Text = "Edition Servicing"
        Me.TabPage5.UseVisualStyleBackColor = True
        '
        'CmbBoxEditionServicing_GLVKKeys
        '
        Me.CmbBoxEditionServicing_GLVKKeys.FormattingEnabled = True
        Me.CmbBoxEditionServicing_GLVKKeys.Items.AddRange(New Object() {"Windows Server 2022 Datacenter WX4NM-KYWYW-QJJR4-XV3QB-6VM33 ", "Windows Server 2022 Standard VDYBN-27WPP-V4HQT-9VMD4-VMK7H ", "Windows Server 2019 Datacenter WMDGN-G9PQG-XVVXX-R3X43-63DFG ", "Windows Server 2019 Standard N69G4-B89J2-4G8F4-WWYCC-J464C ", "Windows Server 2019 Essentials WVDHN-86M7X-466P6-VHXV7-YY726 ", "Windows Server 2016 Datacenter CB7KF-BWN84-R7R2Y-793K2-8XDDG ", "Windows Server 2016 Standard WC2BQ-8NRM3-FDDYY-2BFGV-KHKQY ", "Windows Server 2016 Essentials JCKRF-N37P4-C2D82-9YXRT-4M63B ", "Windows Server Datacenter versions 20H2, 2004, 1909, 1903, 1809 6NMRW-2C8FM-D24W7" &
                "-TQWMY-CWH2D ", "Windows Server Standard  20H2, 2004, 1909, 1903, 1809 N2KJX-J94YW-TQVFB-DG9YT-724" &
                "CC ", "Windows 10  / 11 Pro W269N-WFGWX-YVC9B-4J6C9-T83GX ", "Windows 10 / 11 Pro N MH37W-N47XK-V7XM9-C7227-GCQG9 ", "Windows 10 / 11 Pro for Workstations NRG8B-VKK3Q-CXVCJ-9G2XF-6Q84J ", "Windows 10 / 11 Pro for Workstations N  9FNHH-K3HBT-3W4TD-6383H-6XYWF ", "Windows 10  / 11 Pro Education 6TP4R-GNPTD-KYYHQ-7B7DP-J447Y ", "Windows 10 / 11 Pro Education N YVWGF-BXNMC-HTQYQ-CPQ99-66QFC ", "Windows 10 / 11 Education NW6C2-QMPVW-D7KKK-3GKT6-VCFB2 ", "Windows 10  / 11 Education N 2WH4N-8QGBV-H22JP-CT43Q-MDWWJ ", "Windows 10 / 11 Enterprise NPPR9-FWDCX-D2C8J-H872K-2YT43 ", "Windows 10 / 11 Enterprise N DPH2V-TTNVB-4X9Q3-TJR4H-KHJW4 ", "Windows 10 / 11 Enterprise G YYVX9-NTFWV-6MDM3-9PT4T-4M68B ", "Windows 10 / 11 Enterprise G N 44RPN-FTY23-9VTTB-MP9BX-T84FV ", "Windows 10 EnterpriseLTSC 2019 / 2021 M7XTQ-FN8P6-TTKYV-9D4CC-J462D ", "Windows 10 Enterprise N LTSC 2019 / 2021 92NFX-8DJQP-P6BBQ-THF9C-7CG2H ", "Windows 10 EnterpriseLTSB 2016 DCPHK-NFMTC-H88MJ-PFHPY-QJ4BJ ", "Windows 10 Enterprise N LTSB 2016 QFFDN-GRT3P-VKWWX-X7T3R-8B639 ", "Windows 10 Enterprise 2015 LTSB WNMTR-4C88C-JK8YV-HQ7T2-76DF9 ", "Windows 10 Enterprise 2015 LTSB N 2F77B-TNFGY-69QQF-B8YKP-D69TJ ", "Windows Server Datacenter 2HXDN-KRXHB-GPYC7-YCKFJ-7FVDG ", "Windows Server Standard PTXN8-JFHJM-4WC78-MPCBR-9W4KR ", "Windows Server Datacenter 6Y6KB-N82V8-D8CQV-23MJW-BWTG6 ", "Windows Server Standard DPCNP-XQFKJ-BJF7R-FRC8D-GF6G4 ", "Windows Server 2012 R2 Standard D2N9P-3P6X9-2R39C-7RTCD-MDVJX ", "Windows Server 2012 R2 Datacenter W3GGN-FT8W3-Y4M27-J84CP-Q3VJ9 ", "Windows Server 2012 R2 Essentials KNC87-3J2TX-XB4WP-VCPJV-M4FWM ", "Windows Server 2012 BN3D2-R7TKB-3YPBD-8DRP2-27GG4 ", "Windows Server 2012 N 8N2M2-HWPGY-7PGT9-HGDD8-GVGGY ", "Windows Server 2012 SingleLanguage 2WN2H-YGCQR-KFX6K-CD6TF-84YXQ ", "Windows Server 2012 Country Specific 4K36P-JN4VD-GDC6V-KDT89-DYFKP ", "Windows Server 2012 Standard XC9B7-NBPP2-83J2H-RHMBY-92BT4 ", "Windows Server 2012 MultiPoint Standard HM7DN-YVMH3-46JC3-XYTG7-CYQJJ ", "Windows Server 2012 MultiPoint Premium XNH6W-2V9GX-RGJ4K-Y8X6F-QGJ2G ", "Windows Server 2012 Datacenter 48HP8-DN98B-MYWDG-T2DCC-8W83P ", "Windows Server 2008 R2 Web 6TPJF-RBVHG-WBW2R-86QPH-6RTM4 ", "Windows Server 2008 R2 HPC edition TT8MH-CG224-D3D7Q-498W2-9QCTX ", "Windows Server 2008 R2 Standard YC6KT-GKW9T-YTKYR-T4X34-R7VHC ", "Windows Server 2008 R2 Enterprise 489J6-VHDMP-X63PK-3K798-CPX3Y ", "Windows Server 2008 R2 Datacenter 74YFP-3QFB3-KQT8W-PMXWJ-7M648 ", "Windows Server 2008 R2 for Itanium-based Systems GT63C-RJFQ3-4GMB6-BRFB9-CB83V ", "Windows Web Server 2008 WYR28-R7TFJ-3X2YQ-YCY4H-M249D ", "Windows Server 2008 Standard TM24T-X9RMF-VWXK6-X8JC9-BFGM2 ", "Windows Server 2008 Standard without Hyper-V W7VD6-7JFBR-RX26B-YKQ3Y-6FFFJ ", "Windows Server 2008 Enterprise YQGMW-MPWTJ-34KDK-48M3W-X4Q6V ", "Windows Server 2008 Enterprise without Hyper-V 39BXF-X8Q23-P2WWT-38T2F-G3FPG ", "Windows Server 2008 HPC RCTX3-KWVHP-BR6TB-RB6DM-6X7HP ", "Windows Server 2008 Datacenter 7M67G-PC374-GR742-YH8V4-TCBY3 ", "Windows Server 2008 Datacenter without Hyper-V 22XQ2-VRXRG-P8D42-K34TD-G3QQC ", "Windows Server 2008 for Itanium-Based Systems 4DWFP-JF3DJ-B7DTH-78FJB-PDRHK ", "Windows 8.1 Pro GCRJD-8NW9H-F2CDX-CCM8D-9D6T9 ", "Windows 8.1 Pro N HMCNV-VVBFX-7HMBH-CTY9B-B4FXY ", "Windows 8.1 Enterprise MHF9N-XY6XB-WVXMC-BTDCT-MKKG7 ", "Windows 8.1 Enterprise N TT4HM-HN7YT-62K67-RGRQJ-JFFXW ", "Windows 8 Pro NG4HW-VH26C-733KW-K6F98-J8CK4 ", "Windows 8 Pro N XCVCF-2NXM9-723PB-MHCB7-2RYQQ ", "Windows 8 Enterprise 32JNW-9KQ84-P47T8-D8GGY-CWCK7 ", "Windows 8 Enterprise N JMNMF-RHW7P-DMY6X-RF3DR-X2BQT ", "Windows 7 Professional FJ82H-XT6CR-J8D7P-XQJJ2-GPDD4 ", "Windows 7 Professional N MRPKT-YTG23-K7D7T-X2JMM-QY7MG ", "Windows 7 Professional E W82YF-2Q76Y-63HXB-FGJG9-GF7QX ", "Windows 7 Enterprise 33PXH-7Y6KF-2VJC9-XBBR8-HVTHH ", "Windows 7 Enterprise N YDRBP-3D83W-TY26F-D46B2-XCKRJ ", "Windows 7 Enterprise E C29WB-22CC8-VJ326-GHFJW-H9DH4 "})
        Me.CmbBoxEditionServicing_GLVKKeys.Location = New System.Drawing.Point(109, 236)
        Me.CmbBoxEditionServicing_GLVKKeys.Name = "CmbBoxEditionServicing_GLVKKeys"
        Me.CmbBoxEditionServicing_GLVKKeys.Size = New System.Drawing.Size(755, 28)
        Me.CmbBoxEditionServicing_GLVKKeys.TabIndex = 43
        '
        'LblEditionServicing_GLVKKeys
        '
        Me.LblEditionServicing_GLVKKeys.AutoSize = True
        Me.LblEditionServicing_GLVKKeys.Location = New System.Drawing.Point(13, 244)
        Me.LblEditionServicing_GLVKKeys.Name = "LblEditionServicing_GLVKKeys"
        Me.LblEditionServicing_GLVKKeys.Size = New System.Drawing.Size(94, 20)
        Me.LblEditionServicing_GLVKKeys.TabIndex = 42
        Me.LblEditionServicing_GLVKKeys.Text = "GLVK Keys:"
        '
        'CmbBoxEditionServicing_AVMAKeys
        '
        Me.CmbBoxEditionServicing_AVMAKeys.FormattingEnabled = True
        Me.CmbBoxEditionServicing_AVMAKeys.Items.AddRange(New Object() {"Windows Serveur 2022 Standard YDFWN-MJ9JR-3DYRK-FXXRW-78VHK ", "Windows Serveur 2019 DataCenter H3RNG-8C32Q-Q8FRX-6TDXV-WMBMW ", "Windows Serveur 2019 Standard TNK62-RXVTB-4P47B-2D623-4GF74 ", "Windows Serveur 2019 Essentials 2CTP7-NHT64-BP62M-FV6GG-HFV28 ", "Windows Serveur 1909, 1903, 1809 DataCenter H3RNG-8C32Q-Q8FRX-6TDXV-WMBMW ", "Windows Serveur 1909, 1903, 1809 Standard TNK62-RXVTB-4P47B-2D623-4GF74 ", "Windows Serveur 1803,1709 DataCenter TMJ3Y-NTRTM-FJYXT-T22BY-CWG3J ", "Windows Serveur 1803,1709 Standard C3RCX-M6NRP-6CXC9-TW2F2-4RHYD ", "Windows Serveur 2016 DataCenter TMJ3Y-NTRTM-FJYXT-T22BY-CWG3J ", "Windows Serveur 2016 Standard C3RCX-M6NRP-6CXC9-TW2F2-4RHYD ", "Windows Serveur 2016 Essentials B4YNW-62DX9-W8V6M-82649-MHBKQ ", "Windows Serveur 2012 R2 DataCenter Y4TGP-NPTV9-HTC2H-7MGQ3-DV4TW ", "Windows Serveur 2012 R2 Standard DBGBW-NPF86-BJVTX-K3WKJ-MTB6V ", "Windows Serveur 2012 R2 Essentials K2XGM-NMBT3-2R6Q8-WF2FK-P36R2 "})
        Me.CmbBoxEditionServicing_AVMAKeys.Location = New System.Drawing.Point(109, 270)
        Me.CmbBoxEditionServicing_AVMAKeys.Name = "CmbBoxEditionServicing_AVMAKeys"
        Me.CmbBoxEditionServicing_AVMAKeys.Size = New System.Drawing.Size(755, 28)
        Me.CmbBoxEditionServicing_AVMAKeys.TabIndex = 41
        '
        'LblEditionServicing_AVMAKeys
        '
        Me.LblEditionServicing_AVMAKeys.AutoSize = True
        Me.LblEditionServicing_AVMAKeys.Location = New System.Drawing.Point(13, 278)
        Me.LblEditionServicing_AVMAKeys.Name = "LblEditionServicing_AVMAKeys"
        Me.LblEditionServicing_AVMAKeys.Size = New System.Drawing.Size(97, 20)
        Me.LblEditionServicing_AVMAKeys.TabIndex = 40
        Me.LblEditionServicing_AVMAKeys.Text = "AVMA Keys:"
        '
        'BtnEditionServicing_GetMountedImageInfo
        '
        Me.BtnEditionServicing_GetMountedImageInfo.Location = New System.Drawing.Point(721, 10)
        Me.BtnEditionServicing_GetMountedImageInfo.Name = "BtnEditionServicing_GetMountedImageInfo"
        Me.BtnEditionServicing_GetMountedImageInfo.Size = New System.Drawing.Size(143, 64)
        Me.BtnEditionServicing_GetMountedImageInfo.TabIndex = 39
        Me.BtnEditionServicing_GetMountedImageInfo.Text = "Get Mounted Image Info"
        Me.BtnEditionServicing_GetMountedImageInfo.UseVisualStyleBackColor = True
        '
        'BtnEditionServicing_RefreshMountedImage
        '
        Me.BtnEditionServicing_RefreshMountedImage.Location = New System.Drawing.Point(254, 10)
        Me.BtnEditionServicing_RefreshMountedImage.Name = "BtnEditionServicing_RefreshMountedImage"
        Me.BtnEditionServicing_RefreshMountedImage.Size = New System.Drawing.Size(221, 32)
        Me.BtnEditionServicing_RefreshMountedImage.TabIndex = 38
        Me.BtnEditionServicing_RefreshMountedImage.Text = "Refresh mounted image"
        Me.BtnEditionServicing_RefreshMountedImage.UseVisualStyleBackColor = True
        '
        'LblEditionServicing_UseMountedImage
        '
        Me.LblEditionServicing_UseMountedImage.AutoSize = True
        Me.LblEditionServicing_UseMountedImage.Location = New System.Drawing.Point(13, 51)
        Me.LblEditionServicing_UseMountedImage.Name = "LblEditionServicing_UseMountedImage"
        Me.LblEditionServicing_UseMountedImage.Size = New System.Drawing.Size(158, 20)
        Me.LblEditionServicing_UseMountedImage.TabIndex = 37
        Me.LblEditionServicing_UseMountedImage.Text = "Use Image Mounted:"
        '
        'CmbBoxEditionServicing_UseImageMounted
        '
        Me.CmbBoxEditionServicing_UseImageMounted.FormattingEnabled = True
        Me.CmbBoxEditionServicing_UseImageMounted.Location = New System.Drawing.Point(196, 48)
        Me.CmbBoxEditionServicing_UseImageMounted.Name = "CmbBoxEditionServicing_UseImageMounted"
        Me.CmbBoxEditionServicing_UseImageMounted.Size = New System.Drawing.Size(349, 28)
        Me.CmbBoxEditionServicing_UseImageMounted.TabIndex = 36
        '
        'ChkBoxEditionServicing_Online
        '
        Me.ChkBoxEditionServicing_Online.AutoSize = True
        Me.ChkBoxEditionServicing_Online.Location = New System.Drawing.Point(758, 323)
        Me.ChkBoxEditionServicing_Online.Name = "ChkBoxEditionServicing_Online"
        Me.ChkBoxEditionServicing_Online.Size = New System.Drawing.Size(125, 24)
        Me.ChkBoxEditionServicing_Online.TabIndex = 29
        Me.ChkBoxEditionServicing_Online.Text = "/Online option"
        Me.ChkBoxEditionServicing_Online.UseVisualStyleBackColor = False
        '
        'LblEditionServicing_Edition
        '
        Me.LblEditionServicing_Edition.AutoSize = True
        Me.LblEditionServicing_Edition.Location = New System.Drawing.Point(24, 155)
        Me.LblEditionServicing_Edition.Name = "LblEditionServicing_Edition"
        Me.LblEditionServicing_Edition.Size = New System.Drawing.Size(58, 20)
        Me.LblEditionServicing_Edition.TabIndex = 28
        Me.LblEditionServicing_Edition.Text = "Edition"
        '
        'BtnEditionServicing_SetEdition
        '
        Me.BtnEditionServicing_SetEdition.Location = New System.Drawing.Point(337, 176)
        Me.BtnEditionServicing_SetEdition.Name = "BtnEditionServicing_SetEdition"
        Me.BtnEditionServicing_SetEdition.Size = New System.Drawing.Size(129, 30)
        Me.BtnEditionServicing_SetEdition.TabIndex = 27
        Me.BtnEditionServicing_SetEdition.Text = "Set Edition"
        Me.BtnEditionServicing_SetEdition.UseVisualStyleBackColor = True
        '
        'txtEdition
        '
        Me.txtEdition.Location = New System.Drawing.Point(14, 178)
        Me.txtEdition.Name = "txtEdition"
        Me.txtEdition.Size = New System.Drawing.Size(303, 26)
        Me.txtEdition.TabIndex = 26
        '
        'txtProdKey
        '
        Me.txtProdKey.Location = New System.Drawing.Point(14, 108)
        Me.txtProdKey.Mask = "&&&&&-&&&&&-&&&&&-&&&&&-&&&&&"
        Me.txtProdKey.Name = "txtProdKey"
        Me.txtProdKey.Size = New System.Drawing.Size(303, 26)
        Me.txtProdKey.TabIndex = 25
        '
        'BtnEditionServicing_SetProductKey
        '
        Me.BtnEditionServicing_SetProductKey.Location = New System.Drawing.Point(337, 108)
        Me.BtnEditionServicing_SetProductKey.Name = "BtnEditionServicing_SetProductKey"
        Me.BtnEditionServicing_SetProductKey.Size = New System.Drawing.Size(129, 26)
        Me.BtnEditionServicing_SetProductKey.TabIndex = 24
        Me.BtnEditionServicing_SetProductKey.Text = "Set Product Key"
        Me.BtnEditionServicing_SetProductKey.UseVisualStyleBackColor = True
        '
        'LblEditionServicing_ProductKey
        '
        Me.LblEditionServicing_ProductKey.AutoSize = True
        Me.LblEditionServicing_ProductKey.Location = New System.Drawing.Point(24, 85)
        Me.LblEditionServicing_ProductKey.Name = "LblEditionServicing_ProductKey"
        Me.LblEditionServicing_ProductKey.Size = New System.Drawing.Size(94, 20)
        Me.LblEditionServicing_ProductKey.TabIndex = 22
        Me.LblEditionServicing_ProductKey.Text = "Product Key"
        '
        'BtnEditionServicing_GetTargetEditions
        '
        Me.BtnEditionServicing_GetTargetEditions.Location = New System.Drawing.Point(580, 155)
        Me.BtnEditionServicing_GetTargetEditions.Name = "BtnEditionServicing_GetTargetEditions"
        Me.BtnEditionServicing_GetTargetEditions.Size = New System.Drawing.Size(127, 64)
        Me.BtnEditionServicing_GetTargetEditions.TabIndex = 12
        Me.BtnEditionServicing_GetTargetEditions.Text = "Get Target Editions (/Online)"
        Me.BtnEditionServicing_GetTargetEditions.UseVisualStyleBackColor = True
        '
        'BtnEditionServicing_GetCurrentEdition
        '
        Me.BtnEditionServicing_GetCurrentEdition.Location = New System.Drawing.Point(580, 85)
        Me.BtnEditionServicing_GetCurrentEdition.Name = "BtnEditionServicing_GetCurrentEdition"
        Me.BtnEditionServicing_GetCurrentEdition.Size = New System.Drawing.Size(127, 64)
        Me.BtnEditionServicing_GetCurrentEdition.TabIndex = 11
        Me.BtnEditionServicing_GetCurrentEdition.Text = "Get Current Edition (/Online)"
        Me.BtnEditionServicing_GetCurrentEdition.UseVisualStyleBackColor = True
        '
        'TabPage6
        '
        Me.TabPage6.Controls.Add(Me.BtnUnattendedServicing_GetMountedImageInfo)
        Me.TabPage6.Controls.Add(Me.BtnUnattendedServicing_RefreshMountedImage)
        Me.TabPage6.Controls.Add(Me.LblUnattendedServicing_UseMountedImage)
        Me.TabPage6.Controls.Add(Me.CmBoxUnattendedServicing_UseImageMounted)
        Me.TabPage6.Controls.Add(Me.ChkBoxUnattendedServicing_Online)
        Me.TabPage6.Controls.Add(Me.BtnUnattendedServicing_ChooseUnAttend)
        Me.TabPage6.Controls.Add(Me.TxtBoxUnattendedServicing_XMLFile)
        Me.TabPage6.Controls.Add(Me.LblUnattendedServicing_XMLFile)
        Me.TabPage6.Controls.Add(Me.BtnUnattendedServicing_ApplyUnattend)
        Me.TabPage6.Location = New System.Drawing.Point(4, 29)
        Me.TabPage6.Name = "TabPage6"
        Me.TabPage6.Size = New System.Drawing.Size(886, 350)
        Me.TabPage6.TabIndex = 5
        Me.TabPage6.Text = "Unattended Servicing"
        Me.TabPage6.UseVisualStyleBackColor = True
        '
        'BtnUnattendedServicing_GetMountedImageInfo
        '
        Me.BtnUnattendedServicing_GetMountedImageInfo.Location = New System.Drawing.Point(711, 11)
        Me.BtnUnattendedServicing_GetMountedImageInfo.Name = "BtnUnattendedServicing_GetMountedImageInfo"
        Me.BtnUnattendedServicing_GetMountedImageInfo.Size = New System.Drawing.Size(154, 64)
        Me.BtnUnattendedServicing_GetMountedImageInfo.TabIndex = 42
        Me.BtnUnattendedServicing_GetMountedImageInfo.Text = "Get Mounted Image Info"
        Me.BtnUnattendedServicing_GetMountedImageInfo.UseVisualStyleBackColor = True
        '
        'BtnUnattendedServicing_RefreshMountedImage
        '
        Me.BtnUnattendedServicing_RefreshMountedImage.Location = New System.Drawing.Point(236, 9)
        Me.BtnUnattendedServicing_RefreshMountedImage.Name = "BtnUnattendedServicing_RefreshMountedImage"
        Me.BtnUnattendedServicing_RefreshMountedImage.Size = New System.Drawing.Size(221, 32)
        Me.BtnUnattendedServicing_RefreshMountedImage.TabIndex = 41
        Me.BtnUnattendedServicing_RefreshMountedImage.Text = "Refresh mounted image"
        Me.BtnUnattendedServicing_RefreshMountedImage.UseVisualStyleBackColor = True
        '
        'LblUnattendedServicing_UseMountedImage
        '
        Me.LblUnattendedServicing_UseMountedImage.AutoSize = True
        Me.LblUnattendedServicing_UseMountedImage.Location = New System.Drawing.Point(8, 50)
        Me.LblUnattendedServicing_UseMountedImage.Name = "LblUnattendedServicing_UseMountedImage"
        Me.LblUnattendedServicing_UseMountedImage.Size = New System.Drawing.Size(158, 20)
        Me.LblUnattendedServicing_UseMountedImage.TabIndex = 40
        Me.LblUnattendedServicing_UseMountedImage.Text = "Use Image Mounted:"
        '
        'CmBoxUnattendedServicing_UseImageMounted
        '
        Me.CmBoxUnattendedServicing_UseImageMounted.FormattingEnabled = True
        Me.CmBoxUnattendedServicing_UseImageMounted.Location = New System.Drawing.Point(178, 47)
        Me.CmBoxUnattendedServicing_UseImageMounted.Name = "CmBoxUnattendedServicing_UseImageMounted"
        Me.CmBoxUnattendedServicing_UseImageMounted.Size = New System.Drawing.Size(349, 28)
        Me.CmBoxUnattendedServicing_UseImageMounted.TabIndex = 39
        '
        'ChkBoxUnattendedServicing_Online
        '
        Me.ChkBoxUnattendedServicing_Online.AutoSize = True
        Me.ChkBoxUnattendedServicing_Online.Location = New System.Drawing.Point(758, 323)
        Me.ChkBoxUnattendedServicing_Online.Name = "ChkBoxUnattendedServicing_Online"
        Me.ChkBoxUnattendedServicing_Online.Size = New System.Drawing.Size(125, 24)
        Me.ChkBoxUnattendedServicing_Online.TabIndex = 30
        Me.ChkBoxUnattendedServicing_Online.Text = "/Online option"
        Me.ChkBoxUnattendedServicing_Online.UseVisualStyleBackColor = False
        '
        'BtnUnattendedServicing_ChooseUnAttend
        '
        Me.BtnUnattendedServicing_ChooseUnAttend.Location = New System.Drawing.Point(363, 119)
        Me.BtnUnattendedServicing_ChooseUnAttend.Name = "BtnUnattendedServicing_ChooseUnAttend"
        Me.BtnUnattendedServicing_ChooseUnAttend.Size = New System.Drawing.Size(106, 26)
        Me.BtnUnattendedServicing_ChooseUnAttend.TabIndex = 23
        Me.BtnUnattendedServicing_ChooseUnAttend.Text = "Choose XML"
        Me.BtnUnattendedServicing_ChooseUnAttend.UseVisualStyleBackColor = True
        '
        'TxtBoxUnattendedServicing_XMLFile
        '
        Me.TxtBoxUnattendedServicing_XMLFile.Location = New System.Drawing.Point(12, 119)
        Me.TxtBoxUnattendedServicing_XMLFile.Name = "TxtBoxUnattendedServicing_XMLFile"
        Me.TxtBoxUnattendedServicing_XMLFile.Size = New System.Drawing.Size(339, 26)
        Me.TxtBoxUnattendedServicing_XMLFile.TabIndex = 21
        '
        'LblUnattendedServicing_XMLFile
        '
        Me.LblUnattendedServicing_XMLFile.AutoSize = True
        Me.LblUnattendedServicing_XMLFile.Location = New System.Drawing.Point(8, 96)
        Me.LblUnattendedServicing_XMLFile.Name = "LblUnattendedServicing_XMLFile"
        Me.LblUnattendedServicing_XMLFile.Size = New System.Drawing.Size(142, 20)
        Me.LblUnattendedServicing_XMLFile.TabIndex = 22
        Me.LblUnattendedServicing_XMLFile.Text = "Unattend XML File"
        '
        'BtnUnattendedServicing_ApplyUnattend
        '
        Me.BtnUnattendedServicing_ApplyUnattend.Location = New System.Drawing.Point(530, 96)
        Me.BtnUnattendedServicing_ApplyUnattend.Name = "BtnUnattendedServicing_ApplyUnattend"
        Me.BtnUnattendedServicing_ApplyUnattend.Size = New System.Drawing.Size(127, 64)
        Me.BtnUnattendedServicing_ApplyUnattend.TabIndex = 20
        Me.BtnUnattendedServicing_ApplyUnattend.Text = "Apply Unattend.xml"
        Me.BtnUnattendedServicing_ApplyUnattend.UseVisualStyleBackColor = True
        '
        'TabPage7
        '
        Me.TabPage7.Controls.Add(Me.BtnApplicationServicing_GetMountedImageInfo)
        Me.TabPage7.Controls.Add(Me.BtnApplicationServicing_RefreshMountedImage)
        Me.TabPage7.Controls.Add(Me.LblApplicationServicing_UseMountedImage)
        Me.TabPage7.Controls.Add(Me.CmbBoxApplicationServicing_UseImageMounted)
        Me.TabPage7.Controls.Add(Me.BtnApplicationServicing_ChooseMSP)
        Me.TabPage7.Controls.Add(Me.txtPatchLocation)
        Me.TabPage7.Controls.Add(Me.LblApplicationServicing_MSPFile)
        Me.TabPage7.Controls.Add(Me.txtPatchCode)
        Me.TabPage7.Controls.Add(Me.txtProductCode)
        Me.TabPage7.Controls.Add(Me.BtnApplicationServicing_CheckAppPatch)
        Me.TabPage7.Controls.Add(Me.BtnApplicationServicing_GetAppPatchInfo)
        Me.TabPage7.Controls.Add(Me.BtnApplicationServicing_GetAppPatches)
        Me.TabPage7.Controls.Add(Me.BtnApplicationServicing_GetAppInfo)
        Me.TabPage7.Controls.Add(Me.LblApplicationServicing_PathCode)
        Me.TabPage7.Controls.Add(Me.LblApplicationServicing_ProductCode)
        Me.TabPage7.Controls.Add(Me.BtnApplicationServicing_GetApps)
        Me.TabPage7.Location = New System.Drawing.Point(4, 29)
        Me.TabPage7.Name = "TabPage7"
        Me.TabPage7.Size = New System.Drawing.Size(886, 350)
        Me.TabPage7.TabIndex = 6
        Me.TabPage7.Text = "Application Servicing"
        Me.TabPage7.UseVisualStyleBackColor = True
        '
        'BtnApplicationServicing_GetMountedImageInfo
        '
        Me.BtnApplicationServicing_GetMountedImageInfo.Location = New System.Drawing.Point(701, 9)
        Me.BtnApplicationServicing_GetMountedImageInfo.Name = "BtnApplicationServicing_GetMountedImageInfo"
        Me.BtnApplicationServicing_GetMountedImageInfo.Size = New System.Drawing.Size(163, 64)
        Me.BtnApplicationServicing_GetMountedImageInfo.TabIndex = 45
        Me.BtnApplicationServicing_GetMountedImageInfo.Text = "Get Mounted Image Info"
        Me.BtnApplicationServicing_GetMountedImageInfo.UseVisualStyleBackColor = True
        '
        'BtnApplicationServicing_RefreshMountedImage
        '
        Me.BtnApplicationServicing_RefreshMountedImage.Location = New System.Drawing.Point(247, 9)
        Me.BtnApplicationServicing_RefreshMountedImage.Name = "BtnApplicationServicing_RefreshMountedImage"
        Me.BtnApplicationServicing_RefreshMountedImage.Size = New System.Drawing.Size(221, 32)
        Me.BtnApplicationServicing_RefreshMountedImage.TabIndex = 44
        Me.BtnApplicationServicing_RefreshMountedImage.Text = "Refresh mounted image"
        Me.BtnApplicationServicing_RefreshMountedImage.UseVisualStyleBackColor = True
        '
        'LblApplicationServicing_UseMountedImage
        '
        Me.LblApplicationServicing_UseMountedImage.AutoSize = True
        Me.LblApplicationServicing_UseMountedImage.Location = New System.Drawing.Point(10, 53)
        Me.LblApplicationServicing_UseMountedImage.Name = "LblApplicationServicing_UseMountedImage"
        Me.LblApplicationServicing_UseMountedImage.Size = New System.Drawing.Size(158, 20)
        Me.LblApplicationServicing_UseMountedImage.TabIndex = 43
        Me.LblApplicationServicing_UseMountedImage.Text = "Use Image Mounted:"
        '
        'CmbBoxApplicationServicing_UseImageMounted
        '
        Me.CmbBoxApplicationServicing_UseImageMounted.FormattingEnabled = True
        Me.CmbBoxApplicationServicing_UseImageMounted.Location = New System.Drawing.Point(189, 47)
        Me.CmbBoxApplicationServicing_UseImageMounted.Name = "CmbBoxApplicationServicing_UseImageMounted"
        Me.CmbBoxApplicationServicing_UseImageMounted.Size = New System.Drawing.Size(349, 28)
        Me.CmbBoxApplicationServicing_UseImageMounted.TabIndex = 42
        '
        'BtnApplicationServicing_ChooseMSP
        '
        Me.BtnApplicationServicing_ChooseMSP.Location = New System.Drawing.Point(362, 245)
        Me.BtnApplicationServicing_ChooseMSP.Name = "BtnApplicationServicing_ChooseMSP"
        Me.BtnApplicationServicing_ChooseMSP.Size = New System.Drawing.Size(106, 28)
        Me.BtnApplicationServicing_ChooseMSP.TabIndex = 41
        Me.BtnApplicationServicing_ChooseMSP.Text = "Choose MSP"
        Me.BtnApplicationServicing_ChooseMSP.UseVisualStyleBackColor = True
        '
        'txtPatchLocation
        '
        Me.txtPatchLocation.Location = New System.Drawing.Point(10, 247)
        Me.txtPatchLocation.Name = "txtPatchLocation"
        Me.txtPatchLocation.Size = New System.Drawing.Size(327, 26)
        Me.txtPatchLocation.TabIndex = 39
        '
        'LblApplicationServicing_MSPFile
        '
        Me.LblApplicationServicing_MSPFile.AutoSize = True
        Me.LblApplicationServicing_MSPFile.Location = New System.Drawing.Point(6, 224)
        Me.LblApplicationServicing_MSPFile.Name = "LblApplicationServicing_MSPFile"
        Me.LblApplicationServicing_MSPFile.Size = New System.Drawing.Size(72, 20)
        Me.LblApplicationServicing_MSPFile.TabIndex = 40
        Me.LblApplicationServicing_MSPFile.Text = "MSP File"
        '
        'txtPatchCode
        '
        Me.txtPatchCode.Location = New System.Drawing.Point(10, 188)
        Me.txtPatchCode.Mask = "{&&&&&&&&-&&&&-&&&&-&&&&-&&&&&&&&&&&&}"
        Me.txtPatchCode.Name = "txtPatchCode"
        Me.txtPatchCode.Size = New System.Drawing.Size(327, 26)
        Me.txtPatchCode.TabIndex = 38
        '
        'txtProductCode
        '
        Me.txtProductCode.Location = New System.Drawing.Point(9, 136)
        Me.txtProductCode.Mask = "{&&&&&&&&-&&&&-&&&&-&&&&-&&&&&&&&&&&&}"
        Me.txtProductCode.Name = "txtProductCode"
        Me.txtProductCode.Size = New System.Drawing.Size(328, 26)
        Me.txtProductCode.TabIndex = 37
        '
        'BtnApplicationServicing_CheckAppPatch
        '
        Me.BtnApplicationServicing_CheckAppPatch.Location = New System.Drawing.Point(715, 271)
        Me.BtnApplicationServicing_CheckAppPatch.Name = "BtnApplicationServicing_CheckAppPatch"
        Me.BtnApplicationServicing_CheckAppPatch.Size = New System.Drawing.Size(149, 64)
        Me.BtnApplicationServicing_CheckAppPatch.TabIndex = 36
        Me.BtnApplicationServicing_CheckAppPatch.Text = "Check App Patch"
        Me.BtnApplicationServicing_CheckAppPatch.UseVisualStyleBackColor = True
        '
        'BtnApplicationServicing_GetAppPatchInfo
        '
        Me.BtnApplicationServicing_GetAppPatchInfo.Location = New System.Drawing.Point(715, 188)
        Me.BtnApplicationServicing_GetAppPatchInfo.Name = "BtnApplicationServicing_GetAppPatchInfo"
        Me.BtnApplicationServicing_GetAppPatchInfo.Size = New System.Drawing.Size(149, 64)
        Me.BtnApplicationServicing_GetAppPatchInfo.TabIndex = 35
        Me.BtnApplicationServicing_GetAppPatchInfo.Text = "Get Application Patch Info"
        Me.BtnApplicationServicing_GetAppPatchInfo.UseVisualStyleBackColor = True
        '
        'BtnApplicationServicing_GetAppPatches
        '
        Me.BtnApplicationServicing_GetAppPatches.Location = New System.Drawing.Point(528, 188)
        Me.BtnApplicationServicing_GetAppPatches.Name = "BtnApplicationServicing_GetAppPatches"
        Me.BtnApplicationServicing_GetAppPatches.Size = New System.Drawing.Size(154, 64)
        Me.BtnApplicationServicing_GetAppPatches.TabIndex = 34
        Me.BtnApplicationServicing_GetAppPatches.Text = "Get Application Patches"
        Me.BtnApplicationServicing_GetAppPatches.UseVisualStyleBackColor = True
        '
        'BtnApplicationServicing_GetAppInfo
        '
        Me.BtnApplicationServicing_GetAppInfo.Location = New System.Drawing.Point(715, 110)
        Me.BtnApplicationServicing_GetAppInfo.Name = "BtnApplicationServicing_GetAppInfo"
        Me.BtnApplicationServicing_GetAppInfo.Size = New System.Drawing.Size(149, 64)
        Me.BtnApplicationServicing_GetAppInfo.TabIndex = 33
        Me.BtnApplicationServicing_GetAppInfo.Text = "Get Application Info"
        Me.BtnApplicationServicing_GetAppInfo.UseVisualStyleBackColor = True
        '
        'LblApplicationServicing_PathCode
        '
        Me.LblApplicationServicing_PathCode.AutoSize = True
        Me.LblApplicationServicing_PathCode.Location = New System.Drawing.Point(6, 165)
        Me.LblApplicationServicing_PathCode.Name = "LblApplicationServicing_PathCode"
        Me.LblApplicationServicing_PathCode.Size = New System.Drawing.Size(144, 20)
        Me.LblApplicationServicing_PathCode.TabIndex = 32
        Me.LblApplicationServicing_PathCode.Text = "PatchCode (GUID)"
        '
        'LblApplicationServicing_ProductCode
        '
        Me.LblApplicationServicing_ProductCode.AutoSize = True
        Me.LblApplicationServicing_ProductCode.Location = New System.Drawing.Point(3, 110)
        Me.LblApplicationServicing_ProductCode.Name = "LblApplicationServicing_ProductCode"
        Me.LblApplicationServicing_ProductCode.Size = New System.Drawing.Size(158, 20)
        Me.LblApplicationServicing_ProductCode.TabIndex = 30
        Me.LblApplicationServicing_ProductCode.Text = "ProductCode (GUID)"
        '
        'BtnApplicationServicing_GetApps
        '
        Me.BtnApplicationServicing_GetApps.Location = New System.Drawing.Point(528, 110)
        Me.BtnApplicationServicing_GetApps.Name = "BtnApplicationServicing_GetApps"
        Me.BtnApplicationServicing_GetApps.Size = New System.Drawing.Size(154, 64)
        Me.BtnApplicationServicing_GetApps.TabIndex = 12
        Me.BtnApplicationServicing_GetApps.Text = "Get Applications"
        Me.BtnApplicationServicing_GetApps.UseVisualStyleBackColor = True
        '
        'TabPage8
        '
        Me.TabPage8.Controls.Add(Me.LblCaptureImageWim_DescriptionMetadata)
        Me.TabPage8.Controls.Add(Me.TxtBoxCaptureWIM_Description)
        Me.TabPage8.Controls.Add(Me.LblCaptureImageWim_NameMetadata)
        Me.TabPage8.Controls.Add(Me.TxtNameMetadata)
        Me.TabPage8.Controls.Add(Me.ChkBoxCaptureImageWim_Verify)
        Me.TabPage8.Controls.Add(Me.BtnCaptureImageWim_AppendWim)
        Me.TabPage8.Controls.Add(Me.cmbCompression)
        Me.TabPage8.Controls.Add(Me.LblCaptureImageWim_Compression)
        Me.TabPage8.Controls.Add(Me.LblCaptureImageWim_FileName)
        Me.TabPage8.Controls.Add(Me.TxtFileName)
        Me.TabPage8.Controls.Add(Me.BtnCaptureImageWim_CreateWim)
        Me.TabPage8.Controls.Add(Me.LblCaptureImageWim_Destination)
        Me.TabPage8.Controls.Add(Me.LblCaptureImageWim_Source)
        Me.TabPage8.Controls.Add(Me.BtnCaptureImageWim_BrowseDestination)
        Me.TabPage8.Controls.Add(Me.txtCaptureDest)
        Me.TabPage8.Controls.Add(Me.txtCaptureSource)
        Me.TabPage8.Controls.Add(Me.BtnCaptureImageWim_BrowseSource)
        Me.TabPage8.Location = New System.Drawing.Point(4, 29)
        Me.TabPage8.Name = "TabPage8"
        Me.TabPage8.Size = New System.Drawing.Size(886, 350)
        Me.TabPage8.TabIndex = 7
        Me.TabPage8.Text = "Capture Wim Image"
        Me.TabPage8.UseVisualStyleBackColor = True
        '
        'LblCaptureImageWim_DescriptionMetadata
        '
        Me.LblCaptureImageWim_DescriptionMetadata.AutoSize = True
        Me.LblCaptureImageWim_DescriptionMetadata.Location = New System.Drawing.Point(14, 156)
        Me.LblCaptureImageWim_DescriptionMetadata.Name = "LblCaptureImageWim_DescriptionMetadata"
        Me.LblCaptureImageWim_DescriptionMetadata.Size = New System.Drawing.Size(175, 20)
        Me.LblCaptureImageWim_DescriptionMetadata.TabIndex = 50
        Me.LblCaptureImageWim_DescriptionMetadata.Text = "Description (metadata):"
        '
        'TxtBoxCaptureWIM_Description
        '
        Me.TxtBoxCaptureWIM_Description.Location = New System.Drawing.Point(191, 153)
        Me.TxtBoxCaptureWIM_Description.Name = "TxtBoxCaptureWIM_Description"
        Me.TxtBoxCaptureWIM_Description.Size = New System.Drawing.Size(295, 26)
        Me.TxtBoxCaptureWIM_Description.TabIndex = 49
        '
        'LblCaptureImageWim_NameMetadata
        '
        Me.LblCaptureImageWim_NameMetadata.AutoSize = True
        Me.LblCaptureImageWim_NameMetadata.Location = New System.Drawing.Point(14, 124)
        Me.LblCaptureImageWim_NameMetadata.Name = "LblCaptureImageWim_NameMetadata"
        Me.LblCaptureImageWim_NameMetadata.Size = New System.Drawing.Size(137, 20)
        Me.LblCaptureImageWim_NameMetadata.TabIndex = 48
        Me.LblCaptureImageWim_NameMetadata.Text = "Name (metadata):"
        '
        'TxtNameMetadata
        '
        Me.TxtNameMetadata.Location = New System.Drawing.Point(191, 121)
        Me.TxtNameMetadata.Name = "TxtNameMetadata"
        Me.TxtNameMetadata.Size = New System.Drawing.Size(295, 26)
        Me.TxtNameMetadata.TabIndex = 47
        '
        'ChkBoxCaptureImageWim_Verify
        '
        Me.ChkBoxCaptureImageWim_Verify.AutoSize = True
        Me.ChkBoxCaptureImageWim_Verify.Location = New System.Drawing.Point(191, 219)
        Me.ChkBoxCaptureImageWim_Verify.Name = "ChkBoxCaptureImageWim_Verify"
        Me.ChkBoxCaptureImageWim_Verify.Size = New System.Drawing.Size(72, 24)
        Me.ChkBoxCaptureImageWim_Verify.TabIndex = 46
        Me.ChkBoxCaptureImageWim_Verify.Text = "/Verify"
        Me.ChkBoxCaptureImageWim_Verify.UseVisualStyleBackColor = True
        '
        'BtnCaptureImageWim_AppendWim
        '
        Me.BtnCaptureImageWim_AppendWim.Location = New System.Drawing.Point(631, 90)
        Me.BtnCaptureImageWim_AppendWim.Name = "BtnCaptureImageWim_AppendWim"
        Me.BtnCaptureImageWim_AppendWim.Size = New System.Drawing.Size(127, 64)
        Me.BtnCaptureImageWim_AppendWim.TabIndex = 45
        Me.BtnCaptureImageWim_AppendWim.Text = "&Append"
        Me.BtnCaptureImageWim_AppendWim.UseVisualStyleBackColor = True
        '
        'cmbCompression
        '
        Me.cmbCompression.FormattingEnabled = True
        Me.cmbCompression.Items.AddRange(New Object() {"fast", "max", "none"})
        Me.cmbCompression.Location = New System.Drawing.Point(191, 185)
        Me.cmbCompression.Name = "cmbCompression"
        Me.cmbCompression.Size = New System.Drawing.Size(80, 28)
        Me.cmbCompression.TabIndex = 44
        '
        'LblCaptureImageWim_Compression
        '
        Me.LblCaptureImageWim_Compression.AutoSize = True
        Me.LblCaptureImageWim_Compression.Location = New System.Drawing.Point(14, 191)
        Me.LblCaptureImageWim_Compression.Name = "LblCaptureImageWim_Compression"
        Me.LblCaptureImageWim_Compression.Size = New System.Drawing.Size(106, 20)
        Me.LblCaptureImageWim_Compression.TabIndex = 43
        Me.LblCaptureImageWim_Compression.Text = "Compression:"
        '
        'LblCaptureImageWim_FileName
        '
        Me.LblCaptureImageWim_FileName.AutoSize = True
        Me.LblCaptureImageWim_FileName.Location = New System.Drawing.Point(14, 87)
        Me.LblCaptureImageWim_FileName.Name = "LblCaptureImageWim_FileName"
        Me.LblCaptureImageWim_FileName.Size = New System.Drawing.Size(78, 20)
        Me.LblCaptureImageWim_FileName.TabIndex = 42
        Me.LblCaptureImageWim_FileName.Text = "Filename:"
        '
        'TxtFileName
        '
        Me.TxtFileName.Location = New System.Drawing.Point(191, 84)
        Me.TxtFileName.Name = "TxtFileName"
        Me.TxtFileName.Size = New System.Drawing.Size(295, 26)
        Me.TxtFileName.TabIndex = 34
        '
        'BtnCaptureImageWim_CreateWim
        '
        Me.BtnCaptureImageWim_CreateWim.Location = New System.Drawing.Point(631, 20)
        Me.BtnCaptureImageWim_CreateWim.Name = "BtnCaptureImageWim_CreateWim"
        Me.BtnCaptureImageWim_CreateWim.Size = New System.Drawing.Size(127, 64)
        Me.BtnCaptureImageWim_CreateWim.TabIndex = 40
        Me.BtnCaptureImageWim_CreateWim.Text = "&Create"
        Me.BtnCaptureImageWim_CreateWim.UseVisualStyleBackColor = True
        '
        'LblCaptureImageWim_Destination
        '
        Me.LblCaptureImageWim_Destination.AutoSize = True
        Me.LblCaptureImageWim_Destination.Location = New System.Drawing.Point(14, 55)
        Me.LblCaptureImageWim_Destination.Name = "LblCaptureImageWim_Destination"
        Me.LblCaptureImageWim_Destination.Size = New System.Drawing.Size(94, 20)
        Me.LblCaptureImageWim_Destination.TabIndex = 41
        Me.LblCaptureImageWim_Destination.Text = "Destination:"
        '
        'LblCaptureImageWim_Source
        '
        Me.LblCaptureImageWim_Source.AutoSize = True
        Me.LblCaptureImageWim_Source.Location = New System.Drawing.Point(14, 23)
        Me.LblCaptureImageWim_Source.Name = "LblCaptureImageWim_Source"
        Me.LblCaptureImageWim_Source.Size = New System.Drawing.Size(64, 20)
        Me.LblCaptureImageWim_Source.TabIndex = 38
        Me.LblCaptureImageWim_Source.Text = "Source:"
        '
        'BtnCaptureImageWim_BrowseDestination
        '
        Me.BtnCaptureImageWim_BrowseDestination.Location = New System.Drawing.Point(509, 50)
        Me.BtnCaptureImageWim_BrowseDestination.Name = "BtnCaptureImageWim_BrowseDestination"
        Me.BtnCaptureImageWim_BrowseDestination.Size = New System.Drawing.Size(90, 28)
        Me.BtnCaptureImageWim_BrowseDestination.TabIndex = 39
        Me.BtnCaptureImageWim_BrowseDestination.Text = "Browse..."
        Me.BtnCaptureImageWim_BrowseDestination.UseVisualStyleBackColor = True
        '
        'txtCaptureDest
        '
        Me.txtCaptureDest.Location = New System.Drawing.Point(191, 52)
        Me.txtCaptureDest.Name = "txtCaptureDest"
        Me.txtCaptureDest.Size = New System.Drawing.Size(295, 26)
        Me.txtCaptureDest.TabIndex = 37
        '
        'txtCaptureSource
        '
        Me.txtCaptureSource.Location = New System.Drawing.Point(191, 20)
        Me.txtCaptureSource.Name = "txtCaptureSource"
        Me.txtCaptureSource.Size = New System.Drawing.Size(295, 26)
        Me.txtCaptureSource.TabIndex = 35
        '
        'BtnCaptureImageWim_BrowseSource
        '
        Me.BtnCaptureImageWim_BrowseSource.Location = New System.Drawing.Point(509, 18)
        Me.BtnCaptureImageWim_BrowseSource.Name = "BtnCaptureImageWim_BrowseSource"
        Me.BtnCaptureImageWim_BrowseSource.Size = New System.Drawing.Size(90, 28)
        Me.BtnCaptureImageWim_BrowseSource.TabIndex = 36
        Me.BtnCaptureImageWim_BrowseSource.Text = "Browse..."
        Me.BtnCaptureImageWim_BrowseSource.UseVisualStyleBackColor = True
        '
        'TabPage9
        '
        Me.TabPage9.Controls.Add(Me.LblApplyWim_PatternSWMFile)
        Me.TabPage9.Controls.Add(Me.TxtBoxApplySource_PatternSWMFile)
        Me.TabPage9.Controls.Add(Me.LblApplyWim_Size)
        Me.TabPage9.Controls.Add(Me.TxtBoxApplyWim_Size)
        Me.TabPage9.Controls.Add(Me.LblApplyWim_Description)
        Me.TabPage9.Controls.Add(Me.LblApplyWim_Name)
        Me.TabPage9.Controls.Add(Me.TxtBoxApplyWim_Description)
        Me.TabPage9.Controls.Add(Me.TxtBoxApplyWim_Name)
        Me.TabPage9.Controls.Add(Me.ChkBoxApplyWim_Verify)
        Me.TabPage9.Controls.Add(Me.cmbApplyIndex)
        Me.TabPage9.Controls.Add(Me.LblApplyWim_Index)
        Me.TabPage9.Controls.Add(Me.BtnApplyWim_ApplyWim)
        Me.TabPage9.Controls.Add(Me.LblApplyWim_Destination)
        Me.TabPage9.Controls.Add(Me.LblApplyWim_Source)
        Me.TabPage9.Controls.Add(Me.BtnApplyWim_BrowseDestination)
        Me.TabPage9.Controls.Add(Me.txtApplyDest)
        Me.TabPage9.Controls.Add(Me.txtApplySource)
        Me.TabPage9.Controls.Add(Me.BtnApplyWim_BrowseSource)
        Me.TabPage9.Location = New System.Drawing.Point(4, 29)
        Me.TabPage9.Name = "TabPage9"
        Me.TabPage9.Size = New System.Drawing.Size(886, 350)
        Me.TabPage9.TabIndex = 8
        Me.TabPage9.Text = "Apply Wim / Swm Image"
        Me.TabPage9.UseVisualStyleBackColor = True
        '
        'LblApplyWim_PatternSWMFile
        '
        Me.LblApplyWim_PatternSWMFile.AutoSize = True
        Me.LblApplyWim_PatternSWMFile.Location = New System.Drawing.Point(8, 93)
        Me.LblApplyWim_PatternSWMFile.Name = "LblApplyWim_PatternSWMFile"
        Me.LblApplyWim_PatternSWMFile.Size = New System.Drawing.Size(133, 20)
        Me.LblApplyWim_PatternSWMFile.TabIndex = 49
        Me.LblApplyWim_PatternSWMFile.Text = "SWMFile Pattern:"
        '
        'TxtBoxApplySource_PatternSWMFile
        '
        Me.TxtBoxApplySource_PatternSWMFile.Location = New System.Drawing.Point(144, 90)
        Me.TxtBoxApplySource_PatternSWMFile.Name = "TxtBoxApplySource_PatternSWMFile"
        Me.TxtBoxApplySource_PatternSWMFile.Size = New System.Drawing.Size(295, 26)
        Me.TxtBoxApplySource_PatternSWMFile.TabIndex = 48
        '
        'LblApplyWim_Size
        '
        Me.LblApplyWim_Size.AutoSize = True
        Me.LblApplyWim_Size.Location = New System.Drawing.Point(8, 224)
        Me.LblApplyWim_Size.Name = "LblApplyWim_Size"
        Me.LblApplyWim_Size.Size = New System.Drawing.Size(44, 20)
        Me.LblApplyWim_Size.TabIndex = 47
        Me.LblApplyWim_Size.Text = "Size:"
        '
        'TxtBoxApplyWim_Size
        '
        Me.TxtBoxApplyWim_Size.Location = New System.Drawing.Point(144, 221)
        Me.TxtBoxApplyWim_Size.Name = "TxtBoxApplyWim_Size"
        Me.TxtBoxApplyWim_Size.Size = New System.Drawing.Size(295, 26)
        Me.TxtBoxApplyWim_Size.TabIndex = 46
        '
        'LblApplyWim_Description
        '
        Me.LblApplyWim_Description.AutoSize = True
        Me.LblApplyWim_Description.Location = New System.Drawing.Point(8, 189)
        Me.LblApplyWim_Description.Name = "LblApplyWim_Description"
        Me.LblApplyWim_Description.Size = New System.Drawing.Size(93, 20)
        Me.LblApplyWim_Description.TabIndex = 45
        Me.LblApplyWim_Description.Text = "Description:"
        '
        'LblApplyWim_Name
        '
        Me.LblApplyWim_Name.AutoSize = True
        Me.LblApplyWim_Name.Location = New System.Drawing.Point(8, 157)
        Me.LblApplyWim_Name.Name = "LblApplyWim_Name"
        Me.LblApplyWim_Name.Size = New System.Drawing.Size(55, 20)
        Me.LblApplyWim_Name.TabIndex = 44
        Me.LblApplyWim_Name.Text = "Name:"
        '
        'TxtBoxApplyWim_Description
        '
        Me.TxtBoxApplyWim_Description.Location = New System.Drawing.Point(144, 186)
        Me.TxtBoxApplyWim_Description.Name = "TxtBoxApplyWim_Description"
        Me.TxtBoxApplyWim_Description.Size = New System.Drawing.Size(295, 26)
        Me.TxtBoxApplyWim_Description.TabIndex = 43
        '
        'TxtBoxApplyWim_Name
        '
        Me.TxtBoxApplyWim_Name.Location = New System.Drawing.Point(144, 154)
        Me.TxtBoxApplyWim_Name.Name = "TxtBoxApplyWim_Name"
        Me.TxtBoxApplyWim_Name.Size = New System.Drawing.Size(295, 26)
        Me.TxtBoxApplyWim_Name.TabIndex = 42
        '
        'ChkBoxApplyWim_Verify
        '
        Me.ChkBoxApplyWim_Verify.AutoSize = True
        Me.ChkBoxApplyWim_Verify.Location = New System.Drawing.Point(468, 93)
        Me.ChkBoxApplyWim_Verify.Name = "ChkBoxApplyWim_Verify"
        Me.ChkBoxApplyWim_Verify.Size = New System.Drawing.Size(68, 24)
        Me.ChkBoxApplyWim_Verify.TabIndex = 41
        Me.ChkBoxApplyWim_Verify.Text = "Verify"
        Me.ChkBoxApplyWim_Verify.UseVisualStyleBackColor = True
        '
        'cmbApplyIndex
        '
        Me.cmbApplyIndex.FormattingEnabled = True
        Me.cmbApplyIndex.Location = New System.Drawing.Point(518, 154)
        Me.cmbApplyIndex.Name = "cmbApplyIndex"
        Me.cmbApplyIndex.Size = New System.Drawing.Size(63, 28)
        Me.cmbApplyIndex.TabIndex = 40
        '
        'LblApplyWim_Index
        '
        Me.LblApplyWim_Index.AutoSize = True
        Me.LblApplyWim_Index.Location = New System.Drawing.Point(465, 157)
        Me.LblApplyWim_Index.Name = "LblApplyWim_Index"
        Me.LblApplyWim_Index.Size = New System.Drawing.Size(52, 20)
        Me.LblApplyWim_Index.TabIndex = 39
        Me.LblApplyWim_Index.Text = "Index:"
        '
        'BtnApplyWim_ApplyWim
        '
        Me.BtnApplyWim_ApplyWim.Location = New System.Drawing.Point(642, 14)
        Me.BtnApplyWim_ApplyWim.Name = "BtnApplyWim_ApplyWim"
        Me.BtnApplyWim_ApplyWim.Size = New System.Drawing.Size(108, 64)
        Me.BtnApplyWim_ApplyWim.TabIndex = 37
        Me.BtnApplyWim_ApplyWim.Text = "&Apply"
        Me.BtnApplyWim_ApplyWim.UseVisualStyleBackColor = True
        '
        'LblApplyWim_Destination
        '
        Me.LblApplyWim_Destination.AutoSize = True
        Me.LblApplyWim_Destination.Location = New System.Drawing.Point(8, 49)
        Me.LblApplyWim_Destination.Name = "LblApplyWim_Destination"
        Me.LblApplyWim_Destination.Size = New System.Drawing.Size(94, 20)
        Me.LblApplyWim_Destination.TabIndex = 38
        Me.LblApplyWim_Destination.Text = "Destination:"
        '
        'LblApplyWim_Source
        '
        Me.LblApplyWim_Source.AutoSize = True
        Me.LblApplyWim_Source.Location = New System.Drawing.Point(8, 17)
        Me.LblApplyWim_Source.Name = "LblApplyWim_Source"
        Me.LblApplyWim_Source.Size = New System.Drawing.Size(64, 20)
        Me.LblApplyWim_Source.TabIndex = 35
        Me.LblApplyWim_Source.Text = "Source:"
        '
        'BtnApplyWim_BrowseDestination
        '
        Me.BtnApplyWim_BrowseDestination.Location = New System.Drawing.Point(468, 49)
        Me.BtnApplyWim_BrowseDestination.Name = "BtnApplyWim_BrowseDestination"
        Me.BtnApplyWim_BrowseDestination.Size = New System.Drawing.Size(113, 26)
        Me.BtnApplyWim_BrowseDestination.TabIndex = 36
        Me.BtnApplyWim_BrowseDestination.Text = "Browse..."
        Me.BtnApplyWim_BrowseDestination.UseVisualStyleBackColor = True
        '
        'txtApplyDest
        '
        Me.txtApplyDest.Location = New System.Drawing.Point(144, 49)
        Me.txtApplyDest.Name = "txtApplyDest"
        Me.txtApplyDest.Size = New System.Drawing.Size(295, 26)
        Me.txtApplyDest.TabIndex = 34
        '
        'txtApplySource
        '
        Me.txtApplySource.Location = New System.Drawing.Point(144, 14)
        Me.txtApplySource.Name = "txtApplySource"
        Me.txtApplySource.Size = New System.Drawing.Size(295, 26)
        Me.txtApplySource.TabIndex = 32
        '
        'BtnApplyWim_BrowseSource
        '
        Me.BtnApplyWim_BrowseSource.AutoSize = True
        Me.BtnApplyWim_BrowseSource.Location = New System.Drawing.Point(468, 14)
        Me.BtnApplyWim_BrowseSource.Name = "BtnApplyWim_BrowseSource"
        Me.BtnApplyWim_BrowseSource.Size = New System.Drawing.Size(113, 30)
        Me.BtnApplyWim_BrowseSource.TabIndex = 33
        Me.BtnApplyWim_BrowseSource.Text = "Browse..."
        Me.BtnApplyWim_BrowseSource.UseVisualStyleBackColor = True
        '
        'TabPage10
        '
        Me.TabPage10.Controls.Add(Me.ChkBoxExportImage_WimBoot)
        Me.TabPage10.Controls.Add(Me.ChkBoxExportImage_CheckIntegrity)
        Me.TabPage10.Controls.Add(Me.CmbBoxExportImage_Compression)
        Me.TabPage10.Controls.Add(Me.LblExportImage_LevelCompression)
        Me.TabPage10.Controls.Add(Me.ChkBoxExportImage_Bootable)
        Me.TabPage10.Controls.Add(Me.CmbBoxExportImage_Index)
        Me.TabPage10.Controls.Add(Me.LblExportImage_Index)
        Me.TabPage10.Controls.Add(Me.BtnExportImage_ExportImage)
        Me.TabPage10.Controls.Add(Me.BtnExportImage_BrowseDestination)
        Me.TabPage10.Controls.Add(Me.BtnExportImage_BrowseSource)
        Me.TabPage10.Controls.Add(Me.LblExportImage_Size)
        Me.TabPage10.Controls.Add(Me.TxtBoxExportImage_Size)
        Me.TabPage10.Controls.Add(Me.LblExportImage_Description)
        Me.TabPage10.Controls.Add(Me.LblExportImage_Name)
        Me.TabPage10.Controls.Add(Me.TxtBoxExportImage_Description)
        Me.TabPage10.Controls.Add(Me.TxtBoxExportImage_Name)
        Me.TabPage10.Controls.Add(Me.LblExportImage_Filename)
        Me.TabPage10.Controls.Add(Me.TxtBoxExportImage_Filename)
        Me.TabPage10.Controls.Add(Me.LblExportImage_Destination)
        Me.TabPage10.Controls.Add(Me.LblExportImage_Source)
        Me.TabPage10.Controls.Add(Me.TxtBoxExportImage_Destination)
        Me.TabPage10.Controls.Add(Me.TxtBoxExportImage_Source)
        Me.TabPage10.Location = New System.Drawing.Point(4, 29)
        Me.TabPage10.Name = "TabPage10"
        Me.TabPage10.Size = New System.Drawing.Size(886, 350)
        Me.TabPage10.TabIndex = 9
        Me.TabPage10.Text = "Export Image"
        Me.TabPage10.UseVisualStyleBackColor = True
        '
        'ChkBoxExportImage_WimBoot
        '
        Me.ChkBoxExportImage_WimBoot.AutoSize = True
        Me.ChkBoxExportImage_WimBoot.Location = New System.Drawing.Point(748, 157)
        Me.ChkBoxExportImage_WimBoot.Name = "ChkBoxExportImage_WimBoot"
        Me.ChkBoxExportImage_WimBoot.Size = New System.Drawing.Size(97, 24)
        Me.ChkBoxExportImage_WimBoot.TabIndex = 64
        Me.ChkBoxExportImage_WimBoot.Text = "/WimBoot"
        Me.ChkBoxExportImage_WimBoot.UseVisualStyleBackColor = True
        '
        'ChkBoxExportImage_CheckIntegrity
        '
        Me.ChkBoxExportImage_CheckIntegrity.AutoSize = True
        Me.ChkBoxExportImage_CheckIntegrity.Location = New System.Drawing.Point(567, 187)
        Me.ChkBoxExportImage_CheckIntegrity.Name = "ChkBoxExportImage_CheckIntegrity"
        Me.ChkBoxExportImage_CheckIntegrity.Size = New System.Drawing.Size(134, 24)
        Me.ChkBoxExportImage_CheckIntegrity.TabIndex = 63
        Me.ChkBoxExportImage_CheckIntegrity.Text = "/CheckIntegrity"
        Me.ChkBoxExportImage_CheckIntegrity.UseVisualStyleBackColor = True
        '
        'CmbBoxExportImage_Compression
        '
        Me.CmbBoxExportImage_Compression.FormattingEnabled = True
        Me.CmbBoxExportImage_Compression.Items.AddRange(New Object() {"fast", "max", "none", "recovery"})
        Me.CmbBoxExportImage_Compression.Location = New System.Drawing.Point(748, 116)
        Me.CmbBoxExportImage_Compression.Name = "CmbBoxExportImage_Compression"
        Me.CmbBoxExportImage_Compression.Size = New System.Drawing.Size(112, 28)
        Me.CmbBoxExportImage_Compression.TabIndex = 62
        '
        'LblExportImage_LevelCompression
        '
        Me.LblExportImage_LevelCompression.AutoSize = True
        Me.LblExportImage_LevelCompression.Location = New System.Drawing.Point(643, 119)
        Me.LblExportImage_LevelCompression.Name = "LblExportImage_LevelCompression"
        Me.LblExportImage_LevelCompression.Size = New System.Drawing.Size(106, 20)
        Me.LblExportImage_LevelCompression.TabIndex = 61
        Me.LblExportImage_LevelCompression.Text = "Compression:"
        '
        'ChkBoxExportImage_Bootable
        '
        Me.ChkBoxExportImage_Bootable.AutoSize = True
        Me.ChkBoxExportImage_Bootable.Location = New System.Drawing.Point(567, 157)
        Me.ChkBoxExportImage_Bootable.Name = "ChkBoxExportImage_Bootable"
        Me.ChkBoxExportImage_Bootable.Size = New System.Drawing.Size(96, 24)
        Me.ChkBoxExportImage_Bootable.TabIndex = 60
        Me.ChkBoxExportImage_Bootable.Text = "/Bootable"
        Me.ChkBoxExportImage_Bootable.UseVisualStyleBackColor = True
        '
        'CmbBoxExportImage_Index
        '
        Me.CmbBoxExportImage_Index.FormattingEnabled = True
        Me.CmbBoxExportImage_Index.Items.AddRange(New Object() {"1", "2", "3", "4", "5", "6", "7", "8", "9", "10"})
        Me.CmbBoxExportImage_Index.Location = New System.Drawing.Point(567, 116)
        Me.CmbBoxExportImage_Index.Name = "CmbBoxExportImage_Index"
        Me.CmbBoxExportImage_Index.Size = New System.Drawing.Size(50, 28)
        Me.CmbBoxExportImage_Index.TabIndex = 59
        '
        'LblExportImage_Index
        '
        Me.LblExportImage_Index.AutoSize = True
        Me.LblExportImage_Index.Location = New System.Drawing.Point(511, 119)
        Me.LblExportImage_Index.Name = "LblExportImage_Index"
        Me.LblExportImage_Index.Size = New System.Drawing.Size(52, 20)
        Me.LblExportImage_Index.TabIndex = 58
        Me.LblExportImage_Index.Text = "Index:"
        '
        'BtnExportImage_ExportImage
        '
        Me.BtnExportImage_ExportImage.Location = New System.Drawing.Point(658, 25)
        Me.BtnExportImage_ExportImage.Name = "BtnExportImage_ExportImage"
        Me.BtnExportImage_ExportImage.Size = New System.Drawing.Size(202, 62)
        Me.BtnExportImage_ExportImage.TabIndex = 57
        Me.BtnExportImage_ExportImage.Text = "Export Image"
        Me.BtnExportImage_ExportImage.UseVisualStyleBackColor = True
        '
        'BtnExportImage_BrowseDestination
        '
        Me.BtnExportImage_BrowseDestination.Location = New System.Drawing.Point(511, 64)
        Me.BtnExportImage_BrowseDestination.Name = "BtnExportImage_BrowseDestination"
        Me.BtnExportImage_BrowseDestination.Size = New System.Drawing.Size(89, 26)
        Me.BtnExportImage_BrowseDestination.TabIndex = 56
        Me.BtnExportImage_BrowseDestination.Text = "Browse..."
        Me.BtnExportImage_BrowseDestination.UseVisualStyleBackColor = True
        '
        'BtnExportImage_BrowseSource
        '
        Me.BtnExportImage_BrowseSource.Location = New System.Drawing.Point(511, 25)
        Me.BtnExportImage_BrowseSource.Name = "BtnExportImage_BrowseSource"
        Me.BtnExportImage_BrowseSource.Size = New System.Drawing.Size(92, 29)
        Me.BtnExportImage_BrowseSource.TabIndex = 55
        Me.BtnExportImage_BrowseSource.Text = "Browse..."
        Me.BtnExportImage_BrowseSource.UseVisualStyleBackColor = True
        '
        'LblExportImage_Size
        '
        Me.LblExportImage_Size.AutoSize = True
        Me.LblExportImage_Size.Location = New System.Drawing.Point(18, 216)
        Me.LblExportImage_Size.Name = "LblExportImage_Size"
        Me.LblExportImage_Size.Size = New System.Drawing.Size(44, 20)
        Me.LblExportImage_Size.TabIndex = 54
        Me.LblExportImage_Size.Text = "Size:"
        '
        'TxtBoxExportImage_Size
        '
        Me.TxtBoxExportImage_Size.Location = New System.Drawing.Point(114, 213)
        Me.TxtBoxExportImage_Size.Name = "TxtBoxExportImage_Size"
        Me.TxtBoxExportImage_Size.Size = New System.Drawing.Size(383, 26)
        Me.TxtBoxExportImage_Size.TabIndex = 49
        '
        'LblExportImage_Description
        '
        Me.LblExportImage_Description.AutoSize = True
        Me.LblExportImage_Description.Location = New System.Drawing.Point(18, 184)
        Me.LblExportImage_Description.Name = "LblExportImage_Description"
        Me.LblExportImage_Description.Size = New System.Drawing.Size(93, 20)
        Me.LblExportImage_Description.TabIndex = 53
        Me.LblExportImage_Description.Text = "Description:"
        '
        'LblExportImage_Name
        '
        Me.LblExportImage_Name.AutoSize = True
        Me.LblExportImage_Name.Location = New System.Drawing.Point(18, 152)
        Me.LblExportImage_Name.Name = "LblExportImage_Name"
        Me.LblExportImage_Name.Size = New System.Drawing.Size(55, 20)
        Me.LblExportImage_Name.TabIndex = 52
        Me.LblExportImage_Name.Text = "Name:"
        '
        'TxtBoxExportImage_Description
        '
        Me.TxtBoxExportImage_Description.Location = New System.Drawing.Point(114, 181)
        Me.TxtBoxExportImage_Description.Name = "TxtBoxExportImage_Description"
        Me.TxtBoxExportImage_Description.Size = New System.Drawing.Size(383, 26)
        Me.TxtBoxExportImage_Description.TabIndex = 51
        '
        'TxtBoxExportImage_Name
        '
        Me.TxtBoxExportImage_Name.Location = New System.Drawing.Point(114, 149)
        Me.TxtBoxExportImage_Name.Name = "TxtBoxExportImage_Name"
        Me.TxtBoxExportImage_Name.Size = New System.Drawing.Size(383, 26)
        Me.TxtBoxExportImage_Name.TabIndex = 50
        '
        'LblExportImage_Filename
        '
        Me.LblExportImage_Filename.AutoSize = True
        Me.LblExportImage_Filename.Location = New System.Drawing.Point(18, 101)
        Me.LblExportImage_Filename.Name = "LblExportImage_Filename"
        Me.LblExportImage_Filename.Size = New System.Drawing.Size(78, 20)
        Me.LblExportImage_Filename.TabIndex = 48
        Me.LblExportImage_Filename.Text = "Filename:"
        '
        'TxtBoxExportImage_Filename
        '
        Me.TxtBoxExportImage_Filename.Location = New System.Drawing.Point(114, 98)
        Me.TxtBoxExportImage_Filename.Name = "TxtBoxExportImage_Filename"
        Me.TxtBoxExportImage_Filename.Size = New System.Drawing.Size(383, 26)
        Me.TxtBoxExportImage_Filename.TabIndex = 43
        '
        'LblExportImage_Destination
        '
        Me.LblExportImage_Destination.AutoSize = True
        Me.LblExportImage_Destination.Location = New System.Drawing.Point(18, 67)
        Me.LblExportImage_Destination.Name = "LblExportImage_Destination"
        Me.LblExportImage_Destination.Size = New System.Drawing.Size(94, 20)
        Me.LblExportImage_Destination.TabIndex = 47
        Me.LblExportImage_Destination.Text = "Destination:"
        '
        'LblExportImage_Source
        '
        Me.LblExportImage_Source.AutoSize = True
        Me.LblExportImage_Source.Location = New System.Drawing.Point(18, 31)
        Me.LblExportImage_Source.Name = "LblExportImage_Source"
        Me.LblExportImage_Source.Size = New System.Drawing.Size(64, 20)
        Me.LblExportImage_Source.TabIndex = 46
        Me.LblExportImage_Source.Text = "Source:"
        '
        'TxtBoxExportImage_Destination
        '
        Me.TxtBoxExportImage_Destination.Location = New System.Drawing.Point(114, 64)
        Me.TxtBoxExportImage_Destination.Name = "TxtBoxExportImage_Destination"
        Me.TxtBoxExportImage_Destination.Size = New System.Drawing.Size(383, 26)
        Me.TxtBoxExportImage_Destination.TabIndex = 45
        '
        'TxtBoxExportImage_Source
        '
        Me.TxtBoxExportImage_Source.Location = New System.Drawing.Point(114, 28)
        Me.TxtBoxExportImage_Source.Name = "TxtBoxExportImage_Source"
        Me.TxtBoxExportImage_Source.Size = New System.Drawing.Size(383, 26)
        Me.TxtBoxExportImage_Source.TabIndex = 44
        '
        'TabPage11
        '
        Me.TabPage11.Controls.Add(Me.BtnLangAndInterServicing_GetMountedImageInfo)
        Me.TabPage11.Controls.Add(Me.BtnLangAndInterServicing_RefreshMountedImage)
        Me.TabPage11.Controls.Add(Me.LblLangAndInterServicing_UseMountedImage)
        Me.TabPage11.Controls.Add(Me.CmbBoxLangAndInterServ_UseImageMounted)
        Me.TabPage11.Controls.Add(Me.TxtBoxLangAndInterServ_Distribution)
        Me.TabPage11.Controls.Add(Me.TxtBoxLangAndInterServ_DistributionSetupUILang)
        Me.TabPage11.Controls.Add(Me.LblLangAndInterServ_SetupUILangDistribution)
        Me.TabPage11.Controls.Add(Me.TxtBoxLangAndInterServ_PathDistribution)
        Me.TabPage11.Controls.Add(Me.BtnLangAndInterServ_LayeredDriver)
        Me.TabPage11.Controls.Add(Me.CmbBoxLangAndInterServ_SetLayeredDriver)
        Me.TabPage11.Controls.Add(Me.LblLangAndInterServ_SetLayeredDriver)
        Me.TabPage11.Controls.Add(Me.ChkBoxLangAndInterServ_Online)
        Me.TabPage11.Controls.Add(Me.BtnLangAndInterServ_ApplyDistribution)
        Me.TabPage11.Controls.Add(Me.BtnLangAndInterServ_ApplySetupUILang)
        Me.TabPage11.Controls.Add(Me.BtnLangAndInterServ_ApplyGenLangINI)
        Me.TabPage11.Controls.Add(Me.BtnLangAndInterServ_ApplySKUIntlDefaults)
        Me.TabPage11.Controls.Add(Me.LblLangAndInterServ_Distribution)
        Me.TabPage11.Controls.Add(Me.CmbBoxLangAndInterServ_SetSetupUILang)
        Me.TabPage11.Controls.Add(Me.LblLangAndInterServ_SetupUILang)
        Me.TabPage11.Controls.Add(Me.Button9)
        Me.TabPage11.Controls.Add(Me.LblLangAndInterServ_GenLanINI)
        Me.TabPage11.Controls.Add(Me.CmbBoxLangAndInterServ_SetSKUIntlDefaults)
        Me.TabPage11.Controls.Add(Me.Button8)
        Me.TabPage11.Controls.Add(Me.LblLangAndInterServ_SetSKUIntlDefaults)
        Me.TabPage11.Controls.Add(Me.CmbBoxLangAndInterServ_SetTimeZone)
        Me.TabPage11.Controls.Add(Me.BtnLangAndInterServ_ApplyTimeZone)
        Me.TabPage11.Controls.Add(Me.LblLangAndInterServ_SetTimeZone)
        Me.TabPage11.Controls.Add(Me.CmbBoxLangAndInterServ_SetInputLocal)
        Me.TabPage11.Controls.Add(Me.BtnLangAndInterServ_ApplyInputLocale)
        Me.TabPage11.Controls.Add(Me.LblLangAndInterServ_SetInputLocale)
        Me.TabPage11.Controls.Add(Me.CmbBoxLangAndInterServ_SetUserLocale)
        Me.TabPage11.Controls.Add(Me.BtnLangAndInterServ_ApplyUserLocale)
        Me.TabPage11.Controls.Add(Me.LblLangAndInterServ_SetUserLocale)
        Me.TabPage11.Controls.Add(Me.CmbBoxLangAndInterServ_SetUILang_SysLocale)
        Me.TabPage11.Controls.Add(Me.BtnLangAndInterServ_ApplySysLocale)
        Me.TabPage11.Controls.Add(Me.LblLangAndInterServ_SetSysLocale)
        Me.TabPage11.Controls.Add(Me.CmbBoxLangAndInterServ_SetSysUILang)
        Me.TabPage11.Controls.Add(Me.BtnLangAndInterServ_ApplySysUILang)
        Me.TabPage11.Controls.Add(Me.LblLangAndInterServ_SetSysUILang)
        Me.TabPage11.Controls.Add(Me.CmbBoxLangAndInterServ_SetUILangFallback)
        Me.TabPage11.Controls.Add(Me.BtnLangAndInterServ_ApplyUILangFallback)
        Me.TabPage11.Controls.Add(Me.LblLangAndInterServ_SetUILangFallback)
        Me.TabPage11.Controls.Add(Me.CmbBoxLangAndInterServ_SetUILang)
        Me.TabPage11.Controls.Add(Me.BtnLangAndInterServ_ApplyUILang)
        Me.TabPage11.Controls.Add(Me.LblLangAndInterServ_SetUILang)
        Me.TabPage11.Controls.Add(Me.CmbBoxLangAndInterServ_SetAllIntl)
        Me.TabPage11.Controls.Add(Me.BtnLangAndInterServ_ApplyAllIntl)
        Me.TabPage11.Controls.Add(Me.LblLangAndInterServ_SetAllIntl)
        Me.TabPage11.Controls.Add(Me.BtnLangAndInterServicing_DisplayInfo)
        Me.TabPage11.Controls.Add(Me.Label25)
        Me.TabPage11.Location = New System.Drawing.Point(4, 29)
        Me.TabPage11.Name = "TabPage11"
        Me.TabPage11.Size = New System.Drawing.Size(886, 350)
        Me.TabPage11.TabIndex = 10
        Me.TabPage11.Text = "Languages And International Servicing"
        Me.TabPage11.UseVisualStyleBackColor = True
        '
        'BtnLangAndInterServicing_GetMountedImageInfo
        '
        Me.BtnLangAndInterServicing_GetMountedImageInfo.Location = New System.Drawing.Point(713, 12)
        Me.BtnLangAndInterServicing_GetMountedImageInfo.Name = "BtnLangAndInterServicing_GetMountedImageInfo"
        Me.BtnLangAndInterServicing_GetMountedImageInfo.Size = New System.Drawing.Size(158, 64)
        Me.BtnLangAndInterServicing_GetMountedImageInfo.TabIndex = 59
        Me.BtnLangAndInterServicing_GetMountedImageInfo.Text = "Get Mounted Image Info"
        Me.BtnLangAndInterServicing_GetMountedImageInfo.UseVisualStyleBackColor = True
        '
        'BtnLangAndInterServicing_RefreshMountedImage
        '
        Me.BtnLangAndInterServicing_RefreshMountedImage.Location = New System.Drawing.Point(237, 3)
        Me.BtnLangAndInterServicing_RefreshMountedImage.Name = "BtnLangAndInterServicing_RefreshMountedImage"
        Me.BtnLangAndInterServicing_RefreshMountedImage.Size = New System.Drawing.Size(221, 32)
        Me.BtnLangAndInterServicing_RefreshMountedImage.TabIndex = 58
        Me.BtnLangAndInterServicing_RefreshMountedImage.Text = "Refresh mounted image"
        Me.BtnLangAndInterServicing_RefreshMountedImage.UseVisualStyleBackColor = True
        '
        'LblLangAndInterServicing_UseMountedImage
        '
        Me.LblLangAndInterServicing_UseMountedImage.AutoSize = True
        Me.LblLangAndInterServicing_UseMountedImage.Location = New System.Drawing.Point(7, 44)
        Me.LblLangAndInterServicing_UseMountedImage.Name = "LblLangAndInterServicing_UseMountedImage"
        Me.LblLangAndInterServicing_UseMountedImage.Size = New System.Drawing.Size(158, 20)
        Me.LblLangAndInterServicing_UseMountedImage.TabIndex = 57
        Me.LblLangAndInterServicing_UseMountedImage.Text = "Use Image Mounted:"
        '
        'CmbBoxLangAndInterServ_UseImageMounted
        '
        Me.CmbBoxLangAndInterServ_UseImageMounted.FormattingEnabled = True
        Me.CmbBoxLangAndInterServ_UseImageMounted.Location = New System.Drawing.Point(179, 41)
        Me.CmbBoxLangAndInterServ_UseImageMounted.Name = "CmbBoxLangAndInterServ_UseImageMounted"
        Me.CmbBoxLangAndInterServ_UseImageMounted.Size = New System.Drawing.Size(349, 28)
        Me.CmbBoxLangAndInterServ_UseImageMounted.TabIndex = 56
        '
        'TxtBoxLangAndInterServ_Distribution
        '
        Me.TxtBoxLangAndInterServ_Distribution.Location = New System.Drawing.Point(595, 285)
        Me.TxtBoxLangAndInterServ_Distribution.Name = "TxtBoxLangAndInterServ_Distribution"
        Me.TxtBoxLangAndInterServ_Distribution.Size = New System.Drawing.Size(190, 26)
        Me.TxtBoxLangAndInterServ_Distribution.TabIndex = 55
        '
        'TxtBoxLangAndInterServ_DistributionSetupUILang
        '
        Me.TxtBoxLangAndInterServ_DistributionSetupUILang.Location = New System.Drawing.Point(595, 254)
        Me.TxtBoxLangAndInterServ_DistributionSetupUILang.Name = "TxtBoxLangAndInterServ_DistributionSetupUILang"
        Me.TxtBoxLangAndInterServ_DistributionSetupUILang.Size = New System.Drawing.Size(190, 26)
        Me.TxtBoxLangAndInterServ_DistributionSetupUILang.TabIndex = 52
        '
        'LblLangAndInterServ_SetupUILangDistribution
        '
        Me.LblLangAndInterServ_SetupUILangDistribution.AutoSize = True
        Me.LblLangAndInterServ_SetupUILangDistribution.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblLangAndInterServ_SetupUILangDistribution.Location = New System.Drawing.Point(428, 255)
        Me.LblLangAndInterServ_SetupUILangDistribution.Name = "LblLangAndInterServ_SetupUILangDistribution"
        Me.LblLangAndInterServ_SetupUILangDistribution.Size = New System.Drawing.Size(161, 20)
        Me.LblLangAndInterServ_SetupUILangDistribution.TabIndex = 51
        Me.LblLangAndInterServ_SetupUILangDistribution.Text = "Windows Distribution:"
        '
        'TxtBoxLangAndInterServ_PathDistribution
        '
        Me.TxtBoxLangAndInterServ_PathDistribution.Location = New System.Drawing.Point(595, 187)
        Me.TxtBoxLangAndInterServ_PathDistribution.Name = "TxtBoxLangAndInterServ_PathDistribution"
        Me.TxtBoxLangAndInterServ_PathDistribution.Size = New System.Drawing.Size(190, 26)
        Me.TxtBoxLangAndInterServ_PathDistribution.TabIndex = 50
        '
        'BtnLangAndInterServ_LayeredDriver
        '
        Me.BtnLangAndInterServ_LayeredDriver.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnLangAndInterServ_LayeredDriver.Location = New System.Drawing.Point(698, 151)
        Me.BtnLangAndInterServ_LayeredDriver.Name = "BtnLangAndInterServ_LayeredDriver"
        Me.BtnLangAndInterServ_LayeredDriver.Size = New System.Drawing.Size(56, 28)
        Me.BtnLangAndInterServ_LayeredDriver.TabIndex = 49
        Me.BtnLangAndInterServ_LayeredDriver.Text = "Apply"
        Me.BtnLangAndInterServ_LayeredDriver.UseVisualStyleBackColor = True
        '
        'CmbBoxLangAndInterServ_SetLayeredDriver
        '
        Me.CmbBoxLangAndInterServ_SetLayeredDriver.AutoCompleteCustomSource.AddRange(New String() {"bg-bg", "cs-cz", "da-dk", "de-de", "el-gr", "en-gb", "en-us", "es-es", "es-mx", "et-ee", "fi-fi", "fr-ca", "fr-fr", "hr-hr", "hu-hu", "it-it", "ja-jp", "ko-kr", "lt-lt", "lv-lv", "nb-no", "nl-nl", "pl-pl", "pt-br", "pt-pt", "ro-ro", "ru-ru", "sk-sk", "sl-si", "sr-latn-rs", "sv-se", "tr-tr", "uk-ua", "zh-cn", "zh-tw"})
        Me.CmbBoxLangAndInterServ_SetLayeredDriver.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CmbBoxLangAndInterServ_SetLayeredDriver.FormattingEnabled = True
        Me.CmbBoxLangAndInterServ_SetLayeredDriver.Items.AddRange(New Object() {"1", "2", "3", "4", "5", "6"})
        Me.CmbBoxLangAndInterServ_SetLayeredDriver.Location = New System.Drawing.Point(595, 152)
        Me.CmbBoxLangAndInterServ_SetLayeredDriver.Name = "CmbBoxLangAndInterServ_SetLayeredDriver"
        Me.CmbBoxLangAndInterServ_SetLayeredDriver.Size = New System.Drawing.Size(97, 28)
        Me.CmbBoxLangAndInterServ_SetLayeredDriver.TabIndex = 48
        '
        'LblLangAndInterServ_SetLayeredDriver
        '
        Me.LblLangAndInterServ_SetLayeredDriver.AutoSize = True
        Me.LblLangAndInterServ_SetLayeredDriver.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblLangAndInterServ_SetLayeredDriver.Location = New System.Drawing.Point(444, 155)
        Me.LblLangAndInterServ_SetLayeredDriver.Name = "LblLangAndInterServ_SetLayeredDriver"
        Me.LblLangAndInterServ_SetLayeredDriver.Size = New System.Drawing.Size(145, 20)
        Me.LblLangAndInterServ_SetLayeredDriver.TabIndex = 47
        Me.LblLangAndInterServ_SetLayeredDriver.Text = "/Set-LayeredDriver:"
        '
        'ChkBoxLangAndInterServ_Online
        '
        Me.ChkBoxLangAndInterServ_Online.AutoSize = True
        Me.ChkBoxLangAndInterServ_Online.Location = New System.Drawing.Point(758, 323)
        Me.ChkBoxLangAndInterServ_Online.Name = "ChkBoxLangAndInterServ_Online"
        Me.ChkBoxLangAndInterServ_Online.Size = New System.Drawing.Size(125, 24)
        Me.ChkBoxLangAndInterServ_Online.TabIndex = 46
        Me.ChkBoxLangAndInterServ_Online.Text = "/Online option"
        Me.ChkBoxLangAndInterServ_Online.UseVisualStyleBackColor = False
        '
        'BtnLangAndInterServ_ApplyDistribution
        '
        Me.BtnLangAndInterServ_ApplyDistribution.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnLangAndInterServ_ApplyDistribution.Location = New System.Drawing.Point(791, 285)
        Me.BtnLangAndInterServ_ApplyDistribution.Name = "BtnLangAndInterServ_ApplyDistribution"
        Me.BtnLangAndInterServ_ApplyDistribution.Size = New System.Drawing.Size(56, 28)
        Me.BtnLangAndInterServ_ApplyDistribution.TabIndex = 45
        Me.BtnLangAndInterServ_ApplyDistribution.Text = "Apply"
        Me.BtnLangAndInterServ_ApplyDistribution.UseVisualStyleBackColor = True
        '
        'BtnLangAndInterServ_ApplySetupUILang
        '
        Me.BtnLangAndInterServ_ApplySetupUILang.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnLangAndInterServ_ApplySetupUILang.Location = New System.Drawing.Point(791, 219)
        Me.BtnLangAndInterServ_ApplySetupUILang.Name = "BtnLangAndInterServ_ApplySetupUILang"
        Me.BtnLangAndInterServ_ApplySetupUILang.Size = New System.Drawing.Size(56, 28)
        Me.BtnLangAndInterServ_ApplySetupUILang.TabIndex = 44
        Me.BtnLangAndInterServ_ApplySetupUILang.Text = "Apply"
        Me.BtnLangAndInterServ_ApplySetupUILang.UseVisualStyleBackColor = True
        '
        'BtnLangAndInterServ_ApplyGenLangINI
        '
        Me.BtnLangAndInterServ_ApplyGenLangINI.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnLangAndInterServ_ApplyGenLangINI.Location = New System.Drawing.Point(791, 185)
        Me.BtnLangAndInterServ_ApplyGenLangINI.Name = "BtnLangAndInterServ_ApplyGenLangINI"
        Me.BtnLangAndInterServ_ApplyGenLangINI.Size = New System.Drawing.Size(56, 28)
        Me.BtnLangAndInterServ_ApplyGenLangINI.TabIndex = 43
        Me.BtnLangAndInterServ_ApplyGenLangINI.Text = "Apply"
        Me.BtnLangAndInterServ_ApplyGenLangINI.UseVisualStyleBackColor = True
        '
        'BtnLangAndInterServ_ApplySKUIntlDefaults
        '
        Me.BtnLangAndInterServ_ApplySKUIntlDefaults.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnLangAndInterServ_ApplySKUIntlDefaults.Location = New System.Drawing.Point(698, 117)
        Me.BtnLangAndInterServ_ApplySKUIntlDefaults.Name = "BtnLangAndInterServ_ApplySKUIntlDefaults"
        Me.BtnLangAndInterServ_ApplySKUIntlDefaults.Size = New System.Drawing.Size(56, 28)
        Me.BtnLangAndInterServ_ApplySKUIntlDefaults.TabIndex = 42
        Me.BtnLangAndInterServ_ApplySKUIntlDefaults.Text = "Apply"
        Me.BtnLangAndInterServ_ApplySKUIntlDefaults.UseVisualStyleBackColor = True
        '
        'LblLangAndInterServ_Distribution
        '
        Me.LblLangAndInterServ_Distribution.AutoSize = True
        Me.LblLangAndInterServ_Distribution.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblLangAndInterServ_Distribution.Location = New System.Drawing.Point(490, 287)
        Me.LblLangAndInterServ_Distribution.Name = "LblLangAndInterServ_Distribution"
        Me.LblLangAndInterServ_Distribution.Size = New System.Drawing.Size(97, 20)
        Me.LblLangAndInterServ_Distribution.TabIndex = 40
        Me.LblLangAndInterServ_Distribution.Text = "/Distribution:"
        '
        'CmbBoxLangAndInterServ_SetSetupUILang
        '
        Me.CmbBoxLangAndInterServ_SetSetupUILang.AutoCompleteCustomSource.AddRange(New String() {"bg-bg", "cs-cz", "da-dk", "de-de", "el-gr", "en-gb", "en-us", "es-es", "es-mx", "et-ee", "fi-fi", "fr-ca", "fr-fr", "hr-hr", "hu-hu", "it-it", "ja-jp", "ko-kr", "lt-lt", "lv-lv", "nb-no", "nl-nl", "pl-pl", "pt-br", "pt-pt", "ro-ro", "ru-ru", "sk-sk", "sl-si", "sr-latn-rs", "sv-se", "tr-tr", "uk-ua", "zh-cn", "zh-tw"})
        Me.CmbBoxLangAndInterServ_SetSetupUILang.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CmbBoxLangAndInterServ_SetSetupUILang.FormattingEnabled = True
        Me.CmbBoxLangAndInterServ_SetSetupUILang.Items.AddRange(New Object() {"bg-bg", "cs-cz", "da-dk", "de-de", "el-gr", "en-gb", "en-us", "es-es", "es-mx", "et-ee", "fi-fi", "fr-ca", "fr-fr", "hr-hr", "hu-hu", "it-it", "ja-jp", "ko-kr", "lt-lt", "lv-lv", "nb-no", "nl-nl", "pl-pl", "pt-br", "pt-pt", "ro-ro", "ru-ru", "sk-sk", "sl-si", "sr-latn-rs", "sv-se", "tr-tr", "uk-ua", "zh-cn", "zh-tw"})
        Me.CmbBoxLangAndInterServ_SetSetupUILang.Location = New System.Drawing.Point(595, 219)
        Me.CmbBoxLangAndInterServ_SetSetupUILang.Name = "CmbBoxLangAndInterServ_SetSetupUILang"
        Me.CmbBoxLangAndInterServ_SetSetupUILang.Size = New System.Drawing.Size(190, 28)
        Me.CmbBoxLangAndInterServ_SetSetupUILang.TabIndex = 39
        '
        'LblLangAndInterServ_SetupUILang
        '
        Me.LblLangAndInterServ_SetupUILang.AutoSize = True
        Me.LblLangAndInterServ_SetupUILang.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblLangAndInterServ_SetupUILang.Location = New System.Drawing.Point(444, 222)
        Me.LblLangAndInterServ_SetupUILang.Name = "LblLangAndInterServ_SetupUILang"
        Me.LblLangAndInterServ_SetupUILang.Size = New System.Drawing.Size(143, 20)
        Me.LblLangAndInterServ_SetupUILang.TabIndex = 38
        Me.LblLangAndInterServ_SetupUILang.Text = "/Set-SetupUILang:"
        '
        'Button9
        '
        Me.Button9.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button9.Location = New System.Drawing.Point(895, 99)
        Me.Button9.Name = "Button9"
        Me.Button9.Size = New System.Drawing.Size(97, 28)
        Me.Button9.TabIndex = 36
        Me.Button9.Text = "Apply"
        Me.Button9.UseVisualStyleBackColor = True
        '
        'LblLangAndInterServ_GenLanINI
        '
        Me.LblLangAndInterServ_GenLanINI.AutoSize = True
        Me.LblLangAndInterServ_GenLanINI.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblLangAndInterServ_GenLanINI.Location = New System.Drawing.Point(479, 193)
        Me.LblLangAndInterServ_GenLanINI.Name = "LblLangAndInterServ_GenLanINI"
        Me.LblLangAndInterServ_GenLanINI.Size = New System.Drawing.Size(110, 20)
        Me.LblLangAndInterServ_GenLanINI.TabIndex = 35
        Me.LblLangAndInterServ_GenLanINI.Text = "/Gen-LangINI:"
        '
        'CmbBoxLangAndInterServ_SetSKUIntlDefaults
        '
        Me.CmbBoxLangAndInterServ_SetSKUIntlDefaults.AutoCompleteCustomSource.AddRange(New String() {"bg-bg", "cs-cz", "da-dk", "de-de", "el-gr", "en-gb", "en-us", "es-es", "es-mx", "et-ee", "fi-fi", "fr-ca", "fr-fr", "hr-hr", "hu-hu", "it-it", "ja-jp", "ko-kr", "lt-lt", "lv-lv", "nb-no", "nl-nl", "pl-pl", "pt-br", "pt-pt", "ro-ro", "ru-ru", "sk-sk", "sl-si", "sr-latn-rs", "sv-se", "tr-tr", "uk-ua", "zh-cn", "zh-tw"})
        Me.CmbBoxLangAndInterServ_SetSKUIntlDefaults.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CmbBoxLangAndInterServ_SetSKUIntlDefaults.FormattingEnabled = True
        Me.CmbBoxLangAndInterServ_SetSKUIntlDefaults.Items.AddRange(New Object() {"bg-bg", "cs-cz", "da-dk", "de-de", "el-gr", "en-gb", "en-us", "es-es", "es-mx", "et-ee", "fi-fi", "fr-ca", "fr-fr", "hr-hr", "hu-hu", "it-it", "ja-jp", "ko-kr", "lt-lt", "lv-lv", "nb-no", "nl-nl", "pl-pl", "pt-br", "pt-pt", "ro-ro", "ru-ru", "sk-sk", "sl-si", "sr-latn-rs", "sv-se", "tr-tr", "uk-ua", "zh-cn", "zh-tw"})
        Me.CmbBoxLangAndInterServ_SetSKUIntlDefaults.Location = New System.Drawing.Point(595, 118)
        Me.CmbBoxLangAndInterServ_SetSKUIntlDefaults.Name = "CmbBoxLangAndInterServ_SetSKUIntlDefaults"
        Me.CmbBoxLangAndInterServ_SetSKUIntlDefaults.Size = New System.Drawing.Size(97, 28)
        Me.CmbBoxLangAndInterServ_SetSKUIntlDefaults.TabIndex = 34
        '
        'Button8
        '
        Me.Button8.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button8.Location = New System.Drawing.Point(895, 65)
        Me.Button8.Name = "Button8"
        Me.Button8.Size = New System.Drawing.Size(97, 28)
        Me.Button8.TabIndex = 33
        Me.Button8.Text = "Apply"
        Me.Button8.UseVisualStyleBackColor = True
        '
        'LblLangAndInterServ_SetSKUIntlDefaults
        '
        Me.LblLangAndInterServ_SetSKUIntlDefaults.AutoSize = True
        Me.LblLangAndInterServ_SetSKUIntlDefaults.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblLangAndInterServ_SetSKUIntlDefaults.Location = New System.Drawing.Point(431, 121)
        Me.LblLangAndInterServ_SetSKUIntlDefaults.Name = "LblLangAndInterServ_SetSKUIntlDefaults"
        Me.LblLangAndInterServ_SetSKUIntlDefaults.Size = New System.Drawing.Size(162, 20)
        Me.LblLangAndInterServ_SetSKUIntlDefaults.TabIndex = 32
        Me.LblLangAndInterServ_SetSKUIntlDefaults.Text = "/Set-SKUIntlDefaults:"
        '
        'CmbBoxLangAndInterServ_SetTimeZone
        '
        Me.CmbBoxLangAndInterServ_SetTimeZone.AutoCompleteCustomSource.AddRange(New String() {"bg-bg", "cs-cz", "da-dk", "de-de", "el-gr", "en-gb", "en-us", "es-es", "es-mx", "et-ee", "fi-fi", "fr-ca", "fr-fr", "hr-hr", "hu-hu", "it-it", "ja-jp", "ko-kr", "lt-lt", "lv-lv", "nb-no", "nl-nl", "pl-pl", "pt-br", "pt-pt", "ro-ro", "ru-ru", "sk-sk", "sl-si", "sr-latn-rs", "sv-se", "tr-tr", "uk-ua", "zh-cn", "zh-tw"})
        Me.CmbBoxLangAndInterServ_SetTimeZone.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CmbBoxLangAndInterServ_SetTimeZone.FormattingEnabled = True
        Me.CmbBoxLangAndInterServ_SetTimeZone.Items.AddRange(New Object() {"(UTC-12:00) Ligne de date internationale (Ouest) Dateline Standard Time", "(UTC-11:00) Temps universel coordonn‚-11 UTC-11", "(UTC-10:00) Hawaii Hawaiian Standard Time", "(UTC-10:00) ×les Al‚outiennes Aleutian Standard Time", "(UTC-09:30) ×les Marquises Marquesas Standard Time", "(UTC-09:00) Alaska Alaskan Standard Time", "(UTC-09:00) Temps universel coordonn‚-09 UTC-09", "(UTC-08:00) Basse Californie Pacific Standard Time (Mexico)", "(UTC-08:00) Pacifique (.-U. et Canada) Pacific Standard Time", "(UTC-08:00) Temps universel coordonn‚-08 UTC-08", "(UTC-07:00) Arizona US Mountain Standard Time", "(UTC-07:00) Chihuahua, La Paz, Mazatlan Mountain Standard Time (Mexico)", "(UTC-07:00) Montagnes Rocheuses (.-U. et Canada) Mountain Standard Time", "(UTC-07:00) Yukon Yukon Standard Time", "(UTC-06:00) Am‚rique centrale Central America Standard Time", "(UTC-06:00) Centre (.-U. et Canada) Central Standard Time", "(UTC-06:00) Guadalajara, Mexico, Monterrey Central Standard Time (Mexico)", "(UTC-06:00) ×le de Pƒques Easter Island Standard Time", "(UTC-06:00) Saskatchewan Canada Central Standard Time", "(UTC-05:00) Bogota, Lima, Quito, Rio Branco SA Pacific Standard Time", "(UTC-05:00) Chetumal Eastern Standard Time (Mexico)", "(UTC-05:00) Est (.-U. et Canada) Eastern Standard Time", "(UTC-05:00) Ha‹ti Haiti Standard Time", "(UTC-05:00) Havane (La) Cuba Standard Time", "(UTC-05:00) ×les Turques-et-Ca‹ques Turks And Caicos Standard Time", "(UTC-05:00) Indiana (Est) US Eastern Standard Time", "(UTC-04:00) Asunci¢n Paraguay Standard Time", "(UTC-04:00) Caracas Venezuela Standard Time", "(UTC-04:00) Cuiaba Central Brazilian Standard Time", "(UTC-04:00) Georgetown, La Paz, Manaus, San Juan SA Western Standard Time", "(UTC-04:00) Heure Atlantique (Canada) Atlantic Standard Time", "(UTC-04:00) Santiago Pacific SA Standard Time", "(UTC-03:30) Terre-Neuve-et-Labrador Newfoundland Standard Time", "(UTC-03:00) Aragua¡na Tocantins Standard Time", "(UTC-03:00) Brasilia E. South America Standard Time", "(UTC-03:00) Buenos Aires Argentina Standard Time", "(UTC-03:00) Cayenne, Fortaleza SA Eastern Standard Time", "(UTC-03:00) Groenland Greenland Standard Time", "(UTC-03:00) Montevideo Montevideo Standard Time", "(UTC-03:00) Punta Arenas Magallanes Standard Time", "(UTC-03:00) Saint-Pierre-et-Miquelon Saint Pierre Standard Time", "(UTC-03:00) Salvador Bahia Standard Time", "(UTC-02:00) Temps universel coordonn‚-02 UTC-02", "(UTC-01:00) ×les de Cabo Verde Cape Verde Standard Time", "(UTC-01:00) Les A‡ores Azores Standard Time", "(UTC) Temps universel coordonn‚ UTC", "(UTC+00:00) Dublin, dimbourg, Lisbonne, Londres GMT Standard Time", "(UTC+00:00) Monrovia, Reykjavik Greenwich Standard Time", "(UTC+00:00) SÆo Tom‚ Sao Tome Standard Time", "(UTC+01:00) Casablanca Morocco Standard Time", "(UTC+01:00) Afrique centrale - Ouest W. Central Africa Standard Time", "(UTC+01:00) Amsterdam, Berlin, Berne, Rome, Stockholm, Vienne W. Europe Standard " &
                "Time", "(UTC+01:00) Belgrade, Bratislava, Budapest, Ljubljana, Prague Central Europe Stan" &
                "dard Time", "(UTC+01:00) Bruxelles, Copenhague, Madrid, Paris Romance Standard Time", "(UTC+01:00) Sarajevo, Skopje, Varsovie, Zagreb Central European Standard Time", "(UTC+02:00) Amman Jordan Standard Time", "(UTC+02:00) AthŠnes, Bucarest GTB Standard Time", "(UTC+02:00) Beyrouth Middle East Standard Time", "(UTC+02:00) Chisinau E. Europe Standard Time", "(UTC+02:00) Damas Syria Standard Time", "(UTC+02:00) Gaza, H‚bron West Bank Standard Time", "(UTC+02:00) Harare, Pretoria South Africa Standard Time", "(UTC+02:00) Helsinki, Kiev, Riga, Sofia, Tallinn, Vilnius FLE Standard Time", "(UTC+02:00) J‚rusalem Israel Standard Time", "(UTC+02:00) Juba South Sudan Standard Time", "(UTC+02:00) Kaliningrad Kaliningrad Standard Time", "(UTC+02:00) Khartoum Sudan Standard Time", "(UTC+02:00) Le Caire Egypt Standard Time", "(UTC+02:00) Tripoli Libya Standard Time", "(UTC+02:00) Windhoek Namibia Standard Time", "(UTC+03:00) Bagdad Arabic Standard Time", "(UTC+03:00) Istanbul Turkey Standard Time", "(UTC+03:00) Kowe‹t, Riyad Arab Standard Time", "(UTC+03:00) Minsk Belarus Standard Time", "(UTC+03:00) Moscou, Saint-P‚tersbourg Russian Standard Time", "(UTC+03:00) Nairobi E. Africa Standard Time", "(UTC+03:00) Volgograd Volgograd Standard Time", "(UTC+03:30) T‚h‚ran Iran Standard Time", "(UTC+04:00) Abu Dhabi, Muscat Arabian Standard Time", "(UTC+04:00) Astrakhan, Oulianovsk Astrakhan Standard Time", "(UTC+04:00) Bakou Azerbaijan Standard Time", "(UTC+04:00) Erevan Caucasus Standard Time", "(UTC+04:00) Izhevsk, Samara Russia Time Zone 3", "(UTC+04:00) Port Louis Mauritius Standard Time", "(UTC+04:00) Saratov Saratov Standard Time", "(UTC+04:00) Tbilissi Georgian Standard Time", "(UTC+04:30) Kaboul Afghanistan Standard Time", "(UTC+05:00) Achgabat, Tachkent West Asia Standard Time", "(UTC+05:00) Iekaterinbourg Ekaterinburg Standard Time", "(UTC+05:00) Islamabad, Karachi Pakistan Standard Time", "(UTC+05:00) Kyzylorda Qyzylorda Standard Time", "(UTC+05:30) Chennai, Kolkata, Mumbai, New Delhi India Standard Time", "(UTC+05:30) Sri Jayawardenepura Sri Lanka Standard Time", "(UTC+05:45) Katmandou Nepal Standard Time", "(UTC+06:00) Astana Central Asia Standard Time", "(UTC+06:00) Dhaka Bangladesh Standard Time", "(UTC+06:00) Omsk Omsk Standard Time", "(UTC+06:30) Rangoon Myanmar Standard Time", "(UTC+07:00) Bangkok, Hanoi, Djakarta SE Asia Standard Time", "(UTC+07:00) Barnaoul, Gorno-Alta‹sk Altai Standard Time", "(UTC+07:00) Hovd W. Mongolia Standard Time", "(UTC+07:00) Krasno‹arsk North Asia Standard Time", "(UTC+07:00) Novossibirsk N. Central Asia Standard Time", "(UTC+07:00) Tomsk Tomsk Standard Time", "(UTC+08:00) Beijing, Chongqing, Hong Kong (R.A.S.), Urumqi China Standard Time", "(UTC+08:00) Irkoutsk North Asia East Standard Time", "(UTC+08:00) Kuala Lumpur, Singapour Singapore Standard Time", "(UTC+08:00) Oulan-Bator Ulaanbaatar Standard Time", "(UTC+08:00) Perth W. Australia Standard Time", "(UTC+08:00) Taipei Taipei Standard Time", "(UTC+08:45) Eucla Aus Central W. Standard Time", "(UTC+09:00) Chita Transbaikal Standard Time", "(UTC+09:00) Iakoutsk Yakutsk Standard Time", "(UTC+09:00) Osaka, Sapporo, Tokyo Tokyo Standard Time", "(UTC+09:00) Pyongyang North Korea Standard Time", "(UTC+09:00) S‚oul Korea Standard Time", "(UTC+09:30) Ad‚la‹de Cen. Australia Standard Time", "(UTC+09:30) Darwin AUS Central Standard Time", "(UTC+10:00) Brisbane E. Australia Standard Time", "(UTC+10:00) Canberra, Melbourne, Sydney AUS Eastern Standard Time", "(UTC+10:00) Guam, Port Moresby West Pacific Standard Time", "(UTC+10:00) Hobart Tasmania Standard Time", "(UTC+10:00) Vladivostok Vladivostok Standard Time", "(UTC+10:30) ×le Lord Howe Lord Howe Standard Time", "(UTC+11:00) Chokurdakh Russia Time Zone 10", "(UTC+11:00) ×le Bougainville Bougainville Standard Time", "(UTC+11:00) ×le Norfolk Norfolk Standard Time", "(UTC+11:00) ×les Salomon, Nouvelle-Cal‚donie Central Pacific Standard Time", "(UTC+11:00) Magadan Magadan Standard Time", "(UTC+11:00) Sakhaline Sakhalin Standard Time", "(UTC+12:00) Anadyr, Petropavlovsk-Kamtchatski Russia Time Zone 11", "(UTC+12:00) Auckland, Wellington New Zealand Standard Time", "(UTC+12:00) Fidji Fiji Standard Time", "(UTC+12:00) Temps universel coordonn‚+12 UTC+12", "(UTC+12:45) ×les Chatham Chatham Islands Standard Time", "(UTC+13:00) Nuku'alofa Tonga Standard Time", "(UTC+13:00) Samoa Samoa Standard Time", "(UTC+13:00) Temps universel coordonn‚+13 UTC+13", "(UTC+14:00) Kiritimati, ×le Line Islands Standard Time"})
        Me.CmbBoxLangAndInterServ_SetTimeZone.Location = New System.Drawing.Point(160, 319)
        Me.CmbBoxLangAndInterServ_SetTimeZone.Name = "CmbBoxLangAndInterServ_SetTimeZone"
        Me.CmbBoxLangAndInterServ_SetTimeZone.Size = New System.Drawing.Size(503, 28)
        Me.CmbBoxLangAndInterServ_SetTimeZone.TabIndex = 31
        '
        'BtnLangAndInterServ_ApplyTimeZone
        '
        Me.BtnLangAndInterServ_ApplyTimeZone.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnLangAndInterServ_ApplyTimeZone.Location = New System.Drawing.Point(669, 318)
        Me.BtnLangAndInterServ_ApplyTimeZone.Name = "BtnLangAndInterServ_ApplyTimeZone"
        Me.BtnLangAndInterServ_ApplyTimeZone.Size = New System.Drawing.Size(56, 28)
        Me.BtnLangAndInterServ_ApplyTimeZone.TabIndex = 30
        Me.BtnLangAndInterServ_ApplyTimeZone.Text = "Apply"
        Me.BtnLangAndInterServ_ApplyTimeZone.UseVisualStyleBackColor = True
        '
        'LblLangAndInterServ_SetTimeZone
        '
        Me.LblLangAndInterServ_SetTimeZone.AutoSize = True
        Me.LblLangAndInterServ_SetTimeZone.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblLangAndInterServ_SetTimeZone.Location = New System.Drawing.Point(5, 322)
        Me.LblLangAndInterServ_SetTimeZone.Name = "LblLangAndInterServ_SetTimeZone"
        Me.LblLangAndInterServ_SetTimeZone.Size = New System.Drawing.Size(118, 20)
        Me.LblLangAndInterServ_SetTimeZone.TabIndex = 29
        Me.LblLangAndInterServ_SetTimeZone.Text = "/Set-TimeZone:"
        '
        'CmbBoxLangAndInterServ_SetInputLocal
        '
        Me.CmbBoxLangAndInterServ_SetInputLocal.AutoCompleteCustomSource.AddRange(New String() {"bg-bg", "cs-cz", "da-dk", "de-de", "el-gr", "en-gb", "en-us", "es-es", "es-mx", "et-ee", "fi-fi", "fr-ca", "fr-fr", "hr-hr", "hu-hu", "it-it", "ja-jp", "ko-kr", "lt-lt", "lv-lv", "nb-no", "nl-nl", "pl-pl", "pt-br", "pt-pt", "ro-ro", "ru-ru", "sk-sk", "sl-si", "sr-latn-rs", "sv-se", "tr-tr", "uk-ua", "zh-cn", "zh-tw"})
        Me.CmbBoxLangAndInterServ_SetInputLocal.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CmbBoxLangAndInterServ_SetInputLocal.FormattingEnabled = True
        Me.CmbBoxLangAndInterServ_SetInputLocal.Items.AddRange(New Object() {"bg-bg", "cs-cz", "da-dk", "de-de", "el-gr", "en-gb", "en-us", "es-es", "es-mx", "et-ee", "fi-fi", "fr-ca", "fr-fr", "hr-hr", "hu-hu", "it-it", "ja-jp", "ko-kr", "lt-lt", "lv-lv", "nb-no", "nl-nl", "pl-pl", "pt-br", "pt-pt", "ro-ro", "ru-ru", "sk-sk", "sl-si", "sr-latn-rs", "sv-se", "tr-tr", "uk-ua", "zh-cn", "zh-tw"})
        Me.CmbBoxLangAndInterServ_SetInputLocal.Location = New System.Drawing.Point(160, 251)
        Me.CmbBoxLangAndInterServ_SetInputLocal.Name = "CmbBoxLangAndInterServ_SetInputLocal"
        Me.CmbBoxLangAndInterServ_SetInputLocal.Size = New System.Drawing.Size(190, 28)
        Me.CmbBoxLangAndInterServ_SetInputLocal.TabIndex = 28
        '
        'BtnLangAndInterServ_ApplyInputLocale
        '
        Me.BtnLangAndInterServ_ApplyInputLocale.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnLangAndInterServ_ApplyInputLocale.Location = New System.Drawing.Point(356, 251)
        Me.BtnLangAndInterServ_ApplyInputLocale.Name = "BtnLangAndInterServ_ApplyInputLocale"
        Me.BtnLangAndInterServ_ApplyInputLocale.Size = New System.Drawing.Size(56, 28)
        Me.BtnLangAndInterServ_ApplyInputLocale.TabIndex = 27
        Me.BtnLangAndInterServ_ApplyInputLocale.Text = "Apply"
        Me.BtnLangAndInterServ_ApplyInputLocale.UseVisualStyleBackColor = True
        '
        'LblLangAndInterServ_SetInputLocale
        '
        Me.LblLangAndInterServ_SetInputLocale.AutoSize = True
        Me.LblLangAndInterServ_SetInputLocale.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblLangAndInterServ_SetInputLocale.Location = New System.Drawing.Point(5, 254)
        Me.LblLangAndInterServ_SetInputLocale.Name = "LblLangAndInterServ_SetInputLocale"
        Me.LblLangAndInterServ_SetInputLocale.Size = New System.Drawing.Size(131, 20)
        Me.LblLangAndInterServ_SetInputLocale.TabIndex = 26
        Me.LblLangAndInterServ_SetInputLocale.Text = "/Set-InputLocale:"
        '
        'CmbBoxLangAndInterServ_SetUserLocale
        '
        Me.CmbBoxLangAndInterServ_SetUserLocale.AutoCompleteCustomSource.AddRange(New String() {"bg-bg", "cs-cz", "da-dk", "de-de", "el-gr", "en-gb", "en-us", "es-es", "es-mx", "et-ee", "fi-fi", "fr-ca", "fr-fr", "hr-hr", "hu-hu", "it-it", "ja-jp", "ko-kr", "lt-lt", "lv-lv", "nb-no", "nl-nl", "pl-pl", "pt-br", "pt-pt", "ro-ro", "ru-ru", "sk-sk", "sl-si", "sr-latn-rs", "sv-se", "tr-tr", "uk-ua", "zh-cn", "zh-tw"})
        Me.CmbBoxLangAndInterServ_SetUserLocale.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CmbBoxLangAndInterServ_SetUserLocale.FormattingEnabled = True
        Me.CmbBoxLangAndInterServ_SetUserLocale.Items.AddRange(New Object() {"bg-bg", "cs-cz", "da-dk", "de-de", "el-gr", "en-gb", "en-us", "es-es", "es-mx", "et-ee", "fi-fi", "fr-ca", "fr-fr", "hr-hr", "hu-hu", "it-it", "ja-jp", "ko-kr", "lt-lt", "lv-lv", "nb-no", "nl-nl", "pl-pl", "pt-br", "pt-pt", "ro-ro", "ru-ru", "sk-sk", "sl-si", "sr-latn-rs", "sv-se", "tr-tr", "uk-ua", "zh-cn", "zh-tw"})
        Me.CmbBoxLangAndInterServ_SetUserLocale.Location = New System.Drawing.Point(160, 217)
        Me.CmbBoxLangAndInterServ_SetUserLocale.Name = "CmbBoxLangAndInterServ_SetUserLocale"
        Me.CmbBoxLangAndInterServ_SetUserLocale.Size = New System.Drawing.Size(97, 28)
        Me.CmbBoxLangAndInterServ_SetUserLocale.TabIndex = 25
        '
        'BtnLangAndInterServ_ApplyUserLocale
        '
        Me.BtnLangAndInterServ_ApplyUserLocale.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnLangAndInterServ_ApplyUserLocale.Location = New System.Drawing.Point(263, 217)
        Me.BtnLangAndInterServ_ApplyUserLocale.Name = "BtnLangAndInterServ_ApplyUserLocale"
        Me.BtnLangAndInterServ_ApplyUserLocale.Size = New System.Drawing.Size(56, 28)
        Me.BtnLangAndInterServ_ApplyUserLocale.TabIndex = 24
        Me.BtnLangAndInterServ_ApplyUserLocale.Text = "Apply"
        Me.BtnLangAndInterServ_ApplyUserLocale.UseVisualStyleBackColor = True
        '
        'LblLangAndInterServ_SetUserLocale
        '
        Me.LblLangAndInterServ_SetUserLocale.AutoSize = True
        Me.LblLangAndInterServ_SetUserLocale.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblLangAndInterServ_SetUserLocale.Location = New System.Drawing.Point(5, 220)
        Me.LblLangAndInterServ_SetUserLocale.Name = "LblLangAndInterServ_SetUserLocale"
        Me.LblLangAndInterServ_SetUserLocale.Size = New System.Drawing.Size(128, 20)
        Me.LblLangAndInterServ_SetUserLocale.TabIndex = 23
        Me.LblLangAndInterServ_SetUserLocale.Text = "/Set-UserLocale:"
        '
        'CmbBoxLangAndInterServ_SetUILang_SysLocale
        '
        Me.CmbBoxLangAndInterServ_SetUILang_SysLocale.AutoCompleteCustomSource.AddRange(New String() {"bg-bg", "cs-cz", "da-dk", "de-de", "el-gr", "en-gb", "en-us", "es-es", "es-mx", "et-ee", "fi-fi", "fr-ca", "fr-fr", "hr-hr", "hu-hu", "it-it", "ja-jp", "ko-kr", "lt-lt", "lv-lv", "nb-no", "nl-nl", "pl-pl", "pt-br", "pt-pt", "ro-ro", "ru-ru", "sk-sk", "sl-si", "sr-latn-rs", "sv-se", "tr-tr", "uk-ua", "zh-cn", "zh-tw"})
        Me.CmbBoxLangAndInterServ_SetUILang_SysLocale.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CmbBoxLangAndInterServ_SetUILang_SysLocale.FormattingEnabled = True
        Me.CmbBoxLangAndInterServ_SetUILang_SysLocale.Items.AddRange(New Object() {"bg-bg", "cs-cz", "da-dk", "de-de", "el-gr", "en-gb", "en-us", "es-es", "es-mx", "et-ee", "fi-fi", "fr-ca", "fr-fr", "hr-hr", "hu-hu", "it-it", "ja-jp", "ko-kr", "lt-lt", "lv-lv", "nb-no", "nl-nl", "pl-pl", "pt-br", "pt-pt", "ro-ro", "ru-ru", "sk-sk", "sl-si", "sr-latn-rs", "sv-se", "tr-tr", "uk-ua", "zh-cn", "zh-tw"})
        Me.CmbBoxLangAndInterServ_SetUILang_SysLocale.Location = New System.Drawing.Point(160, 183)
        Me.CmbBoxLangAndInterServ_SetUILang_SysLocale.Name = "CmbBoxLangAndInterServ_SetUILang_SysLocale"
        Me.CmbBoxLangAndInterServ_SetUILang_SysLocale.Size = New System.Drawing.Size(97, 28)
        Me.CmbBoxLangAndInterServ_SetUILang_SysLocale.TabIndex = 22
        '
        'BtnLangAndInterServ_ApplySysLocale
        '
        Me.BtnLangAndInterServ_ApplySysLocale.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnLangAndInterServ_ApplySysLocale.Location = New System.Drawing.Point(263, 184)
        Me.BtnLangAndInterServ_ApplySysLocale.Name = "BtnLangAndInterServ_ApplySysLocale"
        Me.BtnLangAndInterServ_ApplySysLocale.Size = New System.Drawing.Size(56, 28)
        Me.BtnLangAndInterServ_ApplySysLocale.TabIndex = 21
        Me.BtnLangAndInterServ_ApplySysLocale.Text = "Apply"
        Me.BtnLangAndInterServ_ApplySysLocale.UseVisualStyleBackColor = True
        '
        'LblLangAndInterServ_SetSysLocale
        '
        Me.LblLangAndInterServ_SetSysLocale.AutoSize = True
        Me.LblLangAndInterServ_SetSysLocale.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblLangAndInterServ_SetSysLocale.Location = New System.Drawing.Point(5, 186)
        Me.LblLangAndInterServ_SetSysLocale.Name = "LblLangAndInterServ_SetSysLocale"
        Me.LblLangAndInterServ_SetSysLocale.Size = New System.Drawing.Size(120, 20)
        Me.LblLangAndInterServ_SetSysLocale.TabIndex = 20
        Me.LblLangAndInterServ_SetSysLocale.Text = "/Set-SysLocale:"
        '
        'CmbBoxLangAndInterServ_SetSysUILang
        '
        Me.CmbBoxLangAndInterServ_SetSysUILang.AutoCompleteCustomSource.AddRange(New String() {"bg-bg", "cs-cz", "da-dk", "de-de", "el-gr", "en-gb", "en-us", "es-es", "es-mx", "et-ee", "fi-fi", "fr-ca", "fr-fr", "hr-hr", "hu-hu", "it-it", "ja-jp", "ko-kr", "lt-lt", "lv-lv", "nb-no", "nl-nl", "pl-pl", "pt-br", "pt-pt", "ro-ro", "ru-ru", "sk-sk", "sl-si", "sr-latn-rs", "sv-se", "tr-tr", "uk-ua", "zh-cn", "zh-tw"})
        Me.CmbBoxLangAndInterServ_SetSysUILang.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CmbBoxLangAndInterServ_SetSysUILang.FormattingEnabled = True
        Me.CmbBoxLangAndInterServ_SetSysUILang.Items.AddRange(New Object() {"bg-bg", "cs-cz", "da-dk", "de-de", "el-gr", "en-gb", "en-us", "es-es", "es-mx", "et-ee", "fi-fi", "fr-ca", "fr-fr", "hr-hr", "hu-hu", "it-it", "ja-jp", "ko-kr", "lt-lt", "lv-lv", "nb-no", "nl-nl", "pl-pl", "pt-br", "pt-pt", "ro-ro", "ru-ru", "sk-sk", "sl-si", "sr-latn-rs", "sv-se", "tr-tr", "uk-ua", "zh-cn", "zh-tw"})
        Me.CmbBoxLangAndInterServ_SetSysUILang.Location = New System.Drawing.Point(160, 149)
        Me.CmbBoxLangAndInterServ_SetSysUILang.Name = "CmbBoxLangAndInterServ_SetSysUILang"
        Me.CmbBoxLangAndInterServ_SetSysUILang.Size = New System.Drawing.Size(97, 28)
        Me.CmbBoxLangAndInterServ_SetSysUILang.TabIndex = 19
        '
        'BtnLangAndInterServ_ApplySysUILang
        '
        Me.BtnLangAndInterServ_ApplySysUILang.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnLangAndInterServ_ApplySysUILang.Location = New System.Drawing.Point(263, 148)
        Me.BtnLangAndInterServ_ApplySysUILang.Name = "BtnLangAndInterServ_ApplySysUILang"
        Me.BtnLangAndInterServ_ApplySysUILang.Size = New System.Drawing.Size(56, 28)
        Me.BtnLangAndInterServ_ApplySysUILang.TabIndex = 18
        Me.BtnLangAndInterServ_ApplySysUILang.Text = "Apply"
        Me.BtnLangAndInterServ_ApplySysUILang.UseVisualStyleBackColor = True
        '
        'LblLangAndInterServ_SetSysUILang
        '
        Me.LblLangAndInterServ_SetSysUILang.AutoSize = True
        Me.LblLangAndInterServ_SetSysUILang.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblLangAndInterServ_SetSysUILang.Location = New System.Drawing.Point(5, 152)
        Me.LblLangAndInterServ_SetSysUILang.Name = "LblLangAndInterServ_SetSysUILang"
        Me.LblLangAndInterServ_SetSysUILang.Size = New System.Drawing.Size(126, 20)
        Me.LblLangAndInterServ_SetSysUILang.TabIndex = 17
        Me.LblLangAndInterServ_SetSysUILang.Text = "/Set-SysUILang:"
        '
        'CmbBoxLangAndInterServ_SetUILangFallback
        '
        Me.CmbBoxLangAndInterServ_SetUILangFallback.AutoCompleteCustomSource.AddRange(New String() {"bg-bg", "cs-cz", "da-dk", "de-de", "el-gr", "en-gb", "en-us", "es-es", "es-mx", "et-ee", "fi-fi", "fr-ca", "fr-fr", "hr-hr", "hu-hu", "it-it", "ja-jp", "ko-kr", "lt-lt", "lv-lv", "nb-no", "nl-nl", "pl-pl", "pt-br", "pt-pt", "ro-ro", "ru-ru", "sk-sk", "sl-si", "sr-latn-rs", "sv-se", "tr-tr", "uk-ua", "zh-cn", "zh-tw"})
        Me.CmbBoxLangAndInterServ_SetUILangFallback.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CmbBoxLangAndInterServ_SetUILangFallback.FormattingEnabled = True
        Me.CmbBoxLangAndInterServ_SetUILangFallback.Items.AddRange(New Object() {"bg-bg", "cs-cz", "da-dk", "de-de", "el-gr", "en-gb", "en-us", "es-es", "es-mx", "et-ee", "fi-fi", "fr-ca", "fr-fr", "hr-hr", "hu-hu", "it-it", "ja-jp", "ko-kr", "lt-lt", "lv-lv", "nb-no", "nl-nl", "pl-pl", "pt-br", "pt-pt", "ro-ro", "ru-ru", "sk-sk", "sl-si", "sr-latn-rs", "sv-se", "tr-tr", "uk-ua", "zh-cn", "zh-tw"})
        Me.CmbBoxLangAndInterServ_SetUILangFallback.Location = New System.Drawing.Point(160, 115)
        Me.CmbBoxLangAndInterServ_SetUILangFallback.Name = "CmbBoxLangAndInterServ_SetUILangFallback"
        Me.CmbBoxLangAndInterServ_SetUILangFallback.Size = New System.Drawing.Size(97, 28)
        Me.CmbBoxLangAndInterServ_SetUILangFallback.TabIndex = 16
        '
        'BtnLangAndInterServ_ApplyUILangFallback
        '
        Me.BtnLangAndInterServ_ApplyUILangFallback.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnLangAndInterServ_ApplyUILangFallback.Location = New System.Drawing.Point(263, 115)
        Me.BtnLangAndInterServ_ApplyUILangFallback.Name = "BtnLangAndInterServ_ApplyUILangFallback"
        Me.BtnLangAndInterServ_ApplyUILangFallback.Size = New System.Drawing.Size(56, 28)
        Me.BtnLangAndInterServ_ApplyUILangFallback.TabIndex = 15
        Me.BtnLangAndInterServ_ApplyUILangFallback.Text = "Apply"
        Me.BtnLangAndInterServ_ApplyUILangFallback.UseVisualStyleBackColor = True
        '
        'LblLangAndInterServ_SetUILangFallback
        '
        Me.LblLangAndInterServ_SetUILangFallback.AutoSize = True
        Me.LblLangAndInterServ_SetUILangFallback.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblLangAndInterServ_SetUILangFallback.Location = New System.Drawing.Point(5, 118)
        Me.LblLangAndInterServ_SetUILangFallback.Name = "LblLangAndInterServ_SetUILangFallback"
        Me.LblLangAndInterServ_SetUILangFallback.Size = New System.Drawing.Size(159, 20)
        Me.LblLangAndInterServ_SetUILangFallback.TabIndex = 14
        Me.LblLangAndInterServ_SetUILangFallback.Text = "/Set-UILangFallback:"
        '
        'CmbBoxLangAndInterServ_SetUILang
        '
        Me.CmbBoxLangAndInterServ_SetUILang.AutoCompleteCustomSource.AddRange(New String() {"bg-bg", "cs-cz", "da-dk", "de-de", "el-gr", "en-gb", "en-us", "es-es", "es-mx", "et-ee", "fi-fi", "fr-ca", "fr-fr", "hr-hr", "hu-hu", "it-it", "ja-jp", "ko-kr", "lt-lt", "lv-lv", "nb-no", "nl-nl", "pl-pl", "pt-br", "pt-pt", "ro-ro", "ru-ru", "sk-sk", "sl-si", "sr-latn-rs", "sv-se", "tr-tr", "uk-ua", "zh-cn", "zh-tw"})
        Me.CmbBoxLangAndInterServ_SetUILang.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CmbBoxLangAndInterServ_SetUILang.FormattingEnabled = True
        Me.CmbBoxLangAndInterServ_SetUILang.Items.AddRange(New Object() {"bg-bg", "cs-cz", "da-dk", "de-de", "el-gr", "en-gb", "en-us", "es-es", "es-mx", "et-ee", "fi-fi", "fr-ca", "fr-fr", "hr-hr", "hu-hu", "it-it", "ja-jp", "ko-kr", "lt-lt", "lv-lv", "nb-no", "nl-nl", "pl-pl", "pt-br", "pt-pt", "ro-ro", "ru-ru", "sk-sk", "sl-si", "sr-latn-rs", "sv-se", "tr-tr", "uk-ua", "zh-cn", "zh-tw"})
        Me.CmbBoxLangAndInterServ_SetUILang.Location = New System.Drawing.Point(160, 81)
        Me.CmbBoxLangAndInterServ_SetUILang.Name = "CmbBoxLangAndInterServ_SetUILang"
        Me.CmbBoxLangAndInterServ_SetUILang.Size = New System.Drawing.Size(97, 28)
        Me.CmbBoxLangAndInterServ_SetUILang.TabIndex = 13
        '
        'BtnLangAndInterServ_ApplyUILang
        '
        Me.BtnLangAndInterServ_ApplyUILang.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnLangAndInterServ_ApplyUILang.Location = New System.Drawing.Point(263, 80)
        Me.BtnLangAndInterServ_ApplyUILang.Name = "BtnLangAndInterServ_ApplyUILang"
        Me.BtnLangAndInterServ_ApplyUILang.Size = New System.Drawing.Size(56, 28)
        Me.BtnLangAndInterServ_ApplyUILang.TabIndex = 12
        Me.BtnLangAndInterServ_ApplyUILang.Text = "Apply"
        Me.BtnLangAndInterServ_ApplyUILang.UseVisualStyleBackColor = True
        '
        'LblLangAndInterServ_SetUILang
        '
        Me.LblLangAndInterServ_SetUILang.AutoSize = True
        Me.LblLangAndInterServ_SetUILang.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblLangAndInterServ_SetUILang.Location = New System.Drawing.Point(5, 84)
        Me.LblLangAndInterServ_SetUILang.Name = "LblLangAndInterServ_SetUILang"
        Me.LblLangAndInterServ_SetUILang.Size = New System.Drawing.Size(100, 20)
        Me.LblLangAndInterServ_SetUILang.TabIndex = 11
        Me.LblLangAndInterServ_SetUILang.Text = "/Set-UILang:"
        '
        'CmbBoxLangAndInterServ_SetAllIntl
        '
        Me.CmbBoxLangAndInterServ_SetAllIntl.AutoCompleteCustomSource.AddRange(New String() {"bg-bg", "cs-cz", "da-dk", "de-de", "el-gr", "en-gb", "en-us", "es-es", "es-mx", "et-ee", "fi-fi", "fr-ca", "fr-fr", "hr-hr", "hu-hu", "it-it", "ja-jp", "ko-kr", "lt-lt", "lv-lv", "nb-no", "nl-nl", "pl-pl", "pt-br", "pt-pt", "ro-ro", "ru-ru", "sk-sk", "sl-si", "sr-latn-rs", "sv-se", "tr-tr", "uk-ua", "zh-cn", "zh-tw"})
        Me.CmbBoxLangAndInterServ_SetAllIntl.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CmbBoxLangAndInterServ_SetAllIntl.FormattingEnabled = True
        Me.CmbBoxLangAndInterServ_SetAllIntl.Items.AddRange(New Object() {"bg-bg", "cs-cz", "da-dk", "de-de", "el-gr", "en-gb", "en-us", "es-es", "es-mx", "et-ee", "fi-fi", "fr-ca", "fr-fr", "hr-hr", "hu-hu", "it-it", "ja-jp", "ko-kr", "lt-lt", "lv-lv", "nb-no", "nl-nl", "pl-pl", "pt-br", "pt-pt", "ro-ro", "ru-ru", "sk-sk", "sl-si", "sr-latn-rs", "sv-se", "tr-tr", "uk-ua", "zh-cn", "zh-tw"})
        Me.CmbBoxLangAndInterServ_SetAllIntl.Location = New System.Drawing.Point(160, 285)
        Me.CmbBoxLangAndInterServ_SetAllIntl.Name = "CmbBoxLangAndInterServ_SetAllIntl"
        Me.CmbBoxLangAndInterServ_SetAllIntl.Size = New System.Drawing.Size(97, 28)
        Me.CmbBoxLangAndInterServ_SetAllIntl.TabIndex = 10
        '
        'BtnLangAndInterServ_ApplyAllIntl
        '
        Me.BtnLangAndInterServ_ApplyAllIntl.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnLangAndInterServ_ApplyAllIntl.Location = New System.Drawing.Point(263, 284)
        Me.BtnLangAndInterServ_ApplyAllIntl.Name = "BtnLangAndInterServ_ApplyAllIntl"
        Me.BtnLangAndInterServ_ApplyAllIntl.Size = New System.Drawing.Size(56, 28)
        Me.BtnLangAndInterServ_ApplyAllIntl.TabIndex = 9
        Me.BtnLangAndInterServ_ApplyAllIntl.Text = "Apply"
        Me.BtnLangAndInterServ_ApplyAllIntl.UseVisualStyleBackColor = True
        '
        'LblLangAndInterServ_SetAllIntl
        '
        Me.LblLangAndInterServ_SetAllIntl.AutoSize = True
        Me.LblLangAndInterServ_SetAllIntl.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblLangAndInterServ_SetAllIntl.Location = New System.Drawing.Point(5, 288)
        Me.LblLangAndInterServ_SetAllIntl.Name = "LblLangAndInterServ_SetAllIntl"
        Me.LblLangAndInterServ_SetAllIntl.Size = New System.Drawing.Size(86, 20)
        Me.LblLangAndInterServ_SetAllIntl.TabIndex = 7
        Me.LblLangAndInterServ_SetAllIntl.Text = "/Set-AllIntl:"
        '
        'BtnLangAndInterServicing_DisplayInfo
        '
        Me.BtnLangAndInterServicing_DisplayInfo.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnLangAndInterServicing_DisplayInfo.Location = New System.Drawing.Point(383, 82)
        Me.BtnLangAndInterServicing_DisplayInfo.Name = "BtnLangAndInterServicing_DisplayInfo"
        Me.BtnLangAndInterServicing_DisplayInfo.Size = New System.Drawing.Size(488, 30)
        Me.BtnLangAndInterServicing_DisplayInfo.TabIndex = 6
        Me.BtnLangAndInterServicing_DisplayInfo.Text = "Display information about international settings and languages"
        Me.BtnLangAndInterServicing_DisplayInfo.UseVisualStyleBackColor = True
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Location = New System.Drawing.Point(-96, 172)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(86, 20)
        Me.Label25.TabIndex = 5
        Me.Label25.Text = "/Set-AllIntl:"
        '
        'TabPage12
        '
        Me.TabPage12.Controls.Add(Me.BtnExportDriver_GetMountedImageInfo)
        Me.TabPage12.Controls.Add(Me.BtnExportDriver_RefreshMountedImage)
        Me.TabPage12.Controls.Add(Me.LblExportDriver_UseMountedImage)
        Me.TabPage12.Controls.Add(Me.CmbBoxExportDriver_UseImageMounted)
        Me.TabPage12.Controls.Add(Me.ChkBoxExportDriver_Online)
        Me.TabPage12.Controls.Add(Me.BtnExportDriver_ExportDriver)
        Me.TabPage12.Controls.Add(Me.LblExportDriver_Folder)
        Me.TabPage12.Controls.Add(Me.TxtBoxExport_PathDriverFolder)
        Me.TabPage12.Controls.Add(Me.BtnExportDriver_SelectFolder)
        Me.TabPage12.Location = New System.Drawing.Point(4, 29)
        Me.TabPage12.Name = "TabPage12"
        Me.TabPage12.Size = New System.Drawing.Size(886, 350)
        Me.TabPage12.TabIndex = 11
        Me.TabPage12.Text = "Export Driver"
        Me.TabPage12.UseVisualStyleBackColor = True
        '
        'BtnExportDriver_GetMountedImageInfo
        '
        Me.BtnExportDriver_GetMountedImageInfo.Location = New System.Drawing.Point(703, 14)
        Me.BtnExportDriver_GetMountedImageInfo.Name = "BtnExportDriver_GetMountedImageInfo"
        Me.BtnExportDriver_GetMountedImageInfo.Size = New System.Drawing.Size(163, 64)
        Me.BtnExportDriver_GetMountedImageInfo.TabIndex = 51
        Me.BtnExportDriver_GetMountedImageInfo.Text = "Get Mounted Image Info"
        Me.BtnExportDriver_GetMountedImageInfo.UseVisualStyleBackColor = False
        '
        'BtnExportDriver_RefreshMountedImage
        '
        Me.BtnExportDriver_RefreshMountedImage.Location = New System.Drawing.Point(256, 14)
        Me.BtnExportDriver_RefreshMountedImage.Name = "BtnExportDriver_RefreshMountedImage"
        Me.BtnExportDriver_RefreshMountedImage.Size = New System.Drawing.Size(221, 32)
        Me.BtnExportDriver_RefreshMountedImage.TabIndex = 50
        Me.BtnExportDriver_RefreshMountedImage.Text = "Refresh mounted image"
        Me.BtnExportDriver_RefreshMountedImage.UseVisualStyleBackColor = True
        '
        'LblExportDriver_UseMountedImage
        '
        Me.LblExportDriver_UseMountedImage.AutoSize = True
        Me.LblExportDriver_UseMountedImage.Location = New System.Drawing.Point(22, 53)
        Me.LblExportDriver_UseMountedImage.Name = "LblExportDriver_UseMountedImage"
        Me.LblExportDriver_UseMountedImage.Size = New System.Drawing.Size(158, 20)
        Me.LblExportDriver_UseMountedImage.TabIndex = 49
        Me.LblExportDriver_UseMountedImage.Text = "Use Image Mounted:"
        '
        'CmbBoxExportDriver_UseImageMounted
        '
        Me.CmbBoxExportDriver_UseImageMounted.FormattingEnabled = True
        Me.CmbBoxExportDriver_UseImageMounted.Location = New System.Drawing.Point(198, 52)
        Me.CmbBoxExportDriver_UseImageMounted.Name = "CmbBoxExportDriver_UseImageMounted"
        Me.CmbBoxExportDriver_UseImageMounted.Size = New System.Drawing.Size(349, 28)
        Me.CmbBoxExportDriver_UseImageMounted.TabIndex = 48
        '
        'ChkBoxExportDriver_Online
        '
        Me.ChkBoxExportDriver_Online.AutoSize = True
        Me.ChkBoxExportDriver_Online.Location = New System.Drawing.Point(741, 323)
        Me.ChkBoxExportDriver_Online.Name = "ChkBoxExportDriver_Online"
        Me.ChkBoxExportDriver_Online.Size = New System.Drawing.Size(125, 24)
        Me.ChkBoxExportDriver_Online.TabIndex = 47
        Me.ChkBoxExportDriver_Online.Text = "/Online option"
        Me.ChkBoxExportDriver_Online.UseVisualStyleBackColor = False
        '
        'BtnExportDriver_ExportDriver
        '
        Me.BtnExportDriver_ExportDriver.Location = New System.Drawing.Point(703, 117)
        Me.BtnExportDriver_ExportDriver.Name = "BtnExportDriver_ExportDriver"
        Me.BtnExportDriver_ExportDriver.Size = New System.Drawing.Size(163, 60)
        Me.BtnExportDriver_ExportDriver.TabIndex = 11
        Me.BtnExportDriver_ExportDriver.Text = "Export Driver"
        Me.BtnExportDriver_ExportDriver.UseVisualStyleBackColor = True
        '
        'LblExportDriver_Folder
        '
        Me.LblExportDriver_Folder.AutoSize = True
        Me.LblExportDriver_Folder.Location = New System.Drawing.Point(22, 137)
        Me.LblExportDriver_Folder.Name = "LblExportDriver_Folder"
        Me.LblExportDriver_Folder.Size = New System.Drawing.Size(58, 20)
        Me.LblExportDriver_Folder.TabIndex = 10
        Me.LblExportDriver_Folder.Text = "Folder:"
        '
        'TxtBoxExport_PathDriverFolder
        '
        Me.TxtBoxExport_PathDriverFolder.Location = New System.Drawing.Point(130, 131)
        Me.TxtBoxExport_PathDriverFolder.Name = "TxtBoxExport_PathDriverFolder"
        Me.TxtBoxExport_PathDriverFolder.Size = New System.Drawing.Size(501, 26)
        Me.TxtBoxExport_PathDriverFolder.TabIndex = 9
        '
        'BtnExportDriver_SelectFolder
        '
        Me.BtnExportDriver_SelectFolder.Location = New System.Drawing.Point(293, 172)
        Me.BtnExportDriver_SelectFolder.Name = "BtnExportDriver_SelectFolder"
        Me.BtnExportDriver_SelectFolder.Size = New System.Drawing.Size(150, 29)
        Me.BtnExportDriver_SelectFolder.TabIndex = 8
        Me.BtnExportDriver_SelectFolder.Text = "Select Folder"
        Me.BtnExportDriver_SelectFolder.UseVisualStyleBackColor = True
        '
        'TabPage13
        '
        Me.TabPage13.Controls.Add(Me.LblSplitImage_Warning)
        Me.TabPage13.Controls.Add(Me.BtnSplitImage_WIMChoice)
        Me.TabPage13.Controls.Add(Me.BtnSplitImage_TargetFolder)
        Me.TabPage13.Controls.Add(Me.LblSplitImage_DestinationFolder)
        Me.TabPage13.Controls.Add(Me.TxtBoxSplitImage_DestinationFolder)
        Me.TabPage13.Controls.Add(Me.BtnSplitImage_SplitImage)
        Me.TabPage13.Controls.Add(Me.ChkBoxSplitImage_CheckIntegrity)
        Me.TabPage13.Controls.Add(Me.LblSplitImage_SplitSize)
        Me.TabPage13.Controls.Add(Me.TxtBoxSplitImage_Filesize)
        Me.TabPage13.Controls.Add(Me.LblSplitImage_SWMFilename)
        Me.TabPage13.Controls.Add(Me.LblSplitImage_WIMFilename)
        Me.TabPage13.Controls.Add(Me.TxtBoxSplitImage_SWMFilename)
        Me.TabPage13.Controls.Add(Me.TxtBoxSplitImage_WIMFilename)
        Me.TabPage13.Location = New System.Drawing.Point(4, 29)
        Me.TabPage13.Name = "TabPage13"
        Me.TabPage13.Size = New System.Drawing.Size(886, 350)
        Me.TabPage13.TabIndex = 12
        Me.TabPage13.Text = "Split Image"
        Me.TabPage13.UseVisualStyleBackColor = True
        '
        'LblSplitImage_Warning
        '
        Me.LblSplitImage_Warning.AutoSize = True
        Me.LblSplitImage_Warning.Location = New System.Drawing.Point(33, 215)
        Me.LblSplitImage_Warning.Name = "LblSplitImage_Warning"
        Me.LblSplitImage_Warning.Size = New System.Drawing.Size(524, 20)
        Me.LblSplitImage_Warning.TabIndex = 53
        Me.LblSplitImage_Warning.Text = "Warning: split size limite for DVD, 4700Mo and for USB (FAT32), 4000Mo"
        '
        'BtnSplitImage_WIMChoice
        '
        Me.BtnSplitImage_WIMChoice.Location = New System.Drawing.Point(552, 45)
        Me.BtnSplitImage_WIMChoice.Name = "BtnSplitImage_WIMChoice"
        Me.BtnSplitImage_WIMChoice.Size = New System.Drawing.Size(136, 26)
        Me.BtnSplitImage_WIMChoice.TabIndex = 52
        Me.BtnSplitImage_WIMChoice.Text = "Open File"
        Me.BtnSplitImage_WIMChoice.UseVisualStyleBackColor = True
        '
        'BtnSplitImage_TargetFolder
        '
        Me.BtnSplitImage_TargetFolder.Location = New System.Drawing.Point(553, 81)
        Me.BtnSplitImage_TargetFolder.Name = "BtnSplitImage_TargetFolder"
        Me.BtnSplitImage_TargetFolder.Size = New System.Drawing.Size(136, 29)
        Me.BtnSplitImage_TargetFolder.TabIndex = 51
        Me.BtnSplitImage_TargetFolder.Text = "Open Target Folder"
        Me.BtnSplitImage_TargetFolder.UseVisualStyleBackColor = True
        '
        'LblSplitImage_DestinationFolder
        '
        Me.LblSplitImage_DestinationFolder.AutoSize = True
        Me.LblSplitImage_DestinationFolder.Location = New System.Drawing.Point(13, 83)
        Me.LblSplitImage_DestinationFolder.Name = "LblSplitImage_DestinationFolder"
        Me.LblSplitImage_DestinationFolder.Size = New System.Drawing.Size(143, 20)
        Me.LblSplitImage_DestinationFolder.TabIndex = 50
        Me.LblSplitImage_DestinationFolder.Text = "Destination Folder:"
        '
        'TxtBoxSplitImage_DestinationFolder
        '
        Me.TxtBoxSplitImage_DestinationFolder.Location = New System.Drawing.Point(225, 80)
        Me.TxtBoxSplitImage_DestinationFolder.Name = "TxtBoxSplitImage_DestinationFolder"
        Me.TxtBoxSplitImage_DestinationFolder.Size = New System.Drawing.Size(303, 26)
        Me.TxtBoxSplitImage_DestinationFolder.TabIndex = 49
        '
        'BtnSplitImage_SplitImage
        '
        Me.BtnSplitImage_SplitImage.Location = New System.Drawing.Point(720, 45)
        Me.BtnSplitImage_SplitImage.Name = "BtnSplitImage_SplitImage"
        Me.BtnSplitImage_SplitImage.Size = New System.Drawing.Size(136, 53)
        Me.BtnSplitImage_SplitImage.TabIndex = 48
        Me.BtnSplitImage_SplitImage.Text = "Split Image"
        Me.BtnSplitImage_SplitImage.UseVisualStyleBackColor = True
        '
        'ChkBoxSplitImage_CheckIntegrity
        '
        Me.ChkBoxSplitImage_CheckIntegrity.AutoSize = True
        Me.ChkBoxSplitImage_CheckIntegrity.Location = New System.Drawing.Point(555, 157)
        Me.ChkBoxSplitImage_CheckIntegrity.Name = "ChkBoxSplitImage_CheckIntegrity"
        Me.ChkBoxSplitImage_CheckIntegrity.Size = New System.Drawing.Size(134, 24)
        Me.ChkBoxSplitImage_CheckIntegrity.TabIndex = 47
        Me.ChkBoxSplitImage_CheckIntegrity.Text = "/CheckIntegrity"
        Me.ChkBoxSplitImage_CheckIntegrity.UseVisualStyleBackColor = True
        '
        'LblSplitImage_SplitSize
        '
        Me.LblSplitImage_SplitSize.AutoSize = True
        Me.LblSplitImage_SplitSize.Location = New System.Drawing.Point(13, 147)
        Me.LblSplitImage_SplitSize.Name = "LblSplitImage_SplitSize"
        Me.LblSplitImage_SplitSize.Size = New System.Drawing.Size(144, 20)
        Me.LblSplitImage_SplitSize.TabIndex = 46
        Me.LblSplitImage_SplitSize.Text = "Split File Size (Mo):"
        '
        'TxtBoxSplitImage_Filesize
        '
        Me.TxtBoxSplitImage_Filesize.Location = New System.Drawing.Point(225, 144)
        Me.TxtBoxSplitImage_Filesize.Name = "TxtBoxSplitImage_Filesize"
        Me.TxtBoxSplitImage_Filesize.Size = New System.Drawing.Size(303, 26)
        Me.TxtBoxSplitImage_Filesize.TabIndex = 45
        '
        'LblSplitImage_SWMFilename
        '
        Me.LblSplitImage_SWMFilename.AutoSize = True
        Me.LblSplitImage_SWMFilename.Location = New System.Drawing.Point(13, 115)
        Me.LblSplitImage_SWMFilename.Name = "LblSplitImage_SWMFilename"
        Me.LblSplitImage_SWMFilename.Size = New System.Drawing.Size(168, 20)
        Me.LblSplitImage_SWMFilename.TabIndex = 44
        Me.LblSplitImage_SWMFilename.Text = "SWM or Sfu Filename:"
        '
        'LblSplitImage_WIMFilename
        '
        Me.LblSplitImage_WIMFilename.AutoSize = True
        Me.LblSplitImage_WIMFilename.Location = New System.Drawing.Point(13, 48)
        Me.LblSplitImage_WIMFilename.Name = "LblSplitImage_WIMFilename"
        Me.LblSplitImage_WIMFilename.Size = New System.Drawing.Size(161, 20)
        Me.LblSplitImage_WIMFilename.TabIndex = 43
        Me.LblSplitImage_WIMFilename.Text = "WIM or Ffu Filename:"
        '
        'TxtBoxSplitImage_SWMFilename
        '
        Me.TxtBoxSplitImage_SWMFilename.Location = New System.Drawing.Point(225, 112)
        Me.TxtBoxSplitImage_SWMFilename.Name = "TxtBoxSplitImage_SWMFilename"
        Me.TxtBoxSplitImage_SWMFilename.Size = New System.Drawing.Size(303, 26)
        Me.TxtBoxSplitImage_SWMFilename.TabIndex = 42
        '
        'TxtBoxSplitImage_WIMFilename
        '
        Me.TxtBoxSplitImage_WIMFilename.Location = New System.Drawing.Point(225, 45)
        Me.TxtBoxSplitImage_WIMFilename.Name = "TxtBoxSplitImage_WIMFilename"
        Me.TxtBoxSplitImage_WIMFilename.Size = New System.Drawing.Size(303, 26)
        Me.TxtBoxSplitImage_WIMFilename.TabIndex = 41
        '
        'TabPage14
        '
        Me.TabPage14.Controls.Add(Me.LblCaptureFfu_Warning)
        Me.TabPage14.Controls.Add(Me.LblCaptureFfu_Description)
        Me.TabPage14.Controls.Add(Me.TxtBoxCaptureFfu_Description)
        Me.TabPage14.Controls.Add(Me.LstBoxCaptureFfu_LogicalDrive)
        Me.TabPage14.Controls.Add(Me.LblCaptureFfu_LogicalDrive)
        Me.TabPage14.Controls.Add(Me.LblCaptureFfu_Name)
        Me.TabPage14.Controls.Add(Me.TxtBoxCaptFfu_Name)
        Me.TabPage14.Controls.Add(Me.LblCaptureFfu_PlatformID)
        Me.TabPage14.Controls.Add(Me.TxtBoxCaptFfu_PlatformID)
        Me.TabPage14.Controls.Add(Me.LblCaptureFfu_Compression)
        Me.TabPage14.Controls.Add(Me.LblCaptureFfu_TargetFilename)
        Me.TabPage14.Controls.Add(Me.LblCaptureFfu_TargetFolder)
        Me.TabPage14.Controls.Add(Me.LblCaptureFfu_PhysicalDrive)
        Me.TabPage14.Controls.Add(Me.CmbBoxCaptureFfu_Compression)
        Me.TabPage14.Controls.Add(Me.TxtBoxCaptFfu_TargetFilename)
        Me.TabPage14.Controls.Add(Me.TxtBoxCaptFfu_TargetFolder)
        Me.TabPage14.Controls.Add(Me.TxtBoxCaptFfu_PhysicalDrive)
        Me.TabPage14.Controls.Add(Me.BtnCaptureFfu_StartCapture)
        Me.TabPage14.Controls.Add(Me.BtnCaptureFfu_SetTargetFolder)
        Me.TabPage14.Controls.Add(Me.BtnCaptureFfu_UpdateLogicalDrive)
        Me.TabPage14.Location = New System.Drawing.Point(4, 29)
        Me.TabPage14.Name = "TabPage14"
        Me.TabPage14.Size = New System.Drawing.Size(886, 350)
        Me.TabPage14.TabIndex = 13
        Me.TabPage14.Text = "Capture Ffu Image"
        Me.TabPage14.UseVisualStyleBackColor = True
        '
        'LblCaptureFfu_Warning
        '
        Me.LblCaptureFfu_Warning.AutoSize = True
        Me.LblCaptureFfu_Warning.Location = New System.Drawing.Point(203, 18)
        Me.LblCaptureFfu_Warning.Name = "LblCaptureFfu_Warning"
        Me.LblCaptureFfu_Warning.Size = New System.Drawing.Size(408, 20)
        Me.LblCaptureFfu_Warning.TabIndex = 57
        Me.LblCaptureFfu_Warning.Text = "Warning: GPT disk is require to use this dism command !."
        '
        'LblCaptureFfu_Description
        '
        Me.LblCaptureFfu_Description.AutoSize = True
        Me.LblCaptureFfu_Description.Location = New System.Drawing.Point(61, 235)
        Me.LblCaptureFfu_Description.Name = "LblCaptureFfu_Description"
        Me.LblCaptureFfu_Description.Size = New System.Drawing.Size(175, 20)
        Me.LblCaptureFfu_Description.TabIndex = 56
        Me.LblCaptureFfu_Description.Text = "Description (metadata):"
        '
        'TxtBoxCaptureFfu_Description
        '
        Me.TxtBoxCaptureFfu_Description.Location = New System.Drawing.Point(247, 233)
        Me.TxtBoxCaptureFfu_Description.Name = "TxtBoxCaptureFfu_Description"
        Me.TxtBoxCaptureFfu_Description.Size = New System.Drawing.Size(300, 26)
        Me.TxtBoxCaptureFfu_Description.TabIndex = 55
        '
        'LstBoxCaptureFfu_LogicalDrive
        '
        Me.LstBoxCaptureFfu_LogicalDrive.FormattingEnabled = True
        Me.LstBoxCaptureFfu_LogicalDrive.ItemHeight = 20
        Me.LstBoxCaptureFfu_LogicalDrive.Location = New System.Drawing.Point(247, 63)
        Me.LstBoxCaptureFfu_LogicalDrive.Name = "LstBoxCaptureFfu_LogicalDrive"
        Me.LstBoxCaptureFfu_LogicalDrive.Size = New System.Drawing.Size(67, 24)
        Me.LstBoxCaptureFfu_LogicalDrive.TabIndex = 54
        '
        'LblCaptureFfu_LogicalDrive
        '
        Me.LblCaptureFfu_LogicalDrive.AutoSize = True
        Me.LblCaptureFfu_LogicalDrive.Location = New System.Drawing.Point(61, 67)
        Me.LblCaptureFfu_LogicalDrive.Name = "LblCaptureFfu_LogicalDrive"
        Me.LblCaptureFfu_LogicalDrive.Size = New System.Drawing.Size(103, 20)
        Me.LblCaptureFfu_LogicalDrive.TabIndex = 53
        Me.LblCaptureFfu_LogicalDrive.Text = "Logical Drive:"
        '
        'LblCaptureFfu_Name
        '
        Me.LblCaptureFfu_Name.AutoSize = True
        Me.LblCaptureFfu_Name.Location = New System.Drawing.Point(61, 198)
        Me.LblCaptureFfu_Name.Name = "LblCaptureFfu_Name"
        Me.LblCaptureFfu_Name.Size = New System.Drawing.Size(137, 20)
        Me.LblCaptureFfu_Name.TabIndex = 52
        Me.LblCaptureFfu_Name.Text = "Name (metadata):"
        '
        'TxtBoxCaptFfu_Name
        '
        Me.TxtBoxCaptFfu_Name.Location = New System.Drawing.Point(247, 196)
        Me.TxtBoxCaptFfu_Name.Name = "TxtBoxCaptFfu_Name"
        Me.TxtBoxCaptFfu_Name.Size = New System.Drawing.Size(300, 26)
        Me.TxtBoxCaptFfu_Name.TabIndex = 51
        '
        'LblCaptureFfu_PlatformID
        '
        Me.LblCaptureFfu_PlatformID.AutoSize = True
        Me.LblCaptureFfu_PlatformID.Location = New System.Drawing.Point(61, 267)
        Me.LblCaptureFfu_PlatformID.Name = "LblCaptureFfu_PlatformID"
        Me.LblCaptureFfu_PlatformID.Size = New System.Drawing.Size(93, 20)
        Me.LblCaptureFfu_PlatformID.TabIndex = 50
        Me.LblCaptureFfu_PlatformID.Text = "Platform ID:"
        '
        'TxtBoxCaptFfu_PlatformID
        '
        Me.TxtBoxCaptFfu_PlatformID.Location = New System.Drawing.Point(247, 265)
        Me.TxtBoxCaptFfu_PlatformID.Name = "TxtBoxCaptFfu_PlatformID"
        Me.TxtBoxCaptFfu_PlatformID.Size = New System.Drawing.Size(300, 26)
        Me.TxtBoxCaptFfu_PlatformID.TabIndex = 49
        Me.TxtBoxCaptFfu_PlatformID.Text = "*"
        '
        'LblCaptureFfu_Compression
        '
        Me.LblCaptureFfu_Compression.AutoSize = True
        Me.LblCaptureFfu_Compression.Location = New System.Drawing.Point(560, 265)
        Me.LblCaptureFfu_Compression.Name = "LblCaptureFfu_Compression"
        Me.LblCaptureFfu_Compression.Size = New System.Drawing.Size(106, 20)
        Me.LblCaptureFfu_Compression.TabIndex = 48
        Me.LblCaptureFfu_Compression.Text = "Compression:"
        '
        'LblCaptureFfu_TargetFilename
        '
        Me.LblCaptureFfu_TargetFilename.AutoSize = True
        Me.LblCaptureFfu_TargetFilename.Location = New System.Drawing.Point(61, 163)
        Me.LblCaptureFfu_TargetFilename.Name = "LblCaptureFfu_TargetFilename"
        Me.LblCaptureFfu_TargetFilename.Size = New System.Drawing.Size(128, 20)
        Me.LblCaptureFfu_TargetFilename.TabIndex = 47
        Me.LblCaptureFfu_TargetFilename.Text = "Target Filename:"
        '
        'LblCaptureFfu_TargetFolder
        '
        Me.LblCaptureFfu_TargetFolder.AutoSize = True
        Me.LblCaptureFfu_TargetFolder.Location = New System.Drawing.Point(61, 131)
        Me.LblCaptureFfu_TargetFolder.Name = "LblCaptureFfu_TargetFolder"
        Me.LblCaptureFfu_TargetFolder.Size = New System.Drawing.Size(108, 20)
        Me.LblCaptureFfu_TargetFolder.TabIndex = 46
        Me.LblCaptureFfu_TargetFolder.Text = "Target Folder:"
        '
        'LblCaptureFfu_PhysicalDrive
        '
        Me.LblCaptureFfu_PhysicalDrive.AutoSize = True
        Me.LblCaptureFfu_PhysicalDrive.Location = New System.Drawing.Point(61, 100)
        Me.LblCaptureFfu_PhysicalDrive.Name = "LblCaptureFfu_PhysicalDrive"
        Me.LblCaptureFfu_PhysicalDrive.Size = New System.Drawing.Size(110, 20)
        Me.LblCaptureFfu_PhysicalDrive.TabIndex = 45
        Me.LblCaptureFfu_PhysicalDrive.Text = "Physical Drive:"
        '
        'CmbBoxCaptureFfu_Compression
        '
        Me.CmbBoxCaptureFfu_Compression.FormattingEnabled = True
        Me.CmbBoxCaptureFfu_Compression.Items.AddRange(New Object() {"default", "none"})
        Me.CmbBoxCaptureFfu_Compression.Location = New System.Drawing.Point(672, 260)
        Me.CmbBoxCaptureFfu_Compression.Name = "CmbBoxCaptureFfu_Compression"
        Me.CmbBoxCaptureFfu_Compression.Size = New System.Drawing.Size(121, 28)
        Me.CmbBoxCaptureFfu_Compression.TabIndex = 44
        '
        'TxtBoxCaptFfu_TargetFilename
        '
        Me.TxtBoxCaptFfu_TargetFilename.Location = New System.Drawing.Point(247, 164)
        Me.TxtBoxCaptFfu_TargetFilename.Name = "TxtBoxCaptFfu_TargetFilename"
        Me.TxtBoxCaptFfu_TargetFilename.Size = New System.Drawing.Size(300, 26)
        Me.TxtBoxCaptFfu_TargetFilename.TabIndex = 43
        '
        'TxtBoxCaptFfu_TargetFolder
        '
        Me.TxtBoxCaptFfu_TargetFolder.Location = New System.Drawing.Point(247, 132)
        Me.TxtBoxCaptFfu_TargetFolder.Name = "TxtBoxCaptFfu_TargetFolder"
        Me.TxtBoxCaptFfu_TargetFolder.Size = New System.Drawing.Size(300, 26)
        Me.TxtBoxCaptFfu_TargetFolder.TabIndex = 42
        '
        'TxtBoxCaptFfu_PhysicalDrive
        '
        Me.TxtBoxCaptFfu_PhysicalDrive.Location = New System.Drawing.Point(247, 98)
        Me.TxtBoxCaptFfu_PhysicalDrive.Name = "TxtBoxCaptFfu_PhysicalDrive"
        Me.TxtBoxCaptFfu_PhysicalDrive.Size = New System.Drawing.Size(300, 26)
        Me.TxtBoxCaptFfu_PhysicalDrive.TabIndex = 41
        '
        'BtnCaptureFfu_StartCapture
        '
        Me.BtnCaptureFfu_StartCapture.Location = New System.Drawing.Point(672, 62)
        Me.BtnCaptureFfu_StartCapture.Name = "BtnCaptureFfu_StartCapture"
        Me.BtnCaptureFfu_StartCapture.Size = New System.Drawing.Size(148, 46)
        Me.BtnCaptureFfu_StartCapture.TabIndex = 40
        Me.BtnCaptureFfu_StartCapture.Text = "Start Capture"
        Me.BtnCaptureFfu_StartCapture.UseVisualStyleBackColor = True
        '
        'BtnCaptureFfu_SetTargetFolder
        '
        Me.BtnCaptureFfu_SetTargetFolder.Location = New System.Drawing.Point(553, 132)
        Me.BtnCaptureFfu_SetTargetFolder.Name = "BtnCaptureFfu_SetTargetFolder"
        Me.BtnCaptureFfu_SetTargetFolder.Size = New System.Drawing.Size(114, 26)
        Me.BtnCaptureFfu_SetTargetFolder.TabIndex = 39
        Me.BtnCaptureFfu_SetTargetFolder.Text = "Select Target Folder"
        Me.BtnCaptureFfu_SetTargetFolder.UseVisualStyleBackColor = True
        '
        'BtnCaptureFfu_UpdateLogicalDrive
        '
        Me.BtnCaptureFfu_UpdateLogicalDrive.Location = New System.Drawing.Point(331, 62)
        Me.BtnCaptureFfu_UpdateLogicalDrive.Name = "BtnCaptureFfu_UpdateLogicalDrive"
        Me.BtnCaptureFfu_UpdateLogicalDrive.Size = New System.Drawing.Size(216, 30)
        Me.BtnCaptureFfu_UpdateLogicalDrive.TabIndex = 38
        Me.BtnCaptureFfu_UpdateLogicalDrive.Text = "Update List Logical Drive"
        Me.BtnCaptureFfu_UpdateLogicalDrive.UseVisualStyleBackColor = True
        '
        'TabPage15
        '
        Me.TabPage15.Controls.Add(Me.LstBoxApplyFfuImage_LogicalDrive)
        Me.TabPage15.Controls.Add(Me.LblApplyFfuImage_LogicalDrive)
        Me.TabPage15.Controls.Add(Me.LblApplyFfuImage_MotifSFUFile)
        Me.TabPage15.Controls.Add(Me.LblApplyFfuImage_SourceFilename)
        Me.TabPage15.Controls.Add(Me.LblApplyFfuImage_PhysicalDrive)
        Me.TabPage15.Controls.Add(Me.TxtBoxApplyFfuImageFfu_MotifSFUFile)
        Me.TabPage15.Controls.Add(Me.TxtBoxApplyFfuImage_FfuSourceFilename)
        Me.TabPage15.Controls.Add(Me.TxtBoxApplyFfuImage_PhysicalDrive)
        Me.TabPage15.Controls.Add(Me.BtnApplyFfuImage_ApplyFfuImage)
        Me.TabPage15.Controls.Add(Me.BtnApplyFfuImage_SelectFfuFile)
        Me.TabPage15.Controls.Add(Me.BtnApplyFfuImage_UpdateLogicalDrive)
        Me.TabPage15.Location = New System.Drawing.Point(4, 29)
        Me.TabPage15.Name = "TabPage15"
        Me.TabPage15.Size = New System.Drawing.Size(886, 350)
        Me.TabPage15.TabIndex = 14
        Me.TabPage15.Text = "Apply Ffu / Sfu Image"
        Me.TabPage15.UseVisualStyleBackColor = True
        '
        'LstBoxApplyFfuImage_LogicalDrive
        '
        Me.LstBoxApplyFfuImage_LogicalDrive.FormattingEnabled = True
        Me.LstBoxApplyFfuImage_LogicalDrive.ItemHeight = 20
        Me.LstBoxApplyFfuImage_LogicalDrive.Location = New System.Drawing.Point(269, 44)
        Me.LstBoxApplyFfuImage_LogicalDrive.Name = "LstBoxApplyFfuImage_LogicalDrive"
        Me.LstBoxApplyFfuImage_LogicalDrive.Size = New System.Drawing.Size(67, 24)
        Me.LstBoxApplyFfuImage_LogicalDrive.TabIndex = 65
        '
        'LblApplyFfuImage_LogicalDrive
        '
        Me.LblApplyFfuImage_LogicalDrive.AutoSize = True
        Me.LblApplyFfuImage_LogicalDrive.Location = New System.Drawing.Point(93, 51)
        Me.LblApplyFfuImage_LogicalDrive.Name = "LblApplyFfuImage_LogicalDrive"
        Me.LblApplyFfuImage_LogicalDrive.Size = New System.Drawing.Size(103, 20)
        Me.LblApplyFfuImage_LogicalDrive.TabIndex = 64
        Me.LblApplyFfuImage_LogicalDrive.Text = "Logical Drive:"
        '
        'LblApplyFfuImage_MotifSFUFile
        '
        Me.LblApplyFfuImage_MotifSFUFile.AutoSize = True
        Me.LblApplyFfuImage_MotifSFUFile.Location = New System.Drawing.Point(93, 145)
        Me.LblApplyFfuImage_MotifSFUFile.Name = "LblApplyFfuImage_MotifSFUFile"
        Me.LblApplyFfuImage_MotifSFUFile.Size = New System.Drawing.Size(114, 20)
        Me.LblApplyFfuImage_MotifSFUFile.TabIndex = 63
        Me.LblApplyFfuImage_MotifSFUFile.Text = "Motif /SFUFile:"
        '
        'LblApplyFfuImage_SourceFilename
        '
        Me.LblApplyFfuImage_SourceFilename.AutoSize = True
        Me.LblApplyFfuImage_SourceFilename.Location = New System.Drawing.Point(93, 113)
        Me.LblApplyFfuImage_SourceFilename.Name = "LblApplyFfuImage_SourceFilename"
        Me.LblApplyFfuImage_SourceFilename.Size = New System.Drawing.Size(161, 20)
        Me.LblApplyFfuImage_SourceFilename.TabIndex = 62
        Me.LblApplyFfuImage_SourceFilename.Text = "Ffu Source Filename:"
        '
        'LblApplyFfuImage_PhysicalDrive
        '
        Me.LblApplyFfuImage_PhysicalDrive.AutoSize = True
        Me.LblApplyFfuImage_PhysicalDrive.Location = New System.Drawing.Point(93, 84)
        Me.LblApplyFfuImage_PhysicalDrive.Name = "LblApplyFfuImage_PhysicalDrive"
        Me.LblApplyFfuImage_PhysicalDrive.Size = New System.Drawing.Size(110, 20)
        Me.LblApplyFfuImage_PhysicalDrive.TabIndex = 61
        Me.LblApplyFfuImage_PhysicalDrive.Text = "Physical Drive:"
        '
        'TxtBoxApplyFfuImageFfu_MotifSFUFile
        '
        Me.TxtBoxApplyFfuImageFfu_MotifSFUFile.Location = New System.Drawing.Point(269, 138)
        Me.TxtBoxApplyFfuImageFfu_MotifSFUFile.Name = "TxtBoxApplyFfuImageFfu_MotifSFUFile"
        Me.TxtBoxApplyFfuImageFfu_MotifSFUFile.Size = New System.Drawing.Size(300, 26)
        Me.TxtBoxApplyFfuImageFfu_MotifSFUFile.TabIndex = 60
        '
        'TxtBoxApplyFfuImage_FfuSourceFilename
        '
        Me.TxtBoxApplyFfuImage_FfuSourceFilename.Location = New System.Drawing.Point(269, 106)
        Me.TxtBoxApplyFfuImage_FfuSourceFilename.Name = "TxtBoxApplyFfuImage_FfuSourceFilename"
        Me.TxtBoxApplyFfuImage_FfuSourceFilename.Size = New System.Drawing.Size(300, 26)
        Me.TxtBoxApplyFfuImage_FfuSourceFilename.TabIndex = 59
        '
        'TxtBoxApplyFfuImage_PhysicalDrive
        '
        Me.TxtBoxApplyFfuImage_PhysicalDrive.Location = New System.Drawing.Point(269, 74)
        Me.TxtBoxApplyFfuImage_PhysicalDrive.Name = "TxtBoxApplyFfuImage_PhysicalDrive"
        Me.TxtBoxApplyFfuImage_PhysicalDrive.Size = New System.Drawing.Size(300, 26)
        Me.TxtBoxApplyFfuImage_PhysicalDrive.TabIndex = 58
        '
        'BtnApplyFfuImage_ApplyFfuImage
        '
        Me.BtnApplyFfuImage_ApplyFfuImage.Location = New System.Drawing.Point(586, 38)
        Me.BtnApplyFfuImage_ApplyFfuImage.Name = "BtnApplyFfuImage_ApplyFfuImage"
        Me.BtnApplyFfuImage_ApplyFfuImage.Size = New System.Drawing.Size(190, 33)
        Me.BtnApplyFfuImage_ApplyFfuImage.TabIndex = 57
        Me.BtnApplyFfuImage_ApplyFfuImage.Text = "Apply Image"
        Me.BtnApplyFfuImage_ApplyFfuImage.UseVisualStyleBackColor = True
        '
        'BtnApplyFfuImage_SelectFfuFile
        '
        Me.BtnApplyFfuImage_SelectFfuFile.Location = New System.Drawing.Point(586, 106)
        Me.BtnApplyFfuImage_SelectFfuFile.Name = "BtnApplyFfuImage_SelectFfuFile"
        Me.BtnApplyFfuImage_SelectFfuFile.Size = New System.Drawing.Size(136, 26)
        Me.BtnApplyFfuImage_SelectFfuFile.TabIndex = 56
        Me.BtnApplyFfuImage_SelectFfuFile.Text = "Select File"
        Me.BtnApplyFfuImage_SelectFfuFile.UseVisualStyleBackColor = True
        '
        'BtnApplyFfuImage_UpdateLogicalDrive
        '
        Me.BtnApplyFfuImage_UpdateLogicalDrive.Location = New System.Drawing.Point(353, 41)
        Me.BtnApplyFfuImage_UpdateLogicalDrive.Name = "BtnApplyFfuImage_UpdateLogicalDrive"
        Me.BtnApplyFfuImage_UpdateLogicalDrive.Size = New System.Drawing.Size(216, 30)
        Me.BtnApplyFfuImage_UpdateLogicalDrive.TabIndex = 55
        Me.BtnApplyFfuImage_UpdateLogicalDrive.Text = "Update Logical Drive"
        Me.BtnApplyFfuImage_UpdateLogicalDrive.UseVisualStyleBackColor = True
        '
        'TabPage16
        '
        Me.TabPage16.Controls.Add(Me.LblSplitFfu_Warning)
        Me.TabPage16.Controls.Add(Me.BtnSplitFfu_SelectFfuFile)
        Me.TabPage16.Controls.Add(Me.BtnSplitFfu_SelectTargetFolder)
        Me.TabPage16.Controls.Add(Me.LblSplitFfu_TargetFolder)
        Me.TabPage16.Controls.Add(Me.TxtBoxSplitFfu_TargetFolder)
        Me.TabPage16.Controls.Add(Me.BtnSplitFfuImage_StartSplitImage)
        Me.TabPage16.Controls.Add(Me.ChkBoxSplitFfu_CheckIntegrity)
        Me.TabPage16.Controls.Add(Me.LblSplitFfu_SplitFileSize)
        Me.TabPage16.Controls.Add(Me.TxtBoxSplitFfu_SplitFileSize)
        Me.TabPage16.Controls.Add(Me.LblSplitFfu_SFUFilename)
        Me.TabPage16.Controls.Add(Me.LblSplitFfu_FfuFilename)
        Me.TabPage16.Controls.Add(Me.TxtBoxSplitFfu_SFUFilename)
        Me.TabPage16.Controls.Add(Me.TxtBoxSplitFfu_FfuFilename)
        Me.TabPage16.Location = New System.Drawing.Point(4, 29)
        Me.TabPage16.Name = "TabPage16"
        Me.TabPage16.Size = New System.Drawing.Size(886, 350)
        Me.TabPage16.TabIndex = 15
        Me.TabPage16.Text = "Split Ffu Image"
        Me.TabPage16.UseVisualStyleBackColor = True
        '
        'LblSplitFfu_Warning
        '
        Me.LblSplitFfu_Warning.AutoSize = True
        Me.LblSplitFfu_Warning.Location = New System.Drawing.Point(3, 219)
        Me.LblSplitFfu_Warning.Name = "LblSplitFfu_Warning"
        Me.LblSplitFfu_Warning.Size = New System.Drawing.Size(618, 20)
        Me.LblSplitFfu_Warning.TabIndex = 66
        Me.LblSplitFfu_Warning.Text = "Warning: Actually, there is a bug with this function, you can use Split Image to " &
    "resolve it"
        '
        'BtnSplitFfu_SelectFfuFile
        '
        Me.BtnSplitFfu_SelectFfuFile.Location = New System.Drawing.Point(540, 30)
        Me.BtnSplitFfu_SelectFfuFile.Name = "BtnSplitFfu_SelectFfuFile"
        Me.BtnSplitFfu_SelectFfuFile.Size = New System.Drawing.Size(136, 26)
        Me.BtnSplitFfu_SelectFfuFile.TabIndex = 64
        Me.BtnSplitFfu_SelectFfuFile.Text = "Select Ffu File"
        Me.BtnSplitFfu_SelectFfuFile.UseVisualStyleBackColor = True
        '
        'BtnSplitFfu_SelectTargetFolder
        '
        Me.BtnSplitFfu_SelectTargetFolder.Location = New System.Drawing.Point(540, 68)
        Me.BtnSplitFfu_SelectTargetFolder.Name = "BtnSplitFfu_SelectTargetFolder"
        Me.BtnSplitFfu_SelectTargetFolder.Size = New System.Drawing.Size(136, 26)
        Me.BtnSplitFfu_SelectTargetFolder.TabIndex = 63
        Me.BtnSplitFfu_SelectTargetFolder.Text = "Select Target Folder"
        Me.BtnSplitFfu_SelectTargetFolder.UseVisualStyleBackColor = True
        '
        'LblSplitFfu_TargetFolder
        '
        Me.LblSplitFfu_TargetFolder.AutoSize = True
        Me.LblSplitFfu_TargetFolder.Location = New System.Drawing.Point(26, 68)
        Me.LblSplitFfu_TargetFolder.Name = "LblSplitFfu_TargetFolder"
        Me.LblSplitFfu_TargetFolder.Size = New System.Drawing.Size(108, 20)
        Me.LblSplitFfu_TargetFolder.TabIndex = 62
        Me.LblSplitFfu_TargetFolder.Text = "Target Folder:"
        '
        'TxtBoxSplitFfu_TargetFolder
        '
        Me.TxtBoxSplitFfu_TargetFolder.Location = New System.Drawing.Point(223, 65)
        Me.TxtBoxSplitFfu_TargetFolder.Name = "TxtBoxSplitFfu_TargetFolder"
        Me.TxtBoxSplitFfu_TargetFolder.Size = New System.Drawing.Size(303, 26)
        Me.TxtBoxSplitFfu_TargetFolder.TabIndex = 61
        '
        'BtnSplitFfuImage_StartSplitImage
        '
        Me.BtnSplitFfuImage_StartSplitImage.Location = New System.Drawing.Point(700, 30)
        Me.BtnSplitFfuImage_StartSplitImage.Name = "BtnSplitFfuImage_StartSplitImage"
        Me.BtnSplitFfuImage_StartSplitImage.Size = New System.Drawing.Size(136, 53)
        Me.BtnSplitFfuImage_StartSplitImage.TabIndex = 60
        Me.BtnSplitFfuImage_StartSplitImage.Text = "Start Split Image"
        Me.BtnSplitFfuImage_StartSplitImage.UseVisualStyleBackColor = True
        '
        'ChkBoxSplitFfu_CheckIntegrity
        '
        Me.ChkBoxSplitFfu_CheckIntegrity.AutoSize = True
        Me.ChkBoxSplitFfu_CheckIntegrity.Location = New System.Drawing.Point(543, 138)
        Me.ChkBoxSplitFfu_CheckIntegrity.Name = "ChkBoxSplitFfu_CheckIntegrity"
        Me.ChkBoxSplitFfu_CheckIntegrity.Size = New System.Drawing.Size(134, 24)
        Me.ChkBoxSplitFfu_CheckIntegrity.TabIndex = 59
        Me.ChkBoxSplitFfu_CheckIntegrity.Text = "/CheckIntegrity"
        Me.ChkBoxSplitFfu_CheckIntegrity.UseVisualStyleBackColor = True
        '
        'LblSplitFfu_SplitFileSize
        '
        Me.LblSplitFfu_SplitFileSize.AutoSize = True
        Me.LblSplitFfu_SplitFileSize.Location = New System.Drawing.Point(26, 132)
        Me.LblSplitFfu_SplitFileSize.Name = "LblSplitFfu_SplitFileSize"
        Me.LblSplitFfu_SplitFileSize.Size = New System.Drawing.Size(144, 20)
        Me.LblSplitFfu_SplitFileSize.TabIndex = 58
        Me.LblSplitFfu_SplitFileSize.Text = "Split File Size (Mo):"
        '
        'TxtBoxSplitFfu_SplitFileSize
        '
        Me.TxtBoxSplitFfu_SplitFileSize.Location = New System.Drawing.Point(223, 129)
        Me.TxtBoxSplitFfu_SplitFileSize.Name = "TxtBoxSplitFfu_SplitFileSize"
        Me.TxtBoxSplitFfu_SplitFileSize.Size = New System.Drawing.Size(303, 26)
        Me.TxtBoxSplitFfu_SplitFileSize.TabIndex = 57
        '
        'LblSplitFfu_SFUFilename
        '
        Me.LblSplitFfu_SFUFilename.AutoSize = True
        Me.LblSplitFfu_SFUFilename.Location = New System.Drawing.Point(26, 100)
        Me.LblSplitFfu_SFUFilename.Name = "LblSplitFfu_SFUFilename"
        Me.LblSplitFfu_SFUFilename.Size = New System.Drawing.Size(115, 20)
        Me.LblSplitFfu_SFUFilename.TabIndex = 56
        Me.LblSplitFfu_SFUFilename.Text = "SFU Filename:"
        '
        'LblSplitFfu_FfuFilename
        '
        Me.LblSplitFfu_FfuFilename.AutoSize = True
        Me.LblSplitFfu_FfuFilename.Location = New System.Drawing.Point(26, 33)
        Me.LblSplitFfu_FfuFilename.Name = "LblSplitFfu_FfuFilename"
        Me.LblSplitFfu_FfuFilename.Size = New System.Drawing.Size(106, 20)
        Me.LblSplitFfu_FfuFilename.TabIndex = 55
        Me.LblSplitFfu_FfuFilename.Text = "Ffu Filename:"
        '
        'TxtBoxSplitFfu_SFUFilename
        '
        Me.TxtBoxSplitFfu_SFUFilename.Location = New System.Drawing.Point(223, 97)
        Me.TxtBoxSplitFfu_SFUFilename.Name = "TxtBoxSplitFfu_SFUFilename"
        Me.TxtBoxSplitFfu_SFUFilename.Size = New System.Drawing.Size(303, 26)
        Me.TxtBoxSplitFfu_SFUFilename.TabIndex = 54
        '
        'TxtBoxSplitFfu_FfuFilename
        '
        Me.TxtBoxSplitFfu_FfuFilename.Location = New System.Drawing.Point(223, 30)
        Me.TxtBoxSplitFfu_FfuFilename.Name = "TxtBoxSplitFfu_FfuFilename"
        Me.TxtBoxSplitFfu_FfuFilename.Size = New System.Drawing.Size(303, 26)
        Me.TxtBoxSplitFfu_FfuFilename.TabIndex = 53
        '
        'TabPage17
        '
        Me.TabPage17.Controls.Add(Me.BtnAppAssocServ_GetMountedImageInfo)
        Me.TabPage17.Controls.Add(Me.Button3)
        Me.TabPage17.Controls.Add(Me.BtnDefaultAppAssocServ_RefreshMountedImage)
        Me.TabPage17.Controls.Add(Me.LblBtnDefaultAppAssocServ_UseMountedImage)
        Me.TabPage17.Controls.Add(Me.CmbBoxDefaultAppAssocServicing_UseImageMounted)
        Me.TabPage17.Controls.Add(Me.LblDefaultAppAssocServ_Warning)
        Me.TabPage17.Controls.Add(Me.LblLblDefaultAppAssocServ_ExportFilename)
        Me.TabPage17.Controls.Add(Me.TxtBoxDefaultAppAssocServ_ExportFilenameXML)
        Me.TabPage17.Controls.Add(Me.BtnDefaultAppAssocServ_ChooseFolder)
        Me.TabPage17.Controls.Add(Me.LblDefaultAppAssocServ_ExportFolder)
        Me.TabPage17.Controls.Add(Me.TxtBoxDefaultAppAssocServ_ExportFolder)
        Me.TabPage17.Controls.Add(Me.BtnDefaultAppAssocServ_ChooseFile)
        Me.TabPage17.Controls.Add(Me.LblDefaultAppAssocServ_ImportFilename)
        Me.TabPage17.Controls.Add(Me.TxtBoxDefaultAppAssocServ_ImportFilenameXML)
        Me.TabPage17.Controls.Add(Me.BtnDefaultAppAssocServ_Remove)
        Me.TabPage17.Controls.Add(Me.BtnDefaultAppAssocServ_Export)
        Me.TabPage17.Controls.Add(Me.BtnDefaultAppAssocServ_Import)
        Me.TabPage17.Controls.Add(Me.ChkBoxDefaultAppAssocServ_Online)
        Me.TabPage17.Controls.Add(Me.BtnDefaultAppAssocServ_GetDefaultAppAssoc)
        Me.TabPage17.Location = New System.Drawing.Point(4, 29)
        Me.TabPage17.Name = "TabPage17"
        Me.TabPage17.Size = New System.Drawing.Size(886, 350)
        Me.TabPage17.TabIndex = 16
        Me.TabPage17.Text = "Default Application Association Servicing"
        Me.TabPage17.UseVisualStyleBackColor = True
        '
        'BtnAppAssocServ_GetMountedImageInfo
        '
        Me.BtnAppAssocServ_GetMountedImageInfo.Location = New System.Drawing.Point(709, 19)
        Me.BtnAppAssocServ_GetMountedImageInfo.Name = "BtnAppAssocServ_GetMountedImageInfo"
        Me.BtnAppAssocServ_GetMountedImageInfo.Size = New System.Drawing.Size(161, 64)
        Me.BtnAppAssocServ_GetMountedImageInfo.TabIndex = 89
        Me.BtnAppAssocServ_GetMountedImageInfo.Text = "Get Mounted Image Info"
        Me.BtnAppAssocServ_GetMountedImageInfo.UseVisualStyleBackColor = True
        '
        'Button3
        '
        Me.Button3.Location = New System.Drawing.Point(743, 19)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(127, 64)
        Me.Button3.TabIndex = 90
        Me.Button3.Text = "Get Mounted Image Info"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'BtnDefaultAppAssocServ_RefreshMountedImage
        '
        Me.BtnDefaultAppAssocServ_RefreshMountedImage.Location = New System.Drawing.Point(253, 19)
        Me.BtnDefaultAppAssocServ_RefreshMountedImage.Name = "BtnDefaultAppAssocServ_RefreshMountedImage"
        Me.BtnDefaultAppAssocServ_RefreshMountedImage.Size = New System.Drawing.Size(221, 32)
        Me.BtnDefaultAppAssocServ_RefreshMountedImage.TabIndex = 88
        Me.BtnDefaultAppAssocServ_RefreshMountedImage.Text = "Refresh mounted image"
        Me.BtnDefaultAppAssocServ_RefreshMountedImage.UseVisualStyleBackColor = True
        '
        'LblBtnDefaultAppAssocServ_UseMountedImage
        '
        Me.LblBtnDefaultAppAssocServ_UseMountedImage.AutoSize = True
        Me.LblBtnDefaultAppAssocServ_UseMountedImage.Location = New System.Drawing.Point(5, 58)
        Me.LblBtnDefaultAppAssocServ_UseMountedImage.Name = "LblBtnDefaultAppAssocServ_UseMountedImage"
        Me.LblBtnDefaultAppAssocServ_UseMountedImage.Size = New System.Drawing.Size(158, 20)
        Me.LblBtnDefaultAppAssocServ_UseMountedImage.TabIndex = 87
        Me.LblBtnDefaultAppAssocServ_UseMountedImage.Text = "Use Image Mounted:"
        '
        'CmbBoxDefaultAppAssocServicing_UseImageMounted
        '
        Me.CmbBoxDefaultAppAssocServicing_UseImageMounted.FormattingEnabled = True
        Me.CmbBoxDefaultAppAssocServicing_UseImageMounted.Location = New System.Drawing.Point(181, 57)
        Me.CmbBoxDefaultAppAssocServicing_UseImageMounted.Name = "CmbBoxDefaultAppAssocServicing_UseImageMounted"
        Me.CmbBoxDefaultAppAssocServicing_UseImageMounted.Size = New System.Drawing.Size(349, 28)
        Me.CmbBoxDefaultAppAssocServicing_UseImageMounted.TabIndex = 86
        '
        'LblDefaultAppAssocServ_Warning
        '
        Me.LblDefaultAppAssocServ_Warning.AutoSize = True
        Me.LblDefaultAppAssocServ_Warning.Location = New System.Drawing.Point(318, 162)
        Me.LblDefaultAppAssocServ_Warning.Name = "LblDefaultAppAssocServ_Warning"
        Me.LblDefaultAppAssocServ_Warning.Size = New System.Drawing.Size(401, 20)
        Me.LblDefaultAppAssocServ_Warning.TabIndex = 36
        Me.LblDefaultAppAssocServ_Warning.Text = "(Warning: Use export commande only on Online mode !)"
        '
        'LblLblDefaultAppAssocServ_ExportFilename
        '
        Me.LblLblDefaultAppAssocServ_ExportFilename.AutoSize = True
        Me.LblLblDefaultAppAssocServ_ExportFilename.Location = New System.Drawing.Point(5, 162)
        Me.LblLblDefaultAppAssocServ_ExportFilename.Name = "LblLblDefaultAppAssocServ_ExportFilename"
        Me.LblLblDefaultAppAssocServ_ExportFilename.Size = New System.Drawing.Size(179, 20)
        Me.LblLblDefaultAppAssocServ_ExportFilename.TabIndex = 35
        Me.LblLblDefaultAppAssocServ_ExportFilename.Text = "Export Filename (.XML):"
        '
        'TxtBoxDefaultAppAssocServ_ExportFilenameXML
        '
        Me.TxtBoxDefaultAppAssocServ_ExportFilenameXML.Location = New System.Drawing.Point(9, 186)
        Me.TxtBoxDefaultAppAssocServ_ExportFilenameXML.Name = "TxtBoxDefaultAppAssocServ_ExportFilenameXML"
        Me.TxtBoxDefaultAppAssocServ_ExportFilenameXML.Size = New System.Drawing.Size(307, 26)
        Me.TxtBoxDefaultAppAssocServ_ExportFilenameXML.TabIndex = 34
        '
        'BtnDefaultAppAssocServ_ChooseFolder
        '
        Me.BtnDefaultAppAssocServ_ChooseFolder.Location = New System.Drawing.Point(322, 133)
        Me.BtnDefaultAppAssocServ_ChooseFolder.Name = "BtnDefaultAppAssocServ_ChooseFolder"
        Me.BtnDefaultAppAssocServ_ChooseFolder.Size = New System.Drawing.Size(125, 26)
        Me.BtnDefaultAppAssocServ_ChooseFolder.TabIndex = 33
        Me.BtnDefaultAppAssocServ_ChooseFolder.Text = "Choose Folder"
        Me.BtnDefaultAppAssocServ_ChooseFolder.UseVisualStyleBackColor = True
        '
        'LblDefaultAppAssocServ_ExportFolder
        '
        Me.LblDefaultAppAssocServ_ExportFolder.AutoSize = True
        Me.LblDefaultAppAssocServ_ExportFolder.Location = New System.Drawing.Point(4, 106)
        Me.LblDefaultAppAssocServ_ExportFolder.Name = "LblDefaultAppAssocServ_ExportFolder"
        Me.LblDefaultAppAssocServ_ExportFolder.Size = New System.Drawing.Size(108, 20)
        Me.LblDefaultAppAssocServ_ExportFolder.TabIndex = 31
        Me.LblDefaultAppAssocServ_ExportFolder.Text = "Export Folder:"
        '
        'TxtBoxDefaultAppAssocServ_ExportFolder
        '
        Me.TxtBoxDefaultAppAssocServ_ExportFolder.Location = New System.Drawing.Point(9, 133)
        Me.TxtBoxDefaultAppAssocServ_ExportFolder.Name = "TxtBoxDefaultAppAssocServ_ExportFolder"
        Me.TxtBoxDefaultAppAssocServ_ExportFolder.Size = New System.Drawing.Size(307, 26)
        Me.TxtBoxDefaultAppAssocServ_ExportFolder.TabIndex = 32
        '
        'BtnDefaultAppAssocServ_ChooseFile
        '
        Me.BtnDefaultAppAssocServ_ChooseFile.Location = New System.Drawing.Point(321, 255)
        Me.BtnDefaultAppAssocServ_ChooseFile.Name = "BtnDefaultAppAssocServ_ChooseFile"
        Me.BtnDefaultAppAssocServ_ChooseFile.Size = New System.Drawing.Size(125, 30)
        Me.BtnDefaultAppAssocServ_ChooseFile.TabIndex = 30
        Me.BtnDefaultAppAssocServ_ChooseFile.Text = "Choose File"
        Me.BtnDefaultAppAssocServ_ChooseFile.UseVisualStyleBackColor = True
        '
        'LblDefaultAppAssocServ_ImportFilename
        '
        Me.LblDefaultAppAssocServ_ImportFilename.AutoSize = True
        Me.LblDefaultAppAssocServ_ImportFilename.Location = New System.Drawing.Point(3, 232)
        Me.LblDefaultAppAssocServ_ImportFilename.Name = "LblDefaultAppAssocServ_ImportFilename"
        Me.LblDefaultAppAssocServ_ImportFilename.Size = New System.Drawing.Size(179, 20)
        Me.LblDefaultAppAssocServ_ImportFilename.TabIndex = 28
        Me.LblDefaultAppAssocServ_ImportFilename.Text = "Import Filename (.XML):"
        '
        'TxtBoxDefaultAppAssocServ_ImportFilenameXML
        '
        Me.TxtBoxDefaultAppAssocServ_ImportFilenameXML.Location = New System.Drawing.Point(8, 259)
        Me.TxtBoxDefaultAppAssocServ_ImportFilenameXML.Name = "TxtBoxDefaultAppAssocServ_ImportFilenameXML"
        Me.TxtBoxDefaultAppAssocServ_ImportFilenameXML.Size = New System.Drawing.Size(307, 26)
        Me.TxtBoxDefaultAppAssocServ_ImportFilenameXML.TabIndex = 29
        '
        'BtnDefaultAppAssocServ_Remove
        '
        Me.BtnDefaultAppAssocServ_Remove.Location = New System.Drawing.Point(468, 291)
        Me.BtnDefaultAppAssocServ_Remove.Name = "BtnDefaultAppAssocServ_Remove"
        Me.BtnDefaultAppAssocServ_Remove.Size = New System.Drawing.Size(402, 30)
        Me.BtnDefaultAppAssocServ_Remove.TabIndex = 27
        Me.BtnDefaultAppAssocServ_Remove.Text = "Remove Default Application Associations"
        Me.BtnDefaultAppAssocServ_Remove.UseVisualStyleBackColor = True
        '
        'BtnDefaultAppAssocServ_Export
        '
        Me.BtnDefaultAppAssocServ_Export.Location = New System.Drawing.Point(468, 129)
        Me.BtnDefaultAppAssocServ_Export.Name = "BtnDefaultAppAssocServ_Export"
        Me.BtnDefaultAppAssocServ_Export.Size = New System.Drawing.Size(402, 30)
        Me.BtnDefaultAppAssocServ_Export.TabIndex = 26
        Me.BtnDefaultAppAssocServ_Export.Text = "Export Default Application Associations"
        Me.BtnDefaultAppAssocServ_Export.UseVisualStyleBackColor = True
        '
        'BtnDefaultAppAssocServ_Import
        '
        Me.BtnDefaultAppAssocServ_Import.Location = New System.Drawing.Point(468, 255)
        Me.BtnDefaultAppAssocServ_Import.Name = "BtnDefaultAppAssocServ_Import"
        Me.BtnDefaultAppAssocServ_Import.Size = New System.Drawing.Size(402, 30)
        Me.BtnDefaultAppAssocServ_Import.TabIndex = 25
        Me.BtnDefaultAppAssocServ_Import.Text = "Import Default Application Associations"
        Me.BtnDefaultAppAssocServ_Import.UseVisualStyleBackColor = True
        '
        'ChkBoxDefaultAppAssocServ_Online
        '
        Me.ChkBoxDefaultAppAssocServ_Online.AutoSize = True
        Me.ChkBoxDefaultAppAssocServ_Online.Location = New System.Drawing.Point(758, 323)
        Me.ChkBoxDefaultAppAssocServ_Online.Name = "ChkBoxDefaultAppAssocServ_Online"
        Me.ChkBoxDefaultAppAssocServ_Online.Size = New System.Drawing.Size(125, 24)
        Me.ChkBoxDefaultAppAssocServ_Online.TabIndex = 24
        Me.ChkBoxDefaultAppAssocServ_Online.Text = "/Online option"
        Me.ChkBoxDefaultAppAssocServ_Online.UseVisualStyleBackColor = False
        '
        'BtnDefaultAppAssocServ_GetDefaultAppAssoc
        '
        Me.BtnDefaultAppAssocServ_GetDefaultAppAssoc.Location = New System.Drawing.Point(468, 89)
        Me.BtnDefaultAppAssocServ_GetDefaultAppAssoc.Name = "BtnDefaultAppAssocServ_GetDefaultAppAssoc"
        Me.BtnDefaultAppAssocServ_GetDefaultAppAssoc.Size = New System.Drawing.Size(402, 30)
        Me.BtnDefaultAppAssocServ_GetDefaultAppAssoc.TabIndex = 0
        Me.BtnDefaultAppAssocServ_GetDefaultAppAssoc.Text = "Get Default Application Associations"
        Me.BtnDefaultAppAssocServ_GetDefaultAppAssoc.UseVisualStyleBackColor = True
        '
        'TabPage18
        '
        Me.TabPage18.Controls.Add(Me.ChkBoxCapPackServ_IncludeImageCapabilities)
        Me.TabPage18.Controls.Add(Me.BtnCapPackServ_SelectTarget)
        Me.TabPage18.Controls.Add(Me.BtnCapPackServ_SelectSource)
        Me.TabPage18.Controls.Add(Me.BtnCapPackServ_GetMountedImageInfo)
        Me.TabPage18.Controls.Add(Me.Button1)
        Me.TabPage18.Controls.Add(Me.BtnCapPackServ_RefreshMountedImage)
        Me.TabPage18.Controls.Add(Me.LblCapPackServ_UseMountedImage)
        Me.TabPage18.Controls.Add(Me.CmbBoxCapPackServicing_UseImageMounted)
        Me.TabPage18.Controls.Add(Me.ChkBoxCapPackServ_Online)
        Me.TabPage18.Controls.Add(Me.BtnCapPackServ_GetCap)
        Me.TabPage18.Controls.Add(Me.BtnCapPackServ_RemoveCap)
        Me.TabPage18.Controls.Add(Me.BtnCapPackServ_GetCapInfo)
        Me.TabPage18.Controls.Add(Me.BtnCapPackServ_ExportSource)
        Me.TabPage18.Controls.Add(Me.LblCapPackServ_TargetExportSource)
        Me.TabPage18.Controls.Add(Me.TxtBoxCapPackServ_Target)
        Me.TabPage18.Controls.Add(Me.LblCapPackServ_SourceExportSource)
        Me.TabPage18.Controls.Add(Me.TxtBoxCapPackServ_Source)
        Me.TabPage18.Controls.Add(Me.ChkBoxCapPackServ_LimitAccess)
        Me.TabPage18.Controls.Add(Me.BtnCapPackServ_AddCapability)
        Me.TabPage18.Controls.Add(Me.LblCapPackServ_CapabilityNameAddCap)
        Me.TabPage18.Controls.Add(Me.TxtBoxCapPackServ_CapabilityName)
        Me.TabPage18.Location = New System.Drawing.Point(4, 29)
        Me.TabPage18.Name = "TabPage18"
        Me.TabPage18.Size = New System.Drawing.Size(886, 350)
        Me.TabPage18.TabIndex = 17
        Me.TabPage18.Text = "Capabilities Package Servicing"
        Me.TabPage18.UseVisualStyleBackColor = True
        '
        'ChkBoxCapPackServ_IncludeImageCapabilities
        '
        Me.ChkBoxCapPackServ_IncludeImageCapabilities.AutoSize = True
        Me.ChkBoxCapPackServ_IncludeImageCapabilities.Location = New System.Drawing.Point(181, 228)
        Me.ChkBoxCapPackServ_IncludeImageCapabilities.Name = "ChkBoxCapPackServ_IncludeImageCapabilities"
        Me.ChkBoxCapPackServ_IncludeImageCapabilities.Size = New System.Drawing.Size(210, 24)
        Me.ChkBoxCapPackServ_IncludeImageCapabilities.TabIndex = 88
        Me.ChkBoxCapPackServ_IncludeImageCapabilities.Text = "/IncludeImageCapabilities"
        Me.ChkBoxCapPackServ_IncludeImageCapabilities.UseVisualStyleBackColor = True
        '
        'BtnCapPackServ_SelectTarget
        '
        Me.BtnCapPackServ_SelectTarget.Location = New System.Drawing.Point(700, 189)
        Me.BtnCapPackServ_SelectTarget.Name = "BtnCapPackServ_SelectTarget"
        Me.BtnCapPackServ_SelectTarget.Size = New System.Drawing.Size(160, 26)
        Me.BtnCapPackServ_SelectTarget.TabIndex = 87
        Me.BtnCapPackServ_SelectTarget.Text = "Select target"
        Me.BtnCapPackServ_SelectTarget.UseVisualStyleBackColor = True
        '
        'BtnCapPackServ_SelectSource
        '
        Me.BtnCapPackServ_SelectSource.Location = New System.Drawing.Point(700, 142)
        Me.BtnCapPackServ_SelectSource.Name = "BtnCapPackServ_SelectSource"
        Me.BtnCapPackServ_SelectSource.Size = New System.Drawing.Size(160, 26)
        Me.BtnCapPackServ_SelectSource.TabIndex = 86
        Me.BtnCapPackServ_SelectSource.Text = "Select source"
        Me.BtnCapPackServ_SelectSource.UseVisualStyleBackColor = True
        '
        'BtnCapPackServ_GetMountedImageInfo
        '
        Me.BtnCapPackServ_GetMountedImageInfo.Location = New System.Drawing.Point(700, 22)
        Me.BtnCapPackServ_GetMountedImageInfo.Name = "BtnCapPackServ_GetMountedImageInfo"
        Me.BtnCapPackServ_GetMountedImageInfo.Size = New System.Drawing.Size(160, 64)
        Me.BtnCapPackServ_GetMountedImageInfo.TabIndex = 85
        Me.BtnCapPackServ_GetMountedImageInfo.Text = "Get Mounted Image Info"
        Me.BtnCapPackServ_GetMountedImageInfo.UseVisualStyleBackColor = True
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(733, 22)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(127, 64)
        Me.Button1.TabIndex = 85
        Me.Button1.Text = "Get Mounted Image Info"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'BtnCapPackServ_RefreshMountedImage
        '
        Me.BtnCapPackServ_RefreshMountedImage.Location = New System.Drawing.Point(273, 3)
        Me.BtnCapPackServ_RefreshMountedImage.Name = "BtnCapPackServ_RefreshMountedImage"
        Me.BtnCapPackServ_RefreshMountedImage.Size = New System.Drawing.Size(221, 32)
        Me.BtnCapPackServ_RefreshMountedImage.TabIndex = 84
        Me.BtnCapPackServ_RefreshMountedImage.Text = "Refresh mounted image"
        Me.BtnCapPackServ_RefreshMountedImage.UseVisualStyleBackColor = True
        '
        'LblCapPackServ_UseMountedImage
        '
        Me.LblCapPackServ_UseMountedImage.AutoSize = True
        Me.LblCapPackServ_UseMountedImage.Location = New System.Drawing.Point(14, 44)
        Me.LblCapPackServ_UseMountedImage.Name = "LblCapPackServ_UseMountedImage"
        Me.LblCapPackServ_UseMountedImage.Size = New System.Drawing.Size(158, 20)
        Me.LblCapPackServ_UseMountedImage.TabIndex = 83
        Me.LblCapPackServ_UseMountedImage.Text = "Use Image Mounted:"
        '
        'CmbBoxCapPackServicing_UseImageMounted
        '
        Me.CmbBoxCapPackServicing_UseImageMounted.FormattingEnabled = True
        Me.CmbBoxCapPackServicing_UseImageMounted.Location = New System.Drawing.Point(181, 41)
        Me.CmbBoxCapPackServicing_UseImageMounted.Name = "CmbBoxCapPackServicing_UseImageMounted"
        Me.CmbBoxCapPackServicing_UseImageMounted.Size = New System.Drawing.Size(369, 28)
        Me.CmbBoxCapPackServicing_UseImageMounted.TabIndex = 82
        '
        'ChkBoxCapPackServ_Online
        '
        Me.ChkBoxCapPackServ_Online.AutoSize = True
        Me.ChkBoxCapPackServ_Online.Location = New System.Drawing.Point(758, 323)
        Me.ChkBoxCapPackServ_Online.Name = "ChkBoxCapPackServ_Online"
        Me.ChkBoxCapPackServ_Online.Size = New System.Drawing.Size(125, 24)
        Me.ChkBoxCapPackServ_Online.TabIndex = 56
        Me.ChkBoxCapPackServ_Online.Text = "/Online option"
        Me.ChkBoxCapPackServ_Online.UseVisualStyleBackColor = False
        '
        'BtnCapPackServ_GetCap
        '
        Me.BtnCapPackServ_GetCap.Location = New System.Drawing.Point(508, 226)
        Me.BtnCapPackServ_GetCap.Name = "BtnCapPackServ_GetCap"
        Me.BtnCapPackServ_GetCap.Size = New System.Drawing.Size(168, 26)
        Me.BtnCapPackServ_GetCap.TabIndex = 55
        Me.BtnCapPackServ_GetCap.Text = "Get Capability"
        Me.BtnCapPackServ_GetCap.UseVisualStyleBackColor = True
        '
        'BtnCapPackServ_RemoveCap
        '
        Me.BtnCapPackServ_RemoveCap.Location = New System.Drawing.Point(692, 272)
        Me.BtnCapPackServ_RemoveCap.Name = "BtnCapPackServ_RemoveCap"
        Me.BtnCapPackServ_RemoveCap.Size = New System.Drawing.Size(168, 26)
        Me.BtnCapPackServ_RemoveCap.TabIndex = 54
        Me.BtnCapPackServ_RemoveCap.Text = "Remove Capability"
        Me.BtnCapPackServ_RemoveCap.UseVisualStyleBackColor = True
        '
        'BtnCapPackServ_GetCapInfo
        '
        Me.BtnCapPackServ_GetCapInfo.Location = New System.Drawing.Point(692, 226)
        Me.BtnCapPackServ_GetCapInfo.Name = "BtnCapPackServ_GetCapInfo"
        Me.BtnCapPackServ_GetCapInfo.Size = New System.Drawing.Size(168, 26)
        Me.BtnCapPackServ_GetCapInfo.TabIndex = 53
        Me.BtnCapPackServ_GetCapInfo.Text = "Get Capability Info"
        Me.BtnCapPackServ_GetCapInfo.UseVisualStyleBackColor = True
        '
        'BtnCapPackServ_ExportSource
        '
        Me.BtnCapPackServ_ExportSource.Location = New System.Drawing.Point(508, 306)
        Me.BtnCapPackServ_ExportSource.Name = "BtnCapPackServ_ExportSource"
        Me.BtnCapPackServ_ExportSource.Size = New System.Drawing.Size(168, 26)
        Me.BtnCapPackServ_ExportSource.TabIndex = 48
        Me.BtnCapPackServ_ExportSource.Text = "Export Source"
        Me.BtnCapPackServ_ExportSource.UseVisualStyleBackColor = True
        '
        'LblCapPackServ_TargetExportSource
        '
        Me.LblCapPackServ_TargetExportSource.AutoSize = True
        Me.LblCapPackServ_TargetExportSource.Location = New System.Drawing.Point(14, 192)
        Me.LblCapPackServ_TargetExportSource.Name = "LblCapPackServ_TargetExportSource"
        Me.LblCapPackServ_TargetExportSource.Size = New System.Drawing.Size(63, 20)
        Me.LblCapPackServ_TargetExportSource.TabIndex = 46
        Me.LblCapPackServ_TargetExportSource.Text = "/Target:"
        '
        'TxtBoxCapPackServ_Target
        '
        Me.TxtBoxCapPackServ_Target.Location = New System.Drawing.Point(181, 189)
        Me.TxtBoxCapPackServ_Target.Name = "TxtBoxCapPackServ_Target"
        Me.TxtBoxCapPackServ_Target.Size = New System.Drawing.Size(503, 26)
        Me.TxtBoxCapPackServ_Target.TabIndex = 47
        '
        'LblCapPackServ_SourceExportSource
        '
        Me.LblCapPackServ_SourceExportSource.AutoSize = True
        Me.LblCapPackServ_SourceExportSource.Location = New System.Drawing.Point(14, 142)
        Me.LblCapPackServ_SourceExportSource.Name = "LblCapPackServ_SourceExportSource"
        Me.LblCapPackServ_SourceExportSource.Size = New System.Drawing.Size(68, 20)
        Me.LblCapPackServ_SourceExportSource.TabIndex = 44
        Me.LblCapPackServ_SourceExportSource.Text = "/Source:"
        '
        'TxtBoxCapPackServ_Source
        '
        Me.TxtBoxCapPackServ_Source.Location = New System.Drawing.Point(181, 142)
        Me.TxtBoxCapPackServ_Source.Name = "TxtBoxCapPackServ_Source"
        Me.TxtBoxCapPackServ_Source.Size = New System.Drawing.Size(503, 26)
        Me.TxtBoxCapPackServ_Source.TabIndex = 45
        '
        'ChkBoxCapPackServ_LimitAccess
        '
        Me.ChkBoxCapPackServ_LimitAccess.AutoSize = True
        Me.ChkBoxCapPackServ_LimitAccess.Location = New System.Drawing.Point(700, 99)
        Me.ChkBoxCapPackServ_LimitAccess.Name = "ChkBoxCapPackServ_LimitAccess"
        Me.ChkBoxCapPackServ_LimitAccess.Size = New System.Drawing.Size(117, 24)
        Me.ChkBoxCapPackServ_LimitAccess.TabIndex = 41
        Me.ChkBoxCapPackServ_LimitAccess.Text = "/LimitAccess"
        Me.ChkBoxCapPackServ_LimitAccess.UseVisualStyleBackColor = True
        '
        'BtnCapPackServ_AddCapability
        '
        Me.BtnCapPackServ_AddCapability.Location = New System.Drawing.Point(508, 272)
        Me.BtnCapPackServ_AddCapability.Name = "BtnCapPackServ_AddCapability"
        Me.BtnCapPackServ_AddCapability.Size = New System.Drawing.Size(168, 26)
        Me.BtnCapPackServ_AddCapability.TabIndex = 36
        Me.BtnCapPackServ_AddCapability.Text = "Add Capability"
        Me.BtnCapPackServ_AddCapability.UseVisualStyleBackColor = True
        '
        'LblCapPackServ_CapabilityNameAddCap
        '
        Me.LblCapPackServ_CapabilityNameAddCap.AutoSize = True
        Me.LblCapPackServ_CapabilityNameAddCap.Location = New System.Drawing.Point(14, 97)
        Me.LblCapPackServ_CapabilityNameAddCap.Name = "LblCapPackServ_CapabilityNameAddCap"
        Me.LblCapPackServ_CapabilityNameAddCap.Size = New System.Drawing.Size(127, 20)
        Me.LblCapPackServ_CapabilityNameAddCap.TabIndex = 34
        Me.LblCapPackServ_CapabilityNameAddCap.Text = "Capability Name:"
        '
        'TxtBoxCapPackServ_CapabilityName
        '
        Me.TxtBoxCapPackServ_CapabilityName.Location = New System.Drawing.Point(181, 97)
        Me.TxtBoxCapPackServ_CapabilityName.Name = "TxtBoxCapPackServ_CapabilityName"
        Me.TxtBoxCapPackServ_CapabilityName.Size = New System.Drawing.Size(503, 26)
        Me.TxtBoxCapPackServ_CapabilityName.TabIndex = 35
        '
        'TabPage19
        '
        Me.TabPage19.Controls.Add(Me.BtnCleanupImage_GetMountedImageInfo)
        Me.TabPage19.Controls.Add(Me.BtnCleanupImage_RefreshMountedImage)
        Me.TabPage19.Controls.Add(Me.LblCleanupImage_UseMountedImage)
        Me.TabPage19.Controls.Add(Me.CmbBoxCleanupImage_UseImageMounted)
        Me.TabPage19.Controls.Add(Me.Label5)
        Me.TabPage19.Controls.Add(Me.cmbCleanupImage_IndexSource)
        Me.TabPage19.Controls.Add(Me.BtnCleanupImage_ChooseSourceRestoreHealth)
        Me.TabPage19.Controls.Add(Me.BtnCleanupImage_RestoreHealth)
        Me.TabPage19.Controls.Add(Me.BtnCleanupImage_ScanHealth)
        Me.TabPage19.Controls.Add(Me.BtnCleanupImage_StartComponentCleanup)
        Me.TabPage19.Controls.Add(Me.BtnCleanupImage_Superseded)
        Me.TabPage19.Controls.Add(Me.BtnCleanupImage_RevertPendingActions)
        Me.TabPage19.Controls.Add(Me.BtnCleanupImage_CheckHealth)
        Me.TabPage19.Controls.Add(Me.ChkBoxCleanupImage_Online)
        Me.TabPage19.Controls.Add(Me.ChkBoxCleanupImage_LimitAccessRestoreHealth)
        Me.TabPage19.Controls.Add(Me.ChkBoxCleanupImage_Defer)
        Me.TabPage19.Controls.Add(Me.ChkBoxCleanupImage_ResetBase)
        Me.TabPage19.Controls.Add(Me.ChkBoxCleanupImage_HideSP)
        Me.TabPage19.Controls.Add(Me.BtnCleanupImage_AnalyzeComponentStore)
        Me.TabPage19.Controls.Add(Me.LblCleanupImage_SourceRestoreHealth)
        Me.TabPage19.Controls.Add(Me.TxtBoxCleanupImage_SourceRestoreHealth)
        Me.TabPage19.Location = New System.Drawing.Point(4, 29)
        Me.TabPage19.Name = "TabPage19"
        Me.TabPage19.Size = New System.Drawing.Size(886, 350)
        Me.TabPage19.TabIndex = 18
        Me.TabPage19.Text = "Cleanup Image"
        Me.TabPage19.UseVisualStyleBackColor = True
        '
        'BtnCleanupImage_GetMountedImageInfo
        '
        Me.BtnCleanupImage_GetMountedImageInfo.Location = New System.Drawing.Point(702, 14)
        Me.BtnCleanupImage_GetMountedImageInfo.Name = "BtnCleanupImage_GetMountedImageInfo"
        Me.BtnCleanupImage_GetMountedImageInfo.Size = New System.Drawing.Size(160, 64)
        Me.BtnCleanupImage_GetMountedImageInfo.TabIndex = 81
        Me.BtnCleanupImage_GetMountedImageInfo.Text = "Get Mounted Image Info"
        Me.BtnCleanupImage_GetMountedImageInfo.UseVisualStyleBackColor = True
        '
        'BtnCleanupImage_RefreshMountedImage
        '
        Me.BtnCleanupImage_RefreshMountedImage.Location = New System.Drawing.Point(246, 14)
        Me.BtnCleanupImage_RefreshMountedImage.Name = "BtnCleanupImage_RefreshMountedImage"
        Me.BtnCleanupImage_RefreshMountedImage.Size = New System.Drawing.Size(221, 32)
        Me.BtnCleanupImage_RefreshMountedImage.TabIndex = 80
        Me.BtnCleanupImage_RefreshMountedImage.Text = "Refresh mounted image"
        Me.BtnCleanupImage_RefreshMountedImage.UseVisualStyleBackColor = True
        '
        'LblCleanupImage_UseMountedImage
        '
        Me.LblCleanupImage_UseMountedImage.AutoSize = True
        Me.LblCleanupImage_UseMountedImage.Location = New System.Drawing.Point(5, 58)
        Me.LblCleanupImage_UseMountedImage.Name = "LblCleanupImage_UseMountedImage"
        Me.LblCleanupImage_UseMountedImage.Size = New System.Drawing.Size(158, 20)
        Me.LblCleanupImage_UseMountedImage.TabIndex = 79
        Me.LblCleanupImage_UseMountedImage.Text = "Use Image Mounted:"
        '
        'CmbBoxCleanupImage_UseImageMounted
        '
        Me.CmbBoxCleanupImage_UseImageMounted.FormattingEnabled = True
        Me.CmbBoxCleanupImage_UseImageMounted.Location = New System.Drawing.Point(180, 55)
        Me.CmbBoxCleanupImage_UseImageMounted.Name = "CmbBoxCleanupImage_UseImageMounted"
        Me.CmbBoxCleanupImage_UseImageMounted.Size = New System.Drawing.Size(349, 28)
        Me.CmbBoxCleanupImage_UseImageMounted.TabIndex = 78
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(583, 289)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(52, 20)
        Me.Label5.TabIndex = 77
        Me.Label5.Text = "Index:"
        '
        'cmbCleanupImage_IndexSource
        '
        Me.cmbCleanupImage_IndexSource.FormattingEnabled = True
        Me.cmbCleanupImage_IndexSource.Location = New System.Drawing.Point(641, 286)
        Me.cmbCleanupImage_IndexSource.Name = "cmbCleanupImage_IndexSource"
        Me.cmbCleanupImage_IndexSource.Size = New System.Drawing.Size(75, 28)
        Me.cmbCleanupImage_IndexSource.TabIndex = 76
        '
        'BtnCleanupImage_ChooseSourceRestoreHealth
        '
        Me.BtnCleanupImage_ChooseSourceRestoreHealth.Location = New System.Drawing.Point(9, 320)
        Me.BtnCleanupImage_ChooseSourceRestoreHealth.Name = "BtnCleanupImage_ChooseSourceRestoreHealth"
        Me.BtnCleanupImage_ChooseSourceRestoreHealth.Size = New System.Drawing.Size(241, 28)
        Me.BtnCleanupImage_ChooseSourceRestoreHealth.TabIndex = 75
        Me.BtnCleanupImage_ChooseSourceRestoreHealth.Text = "Choose Source (WIM or ESD)"
        Me.BtnCleanupImage_ChooseSourceRestoreHealth.UseVisualStyleBackColor = True
        '
        'BtnCleanupImage_RestoreHealth
        '
        Me.BtnCleanupImage_RestoreHealth.Location = New System.Drawing.Point(222, 288)
        Me.BtnCleanupImage_RestoreHealth.Name = "BtnCleanupImage_RestoreHealth"
        Me.BtnCleanupImage_RestoreHealth.Size = New System.Drawing.Size(356, 26)
        Me.BtnCleanupImage_RestoreHealth.TabIndex = 74
        Me.BtnCleanupImage_RestoreHealth.Text = "Dism Cleanup Image Restore Health"
        Me.BtnCleanupImage_RestoreHealth.UseVisualStyleBackColor = True
        '
        'BtnCleanupImage_ScanHealth
        '
        Me.BtnCleanupImage_ScanHealth.Location = New System.Drawing.Point(386, 232)
        Me.BtnCleanupImage_ScanHealth.Name = "BtnCleanupImage_ScanHealth"
        Me.BtnCleanupImage_ScanHealth.Size = New System.Drawing.Size(356, 26)
        Me.BtnCleanupImage_ScanHealth.TabIndex = 73
        Me.BtnCleanupImage_ScanHealth.Text = "Dism Cleanup Image Scan Health"
        Me.BtnCleanupImage_ScanHealth.UseVisualStyleBackColor = True
        '
        'BtnCleanupImage_StartComponentCleanup
        '
        Me.BtnCleanupImage_StartComponentCleanup.Location = New System.Drawing.Point(222, 139)
        Me.BtnCleanupImage_StartComponentCleanup.Name = "BtnCleanupImage_StartComponentCleanup"
        Me.BtnCleanupImage_StartComponentCleanup.Size = New System.Drawing.Size(356, 26)
        Me.BtnCleanupImage_StartComponentCleanup.TabIndex = 72
        Me.BtnCleanupImage_StartComponentCleanup.Text = "Dism Cleanup Image Start Component Cleanup"
        Me.BtnCleanupImage_StartComponentCleanup.UseVisualStyleBackColor = True
        '
        'BtnCleanupImage_Superseded
        '
        Me.BtnCleanupImage_Superseded.Location = New System.Drawing.Point(222, 93)
        Me.BtnCleanupImage_Superseded.Name = "BtnCleanupImage_Superseded"
        Me.BtnCleanupImage_Superseded.Size = New System.Drawing.Size(356, 26)
        Me.BtnCleanupImage_Superseded.TabIndex = 71
        Me.BtnCleanupImage_Superseded.Text = "Dism Cleanup Image Service Pack Superseded"
        Me.BtnCleanupImage_Superseded.UseVisualStyleBackColor = True
        '
        'BtnCleanupImage_RevertPendingActions
        '
        Me.BtnCleanupImage_RevertPendingActions.Location = New System.Drawing.Point(6, 184)
        Me.BtnCleanupImage_RevertPendingActions.Name = "BtnCleanupImage_RevertPendingActions"
        Me.BtnCleanupImage_RevertPendingActions.Size = New System.Drawing.Size(356, 26)
        Me.BtnCleanupImage_RevertPendingActions.TabIndex = 70
        Me.BtnCleanupImage_RevertPendingActions.Text = "Dism Cleanup Image Revert Pending Actions"
        Me.BtnCleanupImage_RevertPendingActions.UseVisualStyleBackColor = True
        '
        'BtnCleanupImage_CheckHealth
        '
        Me.BtnCleanupImage_CheckHealth.Location = New System.Drawing.Point(6, 232)
        Me.BtnCleanupImage_CheckHealth.Name = "BtnCleanupImage_CheckHealth"
        Me.BtnCleanupImage_CheckHealth.Size = New System.Drawing.Size(356, 26)
        Me.BtnCleanupImage_CheckHealth.TabIndex = 69
        Me.BtnCleanupImage_CheckHealth.Text = "Dism Cleanup Image Check Health"
        Me.BtnCleanupImage_CheckHealth.UseVisualStyleBackColor = True
        '
        'ChkBoxCleanupImage_Online
        '
        Me.ChkBoxCleanupImage_Online.AutoSize = True
        Me.ChkBoxCleanupImage_Online.Location = New System.Drawing.Point(758, 323)
        Me.ChkBoxCleanupImage_Online.Name = "ChkBoxCleanupImage_Online"
        Me.ChkBoxCleanupImage_Online.Size = New System.Drawing.Size(125, 24)
        Me.ChkBoxCleanupImage_Online.TabIndex = 68
        Me.ChkBoxCleanupImage_Online.Text = "/Online option"
        Me.ChkBoxCleanupImage_Online.UseVisualStyleBackColor = False
        '
        'ChkBoxCleanupImage_LimitAccessRestoreHealth
        '
        Me.ChkBoxCleanupImage_LimitAccessRestoreHealth.AutoSize = True
        Me.ChkBoxCleanupImage_LimitAccessRestoreHealth.Location = New System.Drawing.Point(10, 290)
        Me.ChkBoxCleanupImage_LimitAccessRestoreHealth.Name = "ChkBoxCleanupImage_LimitAccessRestoreHealth"
        Me.ChkBoxCleanupImage_LimitAccessRestoreHealth.Size = New System.Drawing.Size(211, 24)
        Me.ChkBoxCleanupImage_LimitAccessRestoreHealth.TabIndex = 67
        Me.ChkBoxCleanupImage_LimitAccessRestoreHealth.Text = "/LimitAccess (WU/WSUS)"
        Me.ChkBoxCleanupImage_LimitAccessRestoreHealth.UseVisualStyleBackColor = True
        '
        'ChkBoxCleanupImage_Defer
        '
        Me.ChkBoxCleanupImage_Defer.AutoSize = True
        Me.ChkBoxCleanupImage_Defer.Location = New System.Drawing.Point(127, 141)
        Me.ChkBoxCleanupImage_Defer.Name = "ChkBoxCleanupImage_Defer"
        Me.ChkBoxCleanupImage_Defer.Size = New System.Drawing.Size(72, 24)
        Me.ChkBoxCleanupImage_Defer.TabIndex = 62
        Me.ChkBoxCleanupImage_Defer.Text = "/Defer"
        Me.ChkBoxCleanupImage_Defer.UseVisualStyleBackColor = True
        '
        'ChkBoxCleanupImage_ResetBase
        '
        Me.ChkBoxCleanupImage_ResetBase.AutoSize = True
        Me.ChkBoxCleanupImage_ResetBase.Location = New System.Drawing.Point(9, 141)
        Me.ChkBoxCleanupImage_ResetBase.Name = "ChkBoxCleanupImage_ResetBase"
        Me.ChkBoxCleanupImage_ResetBase.Size = New System.Drawing.Size(112, 24)
        Me.ChkBoxCleanupImage_ResetBase.TabIndex = 61
        Me.ChkBoxCleanupImage_ResetBase.Text = "/ResetBase"
        Me.ChkBoxCleanupImage_ResetBase.UseVisualStyleBackColor = True
        '
        'ChkBoxCleanupImage_HideSP
        '
        Me.ChkBoxCleanupImage_HideSP.AutoSize = True
        Me.ChkBoxCleanupImage_HideSP.Location = New System.Drawing.Point(10, 93)
        Me.ChkBoxCleanupImage_HideSP.Name = "ChkBoxCleanupImage_HideSP"
        Me.ChkBoxCleanupImage_HideSP.Size = New System.Drawing.Size(86, 24)
        Me.ChkBoxCleanupImage_HideSP.TabIndex = 59
        Me.ChkBoxCleanupImage_HideSP.Text = "/HideSP"
        Me.ChkBoxCleanupImage_HideSP.UseVisualStyleBackColor = True
        '
        'BtnCleanupImage_AnalyzeComponentStore
        '
        Me.BtnCleanupImage_AnalyzeComponentStore.Location = New System.Drawing.Point(386, 184)
        Me.BtnCleanupImage_AnalyzeComponentStore.Name = "BtnCleanupImage_AnalyzeComponentStore"
        Me.BtnCleanupImage_AnalyzeComponentStore.Size = New System.Drawing.Size(356, 26)
        Me.BtnCleanupImage_AnalyzeComponentStore.TabIndex = 56
        Me.BtnCleanupImage_AnalyzeComponentStore.Text = "Dism Cleanup Image Analyze Component Store"
        Me.BtnCleanupImage_AnalyzeComponentStore.UseVisualStyleBackColor = True
        '
        'LblCleanupImage_SourceRestoreHealth
        '
        Me.LblCleanupImage_SourceRestoreHealth.AutoSize = True
        Me.LblCleanupImage_SourceRestoreHealth.Location = New System.Drawing.Point(261, 324)
        Me.LblCleanupImage_SourceRestoreHealth.Name = "LblCleanupImage_SourceRestoreHealth"
        Me.LblCleanupImage_SourceRestoreHealth.Size = New System.Drawing.Size(64, 20)
        Me.LblCleanupImage_SourceRestoreHealth.TabIndex = 54
        Me.LblCleanupImage_SourceRestoreHealth.Text = "Source:"
        '
        'TxtBoxCleanupImage_SourceRestoreHealth
        '
        Me.TxtBoxCleanupImage_SourceRestoreHealth.Location = New System.Drawing.Point(331, 321)
        Me.TxtBoxCleanupImage_SourceRestoreHealth.Name = "TxtBoxCleanupImage_SourceRestoreHealth"
        Me.TxtBoxCleanupImage_SourceRestoreHealth.Size = New System.Drawing.Size(356, 26)
        Me.TxtBoxCleanupImage_SourceRestoreHealth.TabIndex = 55
        '
        'TabPage20
        '
        Me.TabPage20.Controls.Add(Me.BtnMakeWinPEISO)
        Me.TabPage20.Controls.Add(Me.GrpBoxDiskpartWinPE_HardwareType)
        Me.TabPage20.Controls.Add(Me.BtnDiskpartWinPE_BootDiskWinPE)
        Me.TabPage20.Controls.Add(Me.BtnDiskpartWinPE_CreateWinPETemplate)
        Me.TabPage20.Controls.Add(Me.PictBoxDiskpartWinPE_Picture)
        Me.TabPage20.Controls.Add(Me.TxtBoxDiskpartWinPE_Recovery)
        Me.TabPage20.Controls.Add(Me.LblDiskpartWinPE_Recovery)
        Me.TabPage20.Controls.Add(Me.TxtBoxDiskpartWinPE_Windows)
        Me.TabPage20.Controls.Add(Me.LblDiskpartWinPE_Windows)
        Me.TabPage20.Controls.Add(Me.TxtBoxDiskpartWinPE_MSR)
        Me.TabPage20.Controls.Add(Me.LblDiskpartWinPE_MSR)
        Me.TabPage20.Controls.Add(Me.TxtBoxDiskpartWinPE_System)
        Me.TabPage20.Controls.Add(Me.LblDiskpartWinPE_System)
        Me.TabPage20.Controls.Add(Me.TxtBoxDiskpartWinPE_NTFSSize)
        Me.TabPage20.Controls.Add(Me.LblDiskpartWinPE_NTFSSize)
        Me.TabPage20.Controls.Add(Me.TxtBoxDiskpartWinPE_FAT32Size)
        Me.TabPage20.Controls.Add(Me.LblDiskpartWinPE_FAT32Size)
        Me.TabPage20.Controls.Add(Me.RadBtnDiskpartWinPE_HardDriveUEFI)
        Me.TabPage20.Controls.Add(Me.RadBtnDiskpartWinPE_HardDriveBIOS)
        Me.TabPage20.Controls.Add(Me.RadBtnDiskparWinPE_FAT32NTFS)
        Me.TabPage20.Controls.Add(Me.RadBtnDiskpartWinPE_NTFS)
        Me.TabPage20.Controls.Add(Me.RadBtnDiskpartWinPE_FAT32)
        Me.TabPage20.Controls.Add(Me.BtnDiskpartWinPE_FormatDisk)
        Me.TabPage20.Controls.Add(Me.LblDiskpartWinPE_SelectDrive)
        Me.TabPage20.Controls.Add(Me.CmbBoxDiskpartWinpe_SelectDrive)
        Me.TabPage20.Controls.Add(Me.TxtBoxDispartWinPE_InfosDisk)
        Me.TabPage20.Controls.Add(Me.BtnDiskpartWinPE_RefreshListDisk)
        Me.TabPage20.Location = New System.Drawing.Point(4, 29)
        Me.TabPage20.Name = "TabPage20"
        Me.TabPage20.Size = New System.Drawing.Size(886, 350)
        Me.TabPage20.TabIndex = 19
        Me.TabPage20.Text = "Diskpart WinPE"
        Me.TabPage20.UseVisualStyleBackColor = True
        '
        'BtnMakeWinPEISO
        '
        Me.BtnMakeWinPEISO.Location = New System.Drawing.Point(229, 218)
        Me.BtnMakeWinPEISO.Name = "BtnMakeWinPEISO"
        Me.BtnMakeWinPEISO.Size = New System.Drawing.Size(185, 32)
        Me.BtnMakeWinPEISO.TabIndex = 28
        Me.BtnMakeWinPEISO.Text = "Make ISO WinPE"
        Me.BtnMakeWinPEISO.UseVisualStyleBackColor = True
        '
        'GrpBoxDiskpartWinPE_HardwareType
        '
        Me.GrpBoxDiskpartWinPE_HardwareType.Controls.Add(Me.RadBtnDiskpartWinPE_WinPEx86)
        Me.GrpBoxDiskpartWinPE_HardwareType.Controls.Add(Me.RadBtnDiskpartWinPE_WinPEamd64)
        Me.GrpBoxDiskpartWinPE_HardwareType.Location = New System.Drawing.Point(278, 259)
        Me.GrpBoxDiskpartWinPE_HardwareType.Name = "GrpBoxDiskpartWinPE_HardwareType"
        Me.GrpBoxDiskpartWinPE_HardwareType.Size = New System.Drawing.Size(139, 77)
        Me.GrpBoxDiskpartWinPE_HardwareType.TabIndex = 27
        Me.GrpBoxDiskpartWinPE_HardwareType.TabStop = False
        Me.GrpBoxDiskpartWinPE_HardwareType.Text = "Type:"
        '
        'RadBtnDiskpartWinPE_WinPEx86
        '
        Me.RadBtnDiskpartWinPE_WinPEx86.AutoSize = True
        Me.RadBtnDiskpartWinPE_WinPEx86.Location = New System.Drawing.Point(6, 26)
        Me.RadBtnDiskpartWinPE_WinPEx86.Name = "RadBtnDiskpartWinPE_WinPEx86"
        Me.RadBtnDiskpartWinPE_WinPEx86.Size = New System.Drawing.Size(52, 24)
        Me.RadBtnDiskpartWinPE_WinPEx86.TabIndex = 24
        Me.RadBtnDiskpartWinPE_WinPEx86.TabStop = True
        Me.RadBtnDiskpartWinPE_WinPEx86.Text = "x86"
        Me.RadBtnDiskpartWinPE_WinPEx86.UseVisualStyleBackColor = True
        '
        'RadBtnDiskpartWinPE_WinPEamd64
        '
        Me.RadBtnDiskpartWinPE_WinPEamd64.AutoSize = True
        Me.RadBtnDiskpartWinPE_WinPEamd64.Location = New System.Drawing.Point(61, 26)
        Me.RadBtnDiskpartWinPE_WinPEamd64.Name = "RadBtnDiskpartWinPE_WinPEamd64"
        Me.RadBtnDiskpartWinPE_WinPEamd64.Size = New System.Drawing.Size(76, 24)
        Me.RadBtnDiskpartWinPE_WinPEamd64.TabIndex = 25
        Me.RadBtnDiskpartWinPE_WinPEamd64.TabStop = True
        Me.RadBtnDiskpartWinPE_WinPEamd64.Text = "amd64"
        Me.RadBtnDiskpartWinPE_WinPEamd64.UseVisualStyleBackColor = True
        '
        'BtnDiskpartWinPE_BootDiskWinPE
        '
        Me.BtnDiskpartWinPE_BootDiskWinPE.Location = New System.Drawing.Point(3, 304)
        Me.BtnDiskpartWinPE_BootDiskWinPE.Name = "BtnDiskpartWinPE_BootDiskWinPE"
        Me.BtnDiskpartWinPE_BootDiskWinPE.Size = New System.Drawing.Size(269, 32)
        Me.BtnDiskpartWinPE_BootDiskWinPE.TabIndex = 26
        Me.BtnDiskpartWinPE_BootDiskWinPE.Text = "Create BootDisk WinPE on P: drive"
        Me.BtnDiskpartWinPE_BootDiskWinPE.UseVisualStyleBackColor = True
        '
        'BtnDiskpartWinPE_CreateWinPETemplate
        '
        Me.BtnDiskpartWinPE_CreateWinPETemplate.Location = New System.Drawing.Point(3, 266)
        Me.BtnDiskpartWinPE_CreateWinPETemplate.Name = "BtnDiskpartWinPE_CreateWinPETemplate"
        Me.BtnDiskpartWinPE_CreateWinPETemplate.Size = New System.Drawing.Size(269, 32)
        Me.BtnDiskpartWinPE_CreateWinPETemplate.TabIndex = 23
        Me.BtnDiskpartWinPE_CreateWinPETemplate.Text = "Create WinPE template  on drive C:"
        Me.BtnDiskpartWinPE_CreateWinPETemplate.UseVisualStyleBackColor = True
        '
        'PictBoxDiskpartWinPE_Picture
        '
        Me.PictBoxDiskpartWinPE_Picture.Location = New System.Drawing.Point(423, 247)
        Me.PictBoxDiskpartWinPE_Picture.Name = "PictBoxDiskpartWinPE_Picture"
        Me.PictBoxDiskpartWinPE_Picture.Size = New System.Drawing.Size(446, 100)
        Me.PictBoxDiskpartWinPE_Picture.TabIndex = 22
        Me.PictBoxDiskpartWinPE_Picture.TabStop = False
        '
        'TxtBoxDiskpartWinPE_Recovery
        '
        Me.TxtBoxDiskpartWinPE_Recovery.Location = New System.Drawing.Point(733, 215)
        Me.TxtBoxDiskpartWinPE_Recovery.Name = "TxtBoxDiskpartWinPE_Recovery"
        Me.TxtBoxDiskpartWinPE_Recovery.Size = New System.Drawing.Size(94, 26)
        Me.TxtBoxDiskpartWinPE_Recovery.TabIndex = 21
        Me.TxtBoxDiskpartWinPE_Recovery.Visible = False
        '
        'LblDiskpartWinPE_Recovery
        '
        Me.LblDiskpartWinPE_Recovery.AutoSize = True
        Me.LblDiskpartWinPE_Recovery.Location = New System.Drawing.Point(631, 218)
        Me.LblDiskpartWinPE_Recovery.Name = "LblDiskpartWinPE_Recovery"
        Me.LblDiskpartWinPE_Recovery.Size = New System.Drawing.Size(79, 20)
        Me.LblDiskpartWinPE_Recovery.TabIndex = 20
        Me.LblDiskpartWinPE_Recovery.Text = "Recovery:"
        Me.LblDiskpartWinPE_Recovery.Visible = False
        '
        'TxtBoxDiskpartWinPE_Windows
        '
        Me.TxtBoxDiskpartWinPE_Windows.Location = New System.Drawing.Point(733, 183)
        Me.TxtBoxDiskpartWinPE_Windows.Name = "TxtBoxDiskpartWinPE_Windows"
        Me.TxtBoxDiskpartWinPE_Windows.Size = New System.Drawing.Size(94, 26)
        Me.TxtBoxDiskpartWinPE_Windows.TabIndex = 19
        Me.TxtBoxDiskpartWinPE_Windows.Visible = False
        '
        'LblDiskpartWinPE_Windows
        '
        Me.LblDiskpartWinPE_Windows.AutoSize = True
        Me.LblDiskpartWinPE_Windows.Location = New System.Drawing.Point(631, 186)
        Me.LblDiskpartWinPE_Windows.Name = "LblDiskpartWinPE_Windows"
        Me.LblDiskpartWinPE_Windows.Size = New System.Drawing.Size(77, 20)
        Me.LblDiskpartWinPE_Windows.TabIndex = 18
        Me.LblDiskpartWinPE_Windows.Text = "Windows:"
        Me.LblDiskpartWinPE_Windows.Visible = False
        '
        'TxtBoxDiskpartWinPE_MSR
        '
        Me.TxtBoxDiskpartWinPE_MSR.Location = New System.Drawing.Point(733, 150)
        Me.TxtBoxDiskpartWinPE_MSR.Name = "TxtBoxDiskpartWinPE_MSR"
        Me.TxtBoxDiskpartWinPE_MSR.Size = New System.Drawing.Size(94, 26)
        Me.TxtBoxDiskpartWinPE_MSR.TabIndex = 17
        Me.TxtBoxDiskpartWinPE_MSR.Visible = False
        '
        'LblDiskpartWinPE_MSR
        '
        Me.LblDiskpartWinPE_MSR.AutoSize = True
        Me.LblDiskpartWinPE_MSR.Location = New System.Drawing.Point(631, 153)
        Me.LblDiskpartWinPE_MSR.Name = "LblDiskpartWinPE_MSR"
        Me.LblDiskpartWinPE_MSR.Size = New System.Drawing.Size(49, 20)
        Me.LblDiskpartWinPE_MSR.TabIndex = 16
        Me.LblDiskpartWinPE_MSR.Text = "MSR:"
        Me.LblDiskpartWinPE_MSR.Visible = False
        '
        'TxtBoxDiskpartWinPE_System
        '
        Me.TxtBoxDiskpartWinPE_System.Location = New System.Drawing.Point(733, 118)
        Me.TxtBoxDiskpartWinPE_System.Name = "TxtBoxDiskpartWinPE_System"
        Me.TxtBoxDiskpartWinPE_System.Size = New System.Drawing.Size(94, 26)
        Me.TxtBoxDiskpartWinPE_System.TabIndex = 15
        Me.TxtBoxDiskpartWinPE_System.Visible = False
        '
        'LblDiskpartWinPE_System
        '
        Me.LblDiskpartWinPE_System.AutoSize = True
        Me.LblDiskpartWinPE_System.Location = New System.Drawing.Point(631, 121)
        Me.LblDiskpartWinPE_System.Name = "LblDiskpartWinPE_System"
        Me.LblDiskpartWinPE_System.Size = New System.Drawing.Size(66, 20)
        Me.LblDiskpartWinPE_System.TabIndex = 14
        Me.LblDiskpartWinPE_System.Text = "System:"
        Me.LblDiskpartWinPE_System.Visible = False
        '
        'TxtBoxDiskpartWinPE_NTFSSize
        '
        Me.TxtBoxDiskpartWinPE_NTFSSize.Location = New System.Drawing.Point(521, 179)
        Me.TxtBoxDiskpartWinPE_NTFSSize.Name = "TxtBoxDiskpartWinPE_NTFSSize"
        Me.TxtBoxDiskpartWinPE_NTFSSize.Size = New System.Drawing.Size(94, 26)
        Me.TxtBoxDiskpartWinPE_NTFSSize.TabIndex = 13
        Me.TxtBoxDiskpartWinPE_NTFSSize.Text = "2000"
        Me.TxtBoxDiskpartWinPE_NTFSSize.Visible = False
        '
        'LblDiskpartWinPE_NTFSSize
        '
        Me.LblDiskpartWinPE_NTFSSize.AutoSize = True
        Me.LblDiskpartWinPE_NTFSSize.Location = New System.Drawing.Point(419, 182)
        Me.LblDiskpartWinPE_NTFSSize.Name = "LblDiskpartWinPE_NTFSSize"
        Me.LblDiskpartWinPE_NTFSSize.Size = New System.Drawing.Size(89, 20)
        Me.LblDiskpartWinPE_NTFSSize.TabIndex = 12
        Me.LblDiskpartWinPE_NTFSSize.Text = "NTFS Size:"
        Me.LblDiskpartWinPE_NTFSSize.Visible = False
        '
        'TxtBoxDiskpartWinPE_FAT32Size
        '
        Me.TxtBoxDiskpartWinPE_FAT32Size.Location = New System.Drawing.Point(521, 147)
        Me.TxtBoxDiskpartWinPE_FAT32Size.Name = "TxtBoxDiskpartWinPE_FAT32Size"
        Me.TxtBoxDiskpartWinPE_FAT32Size.Size = New System.Drawing.Size(94, 26)
        Me.TxtBoxDiskpartWinPE_FAT32Size.TabIndex = 11
        Me.TxtBoxDiskpartWinPE_FAT32Size.Text = "2000"
        Me.TxtBoxDiskpartWinPE_FAT32Size.Visible = False
        '
        'LblDiskpartWinPE_FAT32Size
        '
        Me.LblDiskpartWinPE_FAT32Size.AutoSize = True
        Me.LblDiskpartWinPE_FAT32Size.Location = New System.Drawing.Point(419, 150)
        Me.LblDiskpartWinPE_FAT32Size.Name = "LblDiskpartWinPE_FAT32Size"
        Me.LblDiskpartWinPE_FAT32Size.Size = New System.Drawing.Size(96, 20)
        Me.LblDiskpartWinPE_FAT32Size.TabIndex = 10
        Me.LblDiskpartWinPE_FAT32Size.Text = "FAT32 Size:"
        Me.LblDiskpartWinPE_FAT32Size.Visible = False
        '
        'RadBtnDiskpartWinPE_HardDriveUEFI
        '
        Me.RadBtnDiskpartWinPE_HardDriveUEFI.AutoSize = True
        Me.RadBtnDiskpartWinPE_HardDriveUEFI.Location = New System.Drawing.Point(633, 47)
        Me.RadBtnDiskpartWinPE_HardDriveUEFI.Name = "RadBtnDiskpartWinPE_HardDriveUEFI"
        Me.RadBtnDiskpartWinPE_HardDriveUEFI.Size = New System.Drawing.Size(195, 24)
        Me.RadBtnDiskpartWinPE_HardDriveUEFI.TabIndex = 9
        Me.RadBtnDiskpartWinPE_HardDriveUEFI.TabStop = True
        Me.RadBtnDiskpartWinPE_HardDriveUEFI.Text = "Hard Disk Default UEFI"
        Me.RadBtnDiskpartWinPE_HardDriveUEFI.UseVisualStyleBackColor = True
        '
        'RadBtnDiskpartWinPE_HardDriveBIOS
        '
        Me.RadBtnDiskpartWinPE_HardDriveBIOS.AutoSize = True
        Me.RadBtnDiskpartWinPE_HardDriveBIOS.Location = New System.Drawing.Point(633, 17)
        Me.RadBtnDiskpartWinPE_HardDriveBIOS.Name = "RadBtnDiskpartWinPE_HardDriveBIOS"
        Me.RadBtnDiskpartWinPE_HardDriveBIOS.Size = New System.Drawing.Size(196, 24)
        Me.RadBtnDiskpartWinPE_HardDriveBIOS.TabIndex = 8
        Me.RadBtnDiskpartWinPE_HardDriveBIOS.TabStop = True
        Me.RadBtnDiskpartWinPE_HardDriveBIOS.Text = "Hard Disk Default BIOS"
        Me.RadBtnDiskpartWinPE_HardDriveBIOS.UseVisualStyleBackColor = True
        '
        'RadBtnDiskparWinPE_FAT32NTFS
        '
        Me.RadBtnDiskparWinPE_FAT32NTFS.AutoSize = True
        Me.RadBtnDiskparWinPE_FAT32NTFS.Location = New System.Drawing.Point(423, 76)
        Me.RadBtnDiskparWinPE_FAT32NTFS.Name = "RadBtnDiskparWinPE_FAT32NTFS"
        Me.RadBtnDiskparWinPE_FAT32NTFS.Size = New System.Drawing.Size(158, 24)
        Me.RadBtnDiskparWinPE_FAT32NTFS.TabIndex = 7
        Me.RadBtnDiskparWinPE_FAT32NTFS.TabStop = True
        Me.RadBtnDiskparWinPE_FAT32NTFS.Text = "USB FAT32/NTFS"
        Me.RadBtnDiskparWinPE_FAT32NTFS.UseVisualStyleBackColor = True
        '
        'RadBtnDiskpartWinPE_NTFS
        '
        Me.RadBtnDiskpartWinPE_NTFS.AutoSize = True
        Me.RadBtnDiskpartWinPE_NTFS.Location = New System.Drawing.Point(423, 46)
        Me.RadBtnDiskpartWinPE_NTFS.Name = "RadBtnDiskpartWinPE_NTFS"
        Me.RadBtnDiskpartWinPE_NTFS.Size = New System.Drawing.Size(106, 24)
        Me.RadBtnDiskpartWinPE_NTFS.TabIndex = 6
        Me.RadBtnDiskpartWinPE_NTFS.TabStop = True
        Me.RadBtnDiskpartWinPE_NTFS.Text = "USB NTFS"
        Me.RadBtnDiskpartWinPE_NTFS.UseVisualStyleBackColor = True
        '
        'RadBtnDiskpartWinPE_FAT32
        '
        Me.RadBtnDiskpartWinPE_FAT32.AutoSize = True
        Me.RadBtnDiskpartWinPE_FAT32.Location = New System.Drawing.Point(423, 16)
        Me.RadBtnDiskpartWinPE_FAT32.Name = "RadBtnDiskpartWinPE_FAT32"
        Me.RadBtnDiskpartWinPE_FAT32.Size = New System.Drawing.Size(113, 24)
        Me.RadBtnDiskpartWinPE_FAT32.TabIndex = 5
        Me.RadBtnDiskpartWinPE_FAT32.TabStop = True
        Me.RadBtnDiskpartWinPE_FAT32.Text = "USB FAT32"
        Me.RadBtnDiskpartWinPE_FAT32.UseVisualStyleBackColor = True
        '
        'BtnDiskpartWinPE_FormatDisk
        '
        Me.BtnDiskpartWinPE_FormatDisk.Location = New System.Drawing.Point(14, 218)
        Me.BtnDiskpartWinPE_FormatDisk.Name = "BtnDiskpartWinPE_FormatDisk"
        Me.BtnDiskpartWinPE_FormatDisk.Size = New System.Drawing.Size(185, 32)
        Me.BtnDiskpartWinPE_FormatDisk.TabIndex = 4
        Me.BtnDiskpartWinPE_FormatDisk.Text = "Format Disk"
        Me.BtnDiskpartWinPE_FormatDisk.UseVisualStyleBackColor = True
        '
        'LblDiskpartWinPE_SelectDrive
        '
        Me.LblDiskpartWinPE_SelectDrive.AutoSize = True
        Me.LblDiskpartWinPE_SelectDrive.Location = New System.Drawing.Point(225, 182)
        Me.LblDiskpartWinPE_SelectDrive.Name = "LblDiskpartWinPE_SelectDrive"
        Me.LblDiskpartWinPE_SelectDrive.Size = New System.Drawing.Size(108, 20)
        Me.LblDiskpartWinPE_SelectDrive.TabIndex = 3
        Me.LblDiskpartWinPE_SelectDrive.Text = "Select a drive:"
        '
        'CmbBoxDiskpartWinpe_SelectDrive
        '
        Me.CmbBoxDiskpartWinpe_SelectDrive.FormattingEnabled = True
        Me.CmbBoxDiskpartWinpe_SelectDrive.Location = New System.Drawing.Point(339, 179)
        Me.CmbBoxDiskpartWinpe_SelectDrive.Name = "CmbBoxDiskpartWinpe_SelectDrive"
        Me.CmbBoxDiskpartWinpe_SelectDrive.Size = New System.Drawing.Size(65, 28)
        Me.CmbBoxDiskpartWinpe_SelectDrive.TabIndex = 2
        '
        'TxtBoxDispartWinPE_InfosDisk
        '
        Me.TxtBoxDispartWinPE_InfosDisk.Location = New System.Drawing.Point(14, 16)
        Me.TxtBoxDispartWinPE_InfosDisk.Multiline = True
        Me.TxtBoxDispartWinPE_InfosDisk.Name = "TxtBoxDispartWinPE_InfosDisk"
        Me.TxtBoxDispartWinPE_InfosDisk.ScrollBars = System.Windows.Forms.ScrollBars.Both
        Me.TxtBoxDispartWinPE_InfosDisk.Size = New System.Drawing.Size(390, 154)
        Me.TxtBoxDispartWinPE_InfosDisk.TabIndex = 1
        '
        'BtnDiskpartWinPE_RefreshListDisk
        '
        Me.BtnDiskpartWinPE_RefreshListDisk.Location = New System.Drawing.Point(14, 176)
        Me.BtnDiskpartWinPE_RefreshListDisk.Name = "BtnDiskpartWinPE_RefreshListDisk"
        Me.BtnDiskpartWinPE_RefreshListDisk.Size = New System.Drawing.Size(185, 31)
        Me.BtnDiskpartWinPE_RefreshListDisk.TabIndex = 0
        Me.BtnDiskpartWinPE_RefreshListDisk.Text = "Refresh List Disk"
        Me.BtnDiskpartWinPE_RefreshListDisk.UseVisualStyleBackColor = True
        '
        'TabPage21
        '
        Me.TabPage21.Controls.Add(Me.BtnCustomWinPE_ApplyDetectTypeBios)
        Me.TabPage21.Controls.Add(Me.BtnCustomWinPE_ApplyMaxPerf)
        Me.TabPage21.Controls.Add(Me.ChkboxCustomWinPE_AddMaxPowerPerf)
        Me.TabPage21.Controls.Add(Me.ChkboxCustomWinPE_AddScriptWinPEDetectTypeBios)
        Me.TabPage21.Controls.Add(Me.LblCustomWinPE_Packages)
        Me.TabPage21.Controls.Add(Me.CmbBoxCustomWinPE_Language)
        Me.TabPage21.Controls.Add(Me.LblCustomWinPE_Language)
        Me.TabPage21.Controls.Add(Me.RadBtnCustomWinPE_TypeAmd64)
        Me.TabPage21.Controls.Add(Me.RadBtnCustomWinPE_TypeX86)
        Me.TabPage21.Controls.Add(Me.LblCustomWinPE_SystemType)
        Me.TabPage21.Controls.Add(Me.BtnCustomWinPE_DetectADK)
        Me.TabPage21.Controls.Add(Me.TxtBoxCustomWinPE_DetectADKPath)
        Me.TabPage21.Controls.Add(Me.LblCustomWinPE_DetectADKPath)
        Me.TabPage21.Controls.Add(Me.BtnCustomWinPE_Apply)
        Me.TabPage21.Controls.Add(Me.ChkboxCustomWinPE_StorageWMI)
        Me.TabPage21.Controls.Add(Me.ChkboxCustomWinPE_Scripting)
        Me.TabPage21.Controls.Add(Me.ChkboxCustomWinPE_PowerShell)
        Me.TabPage21.Controls.Add(Me.ChkboxCustomWinPE_NetFx)
        Me.TabPage21.Controls.Add(Me.ChkboxCustomWinPE_WMI)
        Me.TabPage21.Controls.Add(Me.ChkboxCustomWinPE_MDAC)
        Me.TabPage21.Controls.Add(Me.ChkboxCustomWinPE_HTA)
        Me.TabPage21.Controls.Add(Me.BtnCustomWinPE_GetMountedImageInfo)
        Me.TabPage21.Controls.Add(Me.BtnCustomWinPE_RefreshMountedImage)
        Me.TabPage21.Controls.Add(Me.LblCustomWinPE_UseImageMounted)
        Me.TabPage21.Controls.Add(Me.CmbBoxCustomWinPE_UseImageMounted)
        Me.TabPage21.Location = New System.Drawing.Point(4, 29)
        Me.TabPage21.Name = "TabPage21"
        Me.TabPage21.Size = New System.Drawing.Size(886, 350)
        Me.TabPage21.TabIndex = 20
        Me.TabPage21.Text = "Custom WinPE"
        Me.TabPage21.UseVisualStyleBackColor = True
        '
        'BtnCustomWinPE_ApplyDetectTypeBios
        '
        Me.BtnCustomWinPE_ApplyDetectTypeBios.Location = New System.Drawing.Point(508, 255)
        Me.BtnCustomWinPE_ApplyDetectTypeBios.Name = "BtnCustomWinPE_ApplyDetectTypeBios"
        Me.BtnCustomWinPE_ApplyDetectTypeBios.Size = New System.Drawing.Size(66, 34)
        Me.BtnCustomWinPE_ApplyDetectTypeBios.TabIndex = 106
        Me.BtnCustomWinPE_ApplyDetectTypeBios.Text = "Apply"
        Me.BtnCustomWinPE_ApplyDetectTypeBios.UseVisualStyleBackColor = True
        '
        'BtnCustomWinPE_ApplyMaxPerf
        '
        Me.BtnCustomWinPE_ApplyMaxPerf.Location = New System.Drawing.Point(639, 281)
        Me.BtnCustomWinPE_ApplyMaxPerf.Name = "BtnCustomWinPE_ApplyMaxPerf"
        Me.BtnCustomWinPE_ApplyMaxPerf.Size = New System.Drawing.Size(66, 34)
        Me.BtnCustomWinPE_ApplyMaxPerf.TabIndex = 105
        Me.BtnCustomWinPE_ApplyMaxPerf.Text = "Apply"
        Me.BtnCustomWinPE_ApplyMaxPerf.UseVisualStyleBackColor = True
        '
        'ChkboxCustomWinPE_AddMaxPowerPerf
        '
        Me.ChkboxCustomWinPE_AddMaxPowerPerf.AutoSize = True
        Me.ChkboxCustomWinPE_AddMaxPowerPerf.Location = New System.Drawing.Point(7, 291)
        Me.ChkboxCustomWinPE_AddMaxPowerPerf.Name = "ChkboxCustomWinPE_AddMaxPowerPerf"
        Me.ChkboxCustomWinPE_AddMaxPowerPerf.Size = New System.Drawing.Size(626, 24)
        Me.ChkboxCustomWinPE_AddMaxPowerPerf.TabIndex = 104
        Me.ChkboxCustomWinPE_AddMaxPowerPerf.Text = "Add powercfg.exe /s 8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c (on StartNet.cmd file)"
        Me.ChkboxCustomWinPE_AddMaxPowerPerf.UseVisualStyleBackColor = True
        '
        'ChkboxCustomWinPE_AddScriptWinPEDetectTypeBios
        '
        Me.ChkboxCustomWinPE_AddScriptWinPEDetectTypeBios.AutoSize = True
        Me.ChkboxCustomWinPE_AddScriptWinPEDetectTypeBios.Location = New System.Drawing.Point(7, 261)
        Me.ChkboxCustomWinPE_AddScriptWinPEDetectTypeBios.Name = "ChkboxCustomWinPE_AddScriptWinPEDetectTypeBios"
        Me.ChkboxCustomWinPE_AddScriptWinPEDetectTypeBios.Size = New System.Drawing.Size(489, 24)
        Me.ChkboxCustomWinPE_AddScriptWinPEDetectTypeBios.TabIndex = 103
        Me.ChkboxCustomWinPE_AddScriptWinPEDetectTypeBios.Text = "Add script on WinPE to detect type of BIOS (on StartNet.cmd file)"
        Me.ChkboxCustomWinPE_AddScriptWinPEDetectTypeBios.UseVisualStyleBackColor = True
        '
        'LblCustomWinPE_Packages
        '
        Me.LblCustomWinPE_Packages.AutoSize = True
        Me.LblCustomWinPE_Packages.Location = New System.Drawing.Point(3, 201)
        Me.LblCustomWinPE_Packages.Name = "LblCustomWinPE_Packages"
        Me.LblCustomWinPE_Packages.Size = New System.Drawing.Size(140, 20)
        Me.LblCustomWinPE_Packages.TabIndex = 101
        Me.LblCustomWinPE_Packages.Text = "System Packages:"
        '
        'CmbBoxCustomWinPE_Language
        '
        Me.CmbBoxCustomWinPE_Language.FormattingEnabled = True
        Me.CmbBoxCustomWinPE_Language.Items.AddRange(New Object() {"bg-bg", "cs-cz", "da-dk", "de-de", "el-gr", "en-gb", "en-us", "es-es", "es-mx", "et-ee", "fi-fi", "fr-ca", "fr-fr", "hr-hr", "hu-hu", "it-it", "ja-jp", "ko-kr", "lt-lt", "lv-lv", "nb-no", "nl-nl", "pl-pl", "pt-br", "pt-pt", "ro-ro", "ru-ru", "sk-sk", "sl-si", "sr-latn-rs", "sv-se", "tr-tr", "uk-ua", "zh-cn", "zh-tw"})
        Me.CmbBoxCustomWinPE_Language.Location = New System.Drawing.Point(166, 133)
        Me.CmbBoxCustomWinPE_Language.Name = "CmbBoxCustomWinPE_Language"
        Me.CmbBoxCustomWinPE_Language.Size = New System.Drawing.Size(360, 28)
        Me.CmbBoxCustomWinPE_Language.TabIndex = 100
        '
        'LblCustomWinPE_Language
        '
        Me.LblCustomWinPE_Language.AutoSize = True
        Me.LblCustomWinPE_Language.Location = New System.Drawing.Point(3, 136)
        Me.LblCustomWinPE_Language.Name = "LblCustomWinPE_Language"
        Me.LblCustomWinPE_Language.Size = New System.Drawing.Size(85, 20)
        Me.LblCustomWinPE_Language.TabIndex = 99
        Me.LblCustomWinPE_Language.Text = "Language:"
        '
        'RadBtnCustomWinPE_TypeAmd64
        '
        Me.RadBtnCustomWinPE_TypeAmd64.AutoSize = True
        Me.RadBtnCustomWinPE_TypeAmd64.Location = New System.Drawing.Point(232, 167)
        Me.RadBtnCustomWinPE_TypeAmd64.Name = "RadBtnCustomWinPE_TypeAmd64"
        Me.RadBtnCustomWinPE_TypeAmd64.Size = New System.Drawing.Size(76, 24)
        Me.RadBtnCustomWinPE_TypeAmd64.TabIndex = 98
        Me.RadBtnCustomWinPE_TypeAmd64.TabStop = True
        Me.RadBtnCustomWinPE_TypeAmd64.Text = "amd64"
        Me.RadBtnCustomWinPE_TypeAmd64.UseVisualStyleBackColor = True
        '
        'RadBtnCustomWinPE_TypeX86
        '
        Me.RadBtnCustomWinPE_TypeX86.AutoSize = True
        Me.RadBtnCustomWinPE_TypeX86.Location = New System.Drawing.Point(166, 167)
        Me.RadBtnCustomWinPE_TypeX86.Name = "RadBtnCustomWinPE_TypeX86"
        Me.RadBtnCustomWinPE_TypeX86.Size = New System.Drawing.Size(52, 24)
        Me.RadBtnCustomWinPE_TypeX86.TabIndex = 97
        Me.RadBtnCustomWinPE_TypeX86.TabStop = True
        Me.RadBtnCustomWinPE_TypeX86.Text = "x86"
        Me.RadBtnCustomWinPE_TypeX86.UseVisualStyleBackColor = True
        '
        'LblCustomWinPE_SystemType
        '
        Me.LblCustomWinPE_SystemType.AutoSize = True
        Me.LblCustomWinPE_SystemType.Location = New System.Drawing.Point(3, 167)
        Me.LblCustomWinPE_SystemType.Name = "LblCustomWinPE_SystemType"
        Me.LblCustomWinPE_SystemType.Size = New System.Drawing.Size(104, 20)
        Me.LblCustomWinPE_SystemType.TabIndex = 96
        Me.LblCustomWinPE_SystemType.Text = "System Type:"
        '
        'BtnCustomWinPE_DetectADK
        '
        Me.BtnCustomWinPE_DetectADK.Location = New System.Drawing.Point(559, 97)
        Me.BtnCustomWinPE_DetectADK.Name = "BtnCustomWinPE_DetectADK"
        Me.BtnCustomWinPE_DetectADK.Size = New System.Drawing.Size(106, 26)
        Me.BtnCustomWinPE_DetectADK.TabIndex = 95
        Me.BtnCustomWinPE_DetectADK.Text = "Detect ADK"
        Me.BtnCustomWinPE_DetectADK.UseVisualStyleBackColor = True
        '
        'TxtBoxCustomWinPE_DetectADKPath
        '
        Me.TxtBoxCustomWinPE_DetectADKPath.Location = New System.Drawing.Point(166, 97)
        Me.TxtBoxCustomWinPE_DetectADKPath.Name = "TxtBoxCustomWinPE_DetectADKPath"
        Me.TxtBoxCustomWinPE_DetectADKPath.Size = New System.Drawing.Size(359, 26)
        Me.TxtBoxCustomWinPE_DetectADKPath.TabIndex = 94
        '
        'LblCustomWinPE_DetectADKPath
        '
        Me.LblCustomWinPE_DetectADKPath.AutoSize = True
        Me.LblCustomWinPE_DetectADKPath.Location = New System.Drawing.Point(3, 100)
        Me.LblCustomWinPE_DetectADKPath.Name = "LblCustomWinPE_DetectADKPath"
        Me.LblCustomWinPE_DetectADKPath.Size = New System.Drawing.Size(135, 20)
        Me.LblCustomWinPE_DetectADKPath.TabIndex = 93
        Me.LblCustomWinPE_DetectADKPath.Text = "Detect ADK Path:"
        '
        'BtnCustomWinPE_Apply
        '
        Me.BtnCustomWinPE_Apply.Location = New System.Drawing.Point(698, 114)
        Me.BtnCustomWinPE_Apply.Name = "BtnCustomWinPE_Apply"
        Me.BtnCustomWinPE_Apply.Size = New System.Drawing.Size(163, 64)
        Me.BtnCustomWinPE_Apply.TabIndex = 92
        Me.BtnCustomWinPE_Apply.Text = "Apply"
        Me.BtnCustomWinPE_Apply.UseVisualStyleBackColor = True
        '
        'ChkboxCustomWinPE_StorageWMI
        '
        Me.ChkboxCustomWinPE_StorageWMI.AutoSize = True
        Me.ChkboxCustomWinPE_StorageWMI.Location = New System.Drawing.Point(391, 231)
        Me.ChkboxCustomWinPE_StorageWMI.Name = "ChkboxCustomWinPE_StorageWMI"
        Me.ChkboxCustomWinPE_StorageWMI.Size = New System.Drawing.Size(118, 24)
        Me.ChkboxCustomWinPE_StorageWMI.TabIndex = 91
        Me.ChkboxCustomWinPE_StorageWMI.Text = "StorageWMI"
        Me.ChkboxCustomWinPE_StorageWMI.UseVisualStyleBackColor = True
        '
        'ChkboxCustomWinPE_Scripting
        '
        Me.ChkboxCustomWinPE_Scripting.AutoSize = True
        Me.ChkboxCustomWinPE_Scripting.Location = New System.Drawing.Point(282, 231)
        Me.ChkboxCustomWinPE_Scripting.Name = "ChkboxCustomWinPE_Scripting"
        Me.ChkboxCustomWinPE_Scripting.Size = New System.Drawing.Size(90, 24)
        Me.ChkboxCustomWinPE_Scripting.TabIndex = 90
        Me.ChkboxCustomWinPE_Scripting.Text = "Scripting"
        Me.ChkboxCustomWinPE_Scripting.UseVisualStyleBackColor = True
        '
        'ChkboxCustomWinPE_PowerShell
        '
        Me.ChkboxCustomWinPE_PowerShell.AutoSize = True
        Me.ChkboxCustomWinPE_PowerShell.Location = New System.Drawing.Point(166, 231)
        Me.ChkboxCustomWinPE_PowerShell.Name = "ChkboxCustomWinPE_PowerShell"
        Me.ChkboxCustomWinPE_PowerShell.Size = New System.Drawing.Size(107, 24)
        Me.ChkboxCustomWinPE_PowerShell.TabIndex = 89
        Me.ChkboxCustomWinPE_PowerShell.Text = "PowerShell"
        Me.ChkboxCustomWinPE_PowerShell.UseVisualStyleBackColor = True
        '
        'ChkboxCustomWinPE_NetFx
        '
        Me.ChkboxCustomWinPE_NetFx.AutoSize = True
        Me.ChkboxCustomWinPE_NetFx.Location = New System.Drawing.Point(504, 201)
        Me.ChkboxCustomWinPE_NetFx.Name = "ChkboxCustomWinPE_NetFx"
        Me.ChkboxCustomWinPE_NetFx.Size = New System.Drawing.Size(70, 24)
        Me.ChkboxCustomWinPE_NetFx.TabIndex = 88
        Me.ChkboxCustomWinPE_NetFx.Text = "NetFx"
        Me.ChkboxCustomWinPE_NetFx.UseVisualStyleBackColor = True
        '
        'ChkboxCustomWinPE_WMI
        '
        Me.ChkboxCustomWinPE_WMI.AutoSize = True
        Me.ChkboxCustomWinPE_WMI.Location = New System.Drawing.Point(391, 201)
        Me.ChkboxCustomWinPE_WMI.Name = "ChkboxCustomWinPE_WMI"
        Me.ChkboxCustomWinPE_WMI.Size = New System.Drawing.Size(61, 24)
        Me.ChkboxCustomWinPE_WMI.TabIndex = 87
        Me.ChkboxCustomWinPE_WMI.Text = "WMI"
        Me.ChkboxCustomWinPE_WMI.UseVisualStyleBackColor = True
        '
        'ChkboxCustomWinPE_MDAC
        '
        Me.ChkboxCustomWinPE_MDAC.AutoSize = True
        Me.ChkboxCustomWinPE_MDAC.Location = New System.Drawing.Point(282, 201)
        Me.ChkboxCustomWinPE_MDAC.Name = "ChkboxCustomWinPE_MDAC"
        Me.ChkboxCustomWinPE_MDAC.Size = New System.Drawing.Size(75, 24)
        Me.ChkboxCustomWinPE_MDAC.TabIndex = 86
        Me.ChkboxCustomWinPE_MDAC.Text = "MDAC"
        Me.ChkboxCustomWinPE_MDAC.UseVisualStyleBackColor = True
        '
        'ChkboxCustomWinPE_HTA
        '
        Me.ChkboxCustomWinPE_HTA.AutoSize = True
        Me.ChkboxCustomWinPE_HTA.Location = New System.Drawing.Point(166, 201)
        Me.ChkboxCustomWinPE_HTA.Name = "ChkboxCustomWinPE_HTA"
        Me.ChkboxCustomWinPE_HTA.Size = New System.Drawing.Size(60, 24)
        Me.ChkboxCustomWinPE_HTA.TabIndex = 85
        Me.ChkboxCustomWinPE_HTA.Text = "HTA"
        Me.ChkboxCustomWinPE_HTA.UseVisualStyleBackColor = True
        '
        'BtnCustomWinPE_GetMountedImageInfo
        '
        Me.BtnCustomWinPE_GetMountedImageInfo.Location = New System.Drawing.Point(698, 12)
        Me.BtnCustomWinPE_GetMountedImageInfo.Name = "BtnCustomWinPE_GetMountedImageInfo"
        Me.BtnCustomWinPE_GetMountedImageInfo.Size = New System.Drawing.Size(163, 64)
        Me.BtnCustomWinPE_GetMountedImageInfo.TabIndex = 84
        Me.BtnCustomWinPE_GetMountedImageInfo.Text = "Get Mounted Image Info"
        Me.BtnCustomWinPE_GetMountedImageInfo.UseVisualStyleBackColor = True
        '
        'BtnCustomWinPE_RefreshMountedImage
        '
        Me.BtnCustomWinPE_RefreshMountedImage.Location = New System.Drawing.Point(242, 12)
        Me.BtnCustomWinPE_RefreshMountedImage.Name = "BtnCustomWinPE_RefreshMountedImage"
        Me.BtnCustomWinPE_RefreshMountedImage.Size = New System.Drawing.Size(221, 32)
        Me.BtnCustomWinPE_RefreshMountedImage.TabIndex = 83
        Me.BtnCustomWinPE_RefreshMountedImage.Text = "Refresh mounted image"
        Me.BtnCustomWinPE_RefreshMountedImage.UseVisualStyleBackColor = True
        '
        'LblCustomWinPE_UseImageMounted
        '
        Me.LblCustomWinPE_UseImageMounted.AutoSize = True
        Me.LblCustomWinPE_UseImageMounted.Location = New System.Drawing.Point(2, 56)
        Me.LblCustomWinPE_UseImageMounted.Name = "LblCustomWinPE_UseImageMounted"
        Me.LblCustomWinPE_UseImageMounted.Size = New System.Drawing.Size(158, 20)
        Me.LblCustomWinPE_UseImageMounted.TabIndex = 82
        Me.LblCustomWinPE_UseImageMounted.Text = "Use Image Mounted:"
        '
        'CmbBoxCustomWinPE_UseImageMounted
        '
        Me.CmbBoxCustomWinPE_UseImageMounted.FormattingEnabled = True
        Me.CmbBoxCustomWinPE_UseImageMounted.Location = New System.Drawing.Point(166, 53)
        Me.CmbBoxCustomWinPE_UseImageMounted.Name = "CmbBoxCustomWinPE_UseImageMounted"
        Me.CmbBoxCustomWinPE_UseImageMounted.Size = New System.Drawing.Size(359, 28)
        Me.CmbBoxCustomWinPE_UseImageMounted.TabIndex = 81
        '
        'BackgroundWorkerDISMCommand
        '
        '
        'BtnMountControl_ClearConsole
        '
        Me.BtnMountControl_ClearConsole.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnMountControl_ClearConsole.Location = New System.Drawing.Point(788, 410)
        Me.BtnMountControl_ClearConsole.Name = "BtnMountControl_ClearConsole"
        Me.BtnMountControl_ClearConsole.Size = New System.Drawing.Size(113, 32)
        Me.BtnMountControl_ClearConsole.TabIndex = 19
        Me.BtnMountControl_ClearConsole.Text = "Clear console"
        Me.BtnMountControl_ClearConsole.UseVisualStyleBackColor = True
        '
        'TxtBox_DismVersionWindows
        '
        Me.TxtBox_DismVersionWindows.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TxtBox_DismVersionWindows.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TxtBox_DismVersionWindows.Location = New System.Drawing.Point(632, 417)
        Me.TxtBox_DismVersionWindows.Name = "TxtBox_DismVersionWindows"
        Me.TxtBox_DismVersionWindows.Size = New System.Drawing.Size(147, 19)
        Me.TxtBox_DismVersionWindows.TabIndex = 20
        '
        'LblMountUnmount_DismVersion
        '
        Me.LblMountUnmount_DismVersion.AutoSize = True
        Me.LblMountUnmount_DismVersion.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblMountUnmount_DismVersion.Location = New System.Drawing.Point(450, 416)
        Me.LblMountUnmount_DismVersion.Name = "LblMountUnmount_DismVersion"
        Me.LblMountUnmount_DismVersion.Size = New System.Drawing.Size(176, 20)
        Me.LblMountUnmount_DismVersion.TabIndex = 21
        Me.LblMountUnmount_DismVersion.Text = "DISM Windows version:"
        '
        'LblMountUnmount_DismADKVersion
        '
        Me.LblMountUnmount_DismADKVersion.AutoSize = True
        Me.LblMountUnmount_DismADKVersion.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblMountUnmount_DismADKVersion.Location = New System.Drawing.Point(146, 417)
        Me.LblMountUnmount_DismADKVersion.Name = "LblMountUnmount_DismADKVersion"
        Me.LblMountUnmount_DismADKVersion.Size = New System.Drawing.Size(145, 20)
        Me.LblMountUnmount_DismADKVersion.TabIndex = 22
        Me.LblMountUnmount_DismADKVersion.Text = "DISM ADK version:"
        '
        'TxtBox_DismVersionADK
        '
        Me.TxtBox_DismVersionADK.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TxtBox_DismVersionADK.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TxtBox_DismVersionADK.Location = New System.Drawing.Point(297, 417)
        Me.TxtBox_DismVersionADK.Name = "TxtBox_DismVersionADK"
        Me.TxtBox_DismVersionADK.Size = New System.Drawing.Size(147, 19)
        Me.TxtBox_DismVersionADK.TabIndex = 23
        '
        'BackgroundWorkerDismCommand2
        '
        '
        'frmMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(955, 718)
        Me.Controls.Add(Me.TxtBox_DismVersionADK)
        Me.Controls.Add(Me.LblMountUnmount_DismADKVersion)
        Me.Controls.Add(Me.LblMountUnmount_DismVersion)
        Me.Controls.Add(Me.TxtBox_DismVersionWindows)
        Me.Controls.Add(Me.BtnMountControl_ClearConsole)
        Me.Controls.Add(Me.TabControl1)
        Me.Controls.Add(Me.LblMountControl_DISMOutput)
        Me.Controls.Add(Me.txtOutput)
        Me.Controls.Add(Me.MenuStrip1)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "frmMain"
        Me.Text = "DISM GUI"
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.TabPage1.PerformLayout()
        Me.TabPage2.ResumeLayout(False)
        Me.TabPage2.PerformLayout()
        Me.GroupBoxDriverManagement_DeleteDrivers.ResumeLayout(False)
        Me.GroupBoxDriverManagement_DeleteDrivers.PerformLayout()
        Me.GroupBoxDriverManagement_AddDrivers.ResumeLayout(False)
        Me.GroupBoxDriverManagement_AddDrivers.PerformLayout()
        Me.TabPage3.ResumeLayout(False)
        Me.TabPage3.PerformLayout()
        Me.GrpBoxPackageManage_RemovePackages.ResumeLayout(False)
        Me.GrpBoxPackageManage_RemovePackages.PerformLayout()
        Me.GrpBoxPackageManage_AddPackage.ResumeLayout(False)
        Me.GrpBoxPackageManage_AddPackage.PerformLayout()
        Me.TabPage4.ResumeLayout(False)
        Me.TabPage4.PerformLayout()
        Me.TabPage5.ResumeLayout(False)
        Me.TabPage5.PerformLayout()
        Me.TabPage6.ResumeLayout(False)
        Me.TabPage6.PerformLayout()
        Me.TabPage7.ResumeLayout(False)
        Me.TabPage7.PerformLayout()
        Me.TabPage8.ResumeLayout(False)
        Me.TabPage8.PerformLayout()
        Me.TabPage9.ResumeLayout(False)
        Me.TabPage9.PerformLayout()
        Me.TabPage10.ResumeLayout(False)
        Me.TabPage10.PerformLayout()
        Me.TabPage11.ResumeLayout(False)
        Me.TabPage11.PerformLayout()
        Me.TabPage12.ResumeLayout(False)
        Me.TabPage12.PerformLayout()
        Me.TabPage13.ResumeLayout(False)
        Me.TabPage13.PerformLayout()
        Me.TabPage14.ResumeLayout(False)
        Me.TabPage14.PerformLayout()
        Me.TabPage15.ResumeLayout(False)
        Me.TabPage15.PerformLayout()
        Me.TabPage16.ResumeLayout(False)
        Me.TabPage16.PerformLayout()
        Me.TabPage17.ResumeLayout(False)
        Me.TabPage17.PerformLayout()
        Me.TabPage18.ResumeLayout(False)
        Me.TabPage18.PerformLayout()
        Me.TabPage19.ResumeLayout(False)
        Me.TabPage19.PerformLayout()
        Me.TabPage20.ResumeLayout(False)
        Me.TabPage20.PerformLayout()
        Me.GrpBoxDiskpartWinPE_HardwareType.ResumeLayout(False)
        Me.GrpBoxDiskpartWinPE_HardwareType.PerformLayout()
        CType(Me.PictBoxDiskpartWinPE_Picture, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage21.ResumeLayout(False)
        Me.TabPage21.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents TxtMountControl_ImageFile As System.Windows.Forms.TextBox
    Friend WithEvents LblMountControl_WimFile As System.Windows.Forms.Label
    Friend WithEvents LblMountControl_MountLocation As System.Windows.Forms.Label
    Friend WithEvents TxtMountControl_MountLocation As System.Windows.Forms.TextBox
    Friend WithEvents dlgOpenFolder As System.Windows.Forms.FolderBrowserDialog
    Friend WithEvents dlgOpenFile As System.Windows.Forms.OpenFileDialog
    Friend WithEvents BtnMountControl_OpenWIM As System.Windows.Forms.Button
    Friend WithEvents BtnMountControl_OpenMount As System.Windows.Forms.Button
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents ToolsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents BtnMountControl_MountImage As System.Windows.Forms.Button
    Friend WithEvents CmbMountControl_Index As System.Windows.Forms.ComboBox
    Friend WithEvents AboutToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents BtnMountControl_UnmountImage As System.Windows.Forms.Button
    Friend WithEvents txtOutput As System.Windows.Forms.TextBox
    Friend WithEvents LblMountControl_DISMOutput As System.Windows.Forms.Label
    Friend WithEvents BtnMountControl_OpenMountedFolder As System.Windows.Forms.Button
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents OpenDISMLogToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents BackgroundWorkerMount As System.ComponentModel.BackgroundWorker
    Friend WithEvents BackgroundWorkerDisMount As System.ComponentModel.BackgroundWorker
    Friend WithEvents TabControl1 As System.Windows.Forms.TabControl
    Friend WithEvents TabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage2 As System.Windows.Forms.TabPage
    Friend WithEvents LblDriverManagement_DriversFolderLocation As System.Windows.Forms.Label
    Friend WithEvents BtnDriverManagement_GetDrivers As System.Windows.Forms.Button
    Friend WithEvents TxtBoxDriverManagement_DriverFolderLocation As System.Windows.Forms.TextBox
    Friend WithEvents BtnDriverManagement_OpenDriverFolder As System.Windows.Forms.Button
    Friend WithEvents ChkDriverManagement_ForceUnsigned As System.Windows.Forms.CheckBox
    Friend WithEvents BtnDriverManagement_AddDrivers As System.Windows.Forms.Button
    Friend WithEvents BackgroundWorkerDISMCommand As System.ComponentModel.BackgroundWorker
    Friend WithEvents CleanupWIMToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents GetWIMInfoToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TabPage3 As System.Windows.Forms.TabPage
    Friend WithEvents BtnPackageManage_GetPackages As System.Windows.Forms.Button
    Friend WithEvents TabPage4 As System.Windows.Forms.TabPage
    Friend WithEvents LblPackageManage_PackageFolder As System.Windows.Forms.Label
    Friend WithEvents txtPackageFile As System.Windows.Forms.TextBox
    Friend WithEvents BtnPackageManage_OpenPackageFile As System.Windows.Forms.Button
    Friend WithEvents BtnPackageManage_AddPackages As System.Windows.Forms.Button
    Friend WithEvents chkIgnoreCheck As System.Windows.Forms.CheckBox
    Friend WithEvents GroupBoxDriverManagement_AddDrivers As System.Windows.Forms.GroupBox
    Friend WithEvents BtnDriverManagement_GetAllDriverInfo As System.Windows.Forms.Button
    Friend WithEvents GroupBoxDriverManagement_DeleteDrivers As System.Windows.Forms.GroupBox
    Friend WithEvents BtnDriverManagement_DelDriver As System.Windows.Forms.Button
    Friend WithEvents TxtBoxDriverManagement_DelDriverLocation As System.Windows.Forms.TextBox
    Friend WithEvents LblDriverManagement_DriverName As System.Windows.Forms.Label
    Friend WithEvents GrpBoxPackageManage_RemovePackages As System.Windows.Forms.GroupBox
    Friend WithEvents LblPackageManage_PackageName As System.Windows.Forms.Label
    Friend WithEvents LblPackageManage_PackagePath As System.Windows.Forms.Label
    Friend WithEvents BtnPackageManage_RemovePackagePath As System.Windows.Forms.Button
    Friend WithEvents BtnPackageManage_RemovePackage As System.Windows.Forms.Button
    Friend WithEvents txtPackagePath As System.Windows.Forms.TextBox
    Friend WithEvents txtPackageName As System.Windows.Forms.TextBox
    Friend WithEvents GrpBoxPackageManage_AddPackage As System.Windows.Forms.GroupBox
    Friend WithEvents ChkDriverManagement_Recurse As System.Windows.Forms.CheckBox
    Friend WithEvents BtnFeatureManage_GetFeatures As System.Windows.Forms.Button
    Friend WithEvents BtnFeatureManage_EnableFeature As System.Windows.Forms.Button
    Friend WithEvents LblFeatureManage_PackagePath As System.Windows.Forms.Label
    Friend WithEvents LblFeatureManage_PackageName As System.Windows.Forms.Label
    Friend WithEvents LblFeatureManage_FeatureName As System.Windows.Forms.Label
    Friend WithEvents txtFeatPackagePath As System.Windows.Forms.TextBox
    Friend WithEvents txtFeatPackageName As System.Windows.Forms.TextBox
    Friend WithEvents txtFeatureName As System.Windows.Forms.TextBox
    Friend WithEvents chkEnablePkgPath As System.Windows.Forms.CheckBox
    Friend WithEvents chkEnablePkgName As System.Windows.Forms.CheckBox
    Friend WithEvents BtnFeatureManage_DisableFeature As System.Windows.Forms.Button
    Friend WithEvents CleanupImageToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents UseDismADKToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TabPage5 As System.Windows.Forms.TabPage
    Friend WithEvents BtnEditionServicing_GetTargetEditions As System.Windows.Forms.Button
    Friend WithEvents BtnEditionServicing_GetCurrentEdition As System.Windows.Forms.Button
    Friend WithEvents LblEditionServicing_ProductKey As System.Windows.Forms.Label
    Friend WithEvents BtnEditionServicing_SetProductKey As System.Windows.Forms.Button
    Friend WithEvents txtProdKey As System.Windows.Forms.MaskedTextBox
    Friend WithEvents BtnEditionServicing_SetEdition As System.Windows.Forms.Button
    Friend WithEvents txtEdition As System.Windows.Forms.TextBox
    Friend WithEvents TabPage6 As System.Windows.Forms.TabPage
    Friend WithEvents BtnUnattendedServicing_ChooseUnAttend As System.Windows.Forms.Button
    Friend WithEvents TxtBoxUnattendedServicing_XMLFile As System.Windows.Forms.TextBox
    Friend WithEvents LblUnattendedServicing_XMLFile As System.Windows.Forms.Label
    Friend WithEvents BtnUnattendedServicing_ApplyUnattend As System.Windows.Forms.Button
    Friend WithEvents TabPage7 As System.Windows.Forms.TabPage
    Friend WithEvents BtnApplicationServicing_GetApps As System.Windows.Forms.Button
    Friend WithEvents LblEditionServicing_Edition As System.Windows.Forms.Label
    Friend WithEvents BtnApplicationServicing_GetAppInfo As System.Windows.Forms.Button
    Friend WithEvents LblApplicationServicing_PathCode As System.Windows.Forms.Label
    Friend WithEvents LblApplicationServicing_ProductCode As System.Windows.Forms.Label
    Friend WithEvents BtnApplicationServicing_CheckAppPatch As System.Windows.Forms.Button
    Friend WithEvents BtnApplicationServicing_GetAppPatchInfo As System.Windows.Forms.Button
    Friend WithEvents BtnApplicationServicing_GetAppPatches As System.Windows.Forms.Button
    Friend WithEvents txtPatchCode As System.Windows.Forms.MaskedTextBox
    Friend WithEvents txtProductCode As System.Windows.Forms.MaskedTextBox
    Friend WithEvents BtnApplicationServicing_ChooseMSP As System.Windows.Forms.Button
    Friend WithEvents txtPatchLocation As System.Windows.Forms.TextBox
    Friend WithEvents LblApplicationServicing_MSPFile As System.Windows.Forms.Label
    Friend WithEvents dlgOpenXML As System.Windows.Forms.OpenFileDialog
    Friend WithEvents dlgOpenMSP As System.Windows.Forms.OpenFileDialog
    Friend WithEvents TabPage8 As System.Windows.Forms.TabPage
    Friend WithEvents BtnCaptureImageWim_AppendWim As System.Windows.Forms.Button
    Friend WithEvents cmbCompression As System.Windows.Forms.ComboBox
    Friend WithEvents LblCaptureImageWim_Compression As System.Windows.Forms.Label
    Friend WithEvents LblCaptureImageWim_FileName As System.Windows.Forms.Label
    Friend WithEvents TxtFileName As System.Windows.Forms.TextBox
    Friend WithEvents BtnCaptureImageWim_CreateWim As System.Windows.Forms.Button
    Friend WithEvents LblCaptureImageWim_Destination As System.Windows.Forms.Label
    Friend WithEvents LblCaptureImageWim_Source As System.Windows.Forms.Label
    Friend WithEvents BtnCaptureImageWim_BrowseDestination As System.Windows.Forms.Button
    Friend WithEvents txtCaptureDest As System.Windows.Forms.TextBox
    Friend WithEvents txtCaptureSource As System.Windows.Forms.TextBox
    Friend WithEvents BtnCaptureImageWim_BrowseSource As System.Windows.Forms.Button
    Friend WithEvents TabPage9 As System.Windows.Forms.TabPage
    Friend WithEvents cmbApplyIndex As System.Windows.Forms.ComboBox
    Friend WithEvents LblApplyWim_Index As System.Windows.Forms.Label
    Friend WithEvents BtnApplyWim_ApplyWim As System.Windows.Forms.Button
    Friend WithEvents LblApplyWim_Destination As System.Windows.Forms.Label
    Friend WithEvents LblApplyWim_Source As System.Windows.Forms.Label
    Friend WithEvents BtnApplyWim_BrowseDestination As System.Windows.Forms.Button
    Friend WithEvents txtApplyDest As System.Windows.Forms.TextBox
    Friend WithEvents txtApplySource As System.Windows.Forms.TextBox
    Friend WithEvents BtnApplyWim_BrowseSource As System.Windows.Forms.Button
    Friend WithEvents ChkBoxApplyWim_Verify As System.Windows.Forms.CheckBox
    Friend WithEvents ChkBoxCaptureImageWim_Verify As System.Windows.Forms.CheckBox
    Friend WithEvents ChkMountControl_ReadOnly As System.Windows.Forms.CheckBox
    Friend WithEvents LblMountControl_Size As Label
    Friend WithEvents LblMountControl_Description As Label
    Friend WithEvents LblMountControl_Name As Label
    Friend WithEvents TxtBoxMountControl_Size As TextBox
    Friend WithEvents TxtBoxMountControl_Description As TextBox
    Friend WithEvents TxtBoxMountControl_Name As TextBox
    Friend WithEvents LblCaptureImageWim_NameMetadata As Label
    Friend WithEvents TxtNameMetadata As TextBox
    Friend WithEvents TabPage10 As TabPage
    Friend WithEvents TabPage11 As TabPage
    Friend WithEvents TabPage12 As TabPage
    Friend WithEvents TabPage13 As TabPage
    Friend WithEvents TabPage14 As TabPage
    Friend WithEvents TabPage15 As TabPage
    Friend WithEvents TabPage16 As TabPage
    Friend WithEvents BtnExportImage_ExportImage As Button
    Friend WithEvents BtnExportImage_BrowseDestination As Button
    Friend WithEvents BtnExportImage_BrowseSource As Button
    Friend WithEvents LblExportImage_Size As Label
    Friend WithEvents TxtBoxExportImage_Size As TextBox
    Friend WithEvents LblExportImage_Description As Label
    Friend WithEvents LblExportImage_Name As Label
    Friend WithEvents TxtBoxExportImage_Description As TextBox
    Friend WithEvents TxtBoxExportImage_Name As TextBox
    Friend WithEvents LblExportImage_Filename As Label
    Friend WithEvents TxtBoxExportImage_Filename As TextBox
    Friend WithEvents LblExportImage_Destination As Label
    Friend WithEvents LblExportImage_Source As Label
    Friend WithEvents TxtBoxExportImage_Destination As TextBox
    Friend WithEvents TxtBoxExportImage_Source As TextBox
    Friend WithEvents ChkBoxExportImage_WimBoot As CheckBox
    Friend WithEvents ChkBoxExportImage_CheckIntegrity As CheckBox
    Friend WithEvents CmbBoxExportImage_Compression As ComboBox
    Friend WithEvents LblExportImage_LevelCompression As Label
    Friend WithEvents ChkBoxExportImage_Bootable As CheckBox
    Friend WithEvents CmbBoxExportImage_Index As ComboBox
    Friend WithEvents LblExportImage_Index As Label
    Private WithEvents Label25 As Label
    Private WithEvents BtnLangAndInterServ_ApplyAllIntl As Button
    Private WithEvents LblLangAndInterServ_SetAllIntl As Label
    Private WithEvents BtnLangAndInterServicing_DisplayInfo As Button
    Private WithEvents BtnExportDriver_ExportDriver As Button
    Private WithEvents LblExportDriver_Folder As Label
    Private WithEvents TxtBoxExport_PathDriverFolder As TextBox
    Private WithEvents BtnExportDriver_SelectFolder As Button
    Friend WithEvents CmbBoxLangAndInterServ_SetAllIntl As ComboBox
    Private WithEvents BtnSplitImage_WIMChoice As Button
    Private WithEvents BtnSplitImage_TargetFolder As Button
    Private WithEvents LblSplitImage_DestinationFolder As Label
    Private WithEvents TxtBoxSplitImage_DestinationFolder As TextBox
    Private WithEvents BtnSplitImage_SplitImage As Button
    Private WithEvents ChkBoxSplitImage_CheckIntegrity As CheckBox
    Private WithEvents LblSplitImage_SplitSize As Label
    Private WithEvents TxtBoxSplitImage_Filesize As TextBox
    Private WithEvents LblSplitImage_SWMFilename As Label
    Private WithEvents LblSplitImage_WIMFilename As Label
    Private WithEvents TxtBoxSplitImage_SWMFilename As TextBox
    Private WithEvents TxtBoxSplitImage_WIMFilename As TextBox
    Private WithEvents LblCaptureFfu_Description As Label
    Private WithEvents TxtBoxCaptureFfu_Description As TextBox
    Private WithEvents LstBoxCaptureFfu_LogicalDrive As ListBox
    Private WithEvents LblCaptureFfu_LogicalDrive As Label
    Private WithEvents LblCaptureFfu_Name As Label
    Private WithEvents TxtBoxCaptFfu_Name As TextBox
    Private WithEvents LblCaptureFfu_PlatformID As Label
    Private WithEvents TxtBoxCaptFfu_PlatformID As TextBox
    Private WithEvents LblCaptureFfu_Compression As Label
    Private WithEvents LblCaptureFfu_TargetFilename As Label
    Private WithEvents LblCaptureFfu_TargetFolder As Label
    Private WithEvents LblCaptureFfu_PhysicalDrive As Label
    Private WithEvents CmbBoxCaptureFfu_Compression As ComboBox
    Private WithEvents TxtBoxCaptFfu_TargetFilename As TextBox
    Private WithEvents TxtBoxCaptFfu_TargetFolder As TextBox
    Private WithEvents TxtBoxCaptFfu_PhysicalDrive As TextBox
    Private WithEvents BtnCaptureFfu_StartCapture As Button
    Private WithEvents BtnCaptureFfu_SetTargetFolder As Button
    Private WithEvents BtnCaptureFfu_UpdateLogicalDrive As Button
    Private WithEvents LstBoxApplyFfuImage_LogicalDrive As ListBox
    Private WithEvents LblApplyFfuImage_LogicalDrive As Label
    Private WithEvents LblApplyFfuImage_MotifSFUFile As Label
    Private WithEvents LblApplyFfuImage_SourceFilename As Label
    Private WithEvents LblApplyFfuImage_PhysicalDrive As Label
    Private WithEvents TxtBoxApplyFfuImageFfu_MotifSFUFile As TextBox
    Private WithEvents TxtBoxApplyFfuImage_FfuSourceFilename As TextBox
    Private WithEvents TxtBoxApplyFfuImage_PhysicalDrive As TextBox
    Private WithEvents BtnApplyFfuImage_ApplyFfuImage As Button
    Private WithEvents BtnApplyFfuImage_SelectFfuFile As Button
    Private WithEvents BtnApplyFfuImage_UpdateLogicalDrive As Button
    Private WithEvents BtnSplitFfu_SelectFfuFile As Button
    Private WithEvents BtnSplitFfu_SelectTargetFolder As Button
    Private WithEvents LblSplitFfu_TargetFolder As Label
    Private WithEvents TxtBoxSplitFfu_TargetFolder As TextBox
    Private WithEvents BtnSplitFfuImage_StartSplitImage As Button
    Private WithEvents ChkBoxSplitFfu_CheckIntegrity As CheckBox
    Private WithEvents LblSplitFfu_SplitFileSize As Label
    Private WithEvents TxtBoxSplitFfu_SplitFileSize As TextBox
    Private WithEvents LblSplitFfu_SFUFilename As Label
    Private WithEvents LblSplitFfu_FfuFilename As Label
    Private WithEvents TxtBoxSplitFfu_SFUFilename As TextBox
    Private WithEvents TxtBoxSplitFfu_FfuFilename As TextBox
    Friend WithEvents LblCaptureImageWim_DescriptionMetadata As Label
    Friend WithEvents TxtBoxCaptureWIM_Description As TextBox
    Friend WithEvents LblApplyWim_Size As Label
    Friend WithEvents TxtBoxApplyWim_Size As TextBox
    Friend WithEvents LblApplyWim_Description As Label
    Friend WithEvents LblApplyWim_Name As Label
    Friend WithEvents TxtBoxApplyWim_Description As TextBox
    Friend WithEvents TxtBoxApplyWim_Name As TextBox
    Friend WithEvents ChkBoxDriverManagement_Online As CheckBox
    Friend WithEvents ChkBoxPackageManagement_Online As CheckBox
    Friend WithEvents BtnMountControl_ClearConsole As Button
    Friend WithEvents TxtBox_DismVersionWindows As TextBox
    Friend WithEvents LblMountUnmount_DismVersion As Label
    Friend WithEvents ChkBoxFeatureManagement_Online As CheckBox
    Friend WithEvents ChkBoxEditionServicing_Online As CheckBox
    Friend WithEvents ChkBoxUnattendedServicing_Online As CheckBox
    Friend WithEvents LblApplyWim_PatternSWMFile As Label
    Friend WithEvents TxtBoxApplySource_PatternSWMFile As TextBox
    Friend WithEvents BtnMountControl_DisplayImageInfo As Button
    Friend WithEvents BtnPackageManage_GetPackageInfo As Button
    Friend WithEvents TabPage17 As TabPage
    Friend WithEvents BtnDefaultAppAssocServ_Export As Button
    Friend WithEvents BtnDefaultAppAssocServ_Import As Button
    Friend WithEvents ChkBoxDefaultAppAssocServ_Online As CheckBox
    Friend WithEvents BtnDefaultAppAssocServ_GetDefaultAppAssoc As Button
    Friend WithEvents BtnDefaultAppAssocServ_Remove As Button
    Friend WithEvents BtnDefaultAppAssocServ_ChooseFile As Button
    Friend WithEvents LblDefaultAppAssocServ_ImportFilename As Label
    Friend WithEvents TxtBoxDefaultAppAssocServ_ImportFilenameXML As TextBox
    Friend WithEvents BtnDefaultAppAssocServ_ChooseFolder As Button
    Friend WithEvents LblDefaultAppAssocServ_ExportFolder As Label
    Friend WithEvents TxtBoxDefaultAppAssocServ_ExportFolder As TextBox
    Friend WithEvents LblLblDefaultAppAssocServ_ExportFilename As Label
    Friend WithEvents TxtBoxDefaultAppAssocServ_ExportFilenameXML As TextBox
    Friend WithEvents LblDefaultAppAssocServ_Warning As Label
    Friend WithEvents CmbBoxLangAndInterServ_SetInputLocal As ComboBox
    Private WithEvents BtnLangAndInterServ_ApplyInputLocale As Button
    Private WithEvents LblLangAndInterServ_SetInputLocale As Label
    Friend WithEvents CmbBoxLangAndInterServ_SetUserLocale As ComboBox
    Private WithEvents BtnLangAndInterServ_ApplyUserLocale As Button
    Private WithEvents LblLangAndInterServ_SetUserLocale As Label
    Friend WithEvents CmbBoxLangAndInterServ_SetUILang_SysLocale As ComboBox
    Private WithEvents BtnLangAndInterServ_ApplySysLocale As Button
    Private WithEvents LblLangAndInterServ_SetSysLocale As Label
    Friend WithEvents CmbBoxLangAndInterServ_SetSysUILang As ComboBox
    Private WithEvents BtnLangAndInterServ_ApplySysUILang As Button
    Private WithEvents LblLangAndInterServ_SetSysUILang As Label
    Friend WithEvents CmbBoxLangAndInterServ_SetUILangFallback As ComboBox
    Private WithEvents BtnLangAndInterServ_ApplyUILangFallback As Button
    Private WithEvents LblLangAndInterServ_SetUILangFallback As Label
    Friend WithEvents CmbBoxLangAndInterServ_SetUILang As ComboBox
    Private WithEvents BtnLangAndInterServ_ApplyUILang As Button
    Private WithEvents LblLangAndInterServ_SetUILang As Label
    Private WithEvents Button9 As Button
    Private WithEvents LblLangAndInterServ_GenLanINI As Label
    Friend WithEvents CmbBoxLangAndInterServ_SetSKUIntlDefaults As ComboBox
    Private WithEvents Button8 As Button
    Private WithEvents LblLangAndInterServ_SetSKUIntlDefaults As Label
    Friend WithEvents CmbBoxLangAndInterServ_SetTimeZone As ComboBox
    Private WithEvents BtnLangAndInterServ_ApplyTimeZone As Button
    Private WithEvents LblLangAndInterServ_SetTimeZone As Label
    Private WithEvents LblLangAndInterServ_Distribution As Label
    Friend WithEvents CmbBoxLangAndInterServ_SetSetupUILang As ComboBox
    Private WithEvents LblLangAndInterServ_SetupUILang As Label
    Private WithEvents BtnLangAndInterServ_ApplyDistribution As Button
    Private WithEvents BtnLangAndInterServ_ApplySetupUILang As Button
    Private WithEvents BtnLangAndInterServ_ApplyGenLangINI As Button
    Private WithEvents BtnLangAndInterServ_ApplySKUIntlDefaults As Button
    Friend WithEvents ChkBoxLangAndInterServ_Online As CheckBox
    Friend WithEvents LblCaptureFfu_Warning As Label
    Private WithEvents BtnLangAndInterServ_LayeredDriver As Button
    Friend WithEvents CmbBoxLangAndInterServ_SetLayeredDriver As ComboBox
    Private WithEvents LblLangAndInterServ_SetLayeredDriver As Label
    Friend WithEvents TxtBoxLangAndInterServ_PathDistribution As TextBox
    Friend WithEvents TxtBoxLangAndInterServ_Distribution As TextBox
    Friend WithEvents TxtBoxLangAndInterServ_DistributionSetupUILang As TextBox
    Private WithEvents LblLangAndInterServ_SetupUILangDistribution As Label
    Friend WithEvents TabPage18 As TabPage
    Friend WithEvents ChkBoxCapPackServ_Online As CheckBox
    Friend WithEvents BtnCapPackServ_GetCap As Button
    Friend WithEvents BtnCapPackServ_RemoveCap As Button
    Friend WithEvents BtnCapPackServ_GetCapInfo As Button
    Friend WithEvents BtnCapPackServ_ExportSource As Button
    Friend WithEvents LblCapPackServ_TargetExportSource As Label
    Friend WithEvents TxtBoxCapPackServ_Target As TextBox
    Friend WithEvents LblCapPackServ_SourceExportSource As Label
    Friend WithEvents TxtBoxCapPackServ_Source As TextBox
    Friend WithEvents ChkBoxCapPackServ_LimitAccess As CheckBox
    Friend WithEvents BtnCapPackServ_AddCapability As Button
    Friend WithEvents LblCapPackServ_CapabilityNameAddCap As Label
    Friend WithEvents TxtBoxCapPackServ_CapabilityName As TextBox
    Friend WithEvents TabPage19 As TabPage
    Friend WithEvents ChkBoxCleanupImage_Defer As CheckBox
    Friend WithEvents ChkBoxCleanupImage_ResetBase As CheckBox
    Friend WithEvents ChkBoxCleanupImage_HideSP As CheckBox
    Friend WithEvents BtnCleanupImage_AnalyzeComponentStore As Button
    Friend WithEvents LblCleanupImage_SourceRestoreHealth As Label
    Friend WithEvents TxtBoxCleanupImage_SourceRestoreHealth As TextBox
    Friend WithEvents ChkBoxCleanupImage_LimitAccessRestoreHealth As CheckBox
    Friend WithEvents ChkBoxCleanupImage_Online As CheckBox
    Friend WithEvents BtnCleanupImage_RevertPendingActions As Button
    Friend WithEvents BtnCleanupImage_CheckHealth As Button
    Friend WithEvents BtnCleanupImage_StartComponentCleanup As Button
    Friend WithEvents BtnCleanupImage_Superseded As Button
    Friend WithEvents BtnCleanupImage_ChooseSourceRestoreHealth As Button
    Friend WithEvents BtnCleanupImage_RestoreHealth As Button
    Friend WithEvents BtnCleanupImage_ScanHealth As Button
    Friend WithEvents Label5 As Label
    Friend WithEvents cmbCleanupImage_IndexSource As ComboBox
    Friend WithEvents BtnMountControl_GetMountedImageInfo As Button
    Friend WithEvents BtnMountControl_CommitImage As Button
    Friend WithEvents BtnMountControl_CleanupMountPoints As Button
    Friend WithEvents BtnMountControl_RemountWim As Button
    Friend WithEvents ChkBoxMountControl_CheckIntegrity As CheckBox
    Friend WithEvents ChkBoxMountControl_Optimize As CheckBox
    Friend WithEvents ChkBoxMountControl_Append As CheckBox
    Friend WithEvents BtnDriverManagement_GetMountedImageInfo As Button
    Friend WithEvents LblDriverManagement_UseMountedImage As Label
    Friend WithEvents CmbBoxDriverManagement_UseImageMounted As ComboBox
    Friend WithEvents BtnDriverManagement_RefreshMountedImage As Button
    Friend WithEvents BtnPackageManagement_RefreshMountedImage As Button
    Friend WithEvents LblPackageManagement_UseMountedImage As Label
    Friend WithEvents CmbBoxPackageManagement_UseImageMounted As ComboBox
    Friend WithEvents BtnPackageManagement_GetMountedImageInfo As Button
    Friend WithEvents BtnFeatureManagement_RefreshMountedImage As Button
    Friend WithEvents LblFeatureManage_UseMountedImage As Label
    Friend WithEvents CmbBoxFeatureManagement_UseImageMounted As ComboBox
    Friend WithEvents BtnFeatureManagement_GetMountedImageInfo As Button
    Friend WithEvents BtnEditionServicing_GetMountedImageInfo As Button
    Friend WithEvents BtnEditionServicing_RefreshMountedImage As Button
    Friend WithEvents LblEditionServicing_UseMountedImage As Label
    Friend WithEvents CmbBoxEditionServicing_UseImageMounted As ComboBox
    Friend WithEvents BtnUnattendedServicing_GetMountedImageInfo As Button
    Friend WithEvents BtnUnattendedServicing_RefreshMountedImage As Button
    Friend WithEvents LblUnattendedServicing_UseMountedImage As Label
    Friend WithEvents CmBoxUnattendedServicing_UseImageMounted As ComboBox
    Friend WithEvents BtnApplicationServicing_GetMountedImageInfo As Button
    Friend WithEvents BtnApplicationServicing_RefreshMountedImage As Button
    Friend WithEvents LblApplicationServicing_UseMountedImage As Label
    Friend WithEvents CmbBoxApplicationServicing_UseImageMounted As ComboBox
    Friend WithEvents ChkBoxExportDriver_Online As CheckBox
    Friend WithEvents BtnExportDriver_GetMountedImageInfo As Button
    Friend WithEvents BtnExportDriver_RefreshMountedImage As Button
    Friend WithEvents LblExportDriver_UseMountedImage As Label
    Friend WithEvents CmbBoxExportDriver_UseImageMounted As ComboBox
    Friend WithEvents RadBtnMountControl_Commit As RadioButton
    Friend WithEvents RadBtnMountControl_Discard As RadioButton
    Friend WithEvents ChkBoxPackageManagement_PreventPending As CheckBox
    Friend WithEvents LblMountControl_AlreadyMounted As Label
    Friend WithEvents BtnMountControl_RefreshMountedImage As Button
    Friend WithEvents CmbBoxMountControl_AlreadyMounted As ComboBox
    Friend WithEvents LblSplitImage_Warning As Label
    Friend WithEvents BtnFeatureManage_GetFeatureInfo As Button
    Friend WithEvents LblPackageManagement_Format As Label
    Friend WithEvents RadBtnPackageManagement_FormatList As RadioButton
    Friend WithEvents RadBtnPackageManagement_FormatTable As RadioButton
    Friend WithEvents ChkBoxFeatureManagement_All As CheckBox
    Friend WithEvents ChkBoxFeatureManagement_LimitAccess As CheckBox
    Friend WithEvents LblFeatureManage_Source As Label
    Friend WithEvents TxtBoxFeatureManagement_Source As TextBox
    Friend WithEvents ChkBoxFeatureManagement_Source As CheckBox
    Friend WithEvents BtnCleanupImage_GetMountedImageInfo As Button
    Friend WithEvents BtnCleanupImage_RefreshMountedImage As Button
    Friend WithEvents LblCleanupImage_UseMountedImage As Label
    Friend WithEvents CmbBoxCleanupImage_UseImageMounted As ComboBox
    Friend WithEvents Button1 As Button
    Friend WithEvents BtnCapPackServ_RefreshMountedImage As Button
    Friend WithEvents LblCapPackServ_UseMountedImage As Label
    Friend WithEvents CmbBoxCapPackServicing_UseImageMounted As ComboBox
    Friend WithEvents BtnCapPackServ_GetMountedImageInfo As Button
    Friend WithEvents BtnAppAssocServ_GetMountedImageInfo As Button
    Friend WithEvents Button3 As Button
    Friend WithEvents BtnDefaultAppAssocServ_RefreshMountedImage As Button
    Friend WithEvents LblBtnDefaultAppAssocServ_UseMountedImage As Label
    Friend WithEvents CmbBoxDefaultAppAssocServicing_UseImageMounted As ComboBox
    Friend WithEvents BtnLangAndInterServicing_GetMountedImageInfo As Button
    Friend WithEvents BtnLangAndInterServicing_RefreshMountedImage As Button
    Friend WithEvents LblLangAndInterServicing_UseMountedImage As Label
    Friend WithEvents CmbBoxLangAndInterServ_UseImageMounted As ComboBox
    Friend WithEvents TabPage20 As TabPage
    Friend WithEvents TxtBoxDispartWinPE_InfosDisk As TextBox
    Friend WithEvents BtnDiskpartWinPE_RefreshListDisk As Button
    Friend WithEvents BtnDiskpartWinPE_FormatDisk As Button
    Friend WithEvents LblDiskpartWinPE_SelectDrive As Label
    Friend WithEvents CmbBoxDiskpartWinpe_SelectDrive As ComboBox
    Friend WithEvents RadBtnDiskpartWinPE_HardDriveUEFI As RadioButton
    Friend WithEvents RadBtnDiskpartWinPE_HardDriveBIOS As RadioButton
    Friend WithEvents RadBtnDiskparWinPE_FAT32NTFS As RadioButton
    Friend WithEvents RadBtnDiskpartWinPE_NTFS As RadioButton
    Friend WithEvents RadBtnDiskpartWinPE_FAT32 As RadioButton
    Friend WithEvents TxtBoxDiskpartWinPE_Recovery As TextBox
    Friend WithEvents LblDiskpartWinPE_Recovery As Label
    Friend WithEvents TxtBoxDiskpartWinPE_Windows As TextBox
    Friend WithEvents LblDiskpartWinPE_Windows As Label
    Friend WithEvents TxtBoxDiskpartWinPE_MSR As TextBox
    Friend WithEvents LblDiskpartWinPE_MSR As Label
    Friend WithEvents TxtBoxDiskpartWinPE_System As TextBox
    Friend WithEvents LblDiskpartWinPE_System As Label
    Friend WithEvents TxtBoxDiskpartWinPE_NTFSSize As TextBox
    Friend WithEvents LblDiskpartWinPE_NTFSSize As Label
    Friend WithEvents TxtBoxDiskpartWinPE_FAT32Size As TextBox
    Friend WithEvents LblDiskpartWinPE_FAT32Size As Label
    Friend WithEvents PictBoxDiskpartWinPE_Picture As PictureBox
    Friend WithEvents RadBtnDiskpartWinPE_WinPEamd64 As RadioButton
    Friend WithEvents RadBtnDiskpartWinPE_WinPEx86 As RadioButton
    Friend WithEvents BtnDiskpartWinPE_CreateWinPETemplate As Button
    Friend WithEvents BtnDiskpartWinPE_BootDiskWinPE As Button
    Friend WithEvents GrpBoxDiskpartWinPE_HardwareType As GroupBox
    Friend WithEvents BtnPackageManagement_ChoosePackagePath As Button
    Friend WithEvents TabPage21 As TabPage
    Friend WithEvents BtnCustomWinPE_GetMountedImageInfo As Button
    Friend WithEvents BtnCustomWinPE_RefreshMountedImage As Button
    Friend WithEvents LblCustomWinPE_UseImageMounted As Label
    Friend WithEvents CmbBoxCustomWinPE_UseImageMounted As ComboBox
    Friend WithEvents BtnCustomWinPE_DetectADK As Button
    Friend WithEvents TxtBoxCustomWinPE_DetectADKPath As TextBox
    Friend WithEvents LblCustomWinPE_DetectADKPath As Label
    Friend WithEvents BtnCustomWinPE_Apply As Button
    Friend WithEvents ChkboxCustomWinPE_StorageWMI As CheckBox
    Friend WithEvents ChkboxCustomWinPE_Scripting As CheckBox
    Friend WithEvents ChkboxCustomWinPE_PowerShell As CheckBox
    Friend WithEvents ChkboxCustomWinPE_NetFx As CheckBox
    Friend WithEvents ChkboxCustomWinPE_WMI As CheckBox
    Friend WithEvents ChkboxCustomWinPE_MDAC As CheckBox
    Friend WithEvents ChkboxCustomWinPE_HTA As CheckBox
    Friend WithEvents RadBtnCustomWinPE_TypeAmd64 As RadioButton
    Friend WithEvents RadBtnCustomWinPE_TypeX86 As RadioButton
    Friend WithEvents LblCustomWinPE_SystemType As Label
    Friend WithEvents CmbBoxCustomWinPE_Language As ComboBox
    Friend WithEvents LblCustomWinPE_Language As Label
    Friend WithEvents LblMountUnmount_DismADKVersion As Label
    Friend WithEvents TxtBox_DismVersionADK As TextBox
    Friend WithEvents BackgroundWorkerDismCommand2 As System.ComponentModel.BackgroundWorker
    Friend WithEvents LblSplitFfu_Warning As Label
    Friend WithEvents LanguageToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents FrenchToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents EnglishToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents CmbBoxEditionServicing_GLVKKeys As ComboBox
    Friend WithEvents LblEditionServicing_GLVKKeys As Label
    Friend WithEvents CmbBoxEditionServicing_AVMAKeys As ComboBox
    Friend WithEvents LblEditionServicing_AVMAKeys As Label
    Friend WithEvents BtnCapPackServ_SelectTarget As Button
    Friend WithEvents BtnCapPackServ_SelectSource As Button
    Friend WithEvents ChkBoxCapPackServ_IncludeImageCapabilities As CheckBox
    Friend WithEvents BtnMakeWinPEISO As Button
    Friend WithEvents LblCustomWinPE_Packages As Label
    Friend WithEvents ChkboxCustomWinPE_AddScriptWinPEDetectTypeBios As CheckBox
    Friend WithEvents ChkboxCustomWinPE_AddMaxPowerPerf As CheckBox
    Friend WithEvents BtnCustomWinPE_ApplyMaxPerf As Button
    Friend WithEvents BtnCustomWinPE_ApplyDetectTypeBios As Button
End Class

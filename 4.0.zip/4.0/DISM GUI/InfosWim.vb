﻿Public Class InfosWIM
    Private Index_Wim As Integer        ' Index of Wim File
    Private Nom_Wim As String           ' Name of Wim
    Private Description_Wim As String   ' Description of Wim for Index Wim  
    Private Taille_Wim As ULong         ' mémorise la taille du WIM

    Property Index As Integer
        Get
            Return Index_Wim            ' Get Index of Wim
        End Get

        Set
            Index_Wim = Value           ' Set Index of Wim
        End Set
    End Property
    Property Nom As String
        Get
            Return Nom_Wim              ' Get Name of Wim
        End Get

        Set
            Nom_Wim = Value             ' Set Name of Wim
        End Set

    End Property
    Property Description As String

        Get
            Return Description_Wim      ' Get Description of Wim for Index Wim
        End Get

        Set
            Description_Wim = Value     ' Set Description of Wim for Index Wim
        End Set

    End Property

    Property Taille As ULong

        Get
            Return Taille_Wim           ' Get Taille of Wim for Index Wim
        End Get

        Set
            Taille_Wim = Value          ' Set Taille of Wim for Index Wim
        End Set
    End Property
End Class


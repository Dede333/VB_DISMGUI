﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.TxtMountControl_WimFile = New System.Windows.Forms.TextBox()
        Me.LblMountControl_WimFile = New System.Windows.Forms.Label()
        Me.LblMountControl_MountLocation = New System.Windows.Forms.Label()
        Me.TxtMountControl_MountLocation = New System.Windows.Forms.TextBox()
        Me.dlgOpenFolder = New System.Windows.Forms.FolderBrowserDialog()
        Me.dlgOpenFile = New System.Windows.Forms.OpenFileDialog()
        Me.BtnMountControl_OpenWIM = New System.Windows.Forms.Button()
        Me.BtnMountControl_OpenMount = New System.Windows.Forms.Button()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.ToolsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.OpenDISMLogToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.GetWIMInfoToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CleanupWIMToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CleanupImageToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.UseOnlineModeToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AboutToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.BtnMountControl_MountWim = New System.Windows.Forms.Button()
        Me.CmbMountControl_Index = New System.Windows.Forms.ComboBox()
        Me.BtnMountControl_DismountWim = New System.Windows.Forms.Button()
        Me.txtOutput = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.BtnMountControl_OpenMountedFolder = New System.Windows.Forms.Button()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.BackgroundWorkerMount = New System.ComponentModel.BackgroundWorker()
        Me.BackgroundWorkerDisMount = New System.ComponentModel.BackgroundWorker()
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.TxtLbl_Or = New System.Windows.Forms.Label()
        Me.BtnMountControl_DisplayImageInfo = New System.Windows.Forms.Button()
        Me.LblMountControl_Size = New System.Windows.Forms.Label()
        Me.LblMountControl_Description = New System.Windows.Forms.Label()
        Me.LblMountControl_Name = New System.Windows.Forms.Label()
        Me.TxtBoxMountControl_Size = New System.Windows.Forms.TextBox()
        Me.TxtBoxMountControl_Description = New System.Windows.Forms.TextBox()
        Me.TxtBoxMountControl_Name = New System.Windows.Forms.TextBox()
        Me.ChkMountControl_ReadOnly = New System.Windows.Forms.CheckBox()
        Me.BtnMountControl_DisplayWIMInfo = New System.Windows.Forms.Button()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.ChkBoxDriverManagement_Online = New System.Windows.Forms.CheckBox()
        Me.BtnDriverManagement_GetAllDriverInfo = New System.Windows.Forms.Button()
        Me.GroupBoxDriverManagement_DeleteDrivers = New System.Windows.Forms.GroupBox()
        Me.LblDriverManagement_DriverName = New System.Windows.Forms.Label()
        Me.BtnDriverManagement_DelDriver = New System.Windows.Forms.Button()
        Me.TxtBoxDriverManagement_DelDriverLocation = New System.Windows.Forms.TextBox()
        Me.BtnDriverManagement_GetDrivers = New System.Windows.Forms.Button()
        Me.GroupBoxDriverManagement_AddDrivers = New System.Windows.Forms.GroupBox()
        Me.ChkDriverManagement_Recurse = New System.Windows.Forms.CheckBox()
        Me.BtnDriverManagement_AddDrivers = New System.Windows.Forms.Button()
        Me.BtnDriverManagement_OpnDriverFolder = New System.Windows.Forms.Button()
        Me.LblDriverManagement_DriversFolderLocation = New System.Windows.Forms.Label()
        Me.ChkDriverManagement_ForceUnsigned = New System.Windows.Forms.CheckBox()
        Me.TxtBoxDriverManagement_DriverFolderLocation = New System.Windows.Forms.TextBox()
        Me.TabPage3 = New System.Windows.Forms.TabPage()
        Me.BtnGetPackageInfo = New System.Windows.Forms.Button()
        Me.ChkBoxPackageManagement_Online = New System.Windows.Forms.CheckBox()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.btnRemovePackagePath = New System.Windows.Forms.Button()
        Me.btnRemovePackageName = New System.Windows.Forms.Button()
        Me.txtPackagePath = New System.Windows.Forms.TextBox()
        Me.txtPackageName = New System.Windows.Forms.TextBox()
        Me.btnGetPackages = New System.Windows.Forms.Button()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.btnAddPackages = New System.Windows.Forms.Button()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.chkIgnoreCheck = New System.Windows.Forms.CheckBox()
        Me.txtPackageFile = New System.Windows.Forms.TextBox()
        Me.btnOpenPackageFile = New System.Windows.Forms.Button()
        Me.TabPage4 = New System.Windows.Forms.TabPage()
        Me.ChkBoxFeatureManagement_Online = New System.Windows.Forms.CheckBox()
        Me.btnDisableFeature = New System.Windows.Forms.Button()
        Me.chkEnablePkgPath = New System.Windows.Forms.CheckBox()
        Me.chkEnablePkgName = New System.Windows.Forms.CheckBox()
        Me.btnEnableFeature = New System.Windows.Forms.Button()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.txtFeatPackagePath = New System.Windows.Forms.TextBox()
        Me.txtFeatPackageName = New System.Windows.Forms.TextBox()
        Me.txtFeatureName = New System.Windows.Forms.TextBox()
        Me.btnGetFeatures = New System.Windows.Forms.Button()
        Me.TabPage5 = New System.Windows.Forms.TabPage()
        Me.ChkBoxEditionServicing_Online = New System.Windows.Forms.CheckBox()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.btnSetEdition = New System.Windows.Forms.Button()
        Me.txtEdition = New System.Windows.Forms.TextBox()
        Me.txtProdKey = New System.Windows.Forms.MaskedTextBox()
        Me.btnSetProdKey = New System.Windows.Forms.Button()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.btnGetTargetEditions = New System.Windows.Forms.Button()
        Me.btGetCurrentEdition = New System.Windows.Forms.Button()
        Me.TabPage6 = New System.Windows.Forms.TabPage()
        Me.ChkBoxUnattendedServicing_Online = New System.Windows.Forms.CheckBox()
        Me.btnChooseUnAttend = New System.Windows.Forms.Button()
        Me.TxtBox_UnattendXMLFile = New System.Windows.Forms.TextBox()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.btnApplyUnattend = New System.Windows.Forms.Button()
        Me.TabPage7 = New System.Windows.Forms.TabPage()
        Me.btnChooseMSP = New System.Windows.Forms.Button()
        Me.txtPatchLocation = New System.Windows.Forms.TextBox()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.txtPatchCode = New System.Windows.Forms.MaskedTextBox()
        Me.txtProductCode = New System.Windows.Forms.MaskedTextBox()
        Me.btnCheckAppPatch = New System.Windows.Forms.Button()
        Me.btnGetAppPatchInfo = New System.Windows.Forms.Button()
        Me.btnGetAppPatches = New System.Windows.Forms.Button()
        Me.btnGetAppInfo = New System.Windows.Forms.Button()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.btnGetApps = New System.Windows.Forms.Button()
        Me.TabPage8 = New System.Windows.Forms.TabPage()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.TxtBoxCaptureWIM_Description = New System.Windows.Forms.TextBox()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.TxtNameMetadata = New System.Windows.Forms.TextBox()
        Me.chkCaptureVerify = New System.Windows.Forms.CheckBox()
        Me.btnAppend = New System.Windows.Forms.Button()
        Me.cmbCompression = New System.Windows.Forms.ComboBox()
        Me.lblCompression = New System.Windows.Forms.Label()
        Me.lblName = New System.Windows.Forms.Label()
        Me.TxtFileName = New System.Windows.Forms.TextBox()
        Me.btnCreate = New System.Windows.Forms.Button()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.btnCaptureDest = New System.Windows.Forms.Button()
        Me.txtCaptureDest = New System.Windows.Forms.TextBox()
        Me.txtCaptureSource = New System.Windows.Forms.TextBox()
        Me.btnCaptureSrc = New System.Windows.Forms.Button()
        Me.TabPage9 = New System.Windows.Forms.TabPage()
        Me.LblApplySource_PatternSWMFile = New System.Windows.Forms.Label()
        Me.TxtBoxApplySource_PatternSWMFile = New System.Windows.Forms.TextBox()
        Me.LblApplyWim_Size = New System.Windows.Forms.Label()
        Me.TxtBoxApplyWim_Size = New System.Windows.Forms.TextBox()
        Me.LblApplyWim_Description = New System.Windows.Forms.Label()
        Me.LblApplyWim_Name = New System.Windows.Forms.Label()
        Me.TxtBoxApplyWim_Description = New System.Windows.Forms.TextBox()
        Me.TxtBoxApplyWim_Name = New System.Windows.Forms.TextBox()
        Me.chkApplyVerify = New System.Windows.Forms.CheckBox()
        Me.cmbApplyIndex = New System.Windows.Forms.ComboBox()
        Me.lblIndex = New System.Windows.Forms.Label()
        Me.btnApply = New System.Windows.Forms.Button()
        Me.lblDest = New System.Windows.Forms.Label()
        Me.lblSource = New System.Windows.Forms.Label()
        Me.btnBrowseDest = New System.Windows.Forms.Button()
        Me.txtApplyDest = New System.Windows.Forms.TextBox()
        Me.txtApplySource = New System.Windows.Forms.TextBox()
        Me.btnBrowseSource = New System.Windows.Forms.Button()
        Me.TabPage10 = New System.Windows.Forms.TabPage()
        Me.ChkBoxExportImage_WimBoot = New System.Windows.Forms.CheckBox()
        Me.ChkBoxExportImage_CheckIntegrity = New System.Windows.Forms.CheckBox()
        Me.CmbBoxExportImage_Compression = New System.Windows.Forms.ComboBox()
        Me.LblExportImage_LevelCompression = New System.Windows.Forms.Label()
        Me.ChkBoxExportImage_Bootable = New System.Windows.Forms.CheckBox()
        Me.CmbBoxExportImage_Index = New System.Windows.Forms.ComboBox()
        Me.LblExportImage_Index = New System.Windows.Forms.Label()
        Me.BtnExportImage_ExportImage = New System.Windows.Forms.Button()
        Me.BtnExportImage_BrowseDestination = New System.Windows.Forms.Button()
        Me.BtnExportImage_BrowseSource = New System.Windows.Forms.Button()
        Me.LblExportImage_Size = New System.Windows.Forms.Label()
        Me.TxtBoxExportImage_Size = New System.Windows.Forms.TextBox()
        Me.LblExportImage_Description = New System.Windows.Forms.Label()
        Me.LblExportImage_Name = New System.Windows.Forms.Label()
        Me.TxtBoxExportImage_Description = New System.Windows.Forms.TextBox()
        Me.TxtBoxExportImage_Name = New System.Windows.Forms.TextBox()
        Me.LblExportImage_Filename = New System.Windows.Forms.Label()
        Me.TxtBoxExportImage_Filename = New System.Windows.Forms.TextBox()
        Me.LblExportImage_Destination = New System.Windows.Forms.Label()
        Me.LblExportImage_Source = New System.Windows.Forms.Label()
        Me.TxtBoxExportImage_Destination = New System.Windows.Forms.TextBox()
        Me.TxtBoxExportImage_Source = New System.Windows.Forms.TextBox()
        Me.TabPage11 = New System.Windows.Forms.TabPage()
        Me.ChkBoxLangAndInterServ_Online = New System.Windows.Forms.CheckBox()
        Me.BtnLangAndInterServ_ApplyDistribution = New System.Windows.Forms.Button()
        Me.BtnLangAndInterServ_ApplySetupUILang = New System.Windows.Forms.Button()
        Me.BtnLangAndInterServ_ApplyGenLangINI = New System.Windows.Forms.Button()
        Me.BtnLangAndInterServ_ApplySKUIntlDefaults = New System.Windows.Forms.Button()
        Me.CmbBoxLangAndInterServ_Distribution = New System.Windows.Forms.ComboBox()
        Me.LblLangAndInterServ_Distribution = New System.Windows.Forms.Label()
        Me.CmbBoxLangAndInterServ_SetSetupUILang = New System.Windows.Forms.ComboBox()
        Me.LblLangAndInterServ_SetupUILang = New System.Windows.Forms.Label()
        Me.CmbBoxLangAndInterServ_GenLanINI = New System.Windows.Forms.ComboBox()
        Me.Button9 = New System.Windows.Forms.Button()
        Me.LblLangAndInterServ_GenLanINI = New System.Windows.Forms.Label()
        Me.CmbBoxLangAndInterServ_SetSKUIntlDefaults = New System.Windows.Forms.ComboBox()
        Me.Button8 = New System.Windows.Forms.Button()
        Me.LblLangAndInterServ_SetSKUIntlDefaults = New System.Windows.Forms.Label()
        Me.CmbBoxLangAndInterServ_SetTimeZone = New System.Windows.Forms.ComboBox()
        Me.BtnLangAndInterServ_ApplyTimeZone = New System.Windows.Forms.Button()
        Me.LblLangAndInterServ_SetTimeZone = New System.Windows.Forms.Label()
        Me.CmbBoxLangAndInterServ_SetInputLocal = New System.Windows.Forms.ComboBox()
        Me.BtnLangAndInterServ_ApplyInputLocale = New System.Windows.Forms.Button()
        Me.LblLangAndInterServ_SetInputLocale = New System.Windows.Forms.Label()
        Me.CmbBoxLangAndInterServ_SetUserLocale = New System.Windows.Forms.ComboBox()
        Me.BtnLangAndInterServ_ApplyUserLocale = New System.Windows.Forms.Button()
        Me.LblLangAndInterServ_SetUserLocale = New System.Windows.Forms.Label()
        Me.CmbBoxLangAndInterServ_SetUILang_SysLocale = New System.Windows.Forms.ComboBox()
        Me.BtnLangAndInterServ_ApplySysLocale = New System.Windows.Forms.Button()
        Me.LblLangAndInterServ_SetSysLocale = New System.Windows.Forms.Label()
        Me.CmbBoxLangAndInterServ_SetSysUILang = New System.Windows.Forms.ComboBox()
        Me.BtnLangAndInterServ_ApplySysUILang = New System.Windows.Forms.Button()
        Me.LblLangAndInterServ_SetSysUILang = New System.Windows.Forms.Label()
        Me.CmbBoxLangAndInterServ_SetUILangFallback = New System.Windows.Forms.ComboBox()
        Me.BtnLangAndInterServ_ApplyUILangFallback = New System.Windows.Forms.Button()
        Me.LblLangAndInterServ_SetUILangFallback = New System.Windows.Forms.Label()
        Me.CmbBoxLangAndInterServ_SetUILang = New System.Windows.Forms.ComboBox()
        Me.BtnLangAndInterServ_ApplyUILang = New System.Windows.Forms.Button()
        Me.LblLangAndInterServ_SetUILang = New System.Windows.Forms.Label()
        Me.CmbBoxLangAndInterServ_SetAllIntl = New System.Windows.Forms.ComboBox()
        Me.BtnLangAndInterServ_ApplyAllIntl = New System.Windows.Forms.Button()
        Me.LblLangAndInterServ_SetAllIntl = New System.Windows.Forms.Label()
        Me.BtnSetLanguage_DisplayInfo = New System.Windows.Forms.Button()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.TabPage12 = New System.Windows.Forms.TabPage()
        Me.BtnExportDriverOnline = New System.Windows.Forms.Button()
        Me.LblExportDriverOnlineFolder = New System.Windows.Forms.Label()
        Me.TxtBoxExportDriverOnlineFolder = New System.Windows.Forms.TextBox()
        Me.BtnExportDriverOnlineFolderChoice = New System.Windows.Forms.Button()
        Me.BtnExportDriverOffline = New System.Windows.Forms.Button()
        Me.LblExportDriverOfflineChoisirDossierFolder = New System.Windows.Forms.Label()
        Me.TxtBoxExportDriverOfflineFolder = New System.Windows.Forms.TextBox()
        Me.BtnExportDriverOfflineFolderChoice = New System.Windows.Forms.Button()
        Me.TabPage13 = New System.Windows.Forms.TabPage()
        Me.BtnSplitImage_WIMChoice = New System.Windows.Forms.Button()
        Me.BtnSplitImage_TargetFolder = New System.Windows.Forms.Button()
        Me.LblSplitImage_DestinationFolder = New System.Windows.Forms.Label()
        Me.TxtBoxSplitImage_DestinationFolder = New System.Windows.Forms.TextBox()
        Me.BtnSplitImage_SplitImage = New System.Windows.Forms.Button()
        Me.ChkBoxSplitImage_CheckIntegrity = New System.Windows.Forms.CheckBox()
        Me.LblSplitImage_SplitSize = New System.Windows.Forms.Label()
        Me.TxtBoxSplitImage_Filesize = New System.Windows.Forms.TextBox()
        Me.LblSplitImage_SWMFilename = New System.Windows.Forms.Label()
        Me.LblSplitImage_WIMFilename = New System.Windows.Forms.Label()
        Me.TxtBoxSplitImage_SWMFilename = New System.Windows.Forms.TextBox()
        Me.TxtBoxSplitImage_WIMFilename = New System.Windows.Forms.TextBox()
        Me.TabPage14 = New System.Windows.Forms.TabPage()
        Me.LblCaptureFfu_Description = New System.Windows.Forms.Label()
        Me.TxtBoxCaptureFfu_Description = New System.Windows.Forms.TextBox()
        Me.LstBoxCaptureFfu_LogicalDrive = New System.Windows.Forms.ListBox()
        Me.LblCaptFfu_LogicalDrive = New System.Windows.Forms.Label()
        Me.LblCaptFfu_Name = New System.Windows.Forms.Label()
        Me.TxtBoxCaptFfu_Name = New System.Windows.Forms.TextBox()
        Me.LblCaptFfu_PlatformID = New System.Windows.Forms.Label()
        Me.TxtBoxCaptFfu_PlatformID = New System.Windows.Forms.TextBox()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.LblCaptFfu_TargetFilename = New System.Windows.Forms.Label()
        Me.LblCaptFfu_TargetFolder = New System.Windows.Forms.Label()
        Me.LblCaptFfu_PhysicalDrive = New System.Windows.Forms.Label()
        Me.CmbBoxCaptureFfu_Compression = New System.Windows.Forms.ComboBox()
        Me.TxtBoxCaptFfu_TargetFilename = New System.Windows.Forms.TextBox()
        Me.TxtBoxCaptFfu_TargetFolder = New System.Windows.Forms.TextBox()
        Me.TxtBoxCaptFfu_PhysicalDrive = New System.Windows.Forms.TextBox()
        Me.BtnCaptFfu_StartCapture = New System.Windows.Forms.Button()
        Me.BtnCaptureFfu_SetTargetFolder = New System.Windows.Forms.Button()
        Me.BtnCaptureFfu_UpdateLogicalDrive = New System.Windows.Forms.Button()
        Me.TabPage15 = New System.Windows.Forms.TabPage()
        Me.LstBoxApplyFfuImage_LogicalDrive = New System.Windows.Forms.ListBox()
        Me.LblApplyFfuImage_LogicalDrive = New System.Windows.Forms.Label()
        Me.LblApplyFfuImage_MotifSFUFile = New System.Windows.Forms.Label()
        Me.LblApplyFfuImage_SourceFilename = New System.Windows.Forms.Label()
        Me.LblApplyFfuImage_PhysicalDrive = New System.Windows.Forms.Label()
        Me.TxtBoxApplyFfuImageFfu_MotifSFUFile = New System.Windows.Forms.TextBox()
        Me.TxtBoxApplyFfuImage_FfuSourceFilename = New System.Windows.Forms.TextBox()
        Me.TxtBoxApplyFfuImage_PhysicalDrive = New System.Windows.Forms.TextBox()
        Me.BtnApplyFfuImage_ApplyFfuImage = New System.Windows.Forms.Button()
        Me.BtnApplyFfuImage_SelectFfuFile = New System.Windows.Forms.Button()
        Me.BtnApplyFfuImage_UpdateLogicalDrive = New System.Windows.Forms.Button()
        Me.TabPage16 = New System.Windows.Forms.TabPage()
        Me.BtnSplitFfu_SelectFfuFile = New System.Windows.Forms.Button()
        Me.BtnSplitFfu_SelectTargetFolder = New System.Windows.Forms.Button()
        Me.LblSplitFfu_TargetFolder = New System.Windows.Forms.Label()
        Me.TxtBoxSplitFfu_TargetFolder = New System.Windows.Forms.TextBox()
        Me.BtnSplitFfuImage_StartSplitImage = New System.Windows.Forms.Button()
        Me.ChkBoxSplitFfu_CheckIntegrity = New System.Windows.Forms.CheckBox()
        Me.LblSplitFfu_SplitFileSize = New System.Windows.Forms.Label()
        Me.TxtBoxSplitFfu_SplitFileSize = New System.Windows.Forms.TextBox()
        Me.LblSplitFfu_SFUFilename = New System.Windows.Forms.Label()
        Me.LblSplitFfu_FfuFilename = New System.Windows.Forms.Label()
        Me.TxtBoxSplitFfu_SFUFilename = New System.Windows.Forms.TextBox()
        Me.TxtBoxSplitFfu_FfuFilename = New System.Windows.Forms.TextBox()
        Me.TabPage17 = New System.Windows.Forms.TabPage()
        Me.LblDefaultAppAssocServ_Warning = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.TxtBoxDefaultAppAssocServ_ExportFilenameXML = New System.Windows.Forms.TextBox()
        Me.BtnDefaultAppAssocServ_ChooseFolder = New System.Windows.Forms.Button()
        Me.LblDefaultAppAssocServ_ExportFolder = New System.Windows.Forms.Label()
        Me.TxtBoxDefaultAppAssocServ_ExportFolder = New System.Windows.Forms.TextBox()
        Me.BtnDefaultAppAssocServ_ChooseFile = New System.Windows.Forms.Button()
        Me.LblDefaultAppAssocServ_FilenameXML = New System.Windows.Forms.Label()
        Me.TxtBoxDefaultAppAssocServ_ImportFilenameXML = New System.Windows.Forms.TextBox()
        Me.BtnDefaultAppAssocServ_Remove = New System.Windows.Forms.Button()
        Me.BtnDefaultAppAssocServ_Export = New System.Windows.Forms.Button()
        Me.BtnDefaultAppAssocServ_Import = New System.Windows.Forms.Button()
        Me.ChkBoxDefaultAppAssocServ_Online = New System.Windows.Forms.CheckBox()
        Me.BtnDefaultAppAssocServ_GetDefaultAppAssoc = New System.Windows.Forms.Button()
        Me.BackgroundWorkerDISMCommand = New System.ComponentModel.BackgroundWorker()
        Me.dlgOpenXML = New System.Windows.Forms.OpenFileDialog()
        Me.dlgOpenMSP = New System.Windows.Forms.OpenFileDialog()
        Me.Btn_ClearConsole = New System.Windows.Forms.Button()
        Me.TxtBox_DismVersion = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.MenuStrip1.SuspendLayout()
        Me.TabControl1.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.TabPage2.SuspendLayout()
        Me.GroupBoxDriverManagement_DeleteDrivers.SuspendLayout()
        Me.GroupBoxDriverManagement_AddDrivers.SuspendLayout()
        Me.TabPage3.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.TabPage4.SuspendLayout()
        Me.TabPage5.SuspendLayout()
        Me.TabPage6.SuspendLayout()
        Me.TabPage7.SuspendLayout()
        Me.TabPage8.SuspendLayout()
        Me.TabPage9.SuspendLayout()
        Me.TabPage10.SuspendLayout()
        Me.TabPage11.SuspendLayout()
        Me.TabPage12.SuspendLayout()
        Me.TabPage13.SuspendLayout()
        Me.TabPage14.SuspendLayout()
        Me.TabPage15.SuspendLayout()
        Me.TabPage16.SuspendLayout()
        Me.TabPage17.SuspendLayout()
        Me.SuspendLayout()
        '
        'TxtMountControl_WimFile
        '
        Me.TxtMountControl_WimFile.Location = New System.Drawing.Point(5, 25)
        Me.TxtMountControl_WimFile.Name = "TxtMountControl_WimFile"
        Me.TxtMountControl_WimFile.Size = New System.Drawing.Size(339, 26)
        Me.TxtMountControl_WimFile.TabIndex = 0
        '
        'LblMountControl_WimFile
        '
        Me.LblMountControl_WimFile.AutoSize = True
        Me.LblMountControl_WimFile.Location = New System.Drawing.Point(6, 3)
        Me.LblMountControl_WimFile.Name = "LblMountControl_WimFile"
        Me.LblMountControl_WimFile.Size = New System.Drawing.Size(71, 20)
        Me.LblMountControl_WimFile.TabIndex = 1
        Me.LblMountControl_WimFile.Text = "WIM File"
        '
        'LblMountControl_MountLocation
        '
        Me.LblMountControl_MountLocation.AutoSize = True
        Me.LblMountControl_MountLocation.Location = New System.Drawing.Point(6, 91)
        Me.LblMountControl_MountLocation.Name = "LblMountControl_MountLocation"
        Me.LblMountControl_MountLocation.Size = New System.Drawing.Size(119, 20)
        Me.LblMountControl_MountLocation.TabIndex = 2
        Me.LblMountControl_MountLocation.Text = "Mount Location"
        '
        'TxtMountControl_MountLocation
        '
        Me.TxtMountControl_MountLocation.Location = New System.Drawing.Point(5, 114)
        Me.TxtMountControl_MountLocation.Name = "TxtMountControl_MountLocation"
        Me.TxtMountControl_MountLocation.Size = New System.Drawing.Size(339, 26)
        Me.TxtMountControl_MountLocation.TabIndex = 3
        '
        'dlgOpenFolder
        '
        Me.dlgOpenFolder.SelectedPath = "c:\"
        '
        'BtnMountControl_OpenWIM
        '
        Me.BtnMountControl_OpenWIM.Location = New System.Drawing.Point(361, 21)
        Me.BtnMountControl_OpenWIM.Name = "BtnMountControl_OpenWIM"
        Me.BtnMountControl_OpenWIM.Size = New System.Drawing.Size(106, 32)
        Me.BtnMountControl_OpenWIM.TabIndex = 4
        Me.BtnMountControl_OpenWIM.Text = "Choose WIM"
        Me.BtnMountControl_OpenWIM.UseVisualStyleBackColor = True
        '
        'BtnMountControl_OpenMount
        '
        Me.BtnMountControl_OpenMount.Location = New System.Drawing.Point(361, 114)
        Me.BtnMountControl_OpenMount.Name = "BtnMountControl_OpenMount"
        Me.BtnMountControl_OpenMount.Size = New System.Drawing.Size(106, 26)
        Me.BtnMountControl_OpenMount.TabIndex = 5
        Me.BtnMountControl_OpenMount.Text = "Choose Folder"
        Me.BtnMountControl_OpenMount.UseVisualStyleBackColor = True
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolsToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(955, 29)
        Me.MenuStrip1.TabIndex = 6
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'ToolsToolStripMenuItem
        '
        Me.ToolsToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.OpenDISMLogToolStripMenuItem, Me.GetWIMInfoToolStripMenuItem, Me.CleanupWIMToolStripMenuItem, Me.CleanupImageToolStripMenuItem, Me.UseOnlineModeToolStripMenuItem, Me.AboutToolStripMenuItem})
        Me.ToolsToolStripMenuItem.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ToolsToolStripMenuItem.Name = "ToolsToolStripMenuItem"
        Me.ToolsToolStripMenuItem.Size = New System.Drawing.Size(57, 25)
        Me.ToolsToolStripMenuItem.Text = "Tools"
        '
        'OpenDISMLogToolStripMenuItem
        '
        Me.OpenDISMLogToolStripMenuItem.Name = "OpenDISMLogToolStripMenuItem"
        Me.OpenDISMLogToolStripMenuItem.Size = New System.Drawing.Size(239, 26)
        Me.OpenDISMLogToolStripMenuItem.Text = "Open DISM Log"
        '
        'GetWIMInfoToolStripMenuItem
        '
        Me.GetWIMInfoToolStripMenuItem.Name = "GetWIMInfoToolStripMenuItem"
        Me.GetWIMInfoToolStripMenuItem.Size = New System.Drawing.Size(239, 26)
        Me.GetWIMInfoToolStripMenuItem.Text = "Get Mounted WIM Info"
        '
        'CleanupWIMToolStripMenuItem
        '
        Me.CleanupWIMToolStripMenuItem.Name = "CleanupWIMToolStripMenuItem"
        Me.CleanupWIMToolStripMenuItem.Size = New System.Drawing.Size(239, 26)
        Me.CleanupWIMToolStripMenuItem.Text = "Cleanup WIM"
        '
        'CleanupImageToolStripMenuItem
        '
        Me.CleanupImageToolStripMenuItem.Name = "CleanupImageToolStripMenuItem"
        Me.CleanupImageToolStripMenuItem.Size = New System.Drawing.Size(239, 26)
        Me.CleanupImageToolStripMenuItem.Text = "Cleanup Image"
        '
        'UseOnlineModeToolStripMenuItem
        '
        Me.UseOnlineModeToolStripMenuItem.CheckOnClick = True
        Me.UseOnlineModeToolStripMenuItem.Name = "UseOnlineModeToolStripMenuItem"
        Me.UseOnlineModeToolStripMenuItem.Size = New System.Drawing.Size(239, 26)
        Me.UseOnlineModeToolStripMenuItem.Text = "Use Online Mode"
        Me.UseOnlineModeToolStripMenuItem.Visible = False
        '
        'AboutToolStripMenuItem
        '
        Me.AboutToolStripMenuItem.Name = "AboutToolStripMenuItem"
        Me.AboutToolStripMenuItem.Size = New System.Drawing.Size(239, 26)
        Me.AboutToolStripMenuItem.Text = "About"
        '
        'BtnMountControl_MountWim
        '
        Me.BtnMountControl_MountWim.Location = New System.Drawing.Point(580, 21)
        Me.BtnMountControl_MountWim.Name = "BtnMountControl_MountWim"
        Me.BtnMountControl_MountWim.Size = New System.Drawing.Size(127, 64)
        Me.BtnMountControl_MountWim.TabIndex = 7
        Me.BtnMountControl_MountWim.Text = "Mount WIM"
        Me.BtnMountControl_MountWim.UseVisualStyleBackColor = True
        '
        'CmbMountControl_Index
        '
        Me.CmbMountControl_Index.FormattingEnabled = True
        Me.CmbMountControl_Index.Location = New System.Drawing.Point(487, 25)
        Me.CmbMountControl_Index.Name = "CmbMountControl_Index"
        Me.CmbMountControl_Index.Size = New System.Drawing.Size(73, 28)
        Me.CmbMountControl_Index.TabIndex = 8
        '
        'BtnMountControl_DismountWim
        '
        Me.BtnMountControl_DismountWim.Enabled = False
        Me.BtnMountControl_DismountWim.Location = New System.Drawing.Point(580, 91)
        Me.BtnMountControl_DismountWim.Name = "BtnMountControl_DismountWim"
        Me.BtnMountControl_DismountWim.Size = New System.Drawing.Size(127, 64)
        Me.BtnMountControl_DismountWim.TabIndex = 10
        Me.BtnMountControl_DismountWim.Text = "Dismount WIM"
        Me.BtnMountControl_DismountWim.UseVisualStyleBackColor = True
        '
        'txtOutput
        '
        Me.txtOutput.Location = New System.Drawing.Point(11, 443)
        Me.txtOutput.Multiline = True
        Me.txtOutput.Name = "txtOutput"
        Me.txtOutput.ScrollBars = System.Windows.Forms.ScrollBars.Both
        Me.txtOutput.Size = New System.Drawing.Size(890, 225)
        Me.txtOutput.TabIndex = 13
        Me.txtOutput.WordWrap = False
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(7, 416)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(107, 20)
        Me.Label4.TabIndex = 14
        Me.Label4.Text = "DISM Output:"
        '
        'BtnMountControl_OpenMountedFolder
        '
        Me.BtnMountControl_OpenMountedFolder.Location = New System.Drawing.Point(580, 161)
        Me.BtnMountControl_OpenMountedFolder.Name = "BtnMountControl_OpenMountedFolder"
        Me.BtnMountControl_OpenMountedFolder.Size = New System.Drawing.Size(127, 64)
        Me.BtnMountControl_OpenMountedFolder.TabIndex = 15
        Me.BtnMountControl_OpenMountedFolder.Text = "Open Mounted Folder"
        Me.BtnMountControl_OpenMountedFolder.UseVisualStyleBackColor = True
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(498, 2)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(48, 20)
        Me.Label3.TabIndex = 17
        Me.Label3.Text = "Index"
        '
        'BackgroundWorkerMount
        '
        Me.BackgroundWorkerMount.WorkerReportsProgress = True
        Me.BackgroundWorkerMount.WorkerSupportsCancellation = True
        '
        'BackgroundWorkerDisMount
        '
        Me.BackgroundWorkerDisMount.WorkerReportsProgress = True
        Me.BackgroundWorkerDisMount.WorkerSupportsCancellation = True
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Controls.Add(Me.TabPage3)
        Me.TabControl1.Controls.Add(Me.TabPage4)
        Me.TabControl1.Controls.Add(Me.TabPage5)
        Me.TabControl1.Controls.Add(Me.TabPage6)
        Me.TabControl1.Controls.Add(Me.TabPage7)
        Me.TabControl1.Controls.Add(Me.TabPage8)
        Me.TabControl1.Controls.Add(Me.TabPage9)
        Me.TabControl1.Controls.Add(Me.TabPage10)
        Me.TabControl1.Controls.Add(Me.TabPage11)
        Me.TabControl1.Controls.Add(Me.TabPage12)
        Me.TabControl1.Controls.Add(Me.TabPage13)
        Me.TabControl1.Controls.Add(Me.TabPage14)
        Me.TabControl1.Controls.Add(Me.TabPage15)
        Me.TabControl1.Controls.Add(Me.TabPage16)
        Me.TabControl1.Controls.Add(Me.TabPage17)
        Me.TabControl1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TabControl1.Location = New System.Drawing.Point(11, 27)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(894, 383)
        Me.TabControl1.TabIndex = 18
        '
        'TabPage1
        '
        Me.TabPage1.Controls.Add(Me.TxtLbl_Or)
        Me.TabPage1.Controls.Add(Me.BtnMountControl_DisplayImageInfo)
        Me.TabPage1.Controls.Add(Me.LblMountControl_Size)
        Me.TabPage1.Controls.Add(Me.LblMountControl_Description)
        Me.TabPage1.Controls.Add(Me.LblMountControl_Name)
        Me.TabPage1.Controls.Add(Me.TxtBoxMountControl_Size)
        Me.TabPage1.Controls.Add(Me.TxtBoxMountControl_Description)
        Me.TabPage1.Controls.Add(Me.TxtBoxMountControl_Name)
        Me.TabPage1.Controls.Add(Me.ChkMountControl_ReadOnly)
        Me.TabPage1.Controls.Add(Me.BtnMountControl_DisplayWIMInfo)
        Me.TabPage1.Controls.Add(Me.BtnMountControl_OpenWIM)
        Me.TabPage1.Controls.Add(Me.Label3)
        Me.TabPage1.Controls.Add(Me.TxtMountControl_WimFile)
        Me.TabPage1.Controls.Add(Me.LblMountControl_WimFile)
        Me.TabPage1.Controls.Add(Me.BtnMountControl_OpenMountedFolder)
        Me.TabPage1.Controls.Add(Me.LblMountControl_MountLocation)
        Me.TabPage1.Controls.Add(Me.TxtMountControl_MountLocation)
        Me.TabPage1.Controls.Add(Me.BtnMountControl_OpenMount)
        Me.TabPage1.Controls.Add(Me.BtnMountControl_DismountWim)
        Me.TabPage1.Controls.Add(Me.BtnMountControl_MountWim)
        Me.TabPage1.Controls.Add(Me.CmbMountControl_Index)
        Me.TabPage1.Location = New System.Drawing.Point(4, 29)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(886, 350)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "Mount Control"
        Me.TabPage1.UseVisualStyleBackColor = True
        '
        'TxtLbl_Or
        '
        Me.TxtLbl_Or.Location = New System.Drawing.Point(144, 61)
        Me.TxtLbl_Or.Name = "TxtLbl_Or"
        Me.TxtLbl_Or.Size = New System.Drawing.Size(43, 20)
        Me.TxtLbl_Or.TabIndex = 26
        Me.TxtLbl_Or.Text = "or"
        Me.TxtLbl_Or.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'BtnMountControl_DisplayImageInfo
        '
        Me.BtnMountControl_DisplayImageInfo.Location = New System.Drawing.Point(193, 55)
        Me.BtnMountControl_DisplayImageInfo.Name = "BtnMountControl_DisplayImageInfo"
        Me.BtnMountControl_DisplayImageInfo.Size = New System.Drawing.Size(151, 33)
        Me.BtnMountControl_DisplayImageInfo.TabIndex = 25
        Me.BtnMountControl_DisplayImageInfo.Text = "Display Image Info"
        Me.BtnMountControl_DisplayImageInfo.UseVisualStyleBackColor = True
        '
        'LblMountControl_Size
        '
        Me.LblMountControl_Size.AutoSize = True
        Me.LblMountControl_Size.Location = New System.Drawing.Point(10, 270)
        Me.LblMountControl_Size.Name = "LblMountControl_Size"
        Me.LblMountControl_Size.Size = New System.Drawing.Size(44, 20)
        Me.LblMountControl_Size.TabIndex = 24
        Me.LblMountControl_Size.Text = "Size:"
        '
        'LblMountControl_Description
        '
        Me.LblMountControl_Description.AutoSize = True
        Me.LblMountControl_Description.Location = New System.Drawing.Point(10, 229)
        Me.LblMountControl_Description.Name = "LblMountControl_Description"
        Me.LblMountControl_Description.Size = New System.Drawing.Size(93, 20)
        Me.LblMountControl_Description.TabIndex = 23
        Me.LblMountControl_Description.Text = "Description:"
        '
        'LblMountControl_Name
        '
        Me.LblMountControl_Name.AutoSize = True
        Me.LblMountControl_Name.Location = New System.Drawing.Point(10, 187)
        Me.LblMountControl_Name.Name = "LblMountControl_Name"
        Me.LblMountControl_Name.Size = New System.Drawing.Size(55, 20)
        Me.LblMountControl_Name.TabIndex = 22
        Me.LblMountControl_Name.Text = "Name:"
        '
        'TxtBoxMountControl_Size
        '
        Me.TxtBoxMountControl_Size.Location = New System.Drawing.Point(105, 267)
        Me.TxtBoxMountControl_Size.Name = "TxtBoxMountControl_Size"
        Me.TxtBoxMountControl_Size.Size = New System.Drawing.Size(455, 26)
        Me.TxtBoxMountControl_Size.TabIndex = 21
        '
        'TxtBoxMountControl_Description
        '
        Me.TxtBoxMountControl_Description.Location = New System.Drawing.Point(105, 226)
        Me.TxtBoxMountControl_Description.Name = "TxtBoxMountControl_Description"
        Me.TxtBoxMountControl_Description.Size = New System.Drawing.Size(455, 26)
        Me.TxtBoxMountControl_Description.TabIndex = 20
        '
        'TxtBoxMountControl_Name
        '
        Me.TxtBoxMountControl_Name.Location = New System.Drawing.Point(105, 184)
        Me.TxtBoxMountControl_Name.Name = "TxtBoxMountControl_Name"
        Me.TxtBoxMountControl_Name.Size = New System.Drawing.Size(455, 26)
        Me.TxtBoxMountControl_Name.TabIndex = 19
        '
        'ChkMountControl_ReadOnly
        '
        Me.ChkMountControl_ReadOnly.AutoSize = True
        Me.ChkMountControl_ReadOnly.Location = New System.Drawing.Point(6, 146)
        Me.ChkMountControl_ReadOnly.Name = "ChkMountControl_ReadOnly"
        Me.ChkMountControl_ReadOnly.Size = New System.Drawing.Size(102, 24)
        Me.ChkMountControl_ReadOnly.TabIndex = 19
        Me.ChkMountControl_ReadOnly.Text = "Read Only"
        Me.ChkMountControl_ReadOnly.UseVisualStyleBackColor = True
        '
        'BtnMountControl_DisplayWIMInfo
        '
        Me.BtnMountControl_DisplayWIMInfo.Location = New System.Drawing.Point(5, 55)
        Me.BtnMountControl_DisplayWIMInfo.Name = "BtnMountControl_DisplayWIMInfo"
        Me.BtnMountControl_DisplayWIMInfo.Size = New System.Drawing.Size(138, 33)
        Me.BtnMountControl_DisplayWIMInfo.TabIndex = 18
        Me.BtnMountControl_DisplayWIMInfo.Text = "Display WIM Info"
        Me.BtnMountControl_DisplayWIMInfo.UseVisualStyleBackColor = True
        '
        'TabPage2
        '
        Me.TabPage2.Controls.Add(Me.ChkBoxDriverManagement_Online)
        Me.TabPage2.Controls.Add(Me.BtnDriverManagement_GetAllDriverInfo)
        Me.TabPage2.Controls.Add(Me.GroupBoxDriverManagement_DeleteDrivers)
        Me.TabPage2.Controls.Add(Me.BtnDriverManagement_GetDrivers)
        Me.TabPage2.Controls.Add(Me.GroupBoxDriverManagement_AddDrivers)
        Me.TabPage2.Location = New System.Drawing.Point(4, 29)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(886, 350)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "Driver Management"
        Me.TabPage2.UseVisualStyleBackColor = True
        '
        'ChkBoxDriverManagement_Online
        '
        Me.ChkBoxDriverManagement_Online.AutoSize = True
        Me.ChkBoxDriverManagement_Online.Location = New System.Drawing.Point(758, 323)
        Me.ChkBoxDriverManagement_Online.Name = "ChkBoxDriverManagement_Online"
        Me.ChkBoxDriverManagement_Online.Size = New System.Drawing.Size(125, 24)
        Me.ChkBoxDriverManagement_Online.TabIndex = 15
        Me.ChkBoxDriverManagement_Online.Text = "/Online option"
        Me.ChkBoxDriverManagement_Online.UseVisualStyleBackColor = False
        '
        'BtnDriverManagement_GetAllDriverInfo
        '
        Me.BtnDriverManagement_GetAllDriverInfo.Location = New System.Drawing.Point(525, 106)
        Me.BtnDriverManagement_GetAllDriverInfo.Name = "BtnDriverManagement_GetAllDriverInfo"
        Me.BtnDriverManagement_GetAllDriverInfo.Size = New System.Drawing.Size(127, 64)
        Me.BtnDriverManagement_GetAllDriverInfo.TabIndex = 14
        Me.BtnDriverManagement_GetAllDriverInfo.Text = "Get All Driver information from WIM"
        Me.BtnDriverManagement_GetAllDriverInfo.UseVisualStyleBackColor = True
        '
        'GroupBoxDriverManagement_DeleteDrivers
        '
        Me.GroupBoxDriverManagement_DeleteDrivers.Controls.Add(Me.LblDriverManagement_DriverName)
        Me.GroupBoxDriverManagement_DeleteDrivers.Controls.Add(Me.BtnDriverManagement_DelDriver)
        Me.GroupBoxDriverManagement_DeleteDrivers.Controls.Add(Me.TxtBoxDriverManagement_DelDriverLocation)
        Me.GroupBoxDriverManagement_DeleteDrivers.Location = New System.Drawing.Point(6, 215)
        Me.GroupBoxDriverManagement_DeleteDrivers.Name = "GroupBoxDriverManagement_DeleteDrivers"
        Me.GroupBoxDriverManagement_DeleteDrivers.Size = New System.Drawing.Size(461, 105)
        Me.GroupBoxDriverManagement_DeleteDrivers.TabIndex = 13
        Me.GroupBoxDriverManagement_DeleteDrivers.TabStop = False
        Me.GroupBoxDriverManagement_DeleteDrivers.Text = "Delete Drivers"
        '
        'LblDriverManagement_DriverName
        '
        Me.LblDriverManagement_DriverName.AutoSize = True
        Me.LblDriverManagement_DriverName.Location = New System.Drawing.Point(6, 35)
        Me.LblDriverManagement_DriverName.Name = "LblDriverManagement_DriverName"
        Me.LblDriverManagement_DriverName.Size = New System.Drawing.Size(96, 20)
        Me.LblDriverManagement_DriverName.TabIndex = 2
        Me.LblDriverManagement_DriverName.Text = "Driver Name"
        '
        'BtnDriverManagement_DelDriver
        '
        Me.BtnDriverManagement_DelDriver.Location = New System.Drawing.Point(316, 54)
        Me.BtnDriverManagement_DelDriver.Name = "BtnDriverManagement_DelDriver"
        Me.BtnDriverManagement_DelDriver.Size = New System.Drawing.Size(124, 29)
        Me.BtnDriverManagement_DelDriver.TabIndex = 1
        Me.BtnDriverManagement_DelDriver.Text = "Delete Driver"
        Me.BtnDriverManagement_DelDriver.UseVisualStyleBackColor = True
        '
        'TxtBoxDriverManagement_DelDriverLocation
        '
        Me.TxtBoxDriverManagement_DelDriverLocation.Location = New System.Drawing.Point(4, 58)
        Me.TxtBoxDriverManagement_DelDriverLocation.Name = "TxtBoxDriverManagement_DelDriverLocation"
        Me.TxtBoxDriverManagement_DelDriverLocation.Size = New System.Drawing.Size(305, 26)
        Me.TxtBoxDriverManagement_DelDriverLocation.TabIndex = 0
        '
        'BtnDriverManagement_GetDrivers
        '
        Me.BtnDriverManagement_GetDrivers.Location = New System.Drawing.Point(525, 17)
        Me.BtnDriverManagement_GetDrivers.Name = "BtnDriverManagement_GetDrivers"
        Me.BtnDriverManagement_GetDrivers.Size = New System.Drawing.Size(127, 64)
        Me.BtnDriverManagement_GetDrivers.TabIndex = 1
        Me.BtnDriverManagement_GetDrivers.Text = "Get 3rd Party Driver information from WIM"
        Me.BtnDriverManagement_GetDrivers.UseVisualStyleBackColor = True
        '
        'GroupBoxDriverManagement_AddDrivers
        '
        Me.GroupBoxDriverManagement_AddDrivers.Controls.Add(Me.ChkDriverManagement_Recurse)
        Me.GroupBoxDriverManagement_AddDrivers.Controls.Add(Me.BtnDriverManagement_AddDrivers)
        Me.GroupBoxDriverManagement_AddDrivers.Controls.Add(Me.BtnDriverManagement_OpnDriverFolder)
        Me.GroupBoxDriverManagement_AddDrivers.Controls.Add(Me.LblDriverManagement_DriversFolderLocation)
        Me.GroupBoxDriverManagement_AddDrivers.Controls.Add(Me.ChkDriverManagement_ForceUnsigned)
        Me.GroupBoxDriverManagement_AddDrivers.Controls.Add(Me.TxtBoxDriverManagement_DriverFolderLocation)
        Me.GroupBoxDriverManagement_AddDrivers.Location = New System.Drawing.Point(6, 6)
        Me.GroupBoxDriverManagement_AddDrivers.Name = "GroupBoxDriverManagement_AddDrivers"
        Me.GroupBoxDriverManagement_AddDrivers.Size = New System.Drawing.Size(461, 185)
        Me.GroupBoxDriverManagement_AddDrivers.TabIndex = 11
        Me.GroupBoxDriverManagement_AddDrivers.TabStop = False
        Me.GroupBoxDriverManagement_AddDrivers.Text = "Add Drivers"
        '
        'ChkDriverManagement_Recurse
        '
        Me.ChkDriverManagement_Recurse.AutoSize = True
        Me.ChkDriverManagement_Recurse.Checked = True
        Me.ChkDriverManagement_Recurse.CheckState = System.Windows.Forms.CheckState.Checked
        Me.ChkDriverManagement_Recurse.Location = New System.Drawing.Point(151, 81)
        Me.ChkDriverManagement_Recurse.Name = "ChkDriverManagement_Recurse"
        Me.ChkDriverManagement_Recurse.Size = New System.Drawing.Size(88, 24)
        Me.ChkDriverManagement_Recurse.TabIndex = 9
        Me.ChkDriverManagement_Recurse.Text = "Recurse"
        Me.ChkDriverManagement_Recurse.UseVisualStyleBackColor = True
        '
        'BtnDriverManagement_AddDrivers
        '
        Me.BtnDriverManagement_AddDrivers.Location = New System.Drawing.Point(316, 100)
        Me.BtnDriverManagement_AddDrivers.Name = "BtnDriverManagement_AddDrivers"
        Me.BtnDriverManagement_AddDrivers.Size = New System.Drawing.Size(127, 64)
        Me.BtnDriverManagement_AddDrivers.TabIndex = 8
        Me.BtnDriverManagement_AddDrivers.Text = "Add Drivers"
        Me.BtnDriverManagement_AddDrivers.UseVisualStyleBackColor = True
        '
        'BtnDriverManagement_OpnDriverFolder
        '
        Me.BtnDriverManagement_OpnDriverFolder.Location = New System.Drawing.Point(318, 49)
        Me.BtnDriverManagement_OpnDriverFolder.Name = "BtnDriverManagement_OpnDriverFolder"
        Me.BtnDriverManagement_OpnDriverFolder.Size = New System.Drawing.Size(125, 26)
        Me.BtnDriverManagement_OpnDriverFolder.TabIndex = 3
        Me.BtnDriverManagement_OpnDriverFolder.Text = "Choose Driver Folder"
        Me.BtnDriverManagement_OpnDriverFolder.UseVisualStyleBackColor = True
        '
        'LblDriverManagement_DriversFolderLocation
        '
        Me.LblDriverManagement_DriversFolderLocation.AutoSize = True
        Me.LblDriverManagement_DriversFolderLocation.Location = New System.Drawing.Point(0, 22)
        Me.LblDriverManagement_DriversFolderLocation.Name = "LblDriverManagement_DriversFolderLocation"
        Me.LblDriverManagement_DriversFolderLocation.Size = New System.Drawing.Size(172, 20)
        Me.LblDriverManagement_DriversFolderLocation.TabIndex = 0
        Me.LblDriverManagement_DriversFolderLocation.Text = "Drivers Folder Location"
        '
        'ChkDriverManagement_ForceUnsigned
        '
        Me.ChkDriverManagement_ForceUnsigned.AutoSize = True
        Me.ChkDriverManagement_ForceUnsigned.Location = New System.Drawing.Point(4, 81)
        Me.ChkDriverManagement_ForceUnsigned.Name = "ChkDriverManagement_ForceUnsigned"
        Me.ChkDriverManagement_ForceUnsigned.Size = New System.Drawing.Size(141, 24)
        Me.ChkDriverManagement_ForceUnsigned.TabIndex = 10
        Me.ChkDriverManagement_ForceUnsigned.Text = "Force Unsigned"
        Me.ChkDriverManagement_ForceUnsigned.UseVisualStyleBackColor = True
        '
        'TxtBoxDriverManagement_DriverFolderLocation
        '
        Me.TxtBoxDriverManagement_DriverFolderLocation.Location = New System.Drawing.Point(5, 49)
        Me.TxtBoxDriverManagement_DriverFolderLocation.Name = "TxtBoxDriverManagement_DriverFolderLocation"
        Me.TxtBoxDriverManagement_DriverFolderLocation.Size = New System.Drawing.Size(307, 26)
        Me.TxtBoxDriverManagement_DriverFolderLocation.TabIndex = 2
        '
        'TabPage3
        '
        Me.TabPage3.Controls.Add(Me.BtnGetPackageInfo)
        Me.TabPage3.Controls.Add(Me.ChkBoxPackageManagement_Online)
        Me.TabPage3.Controls.Add(Me.GroupBox4)
        Me.TabPage3.Controls.Add(Me.btnGetPackages)
        Me.TabPage3.Controls.Add(Me.GroupBox3)
        Me.TabPage3.Location = New System.Drawing.Point(4, 29)
        Me.TabPage3.Name = "TabPage3"
        Me.TabPage3.Size = New System.Drawing.Size(886, 350)
        Me.TabPage3.TabIndex = 2
        Me.TabPage3.Text = "Package Management"
        Me.TabPage3.UseVisualStyleBackColor = True
        '
        'BtnGetPackageInfo
        '
        Me.BtnGetPackageInfo.Location = New System.Drawing.Point(525, 189)
        Me.BtnGetPackageInfo.Name = "BtnGetPackageInfo"
        Me.BtnGetPackageInfo.Size = New System.Drawing.Size(127, 64)
        Me.BtnGetPackageInfo.TabIndex = 18
        Me.BtnGetPackageInfo.Text = "Get Packages Info"
        Me.BtnGetPackageInfo.UseVisualStyleBackColor = True
        '
        'ChkBoxPackageManagement_Online
        '
        Me.ChkBoxPackageManagement_Online.AutoSize = True
        Me.ChkBoxPackageManagement_Online.Location = New System.Drawing.Point(758, 323)
        Me.ChkBoxPackageManagement_Online.Name = "ChkBoxPackageManagement_Online"
        Me.ChkBoxPackageManagement_Online.Size = New System.Drawing.Size(125, 24)
        Me.ChkBoxPackageManagement_Online.TabIndex = 17
        Me.ChkBoxPackageManagement_Online.Text = "/Online option"
        Me.ChkBoxPackageManagement_Online.UseVisualStyleBackColor = False
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.Label9)
        Me.GroupBox4.Controls.Add(Me.Label8)
        Me.GroupBox4.Controls.Add(Me.btnRemovePackagePath)
        Me.GroupBox4.Controls.Add(Me.btnRemovePackageName)
        Me.GroupBox4.Controls.Add(Me.txtPackagePath)
        Me.GroupBox4.Controls.Add(Me.txtPackageName)
        Me.GroupBox4.Location = New System.Drawing.Point(4, 178)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(515, 159)
        Me.GroupBox4.TabIndex = 16
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "Remove Packages"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(3, 33)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(117, 20)
        Me.Label9.TabIndex = 5
        Me.Label9.Text = "Package Name"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(3, 85)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(108, 20)
        Me.Label8.TabIndex = 4
        Me.Label8.Text = "Package Path"
        '
        'btnRemovePackagePath
        '
        Me.btnRemovePackagePath.Location = New System.Drawing.Point(317, 108)
        Me.btnRemovePackagePath.Name = "btnRemovePackagePath"
        Me.btnRemovePackagePath.Size = New System.Drawing.Size(131, 26)
        Me.btnRemovePackagePath.TabIndex = 3
        Me.btnRemovePackagePath.Text = "Remove Package"
        Me.btnRemovePackagePath.UseVisualStyleBackColor = True
        '
        'btnRemovePackageName
        '
        Me.btnRemovePackageName.Location = New System.Drawing.Point(317, 56)
        Me.btnRemovePackageName.Name = "btnRemovePackageName"
        Me.btnRemovePackageName.Size = New System.Drawing.Size(131, 26)
        Me.btnRemovePackageName.TabIndex = 2
        Me.btnRemovePackageName.Text = "Remove Package"
        Me.btnRemovePackageName.UseVisualStyleBackColor = True
        '
        'txtPackagePath
        '
        Me.txtPackagePath.Location = New System.Drawing.Point(3, 108)
        Me.txtPackagePath.Name = "txtPackagePath"
        Me.txtPackagePath.Size = New System.Drawing.Size(307, 26)
        Me.txtPackagePath.TabIndex = 1
        '
        'txtPackageName
        '
        Me.txtPackageName.Location = New System.Drawing.Point(3, 56)
        Me.txtPackageName.Name = "txtPackageName"
        Me.txtPackageName.Size = New System.Drawing.Size(307, 26)
        Me.txtPackageName.TabIndex = 0
        '
        'btnGetPackages
        '
        Me.btnGetPackages.Location = New System.Drawing.Point(525, 6)
        Me.btnGetPackages.Name = "btnGetPackages"
        Me.btnGetPackages.Size = New System.Drawing.Size(127, 64)
        Me.btnGetPackages.TabIndex = 9
        Me.btnGetPackages.Text = "Get Packages"
        Me.btnGetPackages.UseVisualStyleBackColor = True
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.btnAddPackages)
        Me.GroupBox3.Controls.Add(Me.Label6)
        Me.GroupBox3.Controls.Add(Me.chkIgnoreCheck)
        Me.GroupBox3.Controls.Add(Me.txtPackageFile)
        Me.GroupBox3.Controls.Add(Me.btnOpenPackageFile)
        Me.GroupBox3.Location = New System.Drawing.Point(3, 3)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(516, 169)
        Me.GroupBox3.TabIndex = 15
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Add Packages"
        '
        'btnAddPackages
        '
        Me.btnAddPackages.Location = New System.Drawing.Point(342, 99)
        Me.btnAddPackages.Name = "btnAddPackages"
        Me.btnAddPackages.Size = New System.Drawing.Size(131, 64)
        Me.btnAddPackages.TabIndex = 14
        Me.btnAddPackages.Text = "Add Packages"
        Me.btnAddPackages.UseVisualStyleBackColor = True
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(7, 25)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(120, 20)
        Me.Label6.TabIndex = 11
        Me.Label6.Text = "Package Folder"
        '
        'chkIgnoreCheck
        '
        Me.chkIgnoreCheck.AutoSize = True
        Me.chkIgnoreCheck.Location = New System.Drawing.Point(8, 87)
        Me.chkIgnoreCheck.Name = "chkIgnoreCheck"
        Me.chkIgnoreCheck.Size = New System.Drawing.Size(123, 24)
        Me.chkIgnoreCheck.TabIndex = 13
        Me.chkIgnoreCheck.Text = "Ignore Check"
        Me.chkIgnoreCheck.UseVisualStyleBackColor = True
        '
        'txtPackageFile
        '
        Me.txtPackageFile.Location = New System.Drawing.Point(8, 55)
        Me.txtPackageFile.Name = "txtPackageFile"
        Me.txtPackageFile.Size = New System.Drawing.Size(307, 26)
        Me.txtPackageFile.TabIndex = 10
        '
        'btnOpenPackageFile
        '
        Me.btnOpenPackageFile.Location = New System.Drawing.Point(342, 55)
        Me.btnOpenPackageFile.Name = "btnOpenPackageFile"
        Me.btnOpenPackageFile.Size = New System.Drawing.Size(131, 26)
        Me.btnOpenPackageFile.TabIndex = 12
        Me.btnOpenPackageFile.Text = "Choose Package Folder"
        Me.btnOpenPackageFile.UseVisualStyleBackColor = True
        '
        'TabPage4
        '
        Me.TabPage4.Controls.Add(Me.ChkBoxFeatureManagement_Online)
        Me.TabPage4.Controls.Add(Me.btnDisableFeature)
        Me.TabPage4.Controls.Add(Me.chkEnablePkgPath)
        Me.TabPage4.Controls.Add(Me.chkEnablePkgName)
        Me.TabPage4.Controls.Add(Me.btnEnableFeature)
        Me.TabPage4.Controls.Add(Me.Label12)
        Me.TabPage4.Controls.Add(Me.Label11)
        Me.TabPage4.Controls.Add(Me.Label10)
        Me.TabPage4.Controls.Add(Me.txtFeatPackagePath)
        Me.TabPage4.Controls.Add(Me.txtFeatPackageName)
        Me.TabPage4.Controls.Add(Me.txtFeatureName)
        Me.TabPage4.Controls.Add(Me.btnGetFeatures)
        Me.TabPage4.Location = New System.Drawing.Point(4, 29)
        Me.TabPage4.Name = "TabPage4"
        Me.TabPage4.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage4.Size = New System.Drawing.Size(886, 350)
        Me.TabPage4.TabIndex = 3
        Me.TabPage4.Text = "Feature Management"
        Me.TabPage4.UseVisualStyleBackColor = True
        '
        'ChkBoxFeatureManagement_Online
        '
        Me.ChkBoxFeatureManagement_Online.AutoSize = True
        Me.ChkBoxFeatureManagement_Online.Location = New System.Drawing.Point(758, 324)
        Me.ChkBoxFeatureManagement_Online.Name = "ChkBoxFeatureManagement_Online"
        Me.ChkBoxFeatureManagement_Online.Size = New System.Drawing.Size(125, 24)
        Me.ChkBoxFeatureManagement_Online.TabIndex = 23
        Me.ChkBoxFeatureManagement_Online.Text = "/Online option"
        Me.ChkBoxFeatureManagement_Online.UseVisualStyleBackColor = False
        '
        'btnDisableFeature
        '
        Me.btnDisableFeature.Location = New System.Drawing.Point(525, 143)
        Me.btnDisableFeature.Name = "btnDisableFeature"
        Me.btnDisableFeature.Size = New System.Drawing.Size(127, 64)
        Me.btnDisableFeature.TabIndex = 22
        Me.btnDisableFeature.Text = "Disable Feature"
        Me.btnDisableFeature.UseVisualStyleBackColor = True
        '
        'chkEnablePkgPath
        '
        Me.chkEnablePkgPath.AutoSize = True
        Me.chkEnablePkgPath.Location = New System.Drawing.Point(5, 145)
        Me.chkEnablePkgPath.Name = "chkEnablePkgPath"
        Me.chkEnablePkgPath.Size = New System.Drawing.Size(15, 14)
        Me.chkEnablePkgPath.TabIndex = 21
        Me.chkEnablePkgPath.UseVisualStyleBackColor = True
        '
        'chkEnablePkgName
        '
        Me.chkEnablePkgName.AutoSize = True
        Me.chkEnablePkgName.Location = New System.Drawing.Point(5, 91)
        Me.chkEnablePkgName.Name = "chkEnablePkgName"
        Me.chkEnablePkgName.Size = New System.Drawing.Size(15, 14)
        Me.chkEnablePkgName.TabIndex = 20
        Me.chkEnablePkgName.UseVisualStyleBackColor = True
        '
        'btnEnableFeature
        '
        Me.btnEnableFeature.Location = New System.Drawing.Point(525, 73)
        Me.btnEnableFeature.Name = "btnEnableFeature"
        Me.btnEnableFeature.Size = New System.Drawing.Size(127, 64)
        Me.btnEnableFeature.TabIndex = 19
        Me.btnEnableFeature.Text = "Enable Feature"
        Me.btnEnableFeature.UseVisualStyleBackColor = True
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(27, 116)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(108, 20)
        Me.Label12.TabIndex = 18
        Me.Label12.Text = "Package Path"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(27, 60)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(117, 20)
        Me.Label11.TabIndex = 17
        Me.Label11.Text = "Package Name"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(27, 3)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(111, 20)
        Me.Label10.TabIndex = 16
        Me.Label10.Text = "Feature Name"
        '
        'txtFeatPackagePath
        '
        Me.txtFeatPackagePath.Enabled = False
        Me.txtFeatPackagePath.Location = New System.Drawing.Point(26, 139)
        Me.txtFeatPackagePath.Name = "txtFeatPackagePath"
        Me.txtFeatPackagePath.Size = New System.Drawing.Size(424, 26)
        Me.txtFeatPackagePath.TabIndex = 15
        '
        'txtFeatPackageName
        '
        Me.txtFeatPackageName.Enabled = False
        Me.txtFeatPackageName.Location = New System.Drawing.Point(26, 85)
        Me.txtFeatPackageName.Name = "txtFeatPackageName"
        Me.txtFeatPackageName.Size = New System.Drawing.Size(424, 26)
        Me.txtFeatPackageName.TabIndex = 12
        '
        'txtFeatureName
        '
        Me.txtFeatureName.Location = New System.Drawing.Point(26, 26)
        Me.txtFeatureName.Name = "txtFeatureName"
        Me.txtFeatureName.Size = New System.Drawing.Size(424, 26)
        Me.txtFeatureName.TabIndex = 11
        '
        'btnGetFeatures
        '
        Me.btnGetFeatures.Location = New System.Drawing.Point(525, 3)
        Me.btnGetFeatures.Name = "btnGetFeatures"
        Me.btnGetFeatures.Size = New System.Drawing.Size(127, 64)
        Me.btnGetFeatures.TabIndex = 10
        Me.btnGetFeatures.Text = "Get Features"
        Me.btnGetFeatures.UseVisualStyleBackColor = True
        '
        'TabPage5
        '
        Me.TabPage5.Controls.Add(Me.ChkBoxEditionServicing_Online)
        Me.TabPage5.Controls.Add(Me.Label15)
        Me.TabPage5.Controls.Add(Me.btnSetEdition)
        Me.TabPage5.Controls.Add(Me.txtEdition)
        Me.TabPage5.Controls.Add(Me.txtProdKey)
        Me.TabPage5.Controls.Add(Me.btnSetProdKey)
        Me.TabPage5.Controls.Add(Me.Label13)
        Me.TabPage5.Controls.Add(Me.btnGetTargetEditions)
        Me.TabPage5.Controls.Add(Me.btGetCurrentEdition)
        Me.TabPage5.Location = New System.Drawing.Point(4, 29)
        Me.TabPage5.Name = "TabPage5"
        Me.TabPage5.Size = New System.Drawing.Size(886, 350)
        Me.TabPage5.TabIndex = 4
        Me.TabPage5.Text = "Edition Servicing"
        Me.TabPage5.UseVisualStyleBackColor = True
        '
        'ChkBoxEditionServicing_Online
        '
        Me.ChkBoxEditionServicing_Online.AutoSize = True
        Me.ChkBoxEditionServicing_Online.Location = New System.Drawing.Point(758, 323)
        Me.ChkBoxEditionServicing_Online.Name = "ChkBoxEditionServicing_Online"
        Me.ChkBoxEditionServicing_Online.Size = New System.Drawing.Size(125, 24)
        Me.ChkBoxEditionServicing_Online.TabIndex = 29
        Me.ChkBoxEditionServicing_Online.Text = "/Online option"
        Me.ChkBoxEditionServicing_Online.UseVisualStyleBackColor = False
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(26, 73)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(58, 20)
        Me.Label15.TabIndex = 28
        Me.Label15.Text = "Edition"
        '
        'btnSetEdition
        '
        Me.btnSetEdition.Location = New System.Drawing.Point(339, 94)
        Me.btnSetEdition.Name = "btnSetEdition"
        Me.btnSetEdition.Size = New System.Drawing.Size(129, 30)
        Me.btnSetEdition.TabIndex = 27
        Me.btnSetEdition.Text = "Set Edition"
        Me.btnSetEdition.UseVisualStyleBackColor = True
        '
        'txtEdition
        '
        Me.txtEdition.Location = New System.Drawing.Point(16, 96)
        Me.txtEdition.Name = "txtEdition"
        Me.txtEdition.Size = New System.Drawing.Size(303, 26)
        Me.txtEdition.TabIndex = 26
        '
        'txtProdKey
        '
        Me.txtProdKey.Location = New System.Drawing.Point(16, 26)
        Me.txtProdKey.Mask = "&&&&&-&&&&&-&&&&&-&&&&&-&&&&&"
        Me.txtProdKey.Name = "txtProdKey"
        Me.txtProdKey.Size = New System.Drawing.Size(303, 26)
        Me.txtProdKey.TabIndex = 25
        '
        'btnSetProdKey
        '
        Me.btnSetProdKey.Location = New System.Drawing.Point(339, 26)
        Me.btnSetProdKey.Name = "btnSetProdKey"
        Me.btnSetProdKey.Size = New System.Drawing.Size(129, 26)
        Me.btnSetProdKey.TabIndex = 24
        Me.btnSetProdKey.Text = "Set Product Key"
        Me.btnSetProdKey.UseVisualStyleBackColor = True
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(26, 3)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(94, 20)
        Me.Label13.TabIndex = 22
        Me.Label13.Text = "Product Key"
        '
        'btnGetTargetEditions
        '
        Me.btnGetTargetEditions.Location = New System.Drawing.Point(525, 73)
        Me.btnGetTargetEditions.Name = "btnGetTargetEditions"
        Me.btnGetTargetEditions.Size = New System.Drawing.Size(127, 64)
        Me.btnGetTargetEditions.TabIndex = 12
        Me.btnGetTargetEditions.Text = "Get Target Editions (/Online)"
        Me.btnGetTargetEditions.UseVisualStyleBackColor = True
        '
        'btGetCurrentEdition
        '
        Me.btGetCurrentEdition.Location = New System.Drawing.Point(525, 3)
        Me.btGetCurrentEdition.Name = "btGetCurrentEdition"
        Me.btGetCurrentEdition.Size = New System.Drawing.Size(127, 64)
        Me.btGetCurrentEdition.TabIndex = 11
        Me.btGetCurrentEdition.Text = "Get Current Edition (/Online)"
        Me.btGetCurrentEdition.UseVisualStyleBackColor = True
        '
        'TabPage6
        '
        Me.TabPage6.Controls.Add(Me.ChkBoxUnattendedServicing_Online)
        Me.TabPage6.Controls.Add(Me.btnChooseUnAttend)
        Me.TabPage6.Controls.Add(Me.TxtBox_UnattendXMLFile)
        Me.TabPage6.Controls.Add(Me.Label14)
        Me.TabPage6.Controls.Add(Me.btnApplyUnattend)
        Me.TabPage6.Location = New System.Drawing.Point(4, 29)
        Me.TabPage6.Name = "TabPage6"
        Me.TabPage6.Size = New System.Drawing.Size(886, 350)
        Me.TabPage6.TabIndex = 5
        Me.TabPage6.Text = "Unattended Servicing"
        Me.TabPage6.UseVisualStyleBackColor = True
        '
        'ChkBoxUnattendedServicing_Online
        '
        Me.ChkBoxUnattendedServicing_Online.AutoSize = True
        Me.ChkBoxUnattendedServicing_Online.Location = New System.Drawing.Point(758, 323)
        Me.ChkBoxUnattendedServicing_Online.Name = "ChkBoxUnattendedServicing_Online"
        Me.ChkBoxUnattendedServicing_Online.Size = New System.Drawing.Size(125, 24)
        Me.ChkBoxUnattendedServicing_Online.TabIndex = 30
        Me.ChkBoxUnattendedServicing_Online.Text = "/Online option"
        Me.ChkBoxUnattendedServicing_Online.UseVisualStyleBackColor = False
        '
        'btnChooseUnAttend
        '
        Me.btnChooseUnAttend.Location = New System.Drawing.Point(358, 26)
        Me.btnChooseUnAttend.Name = "btnChooseUnAttend"
        Me.btnChooseUnAttend.Size = New System.Drawing.Size(106, 26)
        Me.btnChooseUnAttend.TabIndex = 23
        Me.btnChooseUnAttend.Text = "Choose XML"
        Me.btnChooseUnAttend.UseVisualStyleBackColor = True
        '
        'TxtBox_UnattendXMLFile
        '
        Me.TxtBox_UnattendXMLFile.Location = New System.Drawing.Point(7, 26)
        Me.TxtBox_UnattendXMLFile.Name = "TxtBox_UnattendXMLFile"
        Me.TxtBox_UnattendXMLFile.Size = New System.Drawing.Size(339, 26)
        Me.TxtBox_UnattendXMLFile.TabIndex = 21
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(3, 3)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(142, 20)
        Me.Label14.TabIndex = 22
        Me.Label14.Text = "Unattend XML File"
        '
        'btnApplyUnattend
        '
        Me.btnApplyUnattend.Location = New System.Drawing.Point(525, 3)
        Me.btnApplyUnattend.Name = "btnApplyUnattend"
        Me.btnApplyUnattend.Size = New System.Drawing.Size(127, 64)
        Me.btnApplyUnattend.TabIndex = 20
        Me.btnApplyUnattend.Text = "Apply Unattend.xml"
        Me.btnApplyUnattend.UseVisualStyleBackColor = True
        '
        'TabPage7
        '
        Me.TabPage7.Controls.Add(Me.btnChooseMSP)
        Me.TabPage7.Controls.Add(Me.txtPatchLocation)
        Me.TabPage7.Controls.Add(Me.Label18)
        Me.TabPage7.Controls.Add(Me.txtPatchCode)
        Me.TabPage7.Controls.Add(Me.txtProductCode)
        Me.TabPage7.Controls.Add(Me.btnCheckAppPatch)
        Me.TabPage7.Controls.Add(Me.btnGetAppPatchInfo)
        Me.TabPage7.Controls.Add(Me.btnGetAppPatches)
        Me.TabPage7.Controls.Add(Me.btnGetAppInfo)
        Me.TabPage7.Controls.Add(Me.Label17)
        Me.TabPage7.Controls.Add(Me.Label16)
        Me.TabPage7.Controls.Add(Me.btnGetApps)
        Me.TabPage7.Location = New System.Drawing.Point(4, 29)
        Me.TabPage7.Name = "TabPage7"
        Me.TabPage7.Size = New System.Drawing.Size(886, 350)
        Me.TabPage7.TabIndex = 6
        Me.TabPage7.Text = "Application Servicing"
        Me.TabPage7.UseVisualStyleBackColor = True
        '
        'btnChooseMSP
        '
        Me.btnChooseMSP.Location = New System.Drawing.Point(359, 138)
        Me.btnChooseMSP.Name = "btnChooseMSP"
        Me.btnChooseMSP.Size = New System.Drawing.Size(106, 28)
        Me.btnChooseMSP.TabIndex = 41
        Me.btnChooseMSP.Text = "Choose MSP"
        Me.btnChooseMSP.UseVisualStyleBackColor = True
        '
        'txtPatchLocation
        '
        Me.txtPatchLocation.Location = New System.Drawing.Point(7, 140)
        Me.txtPatchLocation.Name = "txtPatchLocation"
        Me.txtPatchLocation.Size = New System.Drawing.Size(327, 26)
        Me.txtPatchLocation.TabIndex = 39
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(3, 117)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(72, 20)
        Me.Label18.TabIndex = 40
        Me.Label18.Text = "MSP File"
        '
        'txtPatchCode
        '
        Me.txtPatchCode.Location = New System.Drawing.Point(7, 81)
        Me.txtPatchCode.Mask = "{&&&&&&&&-&&&&-&&&&-&&&&-&&&&&&&&&&&&}"
        Me.txtPatchCode.Name = "txtPatchCode"
        Me.txtPatchCode.Size = New System.Drawing.Size(327, 26)
        Me.txtPatchCode.TabIndex = 38
        '
        'txtProductCode
        '
        Me.txtProductCode.Location = New System.Drawing.Point(6, 29)
        Me.txtProductCode.Mask = "{&&&&&&&&-&&&&-&&&&-&&&&-&&&&&&&&&&&&}"
        Me.txtProductCode.Name = "txtProductCode"
        Me.txtProductCode.Size = New System.Drawing.Size(328, 26)
        Me.txtProductCode.TabIndex = 37
        '
        'btnCheckAppPatch
        '
        Me.btnCheckAppPatch.Location = New System.Drawing.Point(525, 283)
        Me.btnCheckAppPatch.Name = "btnCheckAppPatch"
        Me.btnCheckAppPatch.Size = New System.Drawing.Size(127, 64)
        Me.btnCheckAppPatch.TabIndex = 36
        Me.btnCheckAppPatch.Text = "Check App Patch"
        Me.btnCheckAppPatch.UseVisualStyleBackColor = True
        '
        'btnGetAppPatchInfo
        '
        Me.btnGetAppPatchInfo.Location = New System.Drawing.Point(525, 213)
        Me.btnGetAppPatchInfo.Name = "btnGetAppPatchInfo"
        Me.btnGetAppPatchInfo.Size = New System.Drawing.Size(127, 64)
        Me.btnGetAppPatchInfo.TabIndex = 35
        Me.btnGetAppPatchInfo.Text = "Get Application Patch Info"
        Me.btnGetAppPatchInfo.UseVisualStyleBackColor = True
        '
        'btnGetAppPatches
        '
        Me.btnGetAppPatches.Location = New System.Drawing.Point(525, 143)
        Me.btnGetAppPatches.Name = "btnGetAppPatches"
        Me.btnGetAppPatches.Size = New System.Drawing.Size(127, 64)
        Me.btnGetAppPatches.TabIndex = 34
        Me.btnGetAppPatches.Text = "Get Application Patches"
        Me.btnGetAppPatches.UseVisualStyleBackColor = True
        '
        'btnGetAppInfo
        '
        Me.btnGetAppInfo.Location = New System.Drawing.Point(525, 73)
        Me.btnGetAppInfo.Name = "btnGetAppInfo"
        Me.btnGetAppInfo.Size = New System.Drawing.Size(127, 64)
        Me.btnGetAppInfo.TabIndex = 33
        Me.btnGetAppInfo.Text = "Get Application Info"
        Me.btnGetAppInfo.UseVisualStyleBackColor = True
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(3, 58)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(144, 20)
        Me.Label17.TabIndex = 32
        Me.Label17.Text = "PatchCode (GUID)"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(0, 3)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(158, 20)
        Me.Label16.TabIndex = 30
        Me.Label16.Text = "ProductCode (GUID)"
        '
        'btnGetApps
        '
        Me.btnGetApps.Location = New System.Drawing.Point(525, 3)
        Me.btnGetApps.Name = "btnGetApps"
        Me.btnGetApps.Size = New System.Drawing.Size(127, 64)
        Me.btnGetApps.TabIndex = 12
        Me.btnGetApps.Text = "Get Applications"
        Me.btnGetApps.UseVisualStyleBackColor = True
        '
        'TabPage8
        '
        Me.TabPage8.Controls.Add(Me.Label26)
        Me.TabPage8.Controls.Add(Me.TxtBoxCaptureWIM_Description)
        Me.TabPage8.Controls.Add(Me.Label24)
        Me.TabPage8.Controls.Add(Me.TxtNameMetadata)
        Me.TabPage8.Controls.Add(Me.chkCaptureVerify)
        Me.TabPage8.Controls.Add(Me.btnAppend)
        Me.TabPage8.Controls.Add(Me.cmbCompression)
        Me.TabPage8.Controls.Add(Me.lblCompression)
        Me.TabPage8.Controls.Add(Me.lblName)
        Me.TabPage8.Controls.Add(Me.TxtFileName)
        Me.TabPage8.Controls.Add(Me.btnCreate)
        Me.TabPage8.Controls.Add(Me.Label20)
        Me.TabPage8.Controls.Add(Me.Label21)
        Me.TabPage8.Controls.Add(Me.btnCaptureDest)
        Me.TabPage8.Controls.Add(Me.txtCaptureDest)
        Me.TabPage8.Controls.Add(Me.txtCaptureSource)
        Me.TabPage8.Controls.Add(Me.btnCaptureSrc)
        Me.TabPage8.Location = New System.Drawing.Point(4, 29)
        Me.TabPage8.Name = "TabPage8"
        Me.TabPage8.Size = New System.Drawing.Size(886, 350)
        Me.TabPage8.TabIndex = 7
        Me.TabPage8.Text = "Capture Wim Image"
        Me.TabPage8.UseVisualStyleBackColor = True
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.Location = New System.Drawing.Point(14, 156)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(175, 20)
        Me.Label26.TabIndex = 50
        Me.Label26.Text = "Description (metadata):"
        '
        'TxtBoxCaptureWIM_Description
        '
        Me.TxtBoxCaptureWIM_Description.Location = New System.Drawing.Point(191, 153)
        Me.TxtBoxCaptureWIM_Description.Name = "TxtBoxCaptureWIM_Description"
        Me.TxtBoxCaptureWIM_Description.Size = New System.Drawing.Size(295, 26)
        Me.TxtBoxCaptureWIM_Description.TabIndex = 49
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Location = New System.Drawing.Point(14, 124)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(137, 20)
        Me.Label24.TabIndex = 48
        Me.Label24.Text = "Name (metadata):"
        '
        'TxtNameMetadata
        '
        Me.TxtNameMetadata.Location = New System.Drawing.Point(191, 121)
        Me.TxtNameMetadata.Name = "TxtNameMetadata"
        Me.TxtNameMetadata.Size = New System.Drawing.Size(295, 26)
        Me.TxtNameMetadata.TabIndex = 47
        '
        'chkCaptureVerify
        '
        Me.chkCaptureVerify.AutoSize = True
        Me.chkCaptureVerify.Location = New System.Drawing.Point(191, 219)
        Me.chkCaptureVerify.Name = "chkCaptureVerify"
        Me.chkCaptureVerify.Size = New System.Drawing.Size(72, 24)
        Me.chkCaptureVerify.TabIndex = 46
        Me.chkCaptureVerify.Text = "/Verify"
        Me.chkCaptureVerify.UseVisualStyleBackColor = True
        '
        'btnAppend
        '
        Me.btnAppend.Location = New System.Drawing.Point(631, 90)
        Me.btnAppend.Name = "btnAppend"
        Me.btnAppend.Size = New System.Drawing.Size(127, 64)
        Me.btnAppend.TabIndex = 45
        Me.btnAppend.Text = "&Append"
        Me.btnAppend.UseVisualStyleBackColor = True
        '
        'cmbCompression
        '
        Me.cmbCompression.FormattingEnabled = True
        Me.cmbCompression.Items.AddRange(New Object() {"fast", "max", "none"})
        Me.cmbCompression.Location = New System.Drawing.Point(191, 185)
        Me.cmbCompression.Name = "cmbCompression"
        Me.cmbCompression.Size = New System.Drawing.Size(80, 28)
        Me.cmbCompression.TabIndex = 44
        '
        'lblCompression
        '
        Me.lblCompression.AutoSize = True
        Me.lblCompression.Location = New System.Drawing.Point(14, 191)
        Me.lblCompression.Name = "lblCompression"
        Me.lblCompression.Size = New System.Drawing.Size(106, 20)
        Me.lblCompression.TabIndex = 43
        Me.lblCompression.Text = "Compression:"
        '
        'lblName
        '
        Me.lblName.AutoSize = True
        Me.lblName.Location = New System.Drawing.Point(14, 87)
        Me.lblName.Name = "lblName"
        Me.lblName.Size = New System.Drawing.Size(78, 20)
        Me.lblName.TabIndex = 42
        Me.lblName.Text = "Filename:"
        '
        'TxtFileName
        '
        Me.TxtFileName.Location = New System.Drawing.Point(191, 84)
        Me.TxtFileName.Name = "TxtFileName"
        Me.TxtFileName.Size = New System.Drawing.Size(295, 26)
        Me.TxtFileName.TabIndex = 34
        '
        'btnCreate
        '
        Me.btnCreate.Location = New System.Drawing.Point(631, 20)
        Me.btnCreate.Name = "btnCreate"
        Me.btnCreate.Size = New System.Drawing.Size(127, 64)
        Me.btnCreate.TabIndex = 40
        Me.btnCreate.Text = "&Create"
        Me.btnCreate.UseVisualStyleBackColor = True
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Location = New System.Drawing.Point(14, 55)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(94, 20)
        Me.Label20.TabIndex = 41
        Me.Label20.Text = "Destination:"
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Location = New System.Drawing.Point(14, 23)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(64, 20)
        Me.Label21.TabIndex = 38
        Me.Label21.Text = "Source:"
        '
        'btnCaptureDest
        '
        Me.btnCaptureDest.Location = New System.Drawing.Point(509, 50)
        Me.btnCaptureDest.Name = "btnCaptureDest"
        Me.btnCaptureDest.Size = New System.Drawing.Size(90, 28)
        Me.btnCaptureDest.TabIndex = 39
        Me.btnCaptureDest.Text = "Browse..."
        Me.btnCaptureDest.UseVisualStyleBackColor = True
        '
        'txtCaptureDest
        '
        Me.txtCaptureDest.Location = New System.Drawing.Point(191, 52)
        Me.txtCaptureDest.Name = "txtCaptureDest"
        Me.txtCaptureDest.Size = New System.Drawing.Size(295, 26)
        Me.txtCaptureDest.TabIndex = 37
        '
        'txtCaptureSource
        '
        Me.txtCaptureSource.Location = New System.Drawing.Point(191, 20)
        Me.txtCaptureSource.Name = "txtCaptureSource"
        Me.txtCaptureSource.Size = New System.Drawing.Size(295, 26)
        Me.txtCaptureSource.TabIndex = 35
        '
        'btnCaptureSrc
        '
        Me.btnCaptureSrc.Location = New System.Drawing.Point(509, 18)
        Me.btnCaptureSrc.Name = "btnCaptureSrc"
        Me.btnCaptureSrc.Size = New System.Drawing.Size(90, 28)
        Me.btnCaptureSrc.TabIndex = 36
        Me.btnCaptureSrc.Text = "Browse..."
        Me.btnCaptureSrc.UseVisualStyleBackColor = True
        '
        'TabPage9
        '
        Me.TabPage9.Controls.Add(Me.LblApplySource_PatternSWMFile)
        Me.TabPage9.Controls.Add(Me.TxtBoxApplySource_PatternSWMFile)
        Me.TabPage9.Controls.Add(Me.LblApplyWim_Size)
        Me.TabPage9.Controls.Add(Me.TxtBoxApplyWim_Size)
        Me.TabPage9.Controls.Add(Me.LblApplyWim_Description)
        Me.TabPage9.Controls.Add(Me.LblApplyWim_Name)
        Me.TabPage9.Controls.Add(Me.TxtBoxApplyWim_Description)
        Me.TabPage9.Controls.Add(Me.TxtBoxApplyWim_Name)
        Me.TabPage9.Controls.Add(Me.chkApplyVerify)
        Me.TabPage9.Controls.Add(Me.cmbApplyIndex)
        Me.TabPage9.Controls.Add(Me.lblIndex)
        Me.TabPage9.Controls.Add(Me.btnApply)
        Me.TabPage9.Controls.Add(Me.lblDest)
        Me.TabPage9.Controls.Add(Me.lblSource)
        Me.TabPage9.Controls.Add(Me.btnBrowseDest)
        Me.TabPage9.Controls.Add(Me.txtApplyDest)
        Me.TabPage9.Controls.Add(Me.txtApplySource)
        Me.TabPage9.Controls.Add(Me.btnBrowseSource)
        Me.TabPage9.Location = New System.Drawing.Point(4, 29)
        Me.TabPage9.Name = "TabPage9"
        Me.TabPage9.Size = New System.Drawing.Size(886, 350)
        Me.TabPage9.TabIndex = 8
        Me.TabPage9.Text = "Apply Wim / Swm Image"
        Me.TabPage9.UseVisualStyleBackColor = True
        '
        'LblApplySource_PatternSWMFile
        '
        Me.LblApplySource_PatternSWMFile.AutoSize = True
        Me.LblApplySource_PatternSWMFile.Location = New System.Drawing.Point(8, 93)
        Me.LblApplySource_PatternSWMFile.Name = "LblApplySource_PatternSWMFile"
        Me.LblApplySource_PatternSWMFile.Size = New System.Drawing.Size(133, 20)
        Me.LblApplySource_PatternSWMFile.TabIndex = 49
        Me.LblApplySource_PatternSWMFile.Text = "SWMFile Pattern:"
        '
        'TxtBoxApplySource_PatternSWMFile
        '
        Me.TxtBoxApplySource_PatternSWMFile.Location = New System.Drawing.Point(144, 90)
        Me.TxtBoxApplySource_PatternSWMFile.Name = "TxtBoxApplySource_PatternSWMFile"
        Me.TxtBoxApplySource_PatternSWMFile.Size = New System.Drawing.Size(295, 26)
        Me.TxtBoxApplySource_PatternSWMFile.TabIndex = 48
        '
        'LblApplyWim_Size
        '
        Me.LblApplyWim_Size.AutoSize = True
        Me.LblApplyWim_Size.Location = New System.Drawing.Point(8, 224)
        Me.LblApplyWim_Size.Name = "LblApplyWim_Size"
        Me.LblApplyWim_Size.Size = New System.Drawing.Size(44, 20)
        Me.LblApplyWim_Size.TabIndex = 47
        Me.LblApplyWim_Size.Text = "Size:"
        '
        'TxtBoxApplyWim_Size
        '
        Me.TxtBoxApplyWim_Size.Location = New System.Drawing.Point(144, 221)
        Me.TxtBoxApplyWim_Size.Name = "TxtBoxApplyWim_Size"
        Me.TxtBoxApplyWim_Size.Size = New System.Drawing.Size(295, 26)
        Me.TxtBoxApplyWim_Size.TabIndex = 46
        '
        'LblApplyWim_Description
        '
        Me.LblApplyWim_Description.AutoSize = True
        Me.LblApplyWim_Description.Location = New System.Drawing.Point(8, 189)
        Me.LblApplyWim_Description.Name = "LblApplyWim_Description"
        Me.LblApplyWim_Description.Size = New System.Drawing.Size(93, 20)
        Me.LblApplyWim_Description.TabIndex = 45
        Me.LblApplyWim_Description.Text = "Description:"
        '
        'LblApplyWim_Name
        '
        Me.LblApplyWim_Name.AutoSize = True
        Me.LblApplyWim_Name.Location = New System.Drawing.Point(8, 157)
        Me.LblApplyWim_Name.Name = "LblApplyWim_Name"
        Me.LblApplyWim_Name.Size = New System.Drawing.Size(55, 20)
        Me.LblApplyWim_Name.TabIndex = 44
        Me.LblApplyWim_Name.Text = "Name:"
        '
        'TxtBoxApplyWim_Description
        '
        Me.TxtBoxApplyWim_Description.Location = New System.Drawing.Point(144, 186)
        Me.TxtBoxApplyWim_Description.Name = "TxtBoxApplyWim_Description"
        Me.TxtBoxApplyWim_Description.Size = New System.Drawing.Size(295, 26)
        Me.TxtBoxApplyWim_Description.TabIndex = 43
        '
        'TxtBoxApplyWim_Name
        '
        Me.TxtBoxApplyWim_Name.Location = New System.Drawing.Point(144, 154)
        Me.TxtBoxApplyWim_Name.Name = "TxtBoxApplyWim_Name"
        Me.TxtBoxApplyWim_Name.Size = New System.Drawing.Size(295, 26)
        Me.TxtBoxApplyWim_Name.TabIndex = 42
        '
        'chkApplyVerify
        '
        Me.chkApplyVerify.AutoSize = True
        Me.chkApplyVerify.Location = New System.Drawing.Point(468, 93)
        Me.chkApplyVerify.Name = "chkApplyVerify"
        Me.chkApplyVerify.Size = New System.Drawing.Size(68, 24)
        Me.chkApplyVerify.TabIndex = 41
        Me.chkApplyVerify.Text = "Verify"
        Me.chkApplyVerify.UseVisualStyleBackColor = True
        '
        'cmbApplyIndex
        '
        Me.cmbApplyIndex.FormattingEnabled = True
        Me.cmbApplyIndex.Location = New System.Drawing.Point(518, 154)
        Me.cmbApplyIndex.Name = "cmbApplyIndex"
        Me.cmbApplyIndex.Size = New System.Drawing.Size(63, 28)
        Me.cmbApplyIndex.TabIndex = 40
        '
        'lblIndex
        '
        Me.lblIndex.AutoSize = True
        Me.lblIndex.Location = New System.Drawing.Point(465, 157)
        Me.lblIndex.Name = "lblIndex"
        Me.lblIndex.Size = New System.Drawing.Size(52, 20)
        Me.lblIndex.TabIndex = 39
        Me.lblIndex.Text = "Index:"
        '
        'btnApply
        '
        Me.btnApply.Location = New System.Drawing.Point(642, 14)
        Me.btnApply.Name = "btnApply"
        Me.btnApply.Size = New System.Drawing.Size(108, 64)
        Me.btnApply.TabIndex = 37
        Me.btnApply.Text = "&Apply"
        Me.btnApply.UseVisualStyleBackColor = True
        '
        'lblDest
        '
        Me.lblDest.AutoSize = True
        Me.lblDest.Location = New System.Drawing.Point(8, 49)
        Me.lblDest.Name = "lblDest"
        Me.lblDest.Size = New System.Drawing.Size(94, 20)
        Me.lblDest.TabIndex = 38
        Me.lblDest.Text = "Destination:"
        '
        'lblSource
        '
        Me.lblSource.AutoSize = True
        Me.lblSource.Location = New System.Drawing.Point(8, 17)
        Me.lblSource.Name = "lblSource"
        Me.lblSource.Size = New System.Drawing.Size(64, 20)
        Me.lblSource.TabIndex = 35
        Me.lblSource.Text = "Source:"
        '
        'btnBrowseDest
        '
        Me.btnBrowseDest.Location = New System.Drawing.Point(468, 49)
        Me.btnBrowseDest.Name = "btnBrowseDest"
        Me.btnBrowseDest.Size = New System.Drawing.Size(113, 26)
        Me.btnBrowseDest.TabIndex = 36
        Me.btnBrowseDest.Text = "Browse..."
        Me.btnBrowseDest.UseVisualStyleBackColor = True
        '
        'txtApplyDest
        '
        Me.txtApplyDest.Location = New System.Drawing.Point(144, 49)
        Me.txtApplyDest.Name = "txtApplyDest"
        Me.txtApplyDest.Size = New System.Drawing.Size(295, 26)
        Me.txtApplyDest.TabIndex = 34
        '
        'txtApplySource
        '
        Me.txtApplySource.Location = New System.Drawing.Point(144, 14)
        Me.txtApplySource.Name = "txtApplySource"
        Me.txtApplySource.Size = New System.Drawing.Size(295, 26)
        Me.txtApplySource.TabIndex = 32
        '
        'btnBrowseSource
        '
        Me.btnBrowseSource.AutoSize = True
        Me.btnBrowseSource.Location = New System.Drawing.Point(468, 14)
        Me.btnBrowseSource.Name = "btnBrowseSource"
        Me.btnBrowseSource.Size = New System.Drawing.Size(113, 30)
        Me.btnBrowseSource.TabIndex = 33
        Me.btnBrowseSource.Text = "Browse..."
        Me.btnBrowseSource.UseVisualStyleBackColor = True
        '
        'TabPage10
        '
        Me.TabPage10.Controls.Add(Me.ChkBoxExportImage_WimBoot)
        Me.TabPage10.Controls.Add(Me.ChkBoxExportImage_CheckIntegrity)
        Me.TabPage10.Controls.Add(Me.CmbBoxExportImage_Compression)
        Me.TabPage10.Controls.Add(Me.LblExportImage_LevelCompression)
        Me.TabPage10.Controls.Add(Me.ChkBoxExportImage_Bootable)
        Me.TabPage10.Controls.Add(Me.CmbBoxExportImage_Index)
        Me.TabPage10.Controls.Add(Me.LblExportImage_Index)
        Me.TabPage10.Controls.Add(Me.BtnExportImage_ExportImage)
        Me.TabPage10.Controls.Add(Me.BtnExportImage_BrowseDestination)
        Me.TabPage10.Controls.Add(Me.BtnExportImage_BrowseSource)
        Me.TabPage10.Controls.Add(Me.LblExportImage_Size)
        Me.TabPage10.Controls.Add(Me.TxtBoxExportImage_Size)
        Me.TabPage10.Controls.Add(Me.LblExportImage_Description)
        Me.TabPage10.Controls.Add(Me.LblExportImage_Name)
        Me.TabPage10.Controls.Add(Me.TxtBoxExportImage_Description)
        Me.TabPage10.Controls.Add(Me.TxtBoxExportImage_Name)
        Me.TabPage10.Controls.Add(Me.LblExportImage_Filename)
        Me.TabPage10.Controls.Add(Me.TxtBoxExportImage_Filename)
        Me.TabPage10.Controls.Add(Me.LblExportImage_Destination)
        Me.TabPage10.Controls.Add(Me.LblExportImage_Source)
        Me.TabPage10.Controls.Add(Me.TxtBoxExportImage_Destination)
        Me.TabPage10.Controls.Add(Me.TxtBoxExportImage_Source)
        Me.TabPage10.Location = New System.Drawing.Point(4, 29)
        Me.TabPage10.Name = "TabPage10"
        Me.TabPage10.Size = New System.Drawing.Size(886, 350)
        Me.TabPage10.TabIndex = 9
        Me.TabPage10.Text = "Export Image"
        Me.TabPage10.UseVisualStyleBackColor = True
        '
        'ChkBoxExportImage_WimBoot
        '
        Me.ChkBoxExportImage_WimBoot.AutoSize = True
        Me.ChkBoxExportImage_WimBoot.Location = New System.Drawing.Point(652, 157)
        Me.ChkBoxExportImage_WimBoot.Name = "ChkBoxExportImage_WimBoot"
        Me.ChkBoxExportImage_WimBoot.Size = New System.Drawing.Size(97, 24)
        Me.ChkBoxExportImage_WimBoot.TabIndex = 64
        Me.ChkBoxExportImage_WimBoot.Text = "/WimBoot"
        Me.ChkBoxExportImage_WimBoot.UseVisualStyleBackColor = True
        '
        'ChkBoxExportImage_CheckIntegrity
        '
        Me.ChkBoxExportImage_CheckIntegrity.AutoSize = True
        Me.ChkBoxExportImage_CheckIntegrity.Location = New System.Drawing.Point(471, 187)
        Me.ChkBoxExportImage_CheckIntegrity.Name = "ChkBoxExportImage_CheckIntegrity"
        Me.ChkBoxExportImage_CheckIntegrity.Size = New System.Drawing.Size(134, 24)
        Me.ChkBoxExportImage_CheckIntegrity.TabIndex = 63
        Me.ChkBoxExportImage_CheckIntegrity.Text = "/CheckIntegrity"
        Me.ChkBoxExportImage_CheckIntegrity.UseVisualStyleBackColor = True
        '
        'CmbBoxExportImage_Compression
        '
        Me.CmbBoxExportImage_Compression.FormattingEnabled = True
        Me.CmbBoxExportImage_Compression.Items.AddRange(New Object() {"fast", "max", "none", "recovery"})
        Me.CmbBoxExportImage_Compression.Location = New System.Drawing.Point(652, 116)
        Me.CmbBoxExportImage_Compression.Name = "CmbBoxExportImage_Compression"
        Me.CmbBoxExportImage_Compression.Size = New System.Drawing.Size(112, 28)
        Me.CmbBoxExportImage_Compression.TabIndex = 62
        '
        'LblExportImage_LevelCompression
        '
        Me.LblExportImage_LevelCompression.AutoSize = True
        Me.LblExportImage_LevelCompression.Location = New System.Drawing.Point(547, 119)
        Me.LblExportImage_LevelCompression.Name = "LblExportImage_LevelCompression"
        Me.LblExportImage_LevelCompression.Size = New System.Drawing.Size(106, 20)
        Me.LblExportImage_LevelCompression.TabIndex = 61
        Me.LblExportImage_LevelCompression.Text = "Compression:"
        '
        'ChkBoxExportImage_Bootable
        '
        Me.ChkBoxExportImage_Bootable.AutoSize = True
        Me.ChkBoxExportImage_Bootable.Location = New System.Drawing.Point(471, 157)
        Me.ChkBoxExportImage_Bootable.Name = "ChkBoxExportImage_Bootable"
        Me.ChkBoxExportImage_Bootable.Size = New System.Drawing.Size(96, 24)
        Me.ChkBoxExportImage_Bootable.TabIndex = 60
        Me.ChkBoxExportImage_Bootable.Text = "/Bootable"
        Me.ChkBoxExportImage_Bootable.UseVisualStyleBackColor = True
        '
        'CmbBoxExportImage_Index
        '
        Me.CmbBoxExportImage_Index.FormattingEnabled = True
        Me.CmbBoxExportImage_Index.Items.AddRange(New Object() {"1", "2", "3", "4", "5", "6", "7", "8", "9", "10"})
        Me.CmbBoxExportImage_Index.Location = New System.Drawing.Point(471, 116)
        Me.CmbBoxExportImage_Index.Name = "CmbBoxExportImage_Index"
        Me.CmbBoxExportImage_Index.Size = New System.Drawing.Size(50, 28)
        Me.CmbBoxExportImage_Index.TabIndex = 59
        '
        'LblExportImage_Index
        '
        Me.LblExportImage_Index.AutoSize = True
        Me.LblExportImage_Index.Location = New System.Drawing.Point(415, 119)
        Me.LblExportImage_Index.Name = "LblExportImage_Index"
        Me.LblExportImage_Index.Size = New System.Drawing.Size(52, 20)
        Me.LblExportImage_Index.TabIndex = 58
        Me.LblExportImage_Index.Text = "Index:"
        '
        'BtnExportImage_ExportImage
        '
        Me.BtnExportImage_ExportImage.Location = New System.Drawing.Point(562, 25)
        Me.BtnExportImage_ExportImage.Name = "BtnExportImage_ExportImage"
        Me.BtnExportImage_ExportImage.Size = New System.Drawing.Size(202, 62)
        Me.BtnExportImage_ExportImage.TabIndex = 57
        Me.BtnExportImage_ExportImage.Text = "Export Image"
        Me.BtnExportImage_ExportImage.UseVisualStyleBackColor = True
        '
        'BtnExportImage_BrowseDestination
        '
        Me.BtnExportImage_BrowseDestination.Location = New System.Drawing.Point(415, 64)
        Me.BtnExportImage_BrowseDestination.Name = "BtnExportImage_BrowseDestination"
        Me.BtnExportImage_BrowseDestination.Size = New System.Drawing.Size(89, 26)
        Me.BtnExportImage_BrowseDestination.TabIndex = 56
        Me.BtnExportImage_BrowseDestination.Text = "Browse..."
        Me.BtnExportImage_BrowseDestination.UseVisualStyleBackColor = True
        '
        'BtnExportImage_BrowseSource
        '
        Me.BtnExportImage_BrowseSource.Location = New System.Drawing.Point(415, 25)
        Me.BtnExportImage_BrowseSource.Name = "BtnExportImage_BrowseSource"
        Me.BtnExportImage_BrowseSource.Size = New System.Drawing.Size(92, 29)
        Me.BtnExportImage_BrowseSource.TabIndex = 55
        Me.BtnExportImage_BrowseSource.Text = "Browse..."
        Me.BtnExportImage_BrowseSource.UseVisualStyleBackColor = True
        '
        'LblExportImage_Size
        '
        Me.LblExportImage_Size.AutoSize = True
        Me.LblExportImage_Size.Location = New System.Drawing.Point(18, 216)
        Me.LblExportImage_Size.Name = "LblExportImage_Size"
        Me.LblExportImage_Size.Size = New System.Drawing.Size(44, 20)
        Me.LblExportImage_Size.TabIndex = 54
        Me.LblExportImage_Size.Text = "Size:"
        '
        'TxtBoxExportImage_Size
        '
        Me.TxtBoxExportImage_Size.Location = New System.Drawing.Point(114, 213)
        Me.TxtBoxExportImage_Size.Name = "TxtBoxExportImage_Size"
        Me.TxtBoxExportImage_Size.Size = New System.Drawing.Size(295, 26)
        Me.TxtBoxExportImage_Size.TabIndex = 49
        '
        'LblExportImage_Description
        '
        Me.LblExportImage_Description.AutoSize = True
        Me.LblExportImage_Description.Location = New System.Drawing.Point(18, 184)
        Me.LblExportImage_Description.Name = "LblExportImage_Description"
        Me.LblExportImage_Description.Size = New System.Drawing.Size(93, 20)
        Me.LblExportImage_Description.TabIndex = 53
        Me.LblExportImage_Description.Text = "Description:"
        '
        'LblExportImage_Name
        '
        Me.LblExportImage_Name.AutoSize = True
        Me.LblExportImage_Name.Location = New System.Drawing.Point(18, 152)
        Me.LblExportImage_Name.Name = "LblExportImage_Name"
        Me.LblExportImage_Name.Size = New System.Drawing.Size(55, 20)
        Me.LblExportImage_Name.TabIndex = 52
        Me.LblExportImage_Name.Text = "Name:"
        '
        'TxtBoxExportImage_Description
        '
        Me.TxtBoxExportImage_Description.Location = New System.Drawing.Point(114, 181)
        Me.TxtBoxExportImage_Description.Name = "TxtBoxExportImage_Description"
        Me.TxtBoxExportImage_Description.Size = New System.Drawing.Size(295, 26)
        Me.TxtBoxExportImage_Description.TabIndex = 51
        '
        'TxtBoxExportImage_Name
        '
        Me.TxtBoxExportImage_Name.Location = New System.Drawing.Point(114, 149)
        Me.TxtBoxExportImage_Name.Name = "TxtBoxExportImage_Name"
        Me.TxtBoxExportImage_Name.Size = New System.Drawing.Size(295, 26)
        Me.TxtBoxExportImage_Name.TabIndex = 50
        '
        'LblExportImage_Filename
        '
        Me.LblExportImage_Filename.AutoSize = True
        Me.LblExportImage_Filename.Location = New System.Drawing.Point(18, 101)
        Me.LblExportImage_Filename.Name = "LblExportImage_Filename"
        Me.LblExportImage_Filename.Size = New System.Drawing.Size(78, 20)
        Me.LblExportImage_Filename.TabIndex = 48
        Me.LblExportImage_Filename.Text = "Filename:"
        '
        'TxtBoxExportImage_Filename
        '
        Me.TxtBoxExportImage_Filename.Location = New System.Drawing.Point(114, 98)
        Me.TxtBoxExportImage_Filename.Name = "TxtBoxExportImage_Filename"
        Me.TxtBoxExportImage_Filename.Size = New System.Drawing.Size(295, 26)
        Me.TxtBoxExportImage_Filename.TabIndex = 43
        '
        'LblExportImage_Destination
        '
        Me.LblExportImage_Destination.AutoSize = True
        Me.LblExportImage_Destination.Location = New System.Drawing.Point(18, 67)
        Me.LblExportImage_Destination.Name = "LblExportImage_Destination"
        Me.LblExportImage_Destination.Size = New System.Drawing.Size(94, 20)
        Me.LblExportImage_Destination.TabIndex = 47
        Me.LblExportImage_Destination.Text = "Destination:"
        '
        'LblExportImage_Source
        '
        Me.LblExportImage_Source.AutoSize = True
        Me.LblExportImage_Source.Location = New System.Drawing.Point(18, 31)
        Me.LblExportImage_Source.Name = "LblExportImage_Source"
        Me.LblExportImage_Source.Size = New System.Drawing.Size(64, 20)
        Me.LblExportImage_Source.TabIndex = 46
        Me.LblExportImage_Source.Text = "Source:"
        '
        'TxtBoxExportImage_Destination
        '
        Me.TxtBoxExportImage_Destination.Location = New System.Drawing.Point(114, 64)
        Me.TxtBoxExportImage_Destination.Name = "TxtBoxExportImage_Destination"
        Me.TxtBoxExportImage_Destination.Size = New System.Drawing.Size(295, 26)
        Me.TxtBoxExportImage_Destination.TabIndex = 45
        '
        'TxtBoxExportImage_Source
        '
        Me.TxtBoxExportImage_Source.Location = New System.Drawing.Point(114, 28)
        Me.TxtBoxExportImage_Source.Name = "TxtBoxExportImage_Source"
        Me.TxtBoxExportImage_Source.Size = New System.Drawing.Size(295, 26)
        Me.TxtBoxExportImage_Source.TabIndex = 44
        '
        'TabPage11
        '
        Me.TabPage11.Controls.Add(Me.ChkBoxLangAndInterServ_Online)
        Me.TabPage11.Controls.Add(Me.BtnLangAndInterServ_ApplyDistribution)
        Me.TabPage11.Controls.Add(Me.BtnLangAndInterServ_ApplySetupUILang)
        Me.TabPage11.Controls.Add(Me.BtnLangAndInterServ_ApplyGenLangINI)
        Me.TabPage11.Controls.Add(Me.BtnLangAndInterServ_ApplySKUIntlDefaults)
        Me.TabPage11.Controls.Add(Me.CmbBoxLangAndInterServ_Distribution)
        Me.TabPage11.Controls.Add(Me.LblLangAndInterServ_Distribution)
        Me.TabPage11.Controls.Add(Me.CmbBoxLangAndInterServ_SetSetupUILang)
        Me.TabPage11.Controls.Add(Me.LblLangAndInterServ_SetupUILang)
        Me.TabPage11.Controls.Add(Me.CmbBoxLangAndInterServ_GenLanINI)
        Me.TabPage11.Controls.Add(Me.Button9)
        Me.TabPage11.Controls.Add(Me.LblLangAndInterServ_GenLanINI)
        Me.TabPage11.Controls.Add(Me.CmbBoxLangAndInterServ_SetSKUIntlDefaults)
        Me.TabPage11.Controls.Add(Me.Button8)
        Me.TabPage11.Controls.Add(Me.LblLangAndInterServ_SetSKUIntlDefaults)
        Me.TabPage11.Controls.Add(Me.CmbBoxLangAndInterServ_SetTimeZone)
        Me.TabPage11.Controls.Add(Me.BtnLangAndInterServ_ApplyTimeZone)
        Me.TabPage11.Controls.Add(Me.LblLangAndInterServ_SetTimeZone)
        Me.TabPage11.Controls.Add(Me.CmbBoxLangAndInterServ_SetInputLocal)
        Me.TabPage11.Controls.Add(Me.BtnLangAndInterServ_ApplyInputLocale)
        Me.TabPage11.Controls.Add(Me.LblLangAndInterServ_SetInputLocale)
        Me.TabPage11.Controls.Add(Me.CmbBoxLangAndInterServ_SetUserLocale)
        Me.TabPage11.Controls.Add(Me.BtnLangAndInterServ_ApplyUserLocale)
        Me.TabPage11.Controls.Add(Me.LblLangAndInterServ_SetUserLocale)
        Me.TabPage11.Controls.Add(Me.CmbBoxLangAndInterServ_SetUILang_SysLocale)
        Me.TabPage11.Controls.Add(Me.BtnLangAndInterServ_ApplySysLocale)
        Me.TabPage11.Controls.Add(Me.LblLangAndInterServ_SetSysLocale)
        Me.TabPage11.Controls.Add(Me.CmbBoxLangAndInterServ_SetSysUILang)
        Me.TabPage11.Controls.Add(Me.BtnLangAndInterServ_ApplySysUILang)
        Me.TabPage11.Controls.Add(Me.LblLangAndInterServ_SetSysUILang)
        Me.TabPage11.Controls.Add(Me.CmbBoxLangAndInterServ_SetUILangFallback)
        Me.TabPage11.Controls.Add(Me.BtnLangAndInterServ_ApplyUILangFallback)
        Me.TabPage11.Controls.Add(Me.LblLangAndInterServ_SetUILangFallback)
        Me.TabPage11.Controls.Add(Me.CmbBoxLangAndInterServ_SetUILang)
        Me.TabPage11.Controls.Add(Me.BtnLangAndInterServ_ApplyUILang)
        Me.TabPage11.Controls.Add(Me.LblLangAndInterServ_SetUILang)
        Me.TabPage11.Controls.Add(Me.CmbBoxLangAndInterServ_SetAllIntl)
        Me.TabPage11.Controls.Add(Me.BtnLangAndInterServ_ApplyAllIntl)
        Me.TabPage11.Controls.Add(Me.LblLangAndInterServ_SetAllIntl)
        Me.TabPage11.Controls.Add(Me.BtnSetLanguage_DisplayInfo)
        Me.TabPage11.Controls.Add(Me.Label25)
        Me.TabPage11.Location = New System.Drawing.Point(4, 29)
        Me.TabPage11.Name = "TabPage11"
        Me.TabPage11.Size = New System.Drawing.Size(886, 350)
        Me.TabPage11.TabIndex = 10
        Me.TabPage11.Text = "Languages And International Servicing"
        Me.TabPage11.UseVisualStyleBackColor = True
        '
        'ChkBoxLangAndInterServ_Online
        '
        Me.ChkBoxLangAndInterServ_Online.AutoSize = True
        Me.ChkBoxLangAndInterServ_Online.Location = New System.Drawing.Point(758, 323)
        Me.ChkBoxLangAndInterServ_Online.Name = "ChkBoxLangAndInterServ_Online"
        Me.ChkBoxLangAndInterServ_Online.Size = New System.Drawing.Size(125, 24)
        Me.ChkBoxLangAndInterServ_Online.TabIndex = 46
        Me.ChkBoxLangAndInterServ_Online.Text = "/Online option"
        Me.ChkBoxLangAndInterServ_Online.UseVisualStyleBackColor = False
        '
        'BtnLangAndInterServ_ApplyDistribution
        '
        Me.BtnLangAndInterServ_ApplyDistribution.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnLangAndInterServ_ApplyDistribution.Location = New System.Drawing.Point(788, 173)
        Me.BtnLangAndInterServ_ApplyDistribution.Name = "BtnLangAndInterServ_ApplyDistribution"
        Me.BtnLangAndInterServ_ApplyDistribution.Size = New System.Drawing.Size(56, 28)
        Me.BtnLangAndInterServ_ApplyDistribution.TabIndex = 45
        Me.BtnLangAndInterServ_ApplyDistribution.Text = "Apply"
        Me.BtnLangAndInterServ_ApplyDistribution.UseVisualStyleBackColor = True
        '
        'BtnLangAndInterServ_ApplySetupUILang
        '
        Me.BtnLangAndInterServ_ApplySetupUILang.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnLangAndInterServ_ApplySetupUILang.Location = New System.Drawing.Point(788, 139)
        Me.BtnLangAndInterServ_ApplySetupUILang.Name = "BtnLangAndInterServ_ApplySetupUILang"
        Me.BtnLangAndInterServ_ApplySetupUILang.Size = New System.Drawing.Size(56, 28)
        Me.BtnLangAndInterServ_ApplySetupUILang.TabIndex = 44
        Me.BtnLangAndInterServ_ApplySetupUILang.Text = "Apply"
        Me.BtnLangAndInterServ_ApplySetupUILang.UseVisualStyleBackColor = True
        '
        'BtnLangAndInterServ_ApplyGenLangINI
        '
        Me.BtnLangAndInterServ_ApplyGenLangINI.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnLangAndInterServ_ApplyGenLangINI.Location = New System.Drawing.Point(788, 101)
        Me.BtnLangAndInterServ_ApplyGenLangINI.Name = "BtnLangAndInterServ_ApplyGenLangINI"
        Me.BtnLangAndInterServ_ApplyGenLangINI.Size = New System.Drawing.Size(56, 28)
        Me.BtnLangAndInterServ_ApplyGenLangINI.TabIndex = 43
        Me.BtnLangAndInterServ_ApplyGenLangINI.Text = "Apply"
        Me.BtnLangAndInterServ_ApplyGenLangINI.UseVisualStyleBackColor = True
        '
        'BtnLangAndInterServ_ApplySKUIntlDefaults
        '
        Me.BtnLangAndInterServ_ApplySKUIntlDefaults.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnLangAndInterServ_ApplySKUIntlDefaults.Location = New System.Drawing.Point(788, 67)
        Me.BtnLangAndInterServ_ApplySKUIntlDefaults.Name = "BtnLangAndInterServ_ApplySKUIntlDefaults"
        Me.BtnLangAndInterServ_ApplySKUIntlDefaults.Size = New System.Drawing.Size(56, 28)
        Me.BtnLangAndInterServ_ApplySKUIntlDefaults.TabIndex = 42
        Me.BtnLangAndInterServ_ApplySKUIntlDefaults.Text = "Apply"
        Me.BtnLangAndInterServ_ApplySKUIntlDefaults.UseVisualStyleBackColor = True
        '
        'CmbBoxLangAndInterServ_Distribution
        '
        Me.CmbBoxLangAndInterServ_Distribution.AutoCompleteCustomSource.AddRange(New String() {"bg-bg", "cs-cz", "da-dk", "de-de", "el-gr", "en-gb", "en-us", "es-es", "es-mx", "et-ee", "fi-fi", "fr-ca", "fr-fr", "hr-hr", "hu-hu", "it-it", "ja-jp", "ko-kr", "lt-lt", "lv-lv", "nb-no", "nl-nl", "pl-pl", "pt-br", "pt-pt", "ro-ro", "ru-ru", "sk-sk", "sl-si", "sr-latn-rs", "sv-se", "tr-tr", "uk-ua", "zh-cn", "zh-tw"})
        Me.CmbBoxLangAndInterServ_Distribution.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CmbBoxLangAndInterServ_Distribution.FormattingEnabled = True
        Me.CmbBoxLangAndInterServ_Distribution.Items.AddRange(New Object() {"bg-bg", "cs-cz", "da-dk", "de-de", "el-gr", "en-gb", "en-us", "es-es", "es-mx", "et-ee", "fi-fi", "fr-ca", "fr-fr", "hr-hr", "hu-hu", "it-it", "ja-jp", "ko-kr", "lt-lt", "lv-lv", "nb-no", "nl-nl", "pl-pl", "pt-br", "pt-pt", "ro-ro", "ru-ru", "sk-sk", "sl-si", "sr-latn-rs", "sv-se", "tr-tr", "uk-ua", "zh-cn", "zh-tw"})
        Me.CmbBoxLangAndInterServ_Distribution.Location = New System.Drawing.Point(592, 173)
        Me.CmbBoxLangAndInterServ_Distribution.Name = "CmbBoxLangAndInterServ_Distribution"
        Me.CmbBoxLangAndInterServ_Distribution.Size = New System.Drawing.Size(190, 28)
        Me.CmbBoxLangAndInterServ_Distribution.TabIndex = 41
        '
        'LblLangAndInterServ_Distribution
        '
        Me.LblLangAndInterServ_Distribution.AutoSize = True
        Me.LblLangAndInterServ_Distribution.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblLangAndInterServ_Distribution.Location = New System.Drawing.Point(428, 176)
        Me.LblLangAndInterServ_Distribution.Name = "LblLangAndInterServ_Distribution"
        Me.LblLangAndInterServ_Distribution.Size = New System.Drawing.Size(97, 20)
        Me.LblLangAndInterServ_Distribution.TabIndex = 40
        Me.LblLangAndInterServ_Distribution.Text = "/Distribution:"
        '
        'CmbBoxLangAndInterServ_SetSetupUILang
        '
        Me.CmbBoxLangAndInterServ_SetSetupUILang.AutoCompleteCustomSource.AddRange(New String() {"bg-bg", "cs-cz", "da-dk", "de-de", "el-gr", "en-gb", "en-us", "es-es", "es-mx", "et-ee", "fi-fi", "fr-ca", "fr-fr", "hr-hr", "hu-hu", "it-it", "ja-jp", "ko-kr", "lt-lt", "lv-lv", "nb-no", "nl-nl", "pl-pl", "pt-br", "pt-pt", "ro-ro", "ru-ru", "sk-sk", "sl-si", "sr-latn-rs", "sv-se", "tr-tr", "uk-ua", "zh-cn", "zh-tw"})
        Me.CmbBoxLangAndInterServ_SetSetupUILang.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CmbBoxLangAndInterServ_SetSetupUILang.FormattingEnabled = True
        Me.CmbBoxLangAndInterServ_SetSetupUILang.Items.AddRange(New Object() {"bg-bg", "cs-cz", "da-dk", "de-de", "el-gr", "en-gb", "en-us", "es-es", "es-mx", "et-ee", "fi-fi", "fr-ca", "fr-fr", "hr-hr", "hu-hu", "it-it", "ja-jp", "ko-kr", "lt-lt", "lv-lv", "nb-no", "nl-nl", "pl-pl", "pt-br", "pt-pt", "ro-ro", "ru-ru", "sk-sk", "sl-si", "sr-latn-rs", "sv-se", "tr-tr", "uk-ua", "zh-cn", "zh-tw"})
        Me.CmbBoxLangAndInterServ_SetSetupUILang.Location = New System.Drawing.Point(592, 139)
        Me.CmbBoxLangAndInterServ_SetSetupUILang.Name = "CmbBoxLangAndInterServ_SetSetupUILang"
        Me.CmbBoxLangAndInterServ_SetSetupUILang.Size = New System.Drawing.Size(190, 28)
        Me.CmbBoxLangAndInterServ_SetSetupUILang.TabIndex = 39
        '
        'LblLangAndInterServ_SetupUILang
        '
        Me.LblLangAndInterServ_SetupUILang.AutoSize = True
        Me.LblLangAndInterServ_SetupUILang.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblLangAndInterServ_SetupUILang.Location = New System.Drawing.Point(428, 142)
        Me.LblLangAndInterServ_SetupUILang.Name = "LblLangAndInterServ_SetupUILang"
        Me.LblLangAndInterServ_SetupUILang.Size = New System.Drawing.Size(143, 20)
        Me.LblLangAndInterServ_SetupUILang.TabIndex = 38
        Me.LblLangAndInterServ_SetupUILang.Text = "/Set-SetupUILang:"
        '
        'CmbBoxLangAndInterServ_GenLanINI
        '
        Me.CmbBoxLangAndInterServ_GenLanINI.AutoCompleteCustomSource.AddRange(New String() {"bg-bg", "cs-cz", "da-dk", "de-de", "el-gr", "en-gb", "en-us", "es-es", "es-mx", "et-ee", "fi-fi", "fr-ca", "fr-fr", "hr-hr", "hu-hu", "it-it", "ja-jp", "ko-kr", "lt-lt", "lv-lv", "nb-no", "nl-nl", "pl-pl", "pt-br", "pt-pt", "ro-ro", "ru-ru", "sk-sk", "sl-si", "sr-latn-rs", "sv-se", "tr-tr", "uk-ua", "zh-cn", "zh-tw"})
        Me.CmbBoxLangAndInterServ_GenLanINI.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CmbBoxLangAndInterServ_GenLanINI.FormattingEnabled = True
        Me.CmbBoxLangAndInterServ_GenLanINI.Items.AddRange(New Object() {"bg-bg", "cs-cz", "da-dk", "de-de", "el-gr", "en-gb", "en-us", "es-es", "es-mx", "et-ee", "fi-fi", "fr-ca", "fr-fr", "hr-hr", "hu-hu", "it-it", "ja-jp", "ko-kr", "lt-lt", "lv-lv", "nb-no", "nl-nl", "pl-pl", "pt-br", "pt-pt", "ro-ro", "ru-ru", "sk-sk", "sl-si", "sr-latn-rs", "sv-se", "tr-tr", "uk-ua", "zh-cn", "zh-tw"})
        Me.CmbBoxLangAndInterServ_GenLanINI.Location = New System.Drawing.Point(592, 102)
        Me.CmbBoxLangAndInterServ_GenLanINI.Name = "CmbBoxLangAndInterServ_GenLanINI"
        Me.CmbBoxLangAndInterServ_GenLanINI.Size = New System.Drawing.Size(190, 28)
        Me.CmbBoxLangAndInterServ_GenLanINI.TabIndex = 37
        '
        'Button9
        '
        Me.Button9.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button9.Location = New System.Drawing.Point(895, 99)
        Me.Button9.Name = "Button9"
        Me.Button9.Size = New System.Drawing.Size(97, 28)
        Me.Button9.TabIndex = 36
        Me.Button9.Text = "Apply"
        Me.Button9.UseVisualStyleBackColor = True
        '
        'LblLangAndInterServ_GenLanINI
        '
        Me.LblLangAndInterServ_GenLanINI.AutoSize = True
        Me.LblLangAndInterServ_GenLanINI.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblLangAndInterServ_GenLanINI.Location = New System.Drawing.Point(428, 105)
        Me.LblLangAndInterServ_GenLanINI.Name = "LblLangAndInterServ_GenLanINI"
        Me.LblLangAndInterServ_GenLanINI.Size = New System.Drawing.Size(110, 20)
        Me.LblLangAndInterServ_GenLanINI.TabIndex = 35
        Me.LblLangAndInterServ_GenLanINI.Text = "/Gen-LangINI:"
        '
        'CmbBoxLangAndInterServ_SetSKUIntlDefaults
        '
        Me.CmbBoxLangAndInterServ_SetSKUIntlDefaults.AutoCompleteCustomSource.AddRange(New String() {"bg-bg", "cs-cz", "da-dk", "de-de", "el-gr", "en-gb", "en-us", "es-es", "es-mx", "et-ee", "fi-fi", "fr-ca", "fr-fr", "hr-hr", "hu-hu", "it-it", "ja-jp", "ko-kr", "lt-lt", "lv-lv", "nb-no", "nl-nl", "pl-pl", "pt-br", "pt-pt", "ro-ro", "ru-ru", "sk-sk", "sl-si", "sr-latn-rs", "sv-se", "tr-tr", "uk-ua", "zh-cn", "zh-tw"})
        Me.CmbBoxLangAndInterServ_SetSKUIntlDefaults.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CmbBoxLangAndInterServ_SetSKUIntlDefaults.FormattingEnabled = True
        Me.CmbBoxLangAndInterServ_SetSKUIntlDefaults.Items.AddRange(New Object() {"bg-bg", "cs-cz", "da-dk", "de-de", "el-gr", "en-gb", "en-us", "es-es", "es-mx", "et-ee", "fi-fi", "fr-ca", "fr-fr", "hr-hr", "hu-hu", "it-it", "ja-jp", "ko-kr", "lt-lt", "lv-lv", "nb-no", "nl-nl", "pl-pl", "pt-br", "pt-pt", "ro-ro", "ru-ru", "sk-sk", "sl-si", "sr-latn-rs", "sv-se", "tr-tr", "uk-ua", "zh-cn", "zh-tw"})
        Me.CmbBoxLangAndInterServ_SetSKUIntlDefaults.Location = New System.Drawing.Point(592, 68)
        Me.CmbBoxLangAndInterServ_SetSKUIntlDefaults.Name = "CmbBoxLangAndInterServ_SetSKUIntlDefaults"
        Me.CmbBoxLangAndInterServ_SetSKUIntlDefaults.Size = New System.Drawing.Size(190, 28)
        Me.CmbBoxLangAndInterServ_SetSKUIntlDefaults.TabIndex = 34
        '
        'Button8
        '
        Me.Button8.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button8.Location = New System.Drawing.Point(895, 65)
        Me.Button8.Name = "Button8"
        Me.Button8.Size = New System.Drawing.Size(97, 28)
        Me.Button8.TabIndex = 33
        Me.Button8.Text = "Apply"
        Me.Button8.UseVisualStyleBackColor = True
        '
        'LblLangAndInterServ_SetSKUIntlDefaults
        '
        Me.LblLangAndInterServ_SetSKUIntlDefaults.AutoSize = True
        Me.LblLangAndInterServ_SetSKUIntlDefaults.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblLangAndInterServ_SetSKUIntlDefaults.Location = New System.Drawing.Point(428, 71)
        Me.LblLangAndInterServ_SetSKUIntlDefaults.Name = "LblLangAndInterServ_SetSKUIntlDefaults"
        Me.LblLangAndInterServ_SetSKUIntlDefaults.Size = New System.Drawing.Size(162, 20)
        Me.LblLangAndInterServ_SetSKUIntlDefaults.TabIndex = 32
        Me.LblLangAndInterServ_SetSKUIntlDefaults.Text = "/Set-SKUIntlDefaults:"
        '
        'CmbBoxLangAndInterServ_SetTimeZone
        '
        Me.CmbBoxLangAndInterServ_SetTimeZone.AutoCompleteCustomSource.AddRange(New String() {"bg-bg", "cs-cz", "da-dk", "de-de", "el-gr", "en-gb", "en-us", "es-es", "es-mx", "et-ee", "fi-fi", "fr-ca", "fr-fr", "hr-hr", "hu-hu", "it-it", "ja-jp", "ko-kr", "lt-lt", "lv-lv", "nb-no", "nl-nl", "pl-pl", "pt-br", "pt-pt", "ro-ro", "ru-ru", "sk-sk", "sl-si", "sr-latn-rs", "sv-se", "tr-tr", "uk-ua", "zh-cn", "zh-tw"})
        Me.CmbBoxLangAndInterServ_SetTimeZone.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CmbBoxLangAndInterServ_SetTimeZone.FormattingEnabled = True
        Me.CmbBoxLangAndInterServ_SetTimeZone.Items.AddRange(New Object() {"bg-bg", "cs-cz", "da-dk", "de-de", "el-gr", "en-gb", "en-us", "es-es", "es-mx", "et-ee", "fi-fi", "fr-ca", "fr-fr", "hr-hr", "hu-hu", "it-it", "ja-jp", "ko-kr", "lt-lt", "lv-lv", "nb-no", "nl-nl", "pl-pl", "pt-br", "pt-pt", "ro-ro", "ru-ru", "sk-sk", "sl-si", "sr-latn-rs", "sv-se", "tr-tr", "uk-ua", "zh-cn", "zh-tw"})
        Me.CmbBoxLangAndInterServ_SetTimeZone.Location = New System.Drawing.Point(160, 303)
        Me.CmbBoxLangAndInterServ_SetTimeZone.Name = "CmbBoxLangAndInterServ_SetTimeZone"
        Me.CmbBoxLangAndInterServ_SetTimeZone.Size = New System.Drawing.Size(190, 28)
        Me.CmbBoxLangAndInterServ_SetTimeZone.TabIndex = 31
        '
        'BtnLangAndInterServ_ApplyTimeZone
        '
        Me.BtnLangAndInterServ_ApplyTimeZone.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnLangAndInterServ_ApplyTimeZone.Location = New System.Drawing.Point(356, 303)
        Me.BtnLangAndInterServ_ApplyTimeZone.Name = "BtnLangAndInterServ_ApplyTimeZone"
        Me.BtnLangAndInterServ_ApplyTimeZone.Size = New System.Drawing.Size(56, 28)
        Me.BtnLangAndInterServ_ApplyTimeZone.TabIndex = 30
        Me.BtnLangAndInterServ_ApplyTimeZone.Text = "Apply"
        Me.BtnLangAndInterServ_ApplyTimeZone.UseVisualStyleBackColor = True
        '
        'LblLangAndInterServ_SetTimeZone
        '
        Me.LblLangAndInterServ_SetTimeZone.AutoSize = True
        Me.LblLangAndInterServ_SetTimeZone.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblLangAndInterServ_SetTimeZone.Location = New System.Drawing.Point(5, 306)
        Me.LblLangAndInterServ_SetTimeZone.Name = "LblLangAndInterServ_SetTimeZone"
        Me.LblLangAndInterServ_SetTimeZone.Size = New System.Drawing.Size(118, 20)
        Me.LblLangAndInterServ_SetTimeZone.TabIndex = 29
        Me.LblLangAndInterServ_SetTimeZone.Text = "/Set-TimeZone:"
        '
        'CmbBoxLangAndInterServ_SetInputLocal
        '
        Me.CmbBoxLangAndInterServ_SetInputLocal.AutoCompleteCustomSource.AddRange(New String() {"bg-bg", "cs-cz", "da-dk", "de-de", "el-gr", "en-gb", "en-us", "es-es", "es-mx", "et-ee", "fi-fi", "fr-ca", "fr-fr", "hr-hr", "hu-hu", "it-it", "ja-jp", "ko-kr", "lt-lt", "lv-lv", "nb-no", "nl-nl", "pl-pl", "pt-br", "pt-pt", "ro-ro", "ru-ru", "sk-sk", "sl-si", "sr-latn-rs", "sv-se", "tr-tr", "uk-ua", "zh-cn", "zh-tw"})
        Me.CmbBoxLangAndInterServ_SetInputLocal.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CmbBoxLangAndInterServ_SetInputLocal.FormattingEnabled = True
        Me.CmbBoxLangAndInterServ_SetInputLocal.Items.AddRange(New Object() {"bg-bg", "cs-cz", "da-dk", "de-de", "el-gr", "en-gb", "en-us", "es-es", "es-mx", "et-ee", "fi-fi", "fr-ca", "fr-fr", "hr-hr", "hu-hu", "it-it", "ja-jp", "ko-kr", "lt-lt", "lv-lv", "nb-no", "nl-nl", "pl-pl", "pt-br", "pt-pt", "ro-ro", "ru-ru", "sk-sk", "sl-si", "sr-latn-rs", "sv-se", "tr-tr", "uk-ua", "zh-cn", "zh-tw"})
        Me.CmbBoxLangAndInterServ_SetInputLocal.Location = New System.Drawing.Point(160, 235)
        Me.CmbBoxLangAndInterServ_SetInputLocal.Name = "CmbBoxLangAndInterServ_SetInputLocal"
        Me.CmbBoxLangAndInterServ_SetInputLocal.Size = New System.Drawing.Size(190, 28)
        Me.CmbBoxLangAndInterServ_SetInputLocal.TabIndex = 28
        '
        'BtnLangAndInterServ_ApplyInputLocale
        '
        Me.BtnLangAndInterServ_ApplyInputLocale.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnLangAndInterServ_ApplyInputLocale.Location = New System.Drawing.Point(356, 235)
        Me.BtnLangAndInterServ_ApplyInputLocale.Name = "BtnLangAndInterServ_ApplyInputLocale"
        Me.BtnLangAndInterServ_ApplyInputLocale.Size = New System.Drawing.Size(56, 28)
        Me.BtnLangAndInterServ_ApplyInputLocale.TabIndex = 27
        Me.BtnLangAndInterServ_ApplyInputLocale.Text = "Apply"
        Me.BtnLangAndInterServ_ApplyInputLocale.UseVisualStyleBackColor = True
        '
        'LblLangAndInterServ_SetInputLocale
        '
        Me.LblLangAndInterServ_SetInputLocale.AutoSize = True
        Me.LblLangAndInterServ_SetInputLocale.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblLangAndInterServ_SetInputLocale.Location = New System.Drawing.Point(5, 238)
        Me.LblLangAndInterServ_SetInputLocale.Name = "LblLangAndInterServ_SetInputLocale"
        Me.LblLangAndInterServ_SetInputLocale.Size = New System.Drawing.Size(131, 20)
        Me.LblLangAndInterServ_SetInputLocale.TabIndex = 26
        Me.LblLangAndInterServ_SetInputLocale.Text = "/Set-InputLocale:"
        '
        'CmbBoxLangAndInterServ_SetUserLocale
        '
        Me.CmbBoxLangAndInterServ_SetUserLocale.AutoCompleteCustomSource.AddRange(New String() {"bg-bg", "cs-cz", "da-dk", "de-de", "el-gr", "en-gb", "en-us", "es-es", "es-mx", "et-ee", "fi-fi", "fr-ca", "fr-fr", "hr-hr", "hu-hu", "it-it", "ja-jp", "ko-kr", "lt-lt", "lv-lv", "nb-no", "nl-nl", "pl-pl", "pt-br", "pt-pt", "ro-ro", "ru-ru", "sk-sk", "sl-si", "sr-latn-rs", "sv-se", "tr-tr", "uk-ua", "zh-cn", "zh-tw"})
        Me.CmbBoxLangAndInterServ_SetUserLocale.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CmbBoxLangAndInterServ_SetUserLocale.FormattingEnabled = True
        Me.CmbBoxLangAndInterServ_SetUserLocale.Items.AddRange(New Object() {"bg-bg", "cs-cz", "da-dk", "de-de", "el-gr", "en-gb", "en-us", "es-es", "es-mx", "et-ee", "fi-fi", "fr-ca", "fr-fr", "hr-hr", "hu-hu", "it-it", "ja-jp", "ko-kr", "lt-lt", "lv-lv", "nb-no", "nl-nl", "pl-pl", "pt-br", "pt-pt", "ro-ro", "ru-ru", "sk-sk", "sl-si", "sr-latn-rs", "sv-se", "tr-tr", "uk-ua", "zh-cn", "zh-tw"})
        Me.CmbBoxLangAndInterServ_SetUserLocale.Location = New System.Drawing.Point(160, 201)
        Me.CmbBoxLangAndInterServ_SetUserLocale.Name = "CmbBoxLangAndInterServ_SetUserLocale"
        Me.CmbBoxLangAndInterServ_SetUserLocale.Size = New System.Drawing.Size(97, 28)
        Me.CmbBoxLangAndInterServ_SetUserLocale.TabIndex = 25
        '
        'BtnLangAndInterServ_ApplyUserLocale
        '
        Me.BtnLangAndInterServ_ApplyUserLocale.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnLangAndInterServ_ApplyUserLocale.Location = New System.Drawing.Point(263, 201)
        Me.BtnLangAndInterServ_ApplyUserLocale.Name = "BtnLangAndInterServ_ApplyUserLocale"
        Me.BtnLangAndInterServ_ApplyUserLocale.Size = New System.Drawing.Size(56, 28)
        Me.BtnLangAndInterServ_ApplyUserLocale.TabIndex = 24
        Me.BtnLangAndInterServ_ApplyUserLocale.Text = "Apply"
        Me.BtnLangAndInterServ_ApplyUserLocale.UseVisualStyleBackColor = True
        '
        'LblLangAndInterServ_SetUserLocale
        '
        Me.LblLangAndInterServ_SetUserLocale.AutoSize = True
        Me.LblLangAndInterServ_SetUserLocale.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblLangAndInterServ_SetUserLocale.Location = New System.Drawing.Point(5, 204)
        Me.LblLangAndInterServ_SetUserLocale.Name = "LblLangAndInterServ_SetUserLocale"
        Me.LblLangAndInterServ_SetUserLocale.Size = New System.Drawing.Size(128, 20)
        Me.LblLangAndInterServ_SetUserLocale.TabIndex = 23
        Me.LblLangAndInterServ_SetUserLocale.Text = "/Set-UserLocale:"
        '
        'CmbBoxLangAndInterServ_SetUILang_SysLocale
        '
        Me.CmbBoxLangAndInterServ_SetUILang_SysLocale.AutoCompleteCustomSource.AddRange(New String() {"bg-bg", "cs-cz", "da-dk", "de-de", "el-gr", "en-gb", "en-us", "es-es", "es-mx", "et-ee", "fi-fi", "fr-ca", "fr-fr", "hr-hr", "hu-hu", "it-it", "ja-jp", "ko-kr", "lt-lt", "lv-lv", "nb-no", "nl-nl", "pl-pl", "pt-br", "pt-pt", "ro-ro", "ru-ru", "sk-sk", "sl-si", "sr-latn-rs", "sv-se", "tr-tr", "uk-ua", "zh-cn", "zh-tw"})
        Me.CmbBoxLangAndInterServ_SetUILang_SysLocale.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CmbBoxLangAndInterServ_SetUILang_SysLocale.FormattingEnabled = True
        Me.CmbBoxLangAndInterServ_SetUILang_SysLocale.Items.AddRange(New Object() {"bg-bg", "cs-cz", "da-dk", "de-de", "el-gr", "en-gb", "en-us", "es-es", "es-mx", "et-ee", "fi-fi", "fr-ca", "fr-fr", "hr-hr", "hu-hu", "it-it", "ja-jp", "ko-kr", "lt-lt", "lv-lv", "nb-no", "nl-nl", "pl-pl", "pt-br", "pt-pt", "ro-ro", "ru-ru", "sk-sk", "sl-si", "sr-latn-rs", "sv-se", "tr-tr", "uk-ua", "zh-cn", "zh-tw"})
        Me.CmbBoxLangAndInterServ_SetUILang_SysLocale.Location = New System.Drawing.Point(160, 167)
        Me.CmbBoxLangAndInterServ_SetUILang_SysLocale.Name = "CmbBoxLangAndInterServ_SetUILang_SysLocale"
        Me.CmbBoxLangAndInterServ_SetUILang_SysLocale.Size = New System.Drawing.Size(97, 28)
        Me.CmbBoxLangAndInterServ_SetUILang_SysLocale.TabIndex = 22
        '
        'BtnLangAndInterServ_ApplySysLocale
        '
        Me.BtnLangAndInterServ_ApplySysLocale.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnLangAndInterServ_ApplySysLocale.Location = New System.Drawing.Point(263, 168)
        Me.BtnLangAndInterServ_ApplySysLocale.Name = "BtnLangAndInterServ_ApplySysLocale"
        Me.BtnLangAndInterServ_ApplySysLocale.Size = New System.Drawing.Size(56, 28)
        Me.BtnLangAndInterServ_ApplySysLocale.TabIndex = 21
        Me.BtnLangAndInterServ_ApplySysLocale.Text = "Apply"
        Me.BtnLangAndInterServ_ApplySysLocale.UseVisualStyleBackColor = True
        '
        'LblLangAndInterServ_SetSysLocale
        '
        Me.LblLangAndInterServ_SetSysLocale.AutoSize = True
        Me.LblLangAndInterServ_SetSysLocale.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblLangAndInterServ_SetSysLocale.Location = New System.Drawing.Point(5, 170)
        Me.LblLangAndInterServ_SetSysLocale.Name = "LblLangAndInterServ_SetSysLocale"
        Me.LblLangAndInterServ_SetSysLocale.Size = New System.Drawing.Size(120, 20)
        Me.LblLangAndInterServ_SetSysLocale.TabIndex = 20
        Me.LblLangAndInterServ_SetSysLocale.Text = "/Set-SysLocale:"
        '
        'CmbBoxLangAndInterServ_SetSysUILang
        '
        Me.CmbBoxLangAndInterServ_SetSysUILang.AutoCompleteCustomSource.AddRange(New String() {"bg-bg", "cs-cz", "da-dk", "de-de", "el-gr", "en-gb", "en-us", "es-es", "es-mx", "et-ee", "fi-fi", "fr-ca", "fr-fr", "hr-hr", "hu-hu", "it-it", "ja-jp", "ko-kr", "lt-lt", "lv-lv", "nb-no", "nl-nl", "pl-pl", "pt-br", "pt-pt", "ro-ro", "ru-ru", "sk-sk", "sl-si", "sr-latn-rs", "sv-se", "tr-tr", "uk-ua", "zh-cn", "zh-tw"})
        Me.CmbBoxLangAndInterServ_SetSysUILang.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CmbBoxLangAndInterServ_SetSysUILang.FormattingEnabled = True
        Me.CmbBoxLangAndInterServ_SetSysUILang.Items.AddRange(New Object() {"bg-bg", "cs-cz", "da-dk", "de-de", "el-gr", "en-gb", "en-us", "es-es", "es-mx", "et-ee", "fi-fi", "fr-ca", "fr-fr", "hr-hr", "hu-hu", "it-it", "ja-jp", "ko-kr", "lt-lt", "lv-lv", "nb-no", "nl-nl", "pl-pl", "pt-br", "pt-pt", "ro-ro", "ru-ru", "sk-sk", "sl-si", "sr-latn-rs", "sv-se", "tr-tr", "uk-ua", "zh-cn", "zh-tw"})
        Me.CmbBoxLangAndInterServ_SetSysUILang.Location = New System.Drawing.Point(160, 133)
        Me.CmbBoxLangAndInterServ_SetSysUILang.Name = "CmbBoxLangAndInterServ_SetSysUILang"
        Me.CmbBoxLangAndInterServ_SetSysUILang.Size = New System.Drawing.Size(97, 28)
        Me.CmbBoxLangAndInterServ_SetSysUILang.TabIndex = 19
        '
        'BtnLangAndInterServ_ApplySysUILang
        '
        Me.BtnLangAndInterServ_ApplySysUILang.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnLangAndInterServ_ApplySysUILang.Location = New System.Drawing.Point(263, 132)
        Me.BtnLangAndInterServ_ApplySysUILang.Name = "BtnLangAndInterServ_ApplySysUILang"
        Me.BtnLangAndInterServ_ApplySysUILang.Size = New System.Drawing.Size(56, 28)
        Me.BtnLangAndInterServ_ApplySysUILang.TabIndex = 18
        Me.BtnLangAndInterServ_ApplySysUILang.Text = "Apply"
        Me.BtnLangAndInterServ_ApplySysUILang.UseVisualStyleBackColor = True
        '
        'LblLangAndInterServ_SetSysUILang
        '
        Me.LblLangAndInterServ_SetSysUILang.AutoSize = True
        Me.LblLangAndInterServ_SetSysUILang.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblLangAndInterServ_SetSysUILang.Location = New System.Drawing.Point(5, 136)
        Me.LblLangAndInterServ_SetSysUILang.Name = "LblLangAndInterServ_SetSysUILang"
        Me.LblLangAndInterServ_SetSysUILang.Size = New System.Drawing.Size(126, 20)
        Me.LblLangAndInterServ_SetSysUILang.TabIndex = 17
        Me.LblLangAndInterServ_SetSysUILang.Text = "/Set-SysUILang:"
        '
        'CmbBoxLangAndInterServ_SetUILangFallback
        '
        Me.CmbBoxLangAndInterServ_SetUILangFallback.AutoCompleteCustomSource.AddRange(New String() {"bg-bg", "cs-cz", "da-dk", "de-de", "el-gr", "en-gb", "en-us", "es-es", "es-mx", "et-ee", "fi-fi", "fr-ca", "fr-fr", "hr-hr", "hu-hu", "it-it", "ja-jp", "ko-kr", "lt-lt", "lv-lv", "nb-no", "nl-nl", "pl-pl", "pt-br", "pt-pt", "ro-ro", "ru-ru", "sk-sk", "sl-si", "sr-latn-rs", "sv-se", "tr-tr", "uk-ua", "zh-cn", "zh-tw"})
        Me.CmbBoxLangAndInterServ_SetUILangFallback.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CmbBoxLangAndInterServ_SetUILangFallback.FormattingEnabled = True
        Me.CmbBoxLangAndInterServ_SetUILangFallback.Items.AddRange(New Object() {"bg-bg", "cs-cz", "da-dk", "de-de", "el-gr", "en-gb", "en-us", "es-es", "es-mx", "et-ee", "fi-fi", "fr-ca", "fr-fr", "hr-hr", "hu-hu", "it-it", "ja-jp", "ko-kr", "lt-lt", "lv-lv", "nb-no", "nl-nl", "pl-pl", "pt-br", "pt-pt", "ro-ro", "ru-ru", "sk-sk", "sl-si", "sr-latn-rs", "sv-se", "tr-tr", "uk-ua", "zh-cn", "zh-tw"})
        Me.CmbBoxLangAndInterServ_SetUILangFallback.Location = New System.Drawing.Point(160, 99)
        Me.CmbBoxLangAndInterServ_SetUILangFallback.Name = "CmbBoxLangAndInterServ_SetUILangFallback"
        Me.CmbBoxLangAndInterServ_SetUILangFallback.Size = New System.Drawing.Size(97, 28)
        Me.CmbBoxLangAndInterServ_SetUILangFallback.TabIndex = 16
        '
        'BtnLangAndInterServ_ApplyUILangFallback
        '
        Me.BtnLangAndInterServ_ApplyUILangFallback.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnLangAndInterServ_ApplyUILangFallback.Location = New System.Drawing.Point(263, 99)
        Me.BtnLangAndInterServ_ApplyUILangFallback.Name = "BtnLangAndInterServ_ApplyUILangFallback"
        Me.BtnLangAndInterServ_ApplyUILangFallback.Size = New System.Drawing.Size(56, 28)
        Me.BtnLangAndInterServ_ApplyUILangFallback.TabIndex = 15
        Me.BtnLangAndInterServ_ApplyUILangFallback.Text = "Apply"
        Me.BtnLangAndInterServ_ApplyUILangFallback.UseVisualStyleBackColor = True
        '
        'LblLangAndInterServ_SetUILangFallback
        '
        Me.LblLangAndInterServ_SetUILangFallback.AutoSize = True
        Me.LblLangAndInterServ_SetUILangFallback.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblLangAndInterServ_SetUILangFallback.Location = New System.Drawing.Point(5, 102)
        Me.LblLangAndInterServ_SetUILangFallback.Name = "LblLangAndInterServ_SetUILangFallback"
        Me.LblLangAndInterServ_SetUILangFallback.Size = New System.Drawing.Size(159, 20)
        Me.LblLangAndInterServ_SetUILangFallback.TabIndex = 14
        Me.LblLangAndInterServ_SetUILangFallback.Text = "/Set-UILangFallback:"
        '
        'CmbBoxLangAndInterServ_SetUILang
        '
        Me.CmbBoxLangAndInterServ_SetUILang.AutoCompleteCustomSource.AddRange(New String() {"bg-bg", "cs-cz", "da-dk", "de-de", "el-gr", "en-gb", "en-us", "es-es", "es-mx", "et-ee", "fi-fi", "fr-ca", "fr-fr", "hr-hr", "hu-hu", "it-it", "ja-jp", "ko-kr", "lt-lt", "lv-lv", "nb-no", "nl-nl", "pl-pl", "pt-br", "pt-pt", "ro-ro", "ru-ru", "sk-sk", "sl-si", "sr-latn-rs", "sv-se", "tr-tr", "uk-ua", "zh-cn", "zh-tw"})
        Me.CmbBoxLangAndInterServ_SetUILang.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CmbBoxLangAndInterServ_SetUILang.FormattingEnabled = True
        Me.CmbBoxLangAndInterServ_SetUILang.Items.AddRange(New Object() {"bg-bg", "cs-cz", "da-dk", "de-de", "el-gr", "en-gb", "en-us", "es-es", "es-mx", "et-ee", "fi-fi", "fr-ca", "fr-fr", "hr-hr", "hu-hu", "it-it", "ja-jp", "ko-kr", "lt-lt", "lv-lv", "nb-no", "nl-nl", "pl-pl", "pt-br", "pt-pt", "ro-ro", "ru-ru", "sk-sk", "sl-si", "sr-latn-rs", "sv-se", "tr-tr", "uk-ua", "zh-cn", "zh-tw"})
        Me.CmbBoxLangAndInterServ_SetUILang.Location = New System.Drawing.Point(160, 65)
        Me.CmbBoxLangAndInterServ_SetUILang.Name = "CmbBoxLangAndInterServ_SetUILang"
        Me.CmbBoxLangAndInterServ_SetUILang.Size = New System.Drawing.Size(97, 28)
        Me.CmbBoxLangAndInterServ_SetUILang.TabIndex = 13
        '
        'BtnLangAndInterServ_ApplyUILang
        '
        Me.BtnLangAndInterServ_ApplyUILang.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnLangAndInterServ_ApplyUILang.Location = New System.Drawing.Point(263, 64)
        Me.BtnLangAndInterServ_ApplyUILang.Name = "BtnLangAndInterServ_ApplyUILang"
        Me.BtnLangAndInterServ_ApplyUILang.Size = New System.Drawing.Size(56, 28)
        Me.BtnLangAndInterServ_ApplyUILang.TabIndex = 12
        Me.BtnLangAndInterServ_ApplyUILang.Text = "Apply"
        Me.BtnLangAndInterServ_ApplyUILang.UseVisualStyleBackColor = True
        '
        'LblLangAndInterServ_SetUILang
        '
        Me.LblLangAndInterServ_SetUILang.AutoSize = True
        Me.LblLangAndInterServ_SetUILang.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblLangAndInterServ_SetUILang.Location = New System.Drawing.Point(5, 68)
        Me.LblLangAndInterServ_SetUILang.Name = "LblLangAndInterServ_SetUILang"
        Me.LblLangAndInterServ_SetUILang.Size = New System.Drawing.Size(100, 20)
        Me.LblLangAndInterServ_SetUILang.TabIndex = 11
        Me.LblLangAndInterServ_SetUILang.Text = "/Set-UILang:"
        '
        'CmbBoxLangAndInterServ_SetAllIntl
        '
        Me.CmbBoxLangAndInterServ_SetAllIntl.AutoCompleteCustomSource.AddRange(New String() {"bg-bg", "cs-cz", "da-dk", "de-de", "el-gr", "en-gb", "en-us", "es-es", "es-mx", "et-ee", "fi-fi", "fr-ca", "fr-fr", "hr-hr", "hu-hu", "it-it", "ja-jp", "ko-kr", "lt-lt", "lv-lv", "nb-no", "nl-nl", "pl-pl", "pt-br", "pt-pt", "ro-ro", "ru-ru", "sk-sk", "sl-si", "sr-latn-rs", "sv-se", "tr-tr", "uk-ua", "zh-cn", "zh-tw"})
        Me.CmbBoxLangAndInterServ_SetAllIntl.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CmbBoxLangAndInterServ_SetAllIntl.FormattingEnabled = True
        Me.CmbBoxLangAndInterServ_SetAllIntl.Items.AddRange(New Object() {"bg-bg", "cs-cz", "da-dk", "de-de", "el-gr", "en-gb", "en-us", "es-es", "es-mx", "et-ee", "fi-fi", "fr-ca", "fr-fr", "hr-hr", "hu-hu", "it-it", "ja-jp", "ko-kr", "lt-lt", "lv-lv", "nb-no", "nl-nl", "pl-pl", "pt-br", "pt-pt", "ro-ro", "ru-ru", "sk-sk", "sl-si", "sr-latn-rs", "sv-se", "tr-tr", "uk-ua", "zh-cn", "zh-tw"})
        Me.CmbBoxLangAndInterServ_SetAllIntl.Location = New System.Drawing.Point(160, 269)
        Me.CmbBoxLangAndInterServ_SetAllIntl.Name = "CmbBoxLangAndInterServ_SetAllIntl"
        Me.CmbBoxLangAndInterServ_SetAllIntl.Size = New System.Drawing.Size(97, 28)
        Me.CmbBoxLangAndInterServ_SetAllIntl.TabIndex = 10
        '
        'BtnLangAndInterServ_ApplyAllIntl
        '
        Me.BtnLangAndInterServ_ApplyAllIntl.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnLangAndInterServ_ApplyAllIntl.Location = New System.Drawing.Point(263, 268)
        Me.BtnLangAndInterServ_ApplyAllIntl.Name = "BtnLangAndInterServ_ApplyAllIntl"
        Me.BtnLangAndInterServ_ApplyAllIntl.Size = New System.Drawing.Size(56, 28)
        Me.BtnLangAndInterServ_ApplyAllIntl.TabIndex = 9
        Me.BtnLangAndInterServ_ApplyAllIntl.Text = "Apply"
        Me.BtnLangAndInterServ_ApplyAllIntl.UseVisualStyleBackColor = True
        '
        'LblLangAndInterServ_SetAllIntl
        '
        Me.LblLangAndInterServ_SetAllIntl.AutoSize = True
        Me.LblLangAndInterServ_SetAllIntl.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblLangAndInterServ_SetAllIntl.Location = New System.Drawing.Point(5, 272)
        Me.LblLangAndInterServ_SetAllIntl.Name = "LblLangAndInterServ_SetAllIntl"
        Me.LblLangAndInterServ_SetAllIntl.Size = New System.Drawing.Size(86, 20)
        Me.LblLangAndInterServ_SetAllIntl.TabIndex = 7
        Me.LblLangAndInterServ_SetAllIntl.Text = "/Set-AllIntl:"
        '
        'BtnSetLanguage_DisplayInfo
        '
        Me.BtnSetLanguage_DisplayInfo.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnSetLanguage_DisplayInfo.Location = New System.Drawing.Point(192, 12)
        Me.BtnSetLanguage_DisplayInfo.Name = "BtnSetLanguage_DisplayInfo"
        Me.BtnSetLanguage_DisplayInfo.Size = New System.Drawing.Size(488, 30)
        Me.BtnSetLanguage_DisplayInfo.TabIndex = 6
        Me.BtnSetLanguage_DisplayInfo.Text = "Display information about international settings and languages"
        Me.BtnSetLanguage_DisplayInfo.UseVisualStyleBackColor = True
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Location = New System.Drawing.Point(-96, 172)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(86, 20)
        Me.Label25.TabIndex = 5
        Me.Label25.Text = "/Set-AllIntl:"
        '
        'TabPage12
        '
        Me.TabPage12.Controls.Add(Me.BtnExportDriverOnline)
        Me.TabPage12.Controls.Add(Me.LblExportDriverOnlineFolder)
        Me.TabPage12.Controls.Add(Me.TxtBoxExportDriverOnlineFolder)
        Me.TabPage12.Controls.Add(Me.BtnExportDriverOnlineFolderChoice)
        Me.TabPage12.Controls.Add(Me.BtnExportDriverOffline)
        Me.TabPage12.Controls.Add(Me.LblExportDriverOfflineChoisirDossierFolder)
        Me.TabPage12.Controls.Add(Me.TxtBoxExportDriverOfflineFolder)
        Me.TabPage12.Controls.Add(Me.BtnExportDriverOfflineFolderChoice)
        Me.TabPage12.Location = New System.Drawing.Point(4, 29)
        Me.TabPage12.Name = "TabPage12"
        Me.TabPage12.Size = New System.Drawing.Size(886, 350)
        Me.TabPage12.TabIndex = 11
        Me.TabPage12.Text = "Export Driver"
        Me.TabPage12.UseVisualStyleBackColor = True
        '
        'BtnExportDriverOnline
        '
        Me.BtnExportDriverOnline.Location = New System.Drawing.Point(667, 162)
        Me.BtnExportDriverOnline.Name = "BtnExportDriverOnline"
        Me.BtnExportDriverOnline.Size = New System.Drawing.Size(198, 60)
        Me.BtnExportDriverOnline.TabIndex = 15
        Me.BtnExportDriverOnline.Text = "Export Driver Online"
        Me.BtnExportDriverOnline.UseVisualStyleBackColor = True
        '
        'LblExportDriverOnlineFolder
        '
        Me.LblExportDriverOnlineFolder.AutoSize = True
        Me.LblExportDriverOnlineFolder.Location = New System.Drawing.Point(21, 182)
        Me.LblExportDriverOnlineFolder.Name = "LblExportDriverOnlineFolder"
        Me.LblExportDriverOnlineFolder.Size = New System.Drawing.Size(67, 20)
        Me.LblExportDriverOnlineFolder.TabIndex = 14
        Me.LblExportDriverOnlineFolder.Text = "Dossier:"
        '
        'TxtBoxExportDriverOnlineFolder
        '
        Me.TxtBoxExportDriverOnlineFolder.Location = New System.Drawing.Point(129, 176)
        Me.TxtBoxExportDriverOnlineFolder.Name = "TxtBoxExportDriverOnlineFolder"
        Me.TxtBoxExportDriverOnlineFolder.Size = New System.Drawing.Size(501, 26)
        Me.TxtBoxExportDriverOnlineFolder.TabIndex = 13
        '
        'BtnExportDriverOnlineFolderChoice
        '
        Me.BtnExportDriverOnlineFolderChoice.Location = New System.Drawing.Point(292, 217)
        Me.BtnExportDriverOnlineFolderChoice.Name = "BtnExportDriverOnlineFolderChoice"
        Me.BtnExportDriverOnlineFolderChoice.Size = New System.Drawing.Size(150, 29)
        Me.BtnExportDriverOnlineFolderChoice.TabIndex = 12
        Me.BtnExportDriverOnlineFolderChoice.Text = "Select Folder"
        Me.BtnExportDriverOnlineFolderChoice.UseVisualStyleBackColor = True
        '
        'BtnExportDriverOffline
        '
        Me.BtnExportDriverOffline.Location = New System.Drawing.Point(667, 27)
        Me.BtnExportDriverOffline.Name = "BtnExportDriverOffline"
        Me.BtnExportDriverOffline.Size = New System.Drawing.Size(198, 60)
        Me.BtnExportDriverOffline.TabIndex = 11
        Me.BtnExportDriverOffline.Text = "Export Driver Offline"
        Me.BtnExportDriverOffline.UseVisualStyleBackColor = True
        '
        'LblExportDriverOfflineChoisirDossierFolder
        '
        Me.LblExportDriverOfflineChoisirDossierFolder.AutoSize = True
        Me.LblExportDriverOfflineChoisirDossierFolder.Location = New System.Drawing.Point(21, 47)
        Me.LblExportDriverOfflineChoisirDossierFolder.Name = "LblExportDriverOfflineChoisirDossierFolder"
        Me.LblExportDriverOfflineChoisirDossierFolder.Size = New System.Drawing.Size(67, 20)
        Me.LblExportDriverOfflineChoisirDossierFolder.TabIndex = 10
        Me.LblExportDriverOfflineChoisirDossierFolder.Text = "Dossier:"
        '
        'TxtBoxExportDriverOfflineFolder
        '
        Me.TxtBoxExportDriverOfflineFolder.Location = New System.Drawing.Point(129, 41)
        Me.TxtBoxExportDriverOfflineFolder.Name = "TxtBoxExportDriverOfflineFolder"
        Me.TxtBoxExportDriverOfflineFolder.Size = New System.Drawing.Size(501, 26)
        Me.TxtBoxExportDriverOfflineFolder.TabIndex = 9
        '
        'BtnExportDriverOfflineFolderChoice
        '
        Me.BtnExportDriverOfflineFolderChoice.Location = New System.Drawing.Point(292, 82)
        Me.BtnExportDriverOfflineFolderChoice.Name = "BtnExportDriverOfflineFolderChoice"
        Me.BtnExportDriverOfflineFolderChoice.Size = New System.Drawing.Size(150, 29)
        Me.BtnExportDriverOfflineFolderChoice.TabIndex = 8
        Me.BtnExportDriverOfflineFolderChoice.Text = "Select Folder"
        Me.BtnExportDriverOfflineFolderChoice.UseVisualStyleBackColor = True
        '
        'TabPage13
        '
        Me.TabPage13.Controls.Add(Me.BtnSplitImage_WIMChoice)
        Me.TabPage13.Controls.Add(Me.BtnSplitImage_TargetFolder)
        Me.TabPage13.Controls.Add(Me.LblSplitImage_DestinationFolder)
        Me.TabPage13.Controls.Add(Me.TxtBoxSplitImage_DestinationFolder)
        Me.TabPage13.Controls.Add(Me.BtnSplitImage_SplitImage)
        Me.TabPage13.Controls.Add(Me.ChkBoxSplitImage_CheckIntegrity)
        Me.TabPage13.Controls.Add(Me.LblSplitImage_SplitSize)
        Me.TabPage13.Controls.Add(Me.TxtBoxSplitImage_Filesize)
        Me.TabPage13.Controls.Add(Me.LblSplitImage_SWMFilename)
        Me.TabPage13.Controls.Add(Me.LblSplitImage_WIMFilename)
        Me.TabPage13.Controls.Add(Me.TxtBoxSplitImage_SWMFilename)
        Me.TabPage13.Controls.Add(Me.TxtBoxSplitImage_WIMFilename)
        Me.TabPage13.Location = New System.Drawing.Point(4, 29)
        Me.TabPage13.Name = "TabPage13"
        Me.TabPage13.Size = New System.Drawing.Size(886, 350)
        Me.TabPage13.TabIndex = 12
        Me.TabPage13.Text = "Split Image"
        Me.TabPage13.UseVisualStyleBackColor = True
        '
        'BtnSplitImage_WIMChoice
        '
        Me.BtnSplitImage_WIMChoice.Location = New System.Drawing.Point(526, 41)
        Me.BtnSplitImage_WIMChoice.Name = "BtnSplitImage_WIMChoice"
        Me.BtnSplitImage_WIMChoice.Size = New System.Drawing.Size(136, 26)
        Me.BtnSplitImage_WIMChoice.TabIndex = 52
        Me.BtnSplitImage_WIMChoice.Text = "Open File"
        Me.BtnSplitImage_WIMChoice.UseVisualStyleBackColor = True
        '
        'BtnSplitImage_TargetFolder
        '
        Me.BtnSplitImage_TargetFolder.Location = New System.Drawing.Point(527, 77)
        Me.BtnSplitImage_TargetFolder.Name = "BtnSplitImage_TargetFolder"
        Me.BtnSplitImage_TargetFolder.Size = New System.Drawing.Size(136, 29)
        Me.BtnSplitImage_TargetFolder.TabIndex = 51
        Me.BtnSplitImage_TargetFolder.Text = "Open Target Folder"
        Me.BtnSplitImage_TargetFolder.UseVisualStyleBackColor = True
        '
        'LblSplitImage_DestinationFolder
        '
        Me.LblSplitImage_DestinationFolder.AutoSize = True
        Me.LblSplitImage_DestinationFolder.Location = New System.Drawing.Point(32, 82)
        Me.LblSplitImage_DestinationFolder.Name = "LblSplitImage_DestinationFolder"
        Me.LblSplitImage_DestinationFolder.Size = New System.Drawing.Size(143, 20)
        Me.LblSplitImage_DestinationFolder.TabIndex = 50
        Me.LblSplitImage_DestinationFolder.Text = "Destination Folder:"
        '
        'TxtBoxSplitImage_DestinationFolder
        '
        Me.TxtBoxSplitImage_DestinationFolder.Location = New System.Drawing.Point(209, 80)
        Me.TxtBoxSplitImage_DestinationFolder.Name = "TxtBoxSplitImage_DestinationFolder"
        Me.TxtBoxSplitImage_DestinationFolder.Size = New System.Drawing.Size(303, 26)
        Me.TxtBoxSplitImage_DestinationFolder.TabIndex = 49
        '
        'BtnSplitImage_SplitImage
        '
        Me.BtnSplitImage_SplitImage.Location = New System.Drawing.Point(694, 41)
        Me.BtnSplitImage_SplitImage.Name = "BtnSplitImage_SplitImage"
        Me.BtnSplitImage_SplitImage.Size = New System.Drawing.Size(136, 53)
        Me.BtnSplitImage_SplitImage.TabIndex = 48
        Me.BtnSplitImage_SplitImage.Text = "Split Image"
        Me.BtnSplitImage_SplitImage.UseVisualStyleBackColor = True
        '
        'ChkBoxSplitImage_CheckIntegrity
        '
        Me.ChkBoxSplitImage_CheckIntegrity.AutoSize = True
        Me.ChkBoxSplitImage_CheckIntegrity.Location = New System.Drawing.Point(529, 153)
        Me.ChkBoxSplitImage_CheckIntegrity.Name = "ChkBoxSplitImage_CheckIntegrity"
        Me.ChkBoxSplitImage_CheckIntegrity.Size = New System.Drawing.Size(134, 24)
        Me.ChkBoxSplitImage_CheckIntegrity.TabIndex = 47
        Me.ChkBoxSplitImage_CheckIntegrity.Text = "/CheckIntegrity"
        Me.ChkBoxSplitImage_CheckIntegrity.UseVisualStyleBackColor = True
        '
        'LblSplitImage_SplitSize
        '
        Me.LblSplitImage_SplitSize.AutoSize = True
        Me.LblSplitImage_SplitSize.Location = New System.Drawing.Point(32, 146)
        Me.LblSplitImage_SplitSize.Name = "LblSplitImage_SplitSize"
        Me.LblSplitImage_SplitSize.Size = New System.Drawing.Size(144, 20)
        Me.LblSplitImage_SplitSize.TabIndex = 46
        Me.LblSplitImage_SplitSize.Text = "Split File Size (Mo):"
        '
        'TxtBoxSplitImage_Filesize
        '
        Me.TxtBoxSplitImage_Filesize.Location = New System.Drawing.Point(209, 144)
        Me.TxtBoxSplitImage_Filesize.Name = "TxtBoxSplitImage_Filesize"
        Me.TxtBoxSplitImage_Filesize.Size = New System.Drawing.Size(303, 26)
        Me.TxtBoxSplitImage_Filesize.TabIndex = 45
        '
        'LblSplitImage_SWMFilename
        '
        Me.LblSplitImage_SWMFilename.AutoSize = True
        Me.LblSplitImage_SWMFilename.Location = New System.Drawing.Point(32, 114)
        Me.LblSplitImage_SWMFilename.Name = "LblSplitImage_SWMFilename"
        Me.LblSplitImage_SWMFilename.Size = New System.Drawing.Size(168, 20)
        Me.LblSplitImage_SWMFilename.TabIndex = 44
        Me.LblSplitImage_SWMFilename.Text = "SWM or Sfu Filename:"
        '
        'LblSplitImage_WIMFilename
        '
        Me.LblSplitImage_WIMFilename.AutoSize = True
        Me.LblSplitImage_WIMFilename.Location = New System.Drawing.Point(32, 47)
        Me.LblSplitImage_WIMFilename.Name = "LblSplitImage_WIMFilename"
        Me.LblSplitImage_WIMFilename.Size = New System.Drawing.Size(161, 20)
        Me.LblSplitImage_WIMFilename.TabIndex = 43
        Me.LblSplitImage_WIMFilename.Text = "WIM or Ffu Filename:"
        '
        'TxtBoxSplitImage_SWMFilename
        '
        Me.TxtBoxSplitImage_SWMFilename.Location = New System.Drawing.Point(209, 112)
        Me.TxtBoxSplitImage_SWMFilename.Name = "TxtBoxSplitImage_SWMFilename"
        Me.TxtBoxSplitImage_SWMFilename.Size = New System.Drawing.Size(303, 26)
        Me.TxtBoxSplitImage_SWMFilename.TabIndex = 42
        '
        'TxtBoxSplitImage_WIMFilename
        '
        Me.TxtBoxSplitImage_WIMFilename.Location = New System.Drawing.Point(209, 45)
        Me.TxtBoxSplitImage_WIMFilename.Name = "TxtBoxSplitImage_WIMFilename"
        Me.TxtBoxSplitImage_WIMFilename.Size = New System.Drawing.Size(303, 26)
        Me.TxtBoxSplitImage_WIMFilename.TabIndex = 41
        '
        'TabPage14
        '
        Me.TabPage14.Controls.Add(Me.LblCaptureFfu_Description)
        Me.TabPage14.Controls.Add(Me.TxtBoxCaptureFfu_Description)
        Me.TabPage14.Controls.Add(Me.LstBoxCaptureFfu_LogicalDrive)
        Me.TabPage14.Controls.Add(Me.LblCaptFfu_LogicalDrive)
        Me.TabPage14.Controls.Add(Me.LblCaptFfu_Name)
        Me.TabPage14.Controls.Add(Me.TxtBoxCaptFfu_Name)
        Me.TabPage14.Controls.Add(Me.LblCaptFfu_PlatformID)
        Me.TabPage14.Controls.Add(Me.TxtBoxCaptFfu_PlatformID)
        Me.TabPage14.Controls.Add(Me.Label27)
        Me.TabPage14.Controls.Add(Me.LblCaptFfu_TargetFilename)
        Me.TabPage14.Controls.Add(Me.LblCaptFfu_TargetFolder)
        Me.TabPage14.Controls.Add(Me.LblCaptFfu_PhysicalDrive)
        Me.TabPage14.Controls.Add(Me.CmbBoxCaptureFfu_Compression)
        Me.TabPage14.Controls.Add(Me.TxtBoxCaptFfu_TargetFilename)
        Me.TabPage14.Controls.Add(Me.TxtBoxCaptFfu_TargetFolder)
        Me.TabPage14.Controls.Add(Me.TxtBoxCaptFfu_PhysicalDrive)
        Me.TabPage14.Controls.Add(Me.BtnCaptFfu_StartCapture)
        Me.TabPage14.Controls.Add(Me.BtnCaptureFfu_SetTargetFolder)
        Me.TabPage14.Controls.Add(Me.BtnCaptureFfu_UpdateLogicalDrive)
        Me.TabPage14.Location = New System.Drawing.Point(4, 29)
        Me.TabPage14.Name = "TabPage14"
        Me.TabPage14.Size = New System.Drawing.Size(886, 350)
        Me.TabPage14.TabIndex = 13
        Me.TabPage14.Text = "Capture Ffu Image"
        Me.TabPage14.UseVisualStyleBackColor = True
        '
        'LblCaptureFfu_Description
        '
        Me.LblCaptureFfu_Description.AutoSize = True
        Me.LblCaptureFfu_Description.Location = New System.Drawing.Point(62, 201)
        Me.LblCaptureFfu_Description.Name = "LblCaptureFfu_Description"
        Me.LblCaptureFfu_Description.Size = New System.Drawing.Size(175, 20)
        Me.LblCaptureFfu_Description.TabIndex = 56
        Me.LblCaptureFfu_Description.Text = "Description (metadata):"
        '
        'TxtBoxCaptureFfu_Description
        '
        Me.TxtBoxCaptureFfu_Description.Location = New System.Drawing.Point(248, 199)
        Me.TxtBoxCaptureFfu_Description.Name = "TxtBoxCaptureFfu_Description"
        Me.TxtBoxCaptureFfu_Description.Size = New System.Drawing.Size(300, 26)
        Me.TxtBoxCaptureFfu_Description.TabIndex = 55
        '
        'LstBoxCaptureFfu_LogicalDrive
        '
        Me.LstBoxCaptureFfu_LogicalDrive.FormattingEnabled = True
        Me.LstBoxCaptureFfu_LogicalDrive.ItemHeight = 20
        Me.LstBoxCaptureFfu_LogicalDrive.Location = New System.Drawing.Point(248, 29)
        Me.LstBoxCaptureFfu_LogicalDrive.Name = "LstBoxCaptureFfu_LogicalDrive"
        Me.LstBoxCaptureFfu_LogicalDrive.Size = New System.Drawing.Size(67, 24)
        Me.LstBoxCaptureFfu_LogicalDrive.TabIndex = 54
        '
        'LblCaptFfu_LogicalDrive
        '
        Me.LblCaptFfu_LogicalDrive.AutoSize = True
        Me.LblCaptFfu_LogicalDrive.Location = New System.Drawing.Point(62, 33)
        Me.LblCaptFfu_LogicalDrive.Name = "LblCaptFfu_LogicalDrive"
        Me.LblCaptFfu_LogicalDrive.Size = New System.Drawing.Size(103, 20)
        Me.LblCaptFfu_LogicalDrive.TabIndex = 53
        Me.LblCaptFfu_LogicalDrive.Text = "Logical Drive:"
        '
        'LblCaptFfu_Name
        '
        Me.LblCaptFfu_Name.AutoSize = True
        Me.LblCaptFfu_Name.Location = New System.Drawing.Point(62, 164)
        Me.LblCaptFfu_Name.Name = "LblCaptFfu_Name"
        Me.LblCaptFfu_Name.Size = New System.Drawing.Size(137, 20)
        Me.LblCaptFfu_Name.TabIndex = 52
        Me.LblCaptFfu_Name.Text = "Name (metadata):"
        '
        'TxtBoxCaptFfu_Name
        '
        Me.TxtBoxCaptFfu_Name.Location = New System.Drawing.Point(248, 162)
        Me.TxtBoxCaptFfu_Name.Name = "TxtBoxCaptFfu_Name"
        Me.TxtBoxCaptFfu_Name.Size = New System.Drawing.Size(300, 26)
        Me.TxtBoxCaptFfu_Name.TabIndex = 51
        '
        'LblCaptFfu_PlatformID
        '
        Me.LblCaptFfu_PlatformID.AutoSize = True
        Me.LblCaptFfu_PlatformID.Location = New System.Drawing.Point(62, 233)
        Me.LblCaptFfu_PlatformID.Name = "LblCaptFfu_PlatformID"
        Me.LblCaptFfu_PlatformID.Size = New System.Drawing.Size(93, 20)
        Me.LblCaptFfu_PlatformID.TabIndex = 50
        Me.LblCaptFfu_PlatformID.Text = "Platform ID:"
        '
        'TxtBoxCaptFfu_PlatformID
        '
        Me.TxtBoxCaptFfu_PlatformID.Location = New System.Drawing.Point(248, 231)
        Me.TxtBoxCaptFfu_PlatformID.Name = "TxtBoxCaptFfu_PlatformID"
        Me.TxtBoxCaptFfu_PlatformID.Size = New System.Drawing.Size(300, 26)
        Me.TxtBoxCaptFfu_PlatformID.TabIndex = 49
        Me.TxtBoxCaptFfu_PlatformID.Text = "*"
        '
        'Label27
        '
        Me.Label27.AutoSize = True
        Me.Label27.Location = New System.Drawing.Point(561, 231)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(106, 20)
        Me.Label27.TabIndex = 48
        Me.Label27.Text = "Compression:"
        '
        'LblCaptFfu_TargetFilename
        '
        Me.LblCaptFfu_TargetFilename.AutoSize = True
        Me.LblCaptFfu_TargetFilename.Location = New System.Drawing.Point(62, 129)
        Me.LblCaptFfu_TargetFilename.Name = "LblCaptFfu_TargetFilename"
        Me.LblCaptFfu_TargetFilename.Size = New System.Drawing.Size(128, 20)
        Me.LblCaptFfu_TargetFilename.TabIndex = 47
        Me.LblCaptFfu_TargetFilename.Text = "Target Filename:"
        '
        'LblCaptFfu_TargetFolder
        '
        Me.LblCaptFfu_TargetFolder.AutoSize = True
        Me.LblCaptFfu_TargetFolder.Location = New System.Drawing.Point(62, 97)
        Me.LblCaptFfu_TargetFolder.Name = "LblCaptFfu_TargetFolder"
        Me.LblCaptFfu_TargetFolder.Size = New System.Drawing.Size(108, 20)
        Me.LblCaptFfu_TargetFolder.TabIndex = 46
        Me.LblCaptFfu_TargetFolder.Text = "Target Folder:"
        '
        'LblCaptFfu_PhysicalDrive
        '
        Me.LblCaptFfu_PhysicalDrive.AutoSize = True
        Me.LblCaptFfu_PhysicalDrive.Location = New System.Drawing.Point(62, 66)
        Me.LblCaptFfu_PhysicalDrive.Name = "LblCaptFfu_PhysicalDrive"
        Me.LblCaptFfu_PhysicalDrive.Size = New System.Drawing.Size(110, 20)
        Me.LblCaptFfu_PhysicalDrive.TabIndex = 45
        Me.LblCaptFfu_PhysicalDrive.Text = "Physical Drive:"
        '
        'CmbBoxCaptureFfu_Compression
        '
        Me.CmbBoxCaptureFfu_Compression.FormattingEnabled = True
        Me.CmbBoxCaptureFfu_Compression.Items.AddRange(New Object() {"default", "none"})
        Me.CmbBoxCaptureFfu_Compression.Location = New System.Drawing.Point(673, 226)
        Me.CmbBoxCaptureFfu_Compression.Name = "CmbBoxCaptureFfu_Compression"
        Me.CmbBoxCaptureFfu_Compression.Size = New System.Drawing.Size(121, 28)
        Me.CmbBoxCaptureFfu_Compression.TabIndex = 44
        '
        'TxtBoxCaptFfu_TargetFilename
        '
        Me.TxtBoxCaptFfu_TargetFilename.Location = New System.Drawing.Point(248, 130)
        Me.TxtBoxCaptFfu_TargetFilename.Name = "TxtBoxCaptFfu_TargetFilename"
        Me.TxtBoxCaptFfu_TargetFilename.Size = New System.Drawing.Size(300, 26)
        Me.TxtBoxCaptFfu_TargetFilename.TabIndex = 43
        '
        'TxtBoxCaptFfu_TargetFolder
        '
        Me.TxtBoxCaptFfu_TargetFolder.Location = New System.Drawing.Point(248, 98)
        Me.TxtBoxCaptFfu_TargetFolder.Name = "TxtBoxCaptFfu_TargetFolder"
        Me.TxtBoxCaptFfu_TargetFolder.Size = New System.Drawing.Size(300, 26)
        Me.TxtBoxCaptFfu_TargetFolder.TabIndex = 42
        '
        'TxtBoxCaptFfu_PhysicalDrive
        '
        Me.TxtBoxCaptFfu_PhysicalDrive.Location = New System.Drawing.Point(248, 64)
        Me.TxtBoxCaptFfu_PhysicalDrive.Name = "TxtBoxCaptFfu_PhysicalDrive"
        Me.TxtBoxCaptFfu_PhysicalDrive.Size = New System.Drawing.Size(300, 26)
        Me.TxtBoxCaptFfu_PhysicalDrive.TabIndex = 41
        '
        'BtnCaptFfu_StartCapture
        '
        Me.BtnCaptFfu_StartCapture.Location = New System.Drawing.Point(673, 28)
        Me.BtnCaptFfu_StartCapture.Name = "BtnCaptFfu_StartCapture"
        Me.BtnCaptFfu_StartCapture.Size = New System.Drawing.Size(148, 46)
        Me.BtnCaptFfu_StartCapture.TabIndex = 40
        Me.BtnCaptFfu_StartCapture.Text = "Start Capture"
        Me.BtnCaptFfu_StartCapture.UseVisualStyleBackColor = True
        '
        'BtnCaptureFfu_SetTargetFolder
        '
        Me.BtnCaptureFfu_SetTargetFolder.Location = New System.Drawing.Point(554, 98)
        Me.BtnCaptureFfu_SetTargetFolder.Name = "BtnCaptureFfu_SetTargetFolder"
        Me.BtnCaptureFfu_SetTargetFolder.Size = New System.Drawing.Size(114, 26)
        Me.BtnCaptureFfu_SetTargetFolder.TabIndex = 39
        Me.BtnCaptureFfu_SetTargetFolder.Text = "Select Target Folder"
        Me.BtnCaptureFfu_SetTargetFolder.UseVisualStyleBackColor = True
        '
        'BtnCaptureFfu_UpdateLogicalDrive
        '
        Me.BtnCaptureFfu_UpdateLogicalDrive.Location = New System.Drawing.Point(332, 28)
        Me.BtnCaptureFfu_UpdateLogicalDrive.Name = "BtnCaptureFfu_UpdateLogicalDrive"
        Me.BtnCaptureFfu_UpdateLogicalDrive.Size = New System.Drawing.Size(216, 30)
        Me.BtnCaptureFfu_UpdateLogicalDrive.TabIndex = 38
        Me.BtnCaptureFfu_UpdateLogicalDrive.Text = "Update List Logical Drive"
        Me.BtnCaptureFfu_UpdateLogicalDrive.UseVisualStyleBackColor = True
        '
        'TabPage15
        '
        Me.TabPage15.Controls.Add(Me.LstBoxApplyFfuImage_LogicalDrive)
        Me.TabPage15.Controls.Add(Me.LblApplyFfuImage_LogicalDrive)
        Me.TabPage15.Controls.Add(Me.LblApplyFfuImage_MotifSFUFile)
        Me.TabPage15.Controls.Add(Me.LblApplyFfuImage_SourceFilename)
        Me.TabPage15.Controls.Add(Me.LblApplyFfuImage_PhysicalDrive)
        Me.TabPage15.Controls.Add(Me.TxtBoxApplyFfuImageFfu_MotifSFUFile)
        Me.TabPage15.Controls.Add(Me.TxtBoxApplyFfuImage_FfuSourceFilename)
        Me.TabPage15.Controls.Add(Me.TxtBoxApplyFfuImage_PhysicalDrive)
        Me.TabPage15.Controls.Add(Me.BtnApplyFfuImage_ApplyFfuImage)
        Me.TabPage15.Controls.Add(Me.BtnApplyFfuImage_SelectFfuFile)
        Me.TabPage15.Controls.Add(Me.BtnApplyFfuImage_UpdateLogicalDrive)
        Me.TabPage15.Location = New System.Drawing.Point(4, 29)
        Me.TabPage15.Name = "TabPage15"
        Me.TabPage15.Size = New System.Drawing.Size(886, 350)
        Me.TabPage15.TabIndex = 14
        Me.TabPage15.Text = "Apply Ffu / Sfu Image"
        Me.TabPage15.UseVisualStyleBackColor = True
        '
        'LstBoxApplyFfuImage_LogicalDrive
        '
        Me.LstBoxApplyFfuImage_LogicalDrive.FormattingEnabled = True
        Me.LstBoxApplyFfuImage_LogicalDrive.ItemHeight = 20
        Me.LstBoxApplyFfuImage_LogicalDrive.Location = New System.Drawing.Point(263, 44)
        Me.LstBoxApplyFfuImage_LogicalDrive.Name = "LstBoxApplyFfuImage_LogicalDrive"
        Me.LstBoxApplyFfuImage_LogicalDrive.Size = New System.Drawing.Size(67, 24)
        Me.LstBoxApplyFfuImage_LogicalDrive.TabIndex = 65
        '
        'LblApplyFfuImage_LogicalDrive
        '
        Me.LblApplyFfuImage_LogicalDrive.AutoSize = True
        Me.LblApplyFfuImage_LogicalDrive.Location = New System.Drawing.Point(93, 51)
        Me.LblApplyFfuImage_LogicalDrive.Name = "LblApplyFfuImage_LogicalDrive"
        Me.LblApplyFfuImage_LogicalDrive.Size = New System.Drawing.Size(103, 20)
        Me.LblApplyFfuImage_LogicalDrive.TabIndex = 64
        Me.LblApplyFfuImage_LogicalDrive.Text = "Logical Drive:"
        '
        'LblApplyFfuImage_MotifSFUFile
        '
        Me.LblApplyFfuImage_MotifSFUFile.AutoSize = True
        Me.LblApplyFfuImage_MotifSFUFile.Location = New System.Drawing.Point(93, 145)
        Me.LblApplyFfuImage_MotifSFUFile.Name = "LblApplyFfuImage_MotifSFUFile"
        Me.LblApplyFfuImage_MotifSFUFile.Size = New System.Drawing.Size(114, 20)
        Me.LblApplyFfuImage_MotifSFUFile.TabIndex = 63
        Me.LblApplyFfuImage_MotifSFUFile.Text = "Motif /SFUFile:"
        '
        'LblApplyFfuImage_SourceFilename
        '
        Me.LblApplyFfuImage_SourceFilename.AutoSize = True
        Me.LblApplyFfuImage_SourceFilename.Location = New System.Drawing.Point(93, 113)
        Me.LblApplyFfuImage_SourceFilename.Name = "LblApplyFfuImage_SourceFilename"
        Me.LblApplyFfuImage_SourceFilename.Size = New System.Drawing.Size(161, 20)
        Me.LblApplyFfuImage_SourceFilename.TabIndex = 62
        Me.LblApplyFfuImage_SourceFilename.Text = "Ffu Source Filename:"
        '
        'LblApplyFfuImage_PhysicalDrive
        '
        Me.LblApplyFfuImage_PhysicalDrive.AutoSize = True
        Me.LblApplyFfuImage_PhysicalDrive.Location = New System.Drawing.Point(93, 84)
        Me.LblApplyFfuImage_PhysicalDrive.Name = "LblApplyFfuImage_PhysicalDrive"
        Me.LblApplyFfuImage_PhysicalDrive.Size = New System.Drawing.Size(110, 20)
        Me.LblApplyFfuImage_PhysicalDrive.TabIndex = 61
        Me.LblApplyFfuImage_PhysicalDrive.Text = "Physical Drive:"
        '
        'TxtBoxApplyFfuImageFfu_MotifSFUFile
        '
        Me.TxtBoxApplyFfuImageFfu_MotifSFUFile.Location = New System.Drawing.Point(263, 138)
        Me.TxtBoxApplyFfuImageFfu_MotifSFUFile.Name = "TxtBoxApplyFfuImageFfu_MotifSFUFile"
        Me.TxtBoxApplyFfuImageFfu_MotifSFUFile.Size = New System.Drawing.Size(300, 26)
        Me.TxtBoxApplyFfuImageFfu_MotifSFUFile.TabIndex = 60
        '
        'TxtBoxApplyFfuImage_FfuSourceFilename
        '
        Me.TxtBoxApplyFfuImage_FfuSourceFilename.Location = New System.Drawing.Point(263, 106)
        Me.TxtBoxApplyFfuImage_FfuSourceFilename.Name = "TxtBoxApplyFfuImage_FfuSourceFilename"
        Me.TxtBoxApplyFfuImage_FfuSourceFilename.Size = New System.Drawing.Size(300, 26)
        Me.TxtBoxApplyFfuImage_FfuSourceFilename.TabIndex = 59
        '
        'TxtBoxApplyFfuImage_PhysicalDrive
        '
        Me.TxtBoxApplyFfuImage_PhysicalDrive.Location = New System.Drawing.Point(263, 74)
        Me.TxtBoxApplyFfuImage_PhysicalDrive.Name = "TxtBoxApplyFfuImage_PhysicalDrive"
        Me.TxtBoxApplyFfuImage_PhysicalDrive.Size = New System.Drawing.Size(300, 26)
        Me.TxtBoxApplyFfuImage_PhysicalDrive.TabIndex = 58
        '
        'BtnApplyFfuImage_ApplyFfuImage
        '
        Me.BtnApplyFfuImage_ApplyFfuImage.Location = New System.Drawing.Point(580, 38)
        Me.BtnApplyFfuImage_ApplyFfuImage.Name = "BtnApplyFfuImage_ApplyFfuImage"
        Me.BtnApplyFfuImage_ApplyFfuImage.Size = New System.Drawing.Size(190, 33)
        Me.BtnApplyFfuImage_ApplyFfuImage.TabIndex = 57
        Me.BtnApplyFfuImage_ApplyFfuImage.Text = "Apply Image"
        Me.BtnApplyFfuImage_ApplyFfuImage.UseVisualStyleBackColor = True
        '
        'BtnApplyFfuImage_SelectFfuFile
        '
        Me.BtnApplyFfuImage_SelectFfuFile.Location = New System.Drawing.Point(580, 106)
        Me.BtnApplyFfuImage_SelectFfuFile.Name = "BtnApplyFfuImage_SelectFfuFile"
        Me.BtnApplyFfuImage_SelectFfuFile.Size = New System.Drawing.Size(136, 26)
        Me.BtnApplyFfuImage_SelectFfuFile.TabIndex = 56
        Me.BtnApplyFfuImage_SelectFfuFile.Text = "Select File"
        Me.BtnApplyFfuImage_SelectFfuFile.UseVisualStyleBackColor = True
        '
        'BtnApplyFfuImage_UpdateLogicalDrive
        '
        Me.BtnApplyFfuImage_UpdateLogicalDrive.Location = New System.Drawing.Point(347, 41)
        Me.BtnApplyFfuImage_UpdateLogicalDrive.Name = "BtnApplyFfuImage_UpdateLogicalDrive"
        Me.BtnApplyFfuImage_UpdateLogicalDrive.Size = New System.Drawing.Size(216, 30)
        Me.BtnApplyFfuImage_UpdateLogicalDrive.TabIndex = 55
        Me.BtnApplyFfuImage_UpdateLogicalDrive.Text = "Update Logical Drive"
        Me.BtnApplyFfuImage_UpdateLogicalDrive.UseVisualStyleBackColor = True
        '
        'TabPage16
        '
        Me.TabPage16.Controls.Add(Me.BtnSplitFfu_SelectFfuFile)
        Me.TabPage16.Controls.Add(Me.BtnSplitFfu_SelectTargetFolder)
        Me.TabPage16.Controls.Add(Me.LblSplitFfu_TargetFolder)
        Me.TabPage16.Controls.Add(Me.TxtBoxSplitFfu_TargetFolder)
        Me.TabPage16.Controls.Add(Me.BtnSplitFfuImage_StartSplitImage)
        Me.TabPage16.Controls.Add(Me.ChkBoxSplitFfu_CheckIntegrity)
        Me.TabPage16.Controls.Add(Me.LblSplitFfu_SplitFileSize)
        Me.TabPage16.Controls.Add(Me.TxtBoxSplitFfu_SplitFileSize)
        Me.TabPage16.Controls.Add(Me.LblSplitFfu_SFUFilename)
        Me.TabPage16.Controls.Add(Me.LblSplitFfu_FfuFilename)
        Me.TabPage16.Controls.Add(Me.TxtBoxSplitFfu_SFUFilename)
        Me.TabPage16.Controls.Add(Me.TxtBoxSplitFfu_FfuFilename)
        Me.TabPage16.Location = New System.Drawing.Point(4, 29)
        Me.TabPage16.Name = "TabPage16"
        Me.TabPage16.Size = New System.Drawing.Size(886, 350)
        Me.TabPage16.TabIndex = 15
        Me.TabPage16.Text = "Split Ffu Image"
        Me.TabPage16.UseVisualStyleBackColor = True
        '
        'BtnSplitFfu_SelectFfuFile
        '
        Me.BtnSplitFfu_SelectFfuFile.Location = New System.Drawing.Point(496, 30)
        Me.BtnSplitFfu_SelectFfuFile.Name = "BtnSplitFfu_SelectFfuFile"
        Me.BtnSplitFfu_SelectFfuFile.Size = New System.Drawing.Size(136, 26)
        Me.BtnSplitFfu_SelectFfuFile.TabIndex = 64
        Me.BtnSplitFfu_SelectFfuFile.Text = "Select Ffu File"
        Me.BtnSplitFfu_SelectFfuFile.UseVisualStyleBackColor = True
        '
        'BtnSplitFfu_SelectTargetFolder
        '
        Me.BtnSplitFfu_SelectTargetFolder.Location = New System.Drawing.Point(496, 68)
        Me.BtnSplitFfu_SelectTargetFolder.Name = "BtnSplitFfu_SelectTargetFolder"
        Me.BtnSplitFfu_SelectTargetFolder.Size = New System.Drawing.Size(136, 26)
        Me.BtnSplitFfu_SelectTargetFolder.TabIndex = 63
        Me.BtnSplitFfu_SelectTargetFolder.Text = "Select Target Folder"
        Me.BtnSplitFfu_SelectTargetFolder.UseVisualStyleBackColor = True
        '
        'LblSplitFfu_TargetFolder
        '
        Me.LblSplitFfu_TargetFolder.AutoSize = True
        Me.LblSplitFfu_TargetFolder.Location = New System.Drawing.Point(26, 68)
        Me.LblSplitFfu_TargetFolder.Name = "LblSplitFfu_TargetFolder"
        Me.LblSplitFfu_TargetFolder.Size = New System.Drawing.Size(108, 20)
        Me.LblSplitFfu_TargetFolder.TabIndex = 62
        Me.LblSplitFfu_TargetFolder.Text = "Target Folder:"
        '
        'TxtBoxSplitFfu_TargetFolder
        '
        Me.TxtBoxSplitFfu_TargetFolder.Location = New System.Drawing.Point(179, 65)
        Me.TxtBoxSplitFfu_TargetFolder.Name = "TxtBoxSplitFfu_TargetFolder"
        Me.TxtBoxSplitFfu_TargetFolder.Size = New System.Drawing.Size(303, 26)
        Me.TxtBoxSplitFfu_TargetFolder.TabIndex = 61
        '
        'BtnSplitFfuImage_StartSplitImage
        '
        Me.BtnSplitFfuImage_StartSplitImage.Location = New System.Drawing.Point(656, 30)
        Me.BtnSplitFfuImage_StartSplitImage.Name = "BtnSplitFfuImage_StartSplitImage"
        Me.BtnSplitFfuImage_StartSplitImage.Size = New System.Drawing.Size(136, 53)
        Me.BtnSplitFfuImage_StartSplitImage.TabIndex = 60
        Me.BtnSplitFfuImage_StartSplitImage.Text = "Start Split Image"
        Me.BtnSplitFfuImage_StartSplitImage.UseVisualStyleBackColor = True
        '
        'ChkBoxSplitFfu_CheckIntegrity
        '
        Me.ChkBoxSplitFfu_CheckIntegrity.AutoSize = True
        Me.ChkBoxSplitFfu_CheckIntegrity.Location = New System.Drawing.Point(499, 138)
        Me.ChkBoxSplitFfu_CheckIntegrity.Name = "ChkBoxSplitFfu_CheckIntegrity"
        Me.ChkBoxSplitFfu_CheckIntegrity.Size = New System.Drawing.Size(134, 24)
        Me.ChkBoxSplitFfu_CheckIntegrity.TabIndex = 59
        Me.ChkBoxSplitFfu_CheckIntegrity.Text = "/CheckIntegrity"
        Me.ChkBoxSplitFfu_CheckIntegrity.UseVisualStyleBackColor = True
        '
        'LblSplitFfu_SplitFileSize
        '
        Me.LblSplitFfu_SplitFileSize.AutoSize = True
        Me.LblSplitFfu_SplitFileSize.Location = New System.Drawing.Point(26, 132)
        Me.LblSplitFfu_SplitFileSize.Name = "LblSplitFfu_SplitFileSize"
        Me.LblSplitFfu_SplitFileSize.Size = New System.Drawing.Size(144, 20)
        Me.LblSplitFfu_SplitFileSize.TabIndex = 58
        Me.LblSplitFfu_SplitFileSize.Text = "Split File Size (Mo):"
        '
        'TxtBoxSplitFfu_SplitFileSize
        '
        Me.TxtBoxSplitFfu_SplitFileSize.Location = New System.Drawing.Point(179, 129)
        Me.TxtBoxSplitFfu_SplitFileSize.Name = "TxtBoxSplitFfu_SplitFileSize"
        Me.TxtBoxSplitFfu_SplitFileSize.Size = New System.Drawing.Size(303, 26)
        Me.TxtBoxSplitFfu_SplitFileSize.TabIndex = 57
        '
        'LblSplitFfu_SFUFilename
        '
        Me.LblSplitFfu_SFUFilename.AutoSize = True
        Me.LblSplitFfu_SFUFilename.Location = New System.Drawing.Point(26, 100)
        Me.LblSplitFfu_SFUFilename.Name = "LblSplitFfu_SFUFilename"
        Me.LblSplitFfu_SFUFilename.Size = New System.Drawing.Size(115, 20)
        Me.LblSplitFfu_SFUFilename.TabIndex = 56
        Me.LblSplitFfu_SFUFilename.Text = "SFU Filename:"
        '
        'LblSplitFfu_FfuFilename
        '
        Me.LblSplitFfu_FfuFilename.AutoSize = True
        Me.LblSplitFfu_FfuFilename.Location = New System.Drawing.Point(26, 33)
        Me.LblSplitFfu_FfuFilename.Name = "LblSplitFfu_FfuFilename"
        Me.LblSplitFfu_FfuFilename.Size = New System.Drawing.Size(106, 20)
        Me.LblSplitFfu_FfuFilename.TabIndex = 55
        Me.LblSplitFfu_FfuFilename.Text = "Ffu Filename:"
        '
        'TxtBoxSplitFfu_SFUFilename
        '
        Me.TxtBoxSplitFfu_SFUFilename.Location = New System.Drawing.Point(179, 97)
        Me.TxtBoxSplitFfu_SFUFilename.Name = "TxtBoxSplitFfu_SFUFilename"
        Me.TxtBoxSplitFfu_SFUFilename.Size = New System.Drawing.Size(303, 26)
        Me.TxtBoxSplitFfu_SFUFilename.TabIndex = 54
        '
        'TxtBoxSplitFfu_FfuFilename
        '
        Me.TxtBoxSplitFfu_FfuFilename.Location = New System.Drawing.Point(179, 30)
        Me.TxtBoxSplitFfu_FfuFilename.Name = "TxtBoxSplitFfu_FfuFilename"
        Me.TxtBoxSplitFfu_FfuFilename.Size = New System.Drawing.Size(303, 26)
        Me.TxtBoxSplitFfu_FfuFilename.TabIndex = 53
        '
        'TabPage17
        '
        Me.TabPage17.Controls.Add(Me.LblDefaultAppAssocServ_Warning)
        Me.TabPage17.Controls.Add(Me.Label2)
        Me.TabPage17.Controls.Add(Me.TxtBoxDefaultAppAssocServ_ExportFilenameXML)
        Me.TabPage17.Controls.Add(Me.BtnDefaultAppAssocServ_ChooseFolder)
        Me.TabPage17.Controls.Add(Me.LblDefaultAppAssocServ_ExportFolder)
        Me.TabPage17.Controls.Add(Me.TxtBoxDefaultAppAssocServ_ExportFolder)
        Me.TabPage17.Controls.Add(Me.BtnDefaultAppAssocServ_ChooseFile)
        Me.TabPage17.Controls.Add(Me.LblDefaultAppAssocServ_FilenameXML)
        Me.TabPage17.Controls.Add(Me.TxtBoxDefaultAppAssocServ_ImportFilenameXML)
        Me.TabPage17.Controls.Add(Me.BtnDefaultAppAssocServ_Remove)
        Me.TabPage17.Controls.Add(Me.BtnDefaultAppAssocServ_Export)
        Me.TabPage17.Controls.Add(Me.BtnDefaultAppAssocServ_Import)
        Me.TabPage17.Controls.Add(Me.ChkBoxDefaultAppAssocServ_Online)
        Me.TabPage17.Controls.Add(Me.BtnDefaultAppAssocServ_GetDefaultAppAssoc)
        Me.TabPage17.Location = New System.Drawing.Point(4, 29)
        Me.TabPage17.Name = "TabPage17"
        Me.TabPage17.Size = New System.Drawing.Size(886, 350)
        Me.TabPage17.TabIndex = 16
        Me.TabPage17.Text = "Default Application Association Servicing"
        Me.TabPage17.UseVisualStyleBackColor = True
        '
        'LblDefaultAppAssocServ_Warning
        '
        Me.LblDefaultAppAssocServ_Warning.AutoSize = True
        Me.LblDefaultAppAssocServ_Warning.Location = New System.Drawing.Point(380, 108)
        Me.LblDefaultAppAssocServ_Warning.Name = "LblDefaultAppAssocServ_Warning"
        Me.LblDefaultAppAssocServ_Warning.Size = New System.Drawing.Size(401, 20)
        Me.LblDefaultAppAssocServ_Warning.TabIndex = 36
        Me.LblDefaultAppAssocServ_Warning.Text = "(Warning: Use export commande only on Online mode !)"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(5, 108)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(179, 20)
        Me.Label2.TabIndex = 35
        Me.Label2.Text = "Export Filename (.XML):"
        '
        'TxtBoxDefaultAppAssocServ_ExportFilenameXML
        '
        Me.TxtBoxDefaultAppAssocServ_ExportFilenameXML.Location = New System.Drawing.Point(9, 132)
        Me.TxtBoxDefaultAppAssocServ_ExportFilenameXML.Name = "TxtBoxDefaultAppAssocServ_ExportFilenameXML"
        Me.TxtBoxDefaultAppAssocServ_ExportFilenameXML.Size = New System.Drawing.Size(307, 26)
        Me.TxtBoxDefaultAppAssocServ_ExportFilenameXML.TabIndex = 34
        '
        'BtnDefaultAppAssocServ_ChooseFolder
        '
        Me.BtnDefaultAppAssocServ_ChooseFolder.Location = New System.Drawing.Point(322, 79)
        Me.BtnDefaultAppAssocServ_ChooseFolder.Name = "BtnDefaultAppAssocServ_ChooseFolder"
        Me.BtnDefaultAppAssocServ_ChooseFolder.Size = New System.Drawing.Size(125, 26)
        Me.BtnDefaultAppAssocServ_ChooseFolder.TabIndex = 33
        Me.BtnDefaultAppAssocServ_ChooseFolder.Text = "Choose Folder"
        Me.BtnDefaultAppAssocServ_ChooseFolder.UseVisualStyleBackColor = True
        '
        'LblDefaultAppAssocServ_ExportFolder
        '
        Me.LblDefaultAppAssocServ_ExportFolder.AutoSize = True
        Me.LblDefaultAppAssocServ_ExportFolder.Location = New System.Drawing.Point(4, 52)
        Me.LblDefaultAppAssocServ_ExportFolder.Name = "LblDefaultAppAssocServ_ExportFolder"
        Me.LblDefaultAppAssocServ_ExportFolder.Size = New System.Drawing.Size(108, 20)
        Me.LblDefaultAppAssocServ_ExportFolder.TabIndex = 31
        Me.LblDefaultAppAssocServ_ExportFolder.Text = "Export Folder:"
        '
        'TxtBoxDefaultAppAssocServ_ExportFolder
        '
        Me.TxtBoxDefaultAppAssocServ_ExportFolder.Location = New System.Drawing.Point(9, 79)
        Me.TxtBoxDefaultAppAssocServ_ExportFolder.Name = "TxtBoxDefaultAppAssocServ_ExportFolder"
        Me.TxtBoxDefaultAppAssocServ_ExportFolder.Size = New System.Drawing.Size(307, 26)
        Me.TxtBoxDefaultAppAssocServ_ExportFolder.TabIndex = 32
        '
        'BtnDefaultAppAssocServ_ChooseFile
        '
        Me.BtnDefaultAppAssocServ_ChooseFile.Location = New System.Drawing.Point(321, 201)
        Me.BtnDefaultAppAssocServ_ChooseFile.Name = "BtnDefaultAppAssocServ_ChooseFile"
        Me.BtnDefaultAppAssocServ_ChooseFile.Size = New System.Drawing.Size(125, 30)
        Me.BtnDefaultAppAssocServ_ChooseFile.TabIndex = 30
        Me.BtnDefaultAppAssocServ_ChooseFile.Text = "Choose File"
        Me.BtnDefaultAppAssocServ_ChooseFile.UseVisualStyleBackColor = True
        '
        'LblDefaultAppAssocServ_FilenameXML
        '
        Me.LblDefaultAppAssocServ_FilenameXML.AutoSize = True
        Me.LblDefaultAppAssocServ_FilenameXML.Location = New System.Drawing.Point(3, 178)
        Me.LblDefaultAppAssocServ_FilenameXML.Name = "LblDefaultAppAssocServ_FilenameXML"
        Me.LblDefaultAppAssocServ_FilenameXML.Size = New System.Drawing.Size(179, 20)
        Me.LblDefaultAppAssocServ_FilenameXML.TabIndex = 28
        Me.LblDefaultAppAssocServ_FilenameXML.Text = "Import Filename (.XML):"
        '
        'TxtBoxDefaultAppAssocServ_ImportFilenameXML
        '
        Me.TxtBoxDefaultAppAssocServ_ImportFilenameXML.Location = New System.Drawing.Point(8, 205)
        Me.TxtBoxDefaultAppAssocServ_ImportFilenameXML.Name = "TxtBoxDefaultAppAssocServ_ImportFilenameXML"
        Me.TxtBoxDefaultAppAssocServ_ImportFilenameXML.Size = New System.Drawing.Size(307, 26)
        Me.TxtBoxDefaultAppAssocServ_ImportFilenameXML.TabIndex = 29
        '
        'BtnDefaultAppAssocServ_Remove
        '
        Me.BtnDefaultAppAssocServ_Remove.Location = New System.Drawing.Point(468, 269)
        Me.BtnDefaultAppAssocServ_Remove.Name = "BtnDefaultAppAssocServ_Remove"
        Me.BtnDefaultAppAssocServ_Remove.Size = New System.Drawing.Size(315, 30)
        Me.BtnDefaultAppAssocServ_Remove.TabIndex = 27
        Me.BtnDefaultAppAssocServ_Remove.Text = "Remove Default Application Associations"
        Me.BtnDefaultAppAssocServ_Remove.UseVisualStyleBackColor = True
        '
        'BtnDefaultAppAssocServ_Export
        '
        Me.BtnDefaultAppAssocServ_Export.Location = New System.Drawing.Point(468, 75)
        Me.BtnDefaultAppAssocServ_Export.Name = "BtnDefaultAppAssocServ_Export"
        Me.BtnDefaultAppAssocServ_Export.Size = New System.Drawing.Size(315, 30)
        Me.BtnDefaultAppAssocServ_Export.TabIndex = 26
        Me.BtnDefaultAppAssocServ_Export.Text = "Export Default Application Associations"
        Me.BtnDefaultAppAssocServ_Export.UseVisualStyleBackColor = True
        '
        'BtnDefaultAppAssocServ_Import
        '
        Me.BtnDefaultAppAssocServ_Import.Location = New System.Drawing.Point(468, 201)
        Me.BtnDefaultAppAssocServ_Import.Name = "BtnDefaultAppAssocServ_Import"
        Me.BtnDefaultAppAssocServ_Import.Size = New System.Drawing.Size(315, 30)
        Me.BtnDefaultAppAssocServ_Import.TabIndex = 25
        Me.BtnDefaultAppAssocServ_Import.Text = "Import Default Application Associations"
        Me.BtnDefaultAppAssocServ_Import.UseVisualStyleBackColor = True
        '
        'ChkBoxDefaultAppAssocServ_Online
        '
        Me.ChkBoxDefaultAppAssocServ_Online.AutoSize = True
        Me.ChkBoxDefaultAppAssocServ_Online.Location = New System.Drawing.Point(758, 323)
        Me.ChkBoxDefaultAppAssocServ_Online.Name = "ChkBoxDefaultAppAssocServ_Online"
        Me.ChkBoxDefaultAppAssocServ_Online.Size = New System.Drawing.Size(125, 24)
        Me.ChkBoxDefaultAppAssocServ_Online.TabIndex = 24
        Me.ChkBoxDefaultAppAssocServ_Online.Text = "/Online option"
        Me.ChkBoxDefaultAppAssocServ_Online.UseVisualStyleBackColor = False
        '
        'BtnDefaultAppAssocServ_GetDefaultAppAssoc
        '
        Me.BtnDefaultAppAssocServ_GetDefaultAppAssoc.Location = New System.Drawing.Point(468, 25)
        Me.BtnDefaultAppAssocServ_GetDefaultAppAssoc.Name = "BtnDefaultAppAssocServ_GetDefaultAppAssoc"
        Me.BtnDefaultAppAssocServ_GetDefaultAppAssoc.Size = New System.Drawing.Size(315, 30)
        Me.BtnDefaultAppAssocServ_GetDefaultAppAssoc.TabIndex = 0
        Me.BtnDefaultAppAssocServ_GetDefaultAppAssoc.Text = "Get Default Application Associations"
        Me.BtnDefaultAppAssocServ_GetDefaultAppAssoc.UseVisualStyleBackColor = True
        '
        'BackgroundWorkerDISMCommand
        '
        '
        'Btn_ClearConsole
        '
        Me.Btn_ClearConsole.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_ClearConsole.Location = New System.Drawing.Point(788, 410)
        Me.Btn_ClearConsole.Name = "Btn_ClearConsole"
        Me.Btn_ClearConsole.Size = New System.Drawing.Size(113, 32)
        Me.Btn_ClearConsole.TabIndex = 19
        Me.Btn_ClearConsole.Text = "Clear console"
        Me.Btn_ClearConsole.UseVisualStyleBackColor = True
        '
        'TxtBox_DismVersion
        '
        Me.TxtBox_DismVersion.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TxtBox_DismVersion.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TxtBox_DismVersion.Location = New System.Drawing.Point(632, 417)
        Me.TxtBox_DismVersion.Name = "TxtBox_DismVersion"
        Me.TxtBox_DismVersion.Size = New System.Drawing.Size(147, 19)
        Me.TxtBox_DismVersion.TabIndex = 20
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(479, 416)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(147, 20)
        Me.Label1.TabIndex = 21
        Me.Label1.Text = "DISM version used:"
        '
        'frmMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(955, 718)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.TxtBox_DismVersion)
        Me.Controls.Add(Me.Btn_ClearConsole)
        Me.Controls.Add(Me.TabControl1)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.txtOutput)
        Me.Controls.Add(Me.MenuStrip1)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "frmMain"
        Me.Text = "DISM GUI"
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.TabPage1.PerformLayout()
        Me.TabPage2.ResumeLayout(False)
        Me.TabPage2.PerformLayout()
        Me.GroupBoxDriverManagement_DeleteDrivers.ResumeLayout(False)
        Me.GroupBoxDriverManagement_DeleteDrivers.PerformLayout()
        Me.GroupBoxDriverManagement_AddDrivers.ResumeLayout(False)
        Me.GroupBoxDriverManagement_AddDrivers.PerformLayout()
        Me.TabPage3.ResumeLayout(False)
        Me.TabPage3.PerformLayout()
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox4.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.TabPage4.ResumeLayout(False)
        Me.TabPage4.PerformLayout()
        Me.TabPage5.ResumeLayout(False)
        Me.TabPage5.PerformLayout()
        Me.TabPage6.ResumeLayout(False)
        Me.TabPage6.PerformLayout()
        Me.TabPage7.ResumeLayout(False)
        Me.TabPage7.PerformLayout()
        Me.TabPage8.ResumeLayout(False)
        Me.TabPage8.PerformLayout()
        Me.TabPage9.ResumeLayout(False)
        Me.TabPage9.PerformLayout()
        Me.TabPage10.ResumeLayout(False)
        Me.TabPage10.PerformLayout()
        Me.TabPage11.ResumeLayout(False)
        Me.TabPage11.PerformLayout()
        Me.TabPage12.ResumeLayout(False)
        Me.TabPage12.PerformLayout()
        Me.TabPage13.ResumeLayout(False)
        Me.TabPage13.PerformLayout()
        Me.TabPage14.ResumeLayout(False)
        Me.TabPage14.PerformLayout()
        Me.TabPage15.ResumeLayout(False)
        Me.TabPage15.PerformLayout()
        Me.TabPage16.ResumeLayout(False)
        Me.TabPage16.PerformLayout()
        Me.TabPage17.ResumeLayout(False)
        Me.TabPage17.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents TxtMountControl_WimFile As System.Windows.Forms.TextBox
    Friend WithEvents LblMountControl_WimFile As System.Windows.Forms.Label
    Friend WithEvents LblMountControl_MountLocation As System.Windows.Forms.Label
    Friend WithEvents TxtMountControl_MountLocation As System.Windows.Forms.TextBox
    Friend WithEvents dlgOpenFolder As System.Windows.Forms.FolderBrowserDialog
    Friend WithEvents dlgOpenFile As System.Windows.Forms.OpenFileDialog
    Friend WithEvents BtnMountControl_OpenWIM As System.Windows.Forms.Button
    Friend WithEvents BtnMountControl_OpenMount As System.Windows.Forms.Button
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents ToolsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents BtnMountControl_MountWim As System.Windows.Forms.Button
    Friend WithEvents CmbMountControl_Index As System.Windows.Forms.ComboBox
    Friend WithEvents AboutToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents BtnMountControl_DismountWim As System.Windows.Forms.Button
    Friend WithEvents txtOutput As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents BtnMountControl_OpenMountedFolder As System.Windows.Forms.Button
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents OpenDISMLogToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents BackgroundWorkerMount As System.ComponentModel.BackgroundWorker
    Friend WithEvents BackgroundWorkerDisMount As System.ComponentModel.BackgroundWorker
    Friend WithEvents TabControl1 As System.Windows.Forms.TabControl
    Friend WithEvents TabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage2 As System.Windows.Forms.TabPage
    Friend WithEvents LblDriverManagement_DriversFolderLocation As System.Windows.Forms.Label
    Friend WithEvents BtnDriverManagement_GetDrivers As System.Windows.Forms.Button
    Friend WithEvents TxtBoxDriverManagement_DriverFolderLocation As System.Windows.Forms.TextBox
    Friend WithEvents BtnDriverManagement_OpnDriverFolder As System.Windows.Forms.Button
    Friend WithEvents ChkDriverManagement_ForceUnsigned As System.Windows.Forms.CheckBox
    Friend WithEvents BtnDriverManagement_AddDrivers As System.Windows.Forms.Button
    Friend WithEvents BackgroundWorkerDISMCommand As System.ComponentModel.BackgroundWorker
    Friend WithEvents CleanupWIMToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents GetWIMInfoToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents BtnMountControl_DisplayWIMInfo As System.Windows.Forms.Button
    Friend WithEvents TabPage3 As System.Windows.Forms.TabPage
    Friend WithEvents btnGetPackages As System.Windows.Forms.Button
    Friend WithEvents TabPage4 As System.Windows.Forms.TabPage
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents txtPackageFile As System.Windows.Forms.TextBox
    Friend WithEvents btnOpenPackageFile As System.Windows.Forms.Button
    Friend WithEvents btnAddPackages As System.Windows.Forms.Button
    Friend WithEvents chkIgnoreCheck As System.Windows.Forms.CheckBox
    Friend WithEvents GroupBoxDriverManagement_AddDrivers As System.Windows.Forms.GroupBox
    Friend WithEvents BtnDriverManagement_GetAllDriverInfo As System.Windows.Forms.Button
    Friend WithEvents GroupBoxDriverManagement_DeleteDrivers As System.Windows.Forms.GroupBox
    Friend WithEvents BtnDriverManagement_DelDriver As System.Windows.Forms.Button
    Friend WithEvents TxtBoxDriverManagement_DelDriverLocation As System.Windows.Forms.TextBox
    Friend WithEvents LblDriverManagement_DriverName As System.Windows.Forms.Label
    Friend WithEvents GroupBox4 As System.Windows.Forms.GroupBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents btnRemovePackagePath As System.Windows.Forms.Button
    Friend WithEvents btnRemovePackageName As System.Windows.Forms.Button
    Friend WithEvents txtPackagePath As System.Windows.Forms.TextBox
    Friend WithEvents txtPackageName As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents ChkDriverManagement_Recurse As System.Windows.Forms.CheckBox
    Friend WithEvents btnGetFeatures As System.Windows.Forms.Button
    Friend WithEvents btnEnableFeature As System.Windows.Forms.Button
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents txtFeatPackagePath As System.Windows.Forms.TextBox
    Friend WithEvents txtFeatPackageName As System.Windows.Forms.TextBox
    Friend WithEvents txtFeatureName As System.Windows.Forms.TextBox
    Friend WithEvents chkEnablePkgPath As System.Windows.Forms.CheckBox
    Friend WithEvents chkEnablePkgName As System.Windows.Forms.CheckBox
    Friend WithEvents btnDisableFeature As System.Windows.Forms.Button
    Friend WithEvents CleanupImageToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents UseOnlineModeToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TabPage5 As System.Windows.Forms.TabPage
    Friend WithEvents btnGetTargetEditions As System.Windows.Forms.Button
    Friend WithEvents btGetCurrentEdition As System.Windows.Forms.Button
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents btnSetProdKey As System.Windows.Forms.Button
    Friend WithEvents txtProdKey As System.Windows.Forms.MaskedTextBox
    Friend WithEvents btnSetEdition As System.Windows.Forms.Button
    Friend WithEvents txtEdition As System.Windows.Forms.TextBox
    Friend WithEvents TabPage6 As System.Windows.Forms.TabPage
    Friend WithEvents btnChooseUnAttend As System.Windows.Forms.Button
    Friend WithEvents TxtBox_UnattendXMLFile As System.Windows.Forms.TextBox
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents btnApplyUnattend As System.Windows.Forms.Button
    Friend WithEvents TabPage7 As System.Windows.Forms.TabPage
    Friend WithEvents btnGetApps As System.Windows.Forms.Button
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents btnGetAppInfo As System.Windows.Forms.Button
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents btnCheckAppPatch As System.Windows.Forms.Button
    Friend WithEvents btnGetAppPatchInfo As System.Windows.Forms.Button
    Friend WithEvents btnGetAppPatches As System.Windows.Forms.Button
    Friend WithEvents txtPatchCode As System.Windows.Forms.MaskedTextBox
    Friend WithEvents txtProductCode As System.Windows.Forms.MaskedTextBox
    Friend WithEvents btnChooseMSP As System.Windows.Forms.Button
    Friend WithEvents txtPatchLocation As System.Windows.Forms.TextBox
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents dlgOpenXML As System.Windows.Forms.OpenFileDialog
    Friend WithEvents dlgOpenMSP As System.Windows.Forms.OpenFileDialog
    Friend WithEvents TabPage8 As System.Windows.Forms.TabPage
    Friend WithEvents btnAppend As System.Windows.Forms.Button
    Friend WithEvents cmbCompression As System.Windows.Forms.ComboBox
    Friend WithEvents lblCompression As System.Windows.Forms.Label
    Friend WithEvents lblName As System.Windows.Forms.Label
    Friend WithEvents TxtFileName As System.Windows.Forms.TextBox
    Friend WithEvents btnCreate As System.Windows.Forms.Button
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents btnCaptureDest As System.Windows.Forms.Button
    Friend WithEvents txtCaptureDest As System.Windows.Forms.TextBox
    Friend WithEvents txtCaptureSource As System.Windows.Forms.TextBox
    Friend WithEvents btnCaptureSrc As System.Windows.Forms.Button
    Friend WithEvents TabPage9 As System.Windows.Forms.TabPage
    Friend WithEvents cmbApplyIndex As System.Windows.Forms.ComboBox
    Friend WithEvents lblIndex As System.Windows.Forms.Label
    Friend WithEvents btnApply As System.Windows.Forms.Button
    Friend WithEvents lblDest As System.Windows.Forms.Label
    Friend WithEvents lblSource As System.Windows.Forms.Label
    Friend WithEvents btnBrowseDest As System.Windows.Forms.Button
    Friend WithEvents txtApplyDest As System.Windows.Forms.TextBox
    Friend WithEvents txtApplySource As System.Windows.Forms.TextBox
    Friend WithEvents btnBrowseSource As System.Windows.Forms.Button
    Friend WithEvents chkApplyVerify As System.Windows.Forms.CheckBox
    Friend WithEvents chkCaptureVerify As System.Windows.Forms.CheckBox
    Friend WithEvents ChkMountControl_ReadOnly As System.Windows.Forms.CheckBox
    Friend WithEvents LblMountControl_Size As Label
    Friend WithEvents LblMountControl_Description As Label
    Friend WithEvents LblMountControl_Name As Label
    Friend WithEvents TxtBoxMountControl_Size As TextBox
    Friend WithEvents TxtBoxMountControl_Description As TextBox
    Friend WithEvents TxtBoxMountControl_Name As TextBox
    Friend WithEvents Label24 As Label
    Friend WithEvents TxtNameMetadata As TextBox
    Friend WithEvents TabPage10 As TabPage
    Friend WithEvents TabPage11 As TabPage
    Friend WithEvents TabPage12 As TabPage
    Friend WithEvents TabPage13 As TabPage
    Friend WithEvents TabPage14 As TabPage
    Friend WithEvents TabPage15 As TabPage
    Friend WithEvents TabPage16 As TabPage
    Friend WithEvents BtnExportImage_ExportImage As Button
    Friend WithEvents BtnExportImage_BrowseDestination As Button
    Friend WithEvents BtnExportImage_BrowseSource As Button
    Friend WithEvents LblExportImage_Size As Label
    Friend WithEvents TxtBoxExportImage_Size As TextBox
    Friend WithEvents LblExportImage_Description As Label
    Friend WithEvents LblExportImage_Name As Label
    Friend WithEvents TxtBoxExportImage_Description As TextBox
    Friend WithEvents TxtBoxExportImage_Name As TextBox
    Friend WithEvents LblExportImage_Filename As Label
    Friend WithEvents TxtBoxExportImage_Filename As TextBox
    Friend WithEvents LblExportImage_Destination As Label
    Friend WithEvents LblExportImage_Source As Label
    Friend WithEvents TxtBoxExportImage_Destination As TextBox
    Friend WithEvents TxtBoxExportImage_Source As TextBox
    Friend WithEvents ChkBoxExportImage_WimBoot As CheckBox
    Friend WithEvents ChkBoxExportImage_CheckIntegrity As CheckBox
    Friend WithEvents CmbBoxExportImage_Compression As ComboBox
    Friend WithEvents LblExportImage_LevelCompression As Label
    Friend WithEvents ChkBoxExportImage_Bootable As CheckBox
    Friend WithEvents CmbBoxExportImage_Index As ComboBox
    Friend WithEvents LblExportImage_Index As Label
    Private WithEvents Label25 As Label
    Private WithEvents BtnLangAndInterServ_ApplyAllIntl As Button
    Private WithEvents LblLangAndInterServ_SetAllIntl As Label
    Private WithEvents BtnSetLanguage_DisplayInfo As Button
    Private WithEvents BtnExportDriverOnline As Button
    Private WithEvents LblExportDriverOnlineFolder As Label
    Private WithEvents TxtBoxExportDriverOnlineFolder As TextBox
    Private WithEvents BtnExportDriverOnlineFolderChoice As Button
    Private WithEvents BtnExportDriverOffline As Button
    Private WithEvents LblExportDriverOfflineChoisirDossierFolder As Label
    Private WithEvents TxtBoxExportDriverOfflineFolder As TextBox
    Private WithEvents BtnExportDriverOfflineFolderChoice As Button
    Friend WithEvents CmbBoxLangAndInterServ_SetAllIntl As ComboBox
    Private WithEvents BtnSplitImage_WIMChoice As Button
    Private WithEvents BtnSplitImage_TargetFolder As Button
    Private WithEvents LblSplitImage_DestinationFolder As Label
    Private WithEvents TxtBoxSplitImage_DestinationFolder As TextBox
    Private WithEvents BtnSplitImage_SplitImage As Button
    Private WithEvents ChkBoxSplitImage_CheckIntegrity As CheckBox
    Private WithEvents LblSplitImage_SplitSize As Label
    Private WithEvents TxtBoxSplitImage_Filesize As TextBox
    Private WithEvents LblSplitImage_SWMFilename As Label
    Private WithEvents LblSplitImage_WIMFilename As Label
    Private WithEvents TxtBoxSplitImage_SWMFilename As TextBox
    Private WithEvents TxtBoxSplitImage_WIMFilename As TextBox
    Private WithEvents LblCaptureFfu_Description As Label
    Private WithEvents TxtBoxCaptureFfu_Description As TextBox
    Private WithEvents LstBoxCaptureFfu_LogicalDrive As ListBox
    Private WithEvents LblCaptFfu_LogicalDrive As Label
    Private WithEvents LblCaptFfu_Name As Label
    Private WithEvents TxtBoxCaptFfu_Name As TextBox
    Private WithEvents LblCaptFfu_PlatformID As Label
    Private WithEvents TxtBoxCaptFfu_PlatformID As TextBox
    Private WithEvents Label27 As Label
    Private WithEvents LblCaptFfu_TargetFilename As Label
    Private WithEvents LblCaptFfu_TargetFolder As Label
    Private WithEvents LblCaptFfu_PhysicalDrive As Label
    Private WithEvents CmbBoxCaptureFfu_Compression As ComboBox
    Private WithEvents TxtBoxCaptFfu_TargetFilename As TextBox
    Private WithEvents TxtBoxCaptFfu_TargetFolder As TextBox
    Private WithEvents TxtBoxCaptFfu_PhysicalDrive As TextBox
    Private WithEvents BtnCaptFfu_StartCapture As Button
    Private WithEvents BtnCaptureFfu_SetTargetFolder As Button
    Private WithEvents BtnCaptureFfu_UpdateLogicalDrive As Button
    Private WithEvents LstBoxApplyFfuImage_LogicalDrive As ListBox
    Private WithEvents LblApplyFfuImage_LogicalDrive As Label
    Private WithEvents LblApplyFfuImage_MotifSFUFile As Label
    Private WithEvents LblApplyFfuImage_SourceFilename As Label
    Private WithEvents LblApplyFfuImage_PhysicalDrive As Label
    Private WithEvents TxtBoxApplyFfuImageFfu_MotifSFUFile As TextBox
    Private WithEvents TxtBoxApplyFfuImage_FfuSourceFilename As TextBox
    Private WithEvents TxtBoxApplyFfuImage_PhysicalDrive As TextBox
    Private WithEvents BtnApplyFfuImage_ApplyFfuImage As Button
    Private WithEvents BtnApplyFfuImage_SelectFfuFile As Button
    Private WithEvents BtnApplyFfuImage_UpdateLogicalDrive As Button
    Private WithEvents BtnSplitFfu_SelectFfuFile As Button
    Private WithEvents BtnSplitFfu_SelectTargetFolder As Button
    Private WithEvents LblSplitFfu_TargetFolder As Label
    Private WithEvents TxtBoxSplitFfu_TargetFolder As TextBox
    Private WithEvents BtnSplitFfuImage_StartSplitImage As Button
    Private WithEvents ChkBoxSplitFfu_CheckIntegrity As CheckBox
    Private WithEvents LblSplitFfu_SplitFileSize As Label
    Private WithEvents TxtBoxSplitFfu_SplitFileSize As TextBox
    Private WithEvents LblSplitFfu_SFUFilename As Label
    Private WithEvents LblSplitFfu_FfuFilename As Label
    Private WithEvents TxtBoxSplitFfu_SFUFilename As TextBox
    Private WithEvents TxtBoxSplitFfu_FfuFilename As TextBox
    Friend WithEvents Label26 As Label
    Friend WithEvents TxtBoxCaptureWIM_Description As TextBox
    Friend WithEvents LblApplyWim_Size As Label
    Friend WithEvents TxtBoxApplyWim_Size As TextBox
    Friend WithEvents LblApplyWim_Description As Label
    Friend WithEvents LblApplyWim_Name As Label
    Friend WithEvents TxtBoxApplyWim_Description As TextBox
    Friend WithEvents TxtBoxApplyWim_Name As TextBox
    Friend WithEvents ChkBoxDriverManagement_Online As CheckBox
    Friend WithEvents ChkBoxPackageManagement_Online As CheckBox
    Friend WithEvents Btn_ClearConsole As Button
    Friend WithEvents TxtBox_DismVersion As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents ChkBoxFeatureManagement_Online As CheckBox
    Friend WithEvents ChkBoxEditionServicing_Online As CheckBox
    Friend WithEvents ChkBoxUnattendedServicing_Online As CheckBox
    Friend WithEvents LblApplySource_PatternSWMFile As Label
    Friend WithEvents TxtBoxApplySource_PatternSWMFile As TextBox
    Friend WithEvents BtnMountControl_DisplayImageInfo As Button
    Friend WithEvents BtnGetPackageInfo As Button
    Friend WithEvents TxtLbl_Or As Label
    Friend WithEvents TabPage17 As TabPage
    Friend WithEvents BtnDefaultAppAssocServ_Export As Button
    Friend WithEvents BtnDefaultAppAssocServ_Import As Button
    Friend WithEvents ChkBoxDefaultAppAssocServ_Online As CheckBox
    Friend WithEvents BtnDefaultAppAssocServ_GetDefaultAppAssoc As Button
    Friend WithEvents BtnDefaultAppAssocServ_Remove As Button
    Friend WithEvents BtnDefaultAppAssocServ_ChooseFile As Button
    Friend WithEvents LblDefaultAppAssocServ_FilenameXML As Label
    Friend WithEvents TxtBoxDefaultAppAssocServ_ImportFilenameXML As TextBox
    Friend WithEvents BtnDefaultAppAssocServ_ChooseFolder As Button
    Friend WithEvents LblDefaultAppAssocServ_ExportFolder As Label
    Friend WithEvents TxtBoxDefaultAppAssocServ_ExportFolder As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents TxtBoxDefaultAppAssocServ_ExportFilenameXML As TextBox
    Friend WithEvents LblDefaultAppAssocServ_Warning As Label
    Friend WithEvents CmbBoxLangAndInterServ_SetInputLocal As ComboBox
    Private WithEvents BtnLangAndInterServ_ApplyInputLocale As Button
    Private WithEvents LblLangAndInterServ_SetInputLocale As Label
    Friend WithEvents CmbBoxLangAndInterServ_SetUserLocale As ComboBox
    Private WithEvents BtnLangAndInterServ_ApplyUserLocale As Button
    Private WithEvents LblLangAndInterServ_SetUserLocale As Label
    Friend WithEvents CmbBoxLangAndInterServ_SetUILang_SysLocale As ComboBox
    Private WithEvents BtnLangAndInterServ_ApplySysLocale As Button
    Private WithEvents LblLangAndInterServ_SetSysLocale As Label
    Friend WithEvents CmbBoxLangAndInterServ_SetSysUILang As ComboBox
    Private WithEvents BtnLangAndInterServ_ApplySysUILang As Button
    Private WithEvents LblLangAndInterServ_SetSysUILang As Label
    Friend WithEvents CmbBoxLangAndInterServ_SetUILangFallback As ComboBox
    Private WithEvents BtnLangAndInterServ_ApplyUILangFallback As Button
    Private WithEvents LblLangAndInterServ_SetUILangFallback As Label
    Friend WithEvents CmbBoxLangAndInterServ_SetUILang As ComboBox
    Private WithEvents BtnLangAndInterServ_ApplyUILang As Button
    Private WithEvents LblLangAndInterServ_SetUILang As Label
    Friend WithEvents CmbBoxLangAndInterServ_GenLanINI As ComboBox
    Private WithEvents Button9 As Button
    Private WithEvents LblLangAndInterServ_GenLanINI As Label
    Friend WithEvents CmbBoxLangAndInterServ_SetSKUIntlDefaults As ComboBox
    Private WithEvents Button8 As Button
    Private WithEvents LblLangAndInterServ_SetSKUIntlDefaults As Label
    Friend WithEvents CmbBoxLangAndInterServ_SetTimeZone As ComboBox
    Private WithEvents BtnLangAndInterServ_ApplyTimeZone As Button
    Private WithEvents LblLangAndInterServ_SetTimeZone As Label
    Friend WithEvents CmbBoxLangAndInterServ_Distribution As ComboBox
    Private WithEvents LblLangAndInterServ_Distribution As Label
    Friend WithEvents CmbBoxLangAndInterServ_SetSetupUILang As ComboBox
    Private WithEvents LblLangAndInterServ_SetupUILang As Label
    Private WithEvents BtnLangAndInterServ_ApplyDistribution As Button
    Private WithEvents BtnLangAndInterServ_ApplySetupUILang As Button
    Private WithEvents BtnLangAndInterServ_ApplyGenLangINI As Button
    Private WithEvents BtnLangAndInterServ_ApplySKUIntlDefaults As Button
    Friend WithEvents ChkBoxLangAndInterServ_Online As CheckBox
End Class

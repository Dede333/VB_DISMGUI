﻿Imports System.Globalization                    ' for culture, language and zone
Imports System.Text
Imports System.IO
Imports System.Text.RegularExpressions
Imports System.Management

Public Class frmMain
    Public Property RedirectStandardOutput As Boolean
    Dim strFolderName As String                 ' FolderName of Wim file
    Dim WIMMounted As Boolean = False           ' flag WIMMounted value is True if mounted
    Dim strMountedImageLocation As String       ' Path to Wim mounted
    Dim strIndex As String                      ' index of wim
    Dim strWIM As String                        ' name of wim file
    Dim strOutput As String                     ' result of dism command
    Dim strDISMExitCode As String               ' return code error of dism command
    Dim blnDISMCommit As Boolean                ' Flag blnDISMCommit: blnDISMCommit = True (use for commit change)
    Dim strDriverLocation As String             ' Path to driver folder
    Dim blnForceUnsigned As Boolean             ' Flag for force unsigned drivers
    Dim strDISMArguments As String              ' arguments for DISM command
    Dim strPackageLocation As String            ' Path to package folder
    Dim strLocation As String                   ' 
    Dim blnIgnoreCheck As Boolean               ' flag ignore check 
    Dim strDelDriverLocation As String          ' Path to driver deleted folder
    Dim strPackageName As String                ' name of installed package
    Dim strPackagePath As String                ' folder of package
    Dim strFeatureName As String                ' feature name 
    Dim OnlineMode As Boolean = False           ' flag OnlineMode / OfflineMode
    Dim strProductKey As String                 ' product key of windows
    Dim strEdition As String                    ' edition of windows
    Dim strXMLFileName As String                ' Unattend file
    Dim strProductCode As String                ' product code
    Dim strPatchCode As String                  ' Path to Patch windows 
    Dim strMSPFileName As String                ' Name of patch windows
    Dim strSource As String
    Dim strDest As String
    Dim strFilename As String
    Dim strNameMetadata As String
    Dim strNameDescription As String
    Dim strCompression As String
    Dim strAppendIndex As String

    Dim ListInfosWimGestionMontage As New List(Of InfosWIM) ' For index Gestion Montage
    Dim ListInfosWimApplyImage As New List(Of InfosWIM)     ' For index Appliquer Image
    Dim ListInfosWimExportImage As New List(Of InfosWIM)    ' For index Export Image
    '
    ' Sub btnOpenWIM_Click
    ' 
    ' Use for Open File dialog Box WIM/ESD
    ' save the result on txtWIM form variable
    ' Warning: It's not possible to mount ESD image but you can verify index from ESD file !
    ' Only Wim file can be mounted !
    ' "GestionMontage_WimInfos.txt" is creating on the current application folder
    ' rev: 08/26/2021
    '
    Private Sub btnOpenWIM_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnMountControl_OpenWIM.Click

        ' Dim strFileName As String
        Dim DidWork As Integer                                  ' result for dialogue box

        dlgOpenFile.InitialDirectory = "c:\"                    ' default root path
        dlgOpenFile.Title = "Choose WIM file to Open"           ' title of dialog box
        dlgOpenFile.Filter = ("WIM Files(*.wim)|*.wim|ESD Files(*.ESD)|*.ESD|VHD Files(*.VHD)|*.VHD_
                              |Ffu Files(*.Ffu)|*.Ffu|All Files (*.*)|*.*") ' filter extension
        DidWork = dlgOpenFile.ShowDialog                        ' show dialog box

        If DidWork = DialogResult.OK Then                       ' user selected filename from dialog box ?
            ' strFileName = dlgOpenFile.FileName
            TxtMountControl_WimFile.Text = dlgOpenFile.FileName                  ' user choice filename
            DisplayWimInfos("GestionMontage_WimInfos.txt", TxtMountControl_WimFile.Text)
            Me.CmbMountControl_Index.Items.Clear()                           ' clear index count in Form
            ListInfosWimGestionMontage.Clear()                  ' clear list<T> description index
            UpdateListIndexWim("GestionMontage_WimInfos.txt", ListInfosWimGestionMontage) ' Mise à jour des index

            For IdxFor As Integer = 1 To ListInfosWimGestionMontage.Count
                Me.CmbMountControl_Index.Items.Add(IdxFor.ToString)
            Next
        End If
    End Sub
    '
    ' Sub DisplayWimInfos
    ' 
    ' Retreive Information Of WIM or ESD file
    ' rev: 26/06/2022
    '
    Private Sub DisplayWimInfos(NomFichier As String, NomFichierWim As String)

        strWIM = NomFichierWim                      ' Wim or ESD filename
        strDISMArguments = "/Get-WimInfo /WimFile:""" & NomFichierWim & """" ' arguments line for dism.exe

        'txtOutput.Text = strDISMArguments
        BackgroundWorkerDISMCommand.RunWorkerAsync(strDISMArguments)
        frmProgress.ShowDialog()

        Try
            If System.IO.File.Exists(NomFichier) = True Then ' delete old file (no append function)
                System.IO.File.Create(NomFichier).Dispose()
            End If
            ' creation new file on the current application directory
            Using sw As StreamWriter = New StreamWriter(NomFichier, True, Encoding.UTF8)
                sw.WriteLine(strOutput)
                sw.Close()
            End Using
        Catch ex As Exception
            ' Let the user know what went wrong.
            'Console.WriteLine("The file could not be read:")
            'Console.WriteLine(e.Message)
            MessageBox.Show("DisplayWimInfos Error on created filename wiminfos.txt: " + ex.Message.ToString())
        End Try

    End Sub
    '
    ' Create a list of informations index from wim or esd file automatically
    ' warning: extract string from dism command depend of culture and langage from environnement
    ' You must modified offset from substring in consequences !
    ' rev: 26/08/2021
    '
    Private Sub UpdateListIndexWim(NomFichier As String, ByRef ListInfosWim As List(Of InfosWIM))
        Dim FileName As String = NomFichier           ' filename in application folder
        Dim LigneFic As String = ""
        Dim StrSansEspace As String = ""
        Dim IdxDebStr As Integer

        ListInfosWim.Clear()                          ' clear list of InfosWim

        Try
            Using sr As StreamReader = New StreamReader(NomFichier) ' open stream from file
                While (sr.EndOfStream <> True)                      ' end of file ?
                    IdxDebStr = 0                                   ' use for research substring
                    LigneFic = sr.ReadLine()                        ' read a line
                    IdxDebStr = LigneFic.IndexOf("Index")           ' "Index" position search for sync
                    If (IdxDebStr = 0) Then                         ' Index is found
                        Dim AWim As InfosWIM = New InfosWIM()       ' create new instance of InfosWim

                        AWim.Index = Convert.ToInt32(LigneFic.Substring(IdxDebStr + 8, (LigneFic.Length) - 8)) ' index number Int32
                        LigneFic = sr.ReadLine()                    ' read a line
                        AWim.Nom = LigneFic.Substring(6, (LigneFic.Length) - 6) ' Name for this index of wim
                        LigneFic = sr.ReadLine()                    ' read a line
                        AWim.Description = LigneFic.Substring(14, (LigneFic.Length) - 14) ' Description for this index of wim
                        LigneFic = sr.ReadLine()                ' lecture taille wim ' read a line
                        ' StrSansEspace = LigneFic.Replace("\u00A0", String.Empty) ' supprime les espaces en UTF8
                        StrSansEspace = Regex.Replace(LigneFic, "\s+", "") ' delete space from string before conversion !
                        AWim.Taille = Convert.ToUInt64(StrSansEspace.Substring(7, StrSansEspace.Length - 13)) ' size for this index of wim
                        ListInfosWim.Add(AWim)                      ' add to list
                    End If
                End While
                sr.Close()                                          ' close stream reader
            End Using                                               ' dispose stream

        Catch ex As Exception                                       ' catch exception
            MessageBox.Show("UpdateListIndexWim, read error from file: " + ex.Message.ToString()) ' message error
        End Try
    End Sub
    '
    ' Sub btnOpenMount_Click
    '
    ' use for select an empty folder for mount wim file later
    ' save the result on txtMount form variable
    ' Revision 20/04/2022

    Private Sub btnOpenMount_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnMountControl_OpenMount.Click
        Dim dirs As String()
        Dim files As String()
        Dim DidWork As Integer

        dlgOpenFolder.ShowNewFolderButton = False
        dlgOpenFolder.RootFolder = Environment.SpecialFolder.MyComputer
        DidWork = dlgOpenFolder.ShowDialog()
        If DidWork = DialogResult.OK Then
            TxtMountControl_MountLocation.Text = dlgOpenFolder.SelectedPath
        End If

        Try
            dirs = System.IO.Directory.GetDirectories(TxtMountControl_MountLocation.Text)
            files = System.IO.Directory.GetFiles(TxtMountControl_MountLocation.Text)
            If dirs.Length = 0 And files.Length = 0 Then ' check if there is no directory or filename
            Else
                MessageBox.Show("You must choose an empty folder to mount the WIM !")
            End If
        Catch ex As Exception
            MessageBox.Show("btnOpenMount_Click, error detected: " + ex.Message.ToString()) ' message error
        End Try
    End Sub
    '
    ' Sub btnMount_Click
    '
    Private Sub btnMount_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnMountControl_MountWim.Click
        txtOutput.Text = ""
        If TxtMountControl_WimFile.Text = "" Or TxtMountControl_MountLocation.Text = "" Or CmbMountControl_Index.Text = "" Then
            MsgBox("You must select a WIM file, mount location and index for mount wim first !")
        Else
            ' txtMount.Text = Replace(txtMount.Text, """", "") ' prevent for filename with space
            strFolderName = TxtMountControl_MountLocation.Text                    ' save path in global variable 
            strIndex = CmbMountControl_Index.Text                         ' save index
            ' txtWIM.Text = Replace(txtWIM.Text, """", "")     ' prevent for filename with space
            strWIM = TxtMountControl_WimFile.Text                             ' save path in global variable
            BackgroundWorkerMount.RunWorkerAsync()           ' run async command
            frmProgress.ShowDialog()                         ' show speudo progress bar
            ' txtOutput.Text = txtOutput.Text & strOutput & vbCrLf & "Exit code processus: " & strDISMExitCode     ' update console messages
        End If
    End Sub
    '
    ' Sub AboutToolStripMenuItem_Click
    ' 
    ' use from StripMenu for show dialogue box About this software
    '
    Private Sub AboutToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AboutToolStripMenuItem.Click
        frmAbout.ShowDialog()                                  ' about author

    End Sub
    '
    ' Sub frmMain_FormClosing
    '
    ' use for ask user to dismount or not wim file before close the application
    ' check WimMounted variable globale !
    '
    Private Sub frmMain_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        If MessageBox.Show("Are you sure you want to exit?", "Exit?", MessageBoxButtons.YesNo, MessageBoxIcon.Question) = DialogResult.Yes Then
            If WIMMounted = True Then
                If MessageBox.Show("You currently have a WIM Mounted.  Do you want to dismount before exiting?", "WIM Mounted", MessageBoxButtons.YesNo, MessageBoxIcon.Question) = DialogResult.Yes Then
                    'DismountWIM()
                    BackgroundWorkerDisMount.RunWorkerAsync()
                    frmProgress.ShowDialog()
                Else
                    e.Cancel = False
                End If
            Else
                'Do Nothing - Exit form
            End If
        Else
            e.Cancel = True
        End If
    End Sub
    '
    ' Sub btnDismount_Click
    '
    ' Dismount or not wim file before close the application
    '
    Private Sub btnDismount_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnMountControl_DismountWim.Click
        strFolderName = TxtMountControl_MountLocation.Text   ' save in globale variable strFolderName
        strIndex = CmbMountControl_Index.Text        ' save in globale variable strIndex 
        strWIM = TxtMountControl_WimFile.Text            ' save in globale variable strWim
        txtOutput.Text = ""             ' clear the console view
        BackgroundWorkerDisMount.RunWorkerAsync()
        frmProgress.ShowDialog()
        'txtOutput.Text = txtOutput.Text & strOutput  ' display the result (historical)
    End Sub
    '
    ' Sub btnOpenFolder_Click
    '
    ' start a new task (processus explorer) with mount wim folder parameter
    '
    Private Sub btnOpenFolder_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnMountControl_OpenMountedFolder.Click
        Dim OpenFolder As New Process
        Process.Start("Explorer.exe", TxtMountControl_MountLocation.Text)
    End Sub
    '
    ' Sub btnExit_Click
    '
    ' Close the actual form
    '
    Private Sub btnExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Me.Close()
    End Sub
    '
    ' Sub  OpenDISMLogToolStripMenuItem_Click
    '
    ' start a new task (processus Notepad.exe) to dism log folder
    '
    Private Sub OpenDISMLogToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OpenDISMLogToolStripMenuItem.Click
        Dim strWinDir As String = System.Environment.GetEnvironmentVariable("windir")
        Dim OpenDISMLog As New Process
        Process.Start("Notepad.exe", strWinDir & "\Logs\DISM\dism.log")
    End Sub
    '
    ' Sub  btnGetDrivers_Click
    ' Use to display drivers in Offline or Online mode
    '
    Private Sub btnGetDrivers_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnDriverManagement_GetDrivers.Click
        If (WIMMounted = False And ChkBoxDriverManagement_Online.Checked = False) Then
            MessageBox.Show("No WIM is mounted.  You must mount a WIM before running this command (Offline mode) or use /Online option.")
        Else
            If (ChkBoxDriverManagement_Online.Checked) Then
                strDISMArguments = "/Online" & " /Get-Drivers"
            Else
                strDISMArguments = "/Image:""" & strMountedImageLocation & """" & " /Get-Drivers"
            End If
            BackgroundWorkerDISMCommand.RunWorkerAsync(strDISMArguments)
            'BackgroundGetDrivers.RunWorkerAsync()
            frmProgress.ShowDialog()
            'txtOutput.Text = txtOutput.Text & strOutput
        End If
    End Sub
    '
    ' Sub BackgroundWorkerMount_DoWork
    '
    ' mount Wim file in readwrite mode or readonly
    '
    Private Sub BackgroundWorkerMount_DoWork(ByVal sender As System.Object, ByVal e As System.ComponentModel.DoWorkEventArgs) Handles BackgroundWorkerMount.DoWork

        strDISMExitCode = ""                ' reset return exit code value
        Dim DISM As New Process()
        DISM.StartInfo.StandardOutputEncoding = Encoding.GetEncoding(CultureInfo.CurrentCulture.TextInfo.OEMCodePage)
        DISM.StartInfo.RedirectStandardOutput = True
        DISM.StartInfo.RedirectStandardError = True
        DISM.StartInfo.UseShellExecute = False
        DISM.StartInfo.CreateNoWindow = True
        DISM.StartInfo.FileName = "dism.exe"
        If ChkMountControl_ReadOnly.Checked = True Then
            DISM.StartInfo.Arguments = "/Mount-WIM /ReadOnly /WimFile:""" & strWIM & """" & " /Index:" & strIndex & " /MountDir:" & """" & strFolderName & """"
        Else
            DISM.StartInfo.Arguments = "/Mount-WIM /WimFile:""" & strWIM & """" & " /Index:" & strIndex & " /MountDir:" & """" & strFolderName & """"
        End If

        txtOutput.Text = "Command line running is: dism.exe " & DISM.StartInfo.Arguments & vbCrLf
        DISM.Start()
        'strOutput = strOutput & DISM.StandardOutput.ReadToEnd()
        strOutput = DISM.StandardOutput.ReadToEnd()
        DISM.WaitForExit()
        strDISMExitCode = DISM.ExitCode         ' save return value of dism function
        txtOutput.Text = txtOutput.Text & strOutput & vbCrLf & "Exit code processus: " & DISM.ExitCode
    End Sub
    '
    ' BackgroundWorkerMount_RunWorkerCompleted
    '
    Private Sub BackgroundWorkerMount_RunWorkerCompleted(ByVal sender As Object, ByVal e As System.ComponentModel.RunWorkerCompletedEventArgs) Handles BackgroundWorkerMount.RunWorkerCompleted
        'Check to see if WIM mounted correctly
        If strDISMExitCode = "0" Then
            BtnMountControl_MountWim.Enabled = False
            BtnMountControl_DismountWim.Enabled = True
            WIMMounted = True
            If strMountedImageLocation = "" Then
                strMountedImageLocation = strFolderName
            Else
                'Do Nothing
            End If
            frmProgress.Close()
        Else
            frmProgress.Close()
        End If
    End Sub
    '
    ' Sub BackgroundWorkerDisMount_DoWork
    ' 
    ' Use for dismount wim image
    '
    Private Sub BackgroundWorkerDisMount_DoWork(ByVal sender As System.Object, ByVal e As System.ComponentModel.DoWorkEventArgs) Handles BackgroundWorkerDisMount.DoWork
        strDISMExitCode = ""

        If MessageBox.Show("Do you want to commit changes?", "WIM Mounted", MessageBoxButtons.YesNo, MessageBoxIcon.Question) = DialogResult.Yes Then
            blnDISMCommit = True
        Else
            blnDISMCommit = False
        End If

        Dim DISM As New Process()
        DISM.StartInfo.StandardOutputEncoding = Encoding.GetEncoding(CultureInfo.CurrentCulture.TextInfo.OEMCodePage)
        DISM.StartInfo.RedirectStandardOutput = True
        DISM.StartInfo.RedirectStandardError = True
        DISM.StartInfo.UseShellExecute = False
        DISM.StartInfo.CreateNoWindow = True
        DISM.StartInfo.FileName = "dism.exe"

        If blnDISMCommit = True Then
            DISM.StartInfo.Arguments = "/Unmount-wim /MountDir:""" & strFolderName & """ /Commit"
        Else
            DISM.StartInfo.Arguments = "/Unmount-wim /MountDir:""" & strFolderName & """ /Discard"
        End If

        txtOutput.Text = "Command line running is: dism.exe " & DISM.StartInfo.Arguments & vbCrLf
        DISM.Start()
        strOutput = DISM.StandardOutput.ReadToEnd()
        DISM.WaitForExit()
        strDISMExitCode = DISM.ExitCode
        txtOutput.Text = txtOutput.Text & strOutput & vbCrLf & "Exit code processus: " & DISM.ExitCode
    End Sub
    '
    ' Sub BackgroundWorkerDisMount_RunWorkerCompleted
    ' 
    Private Sub BackgroundWorkerDisMount_RunWorkerCompleted(ByVal sender As Object, ByVal e As System.ComponentModel.RunWorkerCompletedEventArgs) Handles BackgroundWorkerDisMount.RunWorkerCompleted
        'Verify DIM was dismounted
        If strDISMExitCode = "0" Then
            BtnMountControl_MountWim.Enabled = True
            BtnMountControl_DismountWim.Enabled = False
            WIMMounted = False
            strMountedImageLocation = ""
            frmProgress.Close()
        Else
            frmProgress.Close()
        End If
    End Sub
    '
    ' Sub btnOpnDriverFolder_Click
    ' 
    Private Sub btnOpnDriverFolder_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnDriverManagement_OpnDriverFolder.Click
        TxtBoxDriverManagement_DriverFolderLocation.Text = OpenFolder()
    End Sub
    '
    ' Sub btnAddDriver_Click
    ' Use to add drivers on offline image (not for online image)
    ' 
    Private Sub btnAddDriver_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnDriverManagement_AddDrivers.Click
        If WIMMounted = False Then
            MessageBox.Show("No WIM is mounted.  You must mount a WIM before running this command.")
        Else
            If TxtBoxDriverManagement_DriverFolderLocation.Text = "" Then
                MessageBox.Show("You must specify a folder where your drivers are located.")
            Else
                strDriverLocation = TxtBoxDriverManagement_DriverFolderLocation.Text
                If ChkDriverManagement_ForceUnsigned.Checked = True Then
                    'blnForceUnsigned = True
                    strDISMArguments = "/Image:""" & strMountedImageLocation & """" & " /Add-Driver /driver:""" & strDriverLocation & """" & " /ForceUnsigned "
                Else
                    'blnForceUnsigned = False
                    strDISMArguments = "/Image:""" & strMountedImageLocation & """" & " /Add-Driver /driver:""" & strDriverLocation & """" & " "
                End If

                If ChkDriverManagement_Recurse.Checked = True Then
                    strDISMArguments = strDISMArguments & "/Recurse"
                Else
                    'Do Nothing
                End If
                BackgroundWorkerDISMCommand.RunWorkerAsync(strDISMArguments)
                frmProgress.ShowDialog()
            End If
        End If
        ' txtOutput.Text = txtOutput.Text & strOutput
    End Sub
    '
    ' Sub GetWIMInfoToolStripMenuItem_Click
    ' 
    Private Sub GetWIMInfoToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GetWIMInfoToolStripMenuItem.Click
        strDISMArguments = "/Get-MountedWIMInfo"
        BackgroundWorkerDISMCommand.RunWorkerAsync(strDISMArguments)
        frmProgress.ShowDialog()
        REM txtOutput.Text = txtOutput.Text & strOutput
    End Sub
    ' 
    ' Run an async command processus DISM.exe
    ' display line argument of dism command, result and exit code of processus
    ' strInput is the command line argument
    ' 
    Private Sub BackgroundWorkerDISMCommand_DoWork(ByVal sender As System.Object, ByVal e As System.ComponentModel.DoWorkEventArgs) Handles BackgroundWorkerDISMCommand.DoWork
        Dim strInput As String = e.Argument  ' retreive argument of dism command
        Dim DISM As New Process()            ' create new process for DISM processus

        strDISMExitCode = ""                 ' reset exit code for processus
        DISM.StartInfo.RedirectStandardOutput = True ' redirect output console enabled
        DISM.StartInfo.StandardOutputEncoding = Encoding.GetEncoding(CultureInfo.CurrentCulture.TextInfo.OEMCodePage) ' encodage OEM
        DISM.StartInfo.RedirectStandardError = True  ' redirect standard error
        DISM.StartInfo.UseShellExecute = False       ' no shell
        DISM.StartInfo.CreateNoWindow = True         ' no window
        DISM.StartInfo.FileName = "DISM.EXE"         ' name of processus call
        DISM.StartInfo.Arguments = strInput          ' arguments for command ligne
        txtOutput.Text = "Command line that running is: dism.exe " & DISM.StartInfo.Arguments & vbCrLf ' show result command line
        DISM.Start()                                 ' start async processus
        strOutput = DISM.StandardOutput.ReadToEnd()  ' read console
        DISM.WaitForExit()                           ' wait for end of processus
        strDISMExitCode = DISM.ExitCode              ' store exit code of processus
        txtOutput.Text = txtOutput.Text & strOutput & vbCrLf & "Exit code processus: " & DISM.ExitCode
        DISM.Close()                                 ' close processus
    End Sub
    ' 
    ' BackgroundWorkerDISMCommand_RunWorkerCompleted
    ' 
    Private Sub BackgroundWorkerDISMCommand_RunWorkerCompleted(ByVal sender As Object, ByVal e As System.ComponentModel.RunWorkerCompletedEventArgs) Handles BackgroundWorkerDISMCommand.RunWorkerCompleted
        strDISMArguments = ""
        frmProgress.Close()
    End Sub
    ' 
    ' CleanupWIMToolStripMenuItem_Click
    ' 
    Private Sub CleanupWIMToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CleanupWIMToolStripMenuItem.Click
        strDISMArguments = "/Cleanup-WIM"
        BackgroundWorkerDISMCommand.RunWorkerAsync(strDISMArguments)
        frmProgress.ShowDialog()
        ' txtOutput.Text = txtOutput.Text & strOutput
    End Sub
    '
    ' Sub btnDisplayWIMInfo_Click
    '
    ' Display Wim informations
    '
    Private Sub btnDisplayWIMInfo_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnMountControl_DisplayWIMInfo.Click

        txtOutput.Text = ""             ' reset console view
        If TxtMountControl_WimFile.Text = "" Then
            MsgBox("You must select a WIM file first")
        Else
            strWIM = TxtMountControl_WimFile.Text
            strDISMArguments = "/Get-WimInfo /WimFile:""" & strWIM & """"
            BackgroundWorkerDISMCommand.RunWorkerAsync(strDISMArguments)
            frmProgress.ShowDialog()
            'txtOutput.Text = txtOutput.Text & strOutput
        End If
    End Sub
    '
    ' Sub btnGetPackages_Click
    ' Use to Get-Packages from Offline / Online image
    ' 
    Private Sub btnGetPackages_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnGetPackages.Click
        If (WIMMounted = False And ChkBoxPackageManagement_Online.Checked = False) Then
            MessageBox.Show("No WIM is mounted.  You must mount a WIM before running this command (Offline mode) or use /Online option.")
        Else
            If (ChkBoxPackageManagement_Online.Checked = True) Then
                strDISMArguments = "/Online" & " /Get-Packages"
            Else
                strDISMArguments = "/Image:""" & strMountedImageLocation & """ /Get-Packages"
            End If
            BackgroundWorkerDISMCommand.RunWorkerAsync(strDISMArguments)
                frmProgress.ShowDialog()
                ' txtOutput.Text = txtOutput.Text & strOutput
            End If
    End Sub
    '
    ' Sub btnOpenPackageFile_Click
    '
    Private Sub btnOpenPackageFile_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnOpenPackageFile.Click
        txtPackageFile.Text = OpenFolder()
    End Sub
    '
    ' Sub btnAddPackages_Click
    '
    Private Sub btnAddPackages_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAddPackages.Click
        If WIMMounted = False Then
            MessageBox.Show("No WIM is mounted.  You must mount a WIM before running this command.")
        Else
            If txtPackageFile.Text = "" Then
                MessageBox.Show("You must specify a folder where your package(s) are located.")
            Else
                strPackageLocation = txtPackageFile.Text
                If chkIgnoreCheck.Checked = True Then
                    blnIgnoreCheck = True
                    strDISMArguments = "/Image:""" & strMountedImageLocation & """" & " /Add-Package /PackagePath:""" & strPackageLocation & """" & " /IgnoreCheck"
                Else
                    blnIgnoreCheck = False
                    strDISMArguments = "/Image:""" & strMountedImageLocation & """" & " /Add-Package /PackagePath:""" & strPackageLocation & """"
                End If
                BackgroundWorkerDISMCommand.RunWorkerAsync(strDISMArguments)
                frmProgress.ShowDialog()
            End If
        End If
        ' txtOutput.Text = txtOutput.Text & strOutput
    End Sub
    '
    ' Function OpenFolder
    '
    Private Function OpenFolder()
        dlgOpenFolder.ShowNewFolderButton = False
        dlgOpenFolder.RootFolder = Environment.SpecialFolder.MyComputer
        Dim DidWork As Integer = dlgOpenFolder.ShowDialog
        If DidWork = DialogResult.Cancel Then
            strLocation = ""
            Return strLocation
        Else
            strLocation = dlgOpenFolder.SelectedPath
            Return strLocation
        End If
    End Function
    '
    ' Sub btnGetAllDriverInfo_Click
    ' Use to get all drivers information in offline or online mode
    ' 
    Private Sub btnGetAllDriverInfo_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnDriverManagement_GetAllDriverInfo.Click
        If (WIMMounted = False And ChkBoxDriverManagement_Online.Checked = False) Then
            MessageBox.Show("No WIM is mounted.  You must mount a WIM before running this command (Offline mode) or use /Online option.")
        Else
            If (ChkBoxDriverManagement_Online.Checked) Then
                strDISMArguments = "/Online" & " /Get-Drivers /All"
            Else
                strDISMArguments = "/Image:""" & strMountedImageLocation & """" & " /Get-Drivers /All"
            End If
            BackgroundWorkerDISMCommand.RunWorkerAsync(strDISMArguments)
            'BackgroundGetDrivers.RunWorkerAsync()
            frmProgress.ShowDialog()
            'txtOutput.Text = txtOutput.Text & strOutput
        End If
    End Sub
    '
    ' Sub btnDelDriver_Click
    ' Use to delete driver on offline image (not for online mode)
    ' 
    Private Sub btnDelDriver_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnDriverManagement_DelDriver.Click
        If WIMMounted = False Then
            MessageBox.Show("No WIM is mounted.  You must mount a WIM before running this command.")
        Else
            If TxtBoxDriverManagement_DelDriverLocation.Text = "" Then
                'Or Microsoft.VisualBasic.Left(txtDelDriverLocation.Text, 3) <> "inf"
                MessageBox.Show("You must enter in a driver name before continuing.  The Driver name must end with inf")
            Else
                strDelDriverLocation = TxtBoxDriverManagement_DelDriverLocation.Text
                strDISMArguments = "/Image:""" & strMountedImageLocation & """" & " /Remove-Driver /Driver:" & strDelDriverLocation
                BackgroundWorkerDISMCommand.RunWorkerAsync(strDISMArguments)
                frmProgress.ShowDialog()
                ' txtOutput.Text = txtOutput.Text & strOutput
            End If
            'Do Nothing
        End If
    End Sub
    '
    ' Sub btnRemovePackageName_Click
    '
    Private Sub btnRemovePackageName_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnRemovePackageName.Click
        If WIMMounted = False Then
            MessageBox.Show("No WIM is mounted.  You must mount a WIM before running this command.")
        Else
            If txtPackageName.Text = "" Then
                MessageBox.Show("You must enter in a package name before continuing.")
            Else
                strPackageName = txtPackageName.Text
                strDISMArguments = "/Image:""" & strMountedImageLocation & """" & " /Remove-Package /PackageName:" & strPackageName
                BackgroundWorkerDISMCommand.RunWorkerAsync(strDISMArguments)
                frmProgress.ShowDialog()
                ' txtOutput.Text = txtOutput.Text & strOutput
            End If
            'Do Nothing
        End If
    End Sub
    '
    ' Sub btnRemovePackagePath_Click
    '
    Private Sub btnRemovePackagePath_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnRemovePackagePath.Click
        If WIMMounted = False Then
            MessageBox.Show("No WIM is mounted.  You must mount a WIM before running this command.")
        Else
            If txtPackagePath.Text = "" Or Microsoft.VisualBasic.Left(txtPackagePath.Text, 3) <> "cab" Then
                MessageBox.Show("You must enter in a package path before continuing.  The package path must point to a valid cab file.")
            Else
                strPackagePath = txtPackagePath.Text
                strDISMArguments = "/Image:""" & strMountedImageLocation & """" & " /Remove-Package /PackagePath:" & strPackagePath
                BackgroundWorkerDISMCommand.RunWorkerAsync(strDISMArguments)
                frmProgress.ShowDialog()
                ' txtOutput.Text = txtOutput.Text & strOutput
            End If
            'Do Nothing
        End If
    End Sub
    '
    ' Sub btnGetFeatures_Click
    ' rev: 14072022
    '
    Private Sub btnGetFeatures_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnGetFeatures.Click
        If (WIMMounted = False And ChkBoxFeatureManagement_Online.Checked = False) Then
            MessageBox.Show("No WIM is mounted.  You must mount a WIM before running this command (Offline mode) or use /Online option.")
        Else
            If (ChkBoxFeatureManagement_Online.Checked = True) Then
                strDISMArguments = "/Online /Get-Features"
            Else
                strDISMArguments = "/Image:""" & strMountedImageLocation & """ /Get-Features"
            End If
            BackgroundWorkerDISMCommand.RunWorkerAsync(strDISMArguments)
            frmProgress.ShowDialog()
            ' txtOutput.Text = txtOutput.Text & strOutput
        End If
    End Sub
    '
    ' Sub chkEnablePkgName_CheckedChanged
    '
    Private Sub chkEnablePkgName_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkEnablePkgName.CheckedChanged
        If chkEnablePkgName.Checked = True Then
            txtFeatPackageName.Enabled = True
        ElseIf chkEnablePkgName.Checked = False Then
            txtFeatPackageName.Enabled = False
        End If

    End Sub
    '
    ' Sub chkEnablePkgPath_CheckedChanged
    '
    Private Sub chkEnablePkgPath_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkEnablePkgPath.CheckedChanged
        If chkEnablePkgPath.Checked = True Then
            txtFeatPackagePath.Enabled = True
        ElseIf chkEnablePkgPath.Checked = False Then
            txtFeatPackagePath.Enabled = False
        End If
    End Sub
    '
    ' Sub btnEnableFeature_Click
    '
    Private Sub btnEnableFeature_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnEnableFeature.Click
        If WIMMounted = False Then
            MessageBox.Show("No WIM is mounted.  You must mount a WIM before running this command.")
            Exit Sub
        Else
            'Do Nothing
        End If

        If txtFeatureName.Text = "" Then
            MessageBox.Show("Feature Name is required to continue.")
            Exit Sub
        Else
            'Do Nothing
        End If

        If chkEnablePkgName.Checked = True And txtFeatPackageName.Text = "" Then
            MessageBox.Show("If you enable the Package Name field you must specify a Package Name")
            Exit Sub
        Else
            'Do Nothing
        End If

        If chkEnablePkgPath.Checked = True And txtFeatPackagePath.Text = "" Then
            MessageBox.Show("If you enable the Package Path field you must specify a Package Path")
            Exit Sub
        Else
            'Do Nothing
        End If

        strFeatureName = txtFeatureName.Text
        strDISMArguments = "/Image:""" & strMountedImageLocation & """" & " /Enable-Feature /FeatureName:""" & strFeatureName & """" & " "

        If chkEnablePkgName.Checked = True Then
            strDISMArguments = strDISMArguments & "/PackageName:" & txtFeatPackageName.Text & " "
        Else
            'Do Nothing
        End If

        If chkEnablePkgPath.Checked = True Then
            strDISMArguments = strDISMArguments & "/PackagePath:" & txtFeatPackagePath.Text & " "
        Else
            'Do Nothing
        End If


        BackgroundWorkerDISMCommand.RunWorkerAsync(strDISMArguments)
        frmProgress.ShowDialog()


        ' txtOutput.Text = txtOutput.Text & strOutput
    End Sub
    '
    ' Sub btnDisableFeature_Click
    ' 
    Private Sub btnDisableFeature_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDisableFeature.Click
        If WIMMounted = False Then
            MessageBox.Show("No WIM is mounted.  You must mount a WIM before running this command.")
            Exit Sub
        Else
            'do nothing
        End If

        If txtFeatureName.Text = "" Then
            MessageBox.Show("Feature Name is required to continue.")
            Exit Sub
        Else
            'do nothing
        End If

        If chkEnablePkgName.Checked = True And txtFeatPackageName.Text = "" Then
            MessageBox.Show("If you enable the Package Name field you must specify a Package Name")
            Exit Sub
        Else
            'Do Nothing
        End If

        If chkEnablePkgPath.Checked = True Then
            MessageBox.Show("The PackagePath option cannot be used with disabling a feature.  Anything entered into that box will be ignored.")
        Else
            'Do Nothing
        End If

        strFeatureName = txtFeatureName.Text
        strDISMArguments = "/Image:""" & strMountedImageLocation & """" & " /Disable-Feature /FeatureName:""" & strFeatureName & """" & " "

        If chkEnablePkgName.Checked = True Then
            strDISMArguments = strDISMArguments & "/PackageName:" & txtFeatPackageName.Text & " "
        Else
            'Do Nothing
        End If

        BackgroundWorkerDISMCommand.RunWorkerAsync(strDISMArguments)
        frmProgress.ShowDialog()
        ' txtOutput.Text = txtOutput.Text & strOutput
    End Sub
    ' 
    ' Sub CleanupImageToolStripMenuItem_Click
    ' 
    Private Sub CleanupImageToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CleanupImageToolStripMenuItem.Click
        strDISMArguments = "/Image:""" & strMountedImageLocation & """" & " /Cleanup-Image /RevertPendingActions"
        BackgroundWorkerDISMCommand.RunWorkerAsync(strDISMArguments)
        frmProgress.ShowDialog()
        ' txtOutput.Text = txtOutput.Text & strOutput
    End Sub
    '
    ' Sub frmMain_Load
    '
    Private Sub frmMain_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        CmbMountControl_Index.Text = "1"
        cmbCompression.Text = "Fast"
        cmbApplyIndex.Text = "1"
        ExtractDismVersion()
    End Sub
    ' 
    ' Sub UseOnlineModeToolStripMenuItem_Click
    ' 
    Private Sub UseOnlineModeToolStripMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles UseOnlineModeToolStripMenuItem.Click
        If UseOnlineModeToolStripMenuItem.CheckState = CheckState.Checked Then
            OnlineMode = True
            BtnMountControl_MountWim.Enabled = False
            BtnMountControl_OpenMountedFolder.Enabled = False
        Else
            OnlineMode = False
            BtnMountControl_MountWim.Enabled = True
            BtnMountControl_OpenMountedFolder.Enabled = True
        End If
    End Sub
    '
    ' btGetCurrentEdition_Click
    ' Rev: 14072022
    '
    Private Sub btGetCurrentEdition_Click(sender As System.Object, e As System.EventArgs) Handles btGetCurrentEdition.Click
        If (WIMMounted = False And ChkBoxEditionServicing_Online.Checked = False) Then
            MessageBox.Show("No WIM is mounted.  You must mount a WIM before running this command (Offline mode) or use /Online option.")
        Else
            If (ChkBoxEditionServicing_Online.Checked = True) Then
                strDISMArguments = "/Online /Get-CurrentEdition"
            Else
                strDISMArguments = "/Image:""" & strMountedImageLocation & """" & " /Get-CurrentEdition"
            End If
            BackgroundWorkerDISMCommand.RunWorkerAsync(strDISMArguments)
            frmProgress.ShowDialog()
            ' txtOutput.Text = txtOutput.Text & strOutput
        End If
    End Sub
    ' 
    ' Sub btnGetTargetEditions_Click
    ' 
    Private Sub btnGetTargetEditions_Click(sender As System.Object, e As System.EventArgs) Handles btnGetTargetEditions.Click
        ' If WIMMounted = False Then
        'MessageBox.Show("No WIM is mounted.  You must mount a WIM before running this command.")
        'Else
        'strDISMArguments = "/image:""" & strMountedImageLocation & """" & " /Get-TargetEditions"

        strDISMArguments = "/Online /Get-TargetEditions"
        BackgroundWorkerDISMCommand.RunWorkerAsync(strDISMArguments)
        frmProgress.ShowDialog()

        ' txtOutput.Text = txtOutput.Text & strOutput
        'End If
    End Sub
    ' 
    ' Sub  btnSetProdKey_Click
    '
    Private Sub btnSetProdKey_Click(sender As System.Object, e As System.EventArgs) Handles btnSetProdKey.Click
        If WIMMounted = False Then
            MessageBox.Show("No WIM is mounted.  You must mount a WIM before running this command.")
            Exit Sub
        Else
            'Do Nothing
        End If

        If txtProdKey.Text = "" Then
            MessageBox.Show("Product Key is required to continue.")
            Exit Sub
        Else
            'Do Nothing
        End If

        strProductKey = txtProdKey.Text
        strDISMArguments = "/Image:""" & strMountedImageLocation & """" & " /Set-ProductKey:" & strProductKey

        BackgroundWorkerDISMCommand.RunWorkerAsync(strDISMArguments)
        frmProgress.ShowDialog()


        txtOutput.Text = txtOutput.Text & strOutput
    End Sub
    ' 
    ' Sub  btnSetEdition_Click
    '
    Private Sub btnSetEdition_Click(sender As System.Object, e As System.EventArgs) Handles btnSetEdition.Click
        If WIMMounted = False Then
            MessageBox.Show("No WIM is mounted.  You must mount a WIM before running this command.")
            Exit Sub
        Else

        End If

        If txtEdition.Text = "" Then
            MessageBox.Show("Edition is required to continue.")
            Exit Sub
        Else
            'Do Nothing
        End If

        strEdition = txtEdition.Text
        strProductKey = txtProdKey.Text
        strDISMArguments = "/Image:""" & strMountedImageLocation & """" & " /Set-Edition:" & strEdition

        BackgroundWorkerDISMCommand.RunWorkerAsync(strDISMArguments)
        frmProgress.ShowDialog()
        txtOutput.Text = txtOutput.Text & strOutput

    End Sub
    ' 
    ' Sub  btnChooseUnAttend_Click
    '
    Private Sub btnChooseUnAttend_Click(sender As System.Object, e As System.EventArgs) Handles btnChooseUnAttend.Click
        Dim DidWork As Integer = dlgOpenXML.ShowDialog

        dlgOpenXML.InitialDirectory = "c:\"
        dlgOpenXML.Title = "Choose Unattend XML file to Open"
        dlgOpenXML.Filter = ("XML Files(*.xml)|*.xml|All Files (*.*)|*.*")

        If DidWork = DialogResult.Cancel Then
            'Do Nothing
        Else
            ' Dim strXMLFileName As String = dlgOpenXML.FileName
            strXMLFileName = dlgOpenXML.FileName
            TxtBox_UnattendXMLFile.Text = strXMLFileName
        End If
    End Sub
    ' 
    ' Sub  btnApplyUnattend_Click
    ' Rev: 14072022
    '
    Private Sub btnApplyUnattend_Click(sender As System.Object, e As System.EventArgs) Handles btnApplyUnattend.Click
        If (WIMMounted = False And ChkBoxUnattendedServicing_Online.Checked = False) Then
            MessageBox.Show("No WIM is mounted.  You must mount a WIM before running this command (Offline mode) or use /Online option.")
        Else
            If TxtBox_UnattendXMLFile.Text = "" Then
                MessageBox.Show("You must enter an XML file.")
            Else
                strXMLFileName = TxtBox_UnattendXMLFile.Text
                If (ChkBoxUnattendedServicing_Online.Checked = True) Then
                    strDISMArguments = "/Online /Apply-Unattend:""" & strXMLFileName & """"
                Else
                    strDISMArguments = "/Image:""" & strMountedImageLocation & """" & " /Apply-Unattend:""" & strXMLFileName & """"
                End If
                ' strXMLFileName = txtPatchLocation.Text
                BackgroundWorkerDISMCommand.RunWorkerAsync(strDISMArguments)
                frmProgress.ShowDialog()
                ' txtOutput.Text = txtOutput.Text & strOutput
            End If
        End If
    End Sub
    ' 
    ' Sub  btnGetApps_Click
    '
    Private Sub btnGetApps_Click(sender As System.Object, e As System.EventArgs) Handles btnGetApps.Click
        If WIMMounted = False Then
            MessageBox.Show("No WIM is mounted.  You must mount a WIM before running this command.")
        Else
            strDISMArguments = "/Image:""" & strMountedImageLocation & """" & " /Get-Apps"
            BackgroundWorkerDISMCommand.RunWorkerAsync(strDISMArguments)
            frmProgress.ShowDialog()
            ' txtOutput.Text = txtOutput.Text & strOutput
        End If
    End Sub
    ' 
    ' Sub  btnGetAppInfo_Click
    '
    Private Sub btnGetAppInfo_Click(sender As System.Object, e As System.EventArgs) Handles btnGetAppInfo.Click
        If WIMMounted = False Then
            MessageBox.Show("No WIM is mounted.  You must mount a WIM before running this command.")
            Exit Sub
        Else
            'Do Nothing
        End If

        If txtProductCode.Text = "{        -    -    -    -            }" Then
            strProductCode = txtProductCode.Text
            strDISMArguments = "/Image:""" & strMountedImageLocation & """" & " /Get-AppInfo"
            BackgroundWorkerDISMCommand.RunWorkerAsync(strDISMArguments)
            frmProgress.ShowDialog()
        Else
            strProductCode = txtProductCode.Text
            strDISMArguments = "/Image:""" & strMountedImageLocation & """" & " /Get-AppInfo /ProductCode:" & strProductCode
            BackgroundWorkerDISMCommand.RunWorkerAsync(strDISMArguments)
            frmProgress.ShowDialog()
        End If


        ' txtOutput.Text = txtOutput.Text & strOutput
    End Sub
    ' 
    ' Sub  btnGetAppPatches_Click
    '
    Private Sub btnGetAppPatches_Click(sender As System.Object, e As System.EventArgs) Handles btnGetAppPatches.Click
        If WIMMounted = False Then
            MessageBox.Show("No WIM is mounted.  You must mount a WIM before running this command.")
            Exit Sub
        Else
            'Do Nothing
        End If

        If txtProductCode.Text = "{        -    -    -    -            }" Then
            strProductCode = txtProductCode.Text
            strDISMArguments = "/Image:""" & strMountedImageLocation & """" & " /Get-AppPatches"
            BackgroundWorkerDISMCommand.RunWorkerAsync(strDISMArguments)
            frmProgress.ShowDialog()
            ' txtOutput.Text = txtOutput.Text & strOutput
        Else
            strProductCode = txtProductCode.Text
            strDISMArguments = "/Image:""" & strMountedImageLocation & """" & " /Get-AppPatches  /ProductCode:" & strProductCode
            BackgroundWorkerDISMCommand.RunWorkerAsync(strDISMArguments)
            frmProgress.ShowDialog()
            ' txtOutput.Text = txtOutput.Text & strOutput
        End If


    End Sub
    ' 
    ' Sub  btnGetAppPatchInfo_Click
    '
    Private Sub btnGetAppPatchInfo_Click(sender As System.Object, e As System.EventArgs) Handles btnGetAppPatchInfo.Click
        If WIMMounted = False Then
            MessageBox.Show("No WIM is mounted.  You must mount a WIM before running this command.")
            Exit Sub
        Else
            'Do Nothing
        End If

        If txtPatchCode.Text = "{        -    -    -    -            }" And txtProductCode.Text = "{        -    -    -    -            }" Then
            strDISMArguments = "/Image:""" & strMountedImageLocation & """" & " /Get-AppPatchInfo"
            BackgroundWorkerDISMCommand.RunWorkerAsync(strDISMArguments)
            frmProgress.ShowDialog()
            ' txtOutput.Text = txtOutput.Text & strOutput
            Exit Sub
        Else
            'Do Nothing
        End If

        If txtPatchCode.Text <> "{        -    -    -    -            }" And txtProductCode.Text = "{        -    -    -    -            }" Then
            strPatchCode = txtPatchCode.Text
            strProductCode = txtProductCode.Text
            strDISMArguments = "/image:""" & strMountedImageLocation & """" & " /Get-AppPatchInfo /PatchCode:" & strPatchCode
            BackgroundWorkerDISMCommand.RunWorkerAsync(strDISMArguments)
            frmProgress.ShowDialog()
            ' txtOutput.Text = txtOutput.Text & strOutput
            Exit Sub
        Else
            'Do Nothing
        End If

        If txtPatchCode.Text = "{        -    -    -    -            }" And txtProductCode.Text <> "{        -    -    -    -            }" Then
            strPatchCode = txtPatchCode.Text
            strProductCode = txtProductCode.Text
            strDISMArguments = "/Image:""" & strMountedImageLocation & """" & " /Get-AppPatchInfo /ProductCode:" & strProductCode
            BackgroundWorkerDISMCommand.RunWorkerAsync(strDISMArguments)
            frmProgress.ShowDialog()
            ' txtOutput.Text = txtOutput.Text & strOutput
            Exit Sub
        Else
            'Do Nothing
        End If

        If txtPatchCode.Text <> "{        -    -    -    -            }" And txtProductCode.Text <> "{        -    -    -    -            }" Then
            strPatchCode = txtPatchCode.Text
            strProductCode = txtProductCode.Text
            strDISMArguments = "/Image:""" & strMountedImageLocation & """" & " /Get-AppPatchInfo /PatchCode:" & strPatchCode & " /ProductCode:" & strProductCode
            BackgroundWorkerDISMCommand.RunWorkerAsync(strDISMArguments)
            frmProgress.ShowDialog()
            ' txtOutput.Text = txtOutput.Text & strOutput
            Exit Sub
        Else
            'Do Nothing
        End If

    End Sub
    ' 
    ' Sub  btnCheckAppPatch_Click
    '
    Private Sub btnCheckAppPatch_Click(sender As System.Object, e As System.EventArgs) Handles btnCheckAppPatch.Click
        If WIMMounted = False Then
            MessageBox.Show("No WIM is mounted.  You must mount a WIM before running this command.")
            Exit Sub
        Else
            'Do Nothing
        End If



        If txtPatchLocation.Text = "" Then
            MessageBox.Show("You must enter an MSP file.")
            Exit Sub
        Else
            'Do Nothing
        End If
        strMSPFileName = txtPatchLocation.Text
        strDISMArguments = "/Image:""" & strMountedImageLocation & """" & " /Check-AppPatch /PatchLocation:""" & strMSPFileName & """"
        BackgroundWorkerDISMCommand.RunWorkerAsync(strDISMArguments)
        frmProgress.ShowDialog()
        ' txtOutput.Text = txtOutput.Text & strOutput


    End Sub
    ' 
    ' Sub  btnChooseMSP_Click
    '
    Private Sub btnChooseMSP_Click(sender As System.Object, e As System.EventArgs) Handles btnChooseMSP.Click
        dlgOpenMSP.InitialDirectory = "c:\"
        dlgOpenMSP.Title = "Choose Unattend XML file to Open"
        dlgOpenMSP.Filter = ("MSP Files(*.msp)|*.msp|All Files (*.*)|*.*")
        Dim DidWork As Integer = dlgOpenMSP.ShowDialog

        If DidWork = DialogResult.Cancel Then
            'Do Nothing
        Else
            Dim strMSPFileName As String = dlgOpenMSP.FileName
            txtPatchLocation.Text = strMSPFileName
        End If
    End Sub
    '
    ' Sub btnCreate_Click
    ' rev: 14072022
    '
    Private Sub btnCreate_Click(sender As System.Object, e As System.EventArgs) Handles btnCreate.Click
        If txtCaptureSource.Text = "" Then
            MessageBox.Show("You must select a source location.")
            Exit Sub
        End If

        If txtCaptureDest.Text = "" Then
            MessageBox.Show("You must set a destination file.")
            Exit Sub
        End If

        If TxtFileName.Text = "" Then
            MessageBox.Show("You must enter a filename for WIM file.")
            Exit Sub
        End If

        If TxtNameMetadata.Text = "" Then
            MessageBox.Show("You must enter a description for the WIM metadata.")
            Exit Sub
        End If

        strSource = txtCaptureSource.Text

        ' detect if logical drive only, no double quot on string preserv for error 87 or 123
        If (strSource.Length <> 3) Then
            strSource = """" + strSource + """" ' if not, style use double quot
        End If

        strDest = txtCaptureDest.Text
        strFilename = TxtFileName.Text
        strNameMetadata = TxtNameMetadata.Text
        strNameDescription = TxtBoxCaptureWIM_Description.Text
        strCompression = cmbCompression.Text

        ' add extension file automatically if forgotten
        If (Path.GetExtension(TxtFileName.Text.ToUpper()) <> ".WIM") Then
            TxtFileName.Text = TxtFileName.Text + ".wim"
            strFilename = TxtFileName.Text
        End If

        strDISMArguments = "/Capture-Image /ImageFile:""" + strDest + "\" + strFilename + """" + " /CaptureDir:" + strSource + " /Name:""" + strNameMetadata + """" + " /Description:" + """" + strNameDescription + """" + " /Compress:" + strCompression

        If chkCaptureVerify.Checked = True Then
            strDISMArguments = strDISMArguments + " /Verify"
        End If

        'txtOutput.Text = strDISMArguments
        BackgroundWorkerDISMCommand.RunWorkerAsync(strDISMArguments)
        frmProgress.ShowDialog()
    End Sub
    ' 
    ' Sub  btnCaptureSrc_Click
    '
    Private Sub btnCaptureSrc_Click(sender As System.Object, e As System.EventArgs) Handles btnCaptureSrc.Click
        dlgOpenFolder.ShowNewFolderButton = False
        dlgOpenFolder.RootFolder = Environment.SpecialFolder.MyComputer
        dlgOpenFolder.ShowDialog()
        Dim strFolderName As String = dlgOpenFolder.SelectedPath
        Dim dirs As String() = System.IO.Directory.GetDirectories(strFolderName)
        Dim files As String() = System.IO.Directory.GetFiles(strFolderName)
        If dirs.Length = 0 AndAlso files.Length = 0 Then
            If MessageBox.Show("You must choose a non-empty folder.") = DialogResult.OK Then
            Else
                'Do Nothing
            End If
        Else
            txtCaptureSource.Text = strFolderName
        End If
    End Sub
    ' 
    ' Sub  btnCaptureDest_Click
    '
    Private Sub btnCaptureDest_Click(sender As System.Object, e As System.EventArgs) Handles btnCaptureDest.Click

        dlgOpenFolder.ShowNewFolderButton = False
        dlgOpenFolder.RootFolder = Environment.SpecialFolder.MyComputer
        dlgOpenFolder.ShowDialog()
        Dim strFolderName As String = dlgOpenFolder.SelectedPath

        txtCaptureDest.Text = strFolderName

    End Sub
    '
    ' Sub btnAppend_Click
    ' rev: 20062022
    '
    Private Sub btnAppend_Click(sender As System.Object, e As System.EventArgs) Handles btnAppend.Click
        If txtCaptureSource.Text = "" Then
            MessageBox.Show("You must select a source location.")
            Exit Sub
        Else
            'Do Nothing
        End If

        If txtCaptureDest.Text = "" Then
            MessageBox.Show("You must set a destination file.")
            Exit Sub
        Else
            'Do Nothing
        End If

        If TxtFileName.Text = "" Then
            MessageBox.Show("You must enter a Name for the WIM.")
            Exit Sub
        Else
            'Do Nothing
        End If

        strSource = txtCaptureSource.Text

        ' detect if logical drive only, no double quot on string preserv for error 87 or 123
        If (strSource.Length <> 3) Then
            strSource = """" + strSource + """" ' if not, style use double quot
        End If

        strDest = txtCaptureDest.Text
        strFilename = TxtFileName.Text
        strNameMetadata = TxtNameMetadata.Text
        strNameDescription = TxtBoxCaptureWIM_Description.Text
        strCompression = cmbCompression.Text

        If (Path.GetExtension(TxtFileName.Text.ToUpper()) <> ".WIM") Then
            TxtFileName.Text = TxtFileName.Text + ".wim"
            strFilename = TxtFileName.Text
        End If

        strDISMArguments = "/Append-Image /ImageFile:""" + strDest + "\" + strFilename + """ /CaptureDir:" + strSource + " /Name:""" + strNameMetadata + """" + " /Description:" + """" + strNameDescription + """"

        If (chkCaptureVerify.Checked = True) Then
            strDISMArguments = strDISMArguments + " /Verify"
        End If

        'txtOutput.Text = strDISMArguments
        BackgroundWorkerDISMCommand.RunWorkerAsync(strDISMArguments)
        frmProgress.ShowDialog()
    End Sub
    ' 
    ' Sub  btnBrowseSource_Click
    ' Rev: 14072022
    '
    Private Sub btnBrowseSource_Click(sender As System.Object, e As System.EventArgs) Handles btnBrowseSource.Click
        dlgOpenFile.InitialDirectory = "c:\"
        dlgOpenFile.Title = "Choose WIM file to Open"
        dlgOpenFile.Filter = ("WIM Files(*.wim)|*.wim|SWM Files(*.swm)|*.swm|All Files (*.*)|*.*")
        Dim DidWork As Integer = dlgOpenFile.ShowDialog

        If DidWork = DialogResult.Cancel Then
            'Do Nothing
        Else
            Dim strFileName As String = dlgOpenFile.FileName
            txtApplySource.Text = strFileName
            DisplayWimInfos("ApplyImage_WimInfos.txt", txtApplySource.Text)
            Me.cmbApplyIndex.Items.Clear()
            ListInfosWimApplyImage.Clear()
            UpdateListIndexWim("ApplyImage_WimInfos.txt", ListInfosWimApplyImage)
            For IdxFor As Integer = 1 To ListInfosWimApplyImage.Count
                Me.cmbApplyIndex.Items.Add(IdxFor.ToString)
            Next
            If (Path.GetExtension(txtApplySource.Text.ToUpper) = ".SWM") Then
                TxtBoxApplySource_PatternSWMFile.Text = txtApplySource.Text
                TxtBoxApplySource_PatternSWMFile.Text = Replace(TxtBoxApplySource_PatternSWMFile.Text, ".swm", "*.swm")
            End If
        End If
    End Sub
    ' 
    ' Sub  btnBrowseDest_Click
    ' Rev: 14072022
    '
    Private Sub btnBrowseDest_Click(sender As System.Object, e As System.EventArgs) Handles btnBrowseDest.Click
        Dim strFolderName As String = dlgOpenFolder.SelectedPath
        Dim dirs As String() = System.IO.Directory.GetDirectories(strFolderName)
        Dim files As String() = System.IO.Directory.GetFiles(strFolderName)
        Dim DidWork As Integer

        dlgOpenFolder.ShowNewFolderButton = False
        dlgOpenFolder.RootFolder = Environment.SpecialFolder.MyComputer
        DidWork = dlgOpenFolder.ShowDialog()
        If DidWork = DialogResult.OK Then
            txtApplyDest.Text = dlgOpenFolder.SelectedPath
        End If

        'If dirs.Length = 0 AndAlso files.Length = 0 Then
        ' txtApplyDest.Text = strFolderName
        'Else
        'If MessageBox.Show("You must choose an empty folder to mount the WIM") = DialogResult.OK Then
        'Else
        'Do Nothing
        'End If
        'End If
    End Sub
    ' 
    ' Sub  btnApply_Click
    ' Rev: 14072022
    '
    Private Sub btnApply_Click(sender As System.Object, e As System.EventArgs) Handles btnApply.Click
        Dim StrExtension As String

        If txtApplySource.Text = "" Then
            MessageBox.Show("You must select a source file WIM or SWM.")
            Exit Sub
        Else
            'Do Nothing
        End If

        If txtApplyDest.Text = "" Then
            MessageBox.Show("You must select a destination file.")
            Exit Sub
        Else
            'Do Nothing
        End If

        If cmbApplyIndex.Text = "" Then                               ' to review...
            MessageBox.Show("You must select an index number.")
            Exit Sub
        Else

        End If

        strSource = txtApplySource.Text
        strDest = txtApplyDest.Text
        If (strDest.Length <> 3) Then
            strDest = """" + strDest + """"          ' to skip dism error 123 or 87
        End If                                       ' no double quot on string if logical drive only

        strAppendIndex = cmbApplyIndex.Text
        'TxtBoxApplySource_PatternSWMFile.Text = txtApplySource.Text   ' prefix pattern

        StrExtension = Path.GetExtension(txtApplySource.Text.ToUpper) ' Extract extension file
        Select Case StrExtension
            Case ".WIM"
                strDISMArguments = "/Apply-Image /ImageFile:""" & strSource & """ /Index:" & strAppendIndex & " /ApplyDir:" & strDest
            Case ".SWM"
                strDISMArguments = "/Apply-Image /ImageFile:""" & strSource & """ /SWMFile:""" & TxtBoxApplySource_PatternSWMFile.Text & """ /Index:" & strAppendIndex & " /ApplyDir:" & strDest
        End Select


        If chkApplyVerify.Checked = True Then
            strDISMArguments = strDISMArguments & " /Verify"
        End If

        'txtOutput.Text = strDISMArguments
        BackgroundWorkerDISMCommand.RunWorkerAsync(strDISMArguments)
        frmProgress.ShowDialog()
    End Sub
    '
    ' Refresh information from wim selected
    '
    Private Sub cmbIndex_SelectedIndexChanged(sender As Object, e As EventArgs) Handles CmbMountControl_Index.SelectedIndexChanged
        TxtBoxMountControl_Name.Text = ListInfosWimGestionMontage.ElementAt(CmbMountControl_Index.SelectedIndex).Nom.ToString
        TxtBoxMountControl_Description.Text = ListInfosWimGestionMontage.ElementAt(CmbMountControl_Index.SelectedIndex).Description.ToString
        TxtBoxMountControl_Size.Text = ListInfosWimGestionMontage.ElementAt(CmbMountControl_Index.SelectedIndex).Taille.ToString
    End Sub
    '
    ' Sub BtnExportImage_BrowseSource_Click
    ' 
    ' Use for Open File dialog Box WIM/ESD
    ' save the result on TxtBoxExportImage_Source form variable
    ' "ExportImage_WimInfos.txt" is creating on the current application folder
    ' rev: 20062022
    '
    Private Sub BtnExportImage_BrowseSource_Click(sender As Object, e As EventArgs) Handles BtnExportImage_BrowseSource.Click
        Dim SourceFileName As String
        Dim MyDlgOpenFile = New System.Windows.Forms.OpenFileDialog() ' instance of dialog box

        MyDlgOpenFile.InitialDirectory = Environment.SpecialFolder.MyComputer                    ' default root path
        MyDlgOpenFile.Title = "Choose WIM or ESD file to Open"    ' title of dialog box
        MyDlgOpenFile.Filter = ("WIM Files(*.wim)|*.wim|Fichier ESD (*.ESD)|*.ESD") ' filter extension

        If MyDlgOpenFile.ShowDialog = DialogResult.OK Then        ' user selected filename from dialog box ?
            SourceFileName = MyDlgOpenFile.FileName
            TxtBoxExportImage_Source.Text = SourceFileName        ' user choice filename

            strDISMArguments = "/Get-WimInfo /WimFile:""" & TxtBoxExportImage_Source.Text & """" ' arguments line for dism.exe
            BackgroundWorkerDISMCommand.RunWorkerAsync(strDISMArguments) ' execute async dism command
            frmProgress.ShowDialog()                                     ' show speudo progress bar

            Try
                If System.IO.File.Exists("ExportImage_WimInfos.txt") = True Then ' delete old file (no append function)
                    System.IO.File.Create("ExportImage_WimInfos.txt").Dispose()
                End If
                ' creation new file on the current application directory
                Using sw As StreamWriter = New StreamWriter("ExportImage_WimInfos.txt", True, Encoding.UTF8)
                    sw.WriteLine(strOutput)
                    sw.Close()
                End Using
            Catch ex As Exception
                ' Let the user know what went wrong.
                'Console.WriteLine("The file could not be read:")
                'Console.WriteLine(e.Message)
                MessageBox.Show("DisplayWimInfos Error on created filename wiminfos.txt: " + ex.Message.ToString())
            End Try

            Me.CmbBoxExportImage_Index.Items.Clear()            ' clear index count in Form
            ListInfosWimExportImage.Clear()                     ' clear list<T> description index
            UpdateListIndexWim("ExportImage_WimInfos.txt", ListInfosWimExportImage) ' Mise à jour des index

            For IdxFor As Integer = 1 To ListInfosWimExportImage.Count ' update index
                Me.CmbBoxExportImage_Index.Items.Add(IdxFor.ToString)
            Next
        End If
    End Sub
    '
    ' Sub BtnExportImage_BrowseDestination_Click
    ' 
    ' Use for Open Folder dialog
    ' save the result on TxtBoxExportImage_Destination
    ' rev: 20062022
    '
    Private Sub BtnExportImage_BrowseDestination_Click(sender As Object, e As EventArgs) Handles BtnExportImage_BrowseDestination.Click
        Dim MyDlgOpenFolder As New System.Windows.Forms.FolderBrowserDialog()
        Dim StrFolderName As String

        MyDlgOpenFolder.ShowNewFolderButton = False
        MyDlgOpenFolder.RootFolder = Environment.SpecialFolder.MyComputer
        If MyDlgOpenFolder.ShowDialog() = DialogResult.OK Then
            StrFolderName = MyDlgOpenFolder.SelectedPath
            TxtBoxExportImage_Destination.Text = StrFolderName
        End If
    End Sub
    '
    ' Sub CmbBoxExportImage_Index_SelectedIndexChanged
    ' rev: 20062022
    '
    Private Sub CmbBoxExportImage_Index_SelectedIndexChanged(sender As Object, e As EventArgs) Handles CmbBoxExportImage_Index.SelectedIndexChanged
        TxtBoxExportImage_Name.Text = ListInfosWimExportImage.ElementAt(CmbBoxExportImage_Index.SelectedIndex).Nom.ToString
        TxtBoxExportImage_Description.Text = ListInfosWimExportImage.ElementAt(CmbBoxExportImage_Index.SelectedIndex).Description.ToString
        TxtBoxExportImage_Size.Text = ListInfosWimExportImage.ElementAt(CmbBoxExportImage_Index.SelectedIndex).Taille.ToString
    End Sub
    '
    ' Sub BtnExportImage_ExportImage_Click
    ' rev: 20062022
    '
    Private Sub BtnExportImage_ExportImage_Click(sender As Object, e As EventArgs) Handles BtnExportImage_ExportImage.Click
        Dim SrcFile, DstFolder, FileName As String
        Dim Index, Compression As String

        If TxtBoxExportImage_Source.Text = "" Then
            MessageBox.Show("You must selected a source file ESD or WIM !")
        Else
            If TxtBoxExportImage_Destination.Text = "" Then
                MessageBox.Show("You must selected a folder destination !")
            Else
                If TxtBoxExportImage_Filename.Text = "" Then
                    MessageBox.Show("You must enter a destination filename !")
                Else
                    If CmbBoxExportImage_Index.Text = "" Then
                        MessageBox.Show("You must selected index on wim !")
                    Else
                        If CmbBoxExportImage_Compression.Text = "" Then
                            MessageBox.Show("You must selected a compression mode !")
                        Else
                            SrcFile = TxtBoxExportImage_Source.Text
                            DstFolder = TxtBoxExportImage_Destination.Text
                            FileName = TxtBoxExportImage_Filename.Text
                            Index = CmbBoxExportImage_Index.Text
                            Compression = CmbBoxExportImage_Compression.Text
                            strDISMArguments = "/Export-Image /SourceImageFile:" + """" + SrcFile + """" + " /SourceIndex:" + Index + " /DestinationImageFile:" + """" + DstFolder + "\" + FileName + """" + " /Compress:" + Compression
                            If ChkBoxExportImage_Bootable.Checked = True Then
                                strDISMArguments = strDISMArguments + " /Bootable"
                            End If
                            If ChkBoxExportImage_WimBoot.Checked = True Then
                                strDISMArguments = strDISMArguments + " /WIMBoot"
                            End If
                            If ChkBoxExportImage_CheckIntegrity.Checked = True Then
                                strDISMArguments = strDISMArguments + " /CheckIntegrity"
                            End If

                            ' txtOutput.Text = strDISMArguments
                            BackgroundWorkerDISMCommand.RunWorkerAsync(strDISMArguments)
                            frmProgress.ShowDialog()
                        End If
                    End If
                End If
            End If
        End If
    End Sub
    '
    ' Sub BtnSetLanguage_Apply_Click
    ' rev: 20062022
    '
    Private Sub BtnLangAndInterServ_ApplyAllIntl_Click(sender As Object, e As EventArgs) Handles BtnLangAndInterServ_ApplyAllIntl.Click

        If WIMMounted = False Then
            MessageBox.Show("No WIM is mounted.  You must mount a WIM before running this command (Offline mode only).")
        Else
            If CmbBoxLangAndInterServ_SetAllIntl.Text <> "" Then
                strDISMArguments = "/Image:" + """" + strMountedImageLocation + """" + " /Set-AllIntl:" + CmbBoxLangAndInterServ_SetAllIntl.Text
                ' txtOutput.Text = strDISMArguments
                BackgroundWorkerDISMCommand.RunWorkerAsync(strDISMArguments)
                frmProgress.ShowDialog()
            Else
                MessageBox.Show("You must enter a value for /SetAllIntl !")
            End If
        End If
    End Sub
    '
    ' Sub BtnExportDriverOnlineFolderChoice_Click
    ' rev: 20062022
    '
    Private Sub BtnExportDriverOnlineFolderChoice_Click(sender As Object, e As EventArgs) Handles BtnExportDriverOnlineFolderChoice.Click
        Dim MyDlgOpenFolder As New System.Windows.Forms.FolderBrowserDialog()
        Dim StrFolderName As String

        MyDlgOpenFolder.ShowNewFolderButton = False
        MyDlgOpenFolder.RootFolder = Environment.SpecialFolder.MyComputer
        If MyDlgOpenFolder.ShowDialog() = DialogResult.OK Then
            StrFolderName = MyDlgOpenFolder.SelectedPath
            TxtBoxExportDriverOnlineFolder.Text = StrFolderName
        End If
    End Sub
    '
    ' Sub BtnExportDriverOfflineFolderChoice_Click
    ' rev: 20062022
    '
    Private Sub BtnExportDriverOfflineFolderChoice_Click(sender As Object, e As EventArgs) Handles BtnExportDriverOfflineFolderChoice.Click
        Dim MyDlgOpenFolder As New System.Windows.Forms.FolderBrowserDialog()
        Dim StrFolderName As String

        MyDlgOpenFolder.ShowNewFolderButton = False
        MyDlgOpenFolder.RootFolder = Environment.SpecialFolder.MyComputer
        If MyDlgOpenFolder.ShowDialog() = DialogResult.OK Then
            StrFolderName = MyDlgOpenFolder.SelectedPath
            TxtBoxExportDriverOfflineFolder.Text = StrFolderName
        End If
    End Sub
    '
    ' Sub BtnExportDriverOffline_Click
    ' rev: 20062022
    '
    Private Sub BtnExportDriverOffline_Click(sender As Object, e As EventArgs) Handles BtnExportDriverOffline.Click
        If WIMMounted = False Then
            MessageBox.Show("No WIM is mounted.  You must mount a WIM before running this command.")
        Else
            If TxtBoxExportDriverOfflineFolder.Text = "" Then
                MessageBox.Show("You must selected folder for export driver (offline)")
            Else
                strDISMArguments = "/Image:" + """" + strMountedImageLocation + """" + " /Export-Driver" + " /Destination:" + """" + TxtBoxExportDriverOfflineFolder.Text + """"
                'txtOutput.Text = strDISMArguments
                BackgroundWorkerDISMCommand.RunWorkerAsync(strDISMArguments)
                frmProgress.ShowDialog()
            End If
        End If
    End Sub
    '
    ' Sub BtnExportDriverOnline_Click
    ' rev: 20062022
    '
    Private Sub BtnExportDriverOnline_Click(sender As Object, e As EventArgs) Handles BtnExportDriverOnline.Click
        If TxtBoxExportDriverOnlineFolder.Text = "" Then
            MessageBox.Show("You must selected folder for export driver (Online)")
        Else
            strDISMArguments = "/Online /Export-Driver /Destination:" + """" + TxtBoxExportDriverOnlineFolder.Text + """"
            'txtOutput.Text = strDISMArguments
            BackgroundWorkerDISMCommand.RunWorkerAsync(strDISMArguments)
            frmProgress.ShowDialog()
        End If
    End Sub
    '
    ' Sub BtnSplitImage_WIMChoice_Click
    ' rev: 20062022
    ' warning: you can't choose a compress Ffu file for split because it's not supported
    '
    Private Sub BtnSplitImage_WIMChoice_Click(sender As Object, e As EventArgs) Handles BtnSplitImage_WIMChoice.Click
        Dim MyDlgOpenFile = New System.Windows.Forms.OpenFileDialog() ' instance of dialog box

        MyDlgOpenFile.InitialDirectory = Environment.SpecialFolder.MyComputer                    ' default root path
        MyDlgOpenFile.Title = "Choose WIM or Ffu file to Open"    ' title of dialog box
        MyDlgOpenFile.Filter = ("WIM Files(*.wim)|*.wim|Ffu Files(*.ffu)|*.ffu") ' filter extension

        If MyDlgOpenFile.ShowDialog = DialogResult.OK Then        ' user selected filename from dialog box ?
            TxtBoxSplitImage_WIMFilename.Text = MyDlgOpenFile.FileName
        End If
        If TxtBoxSplitImage_WIMFilename.Text = "" Then
            MessageBox.Show("You must selected a WIM or Ffu file", "Information WIM or Ffu", MessageBoxButtons.OK)
        End If
    End Sub
    '
    ' Sub BtnSplitImage_TargetFolder_Click
    ' rev: 20062022
    '
    Private Sub BtnSplitImage_TargetFolder_Click(sender As Object, e As EventArgs) Handles BtnSplitImage_TargetFolder.Click
        Dim MyDlgOpenFolder As New System.Windows.Forms.FolderBrowserDialog()
        Dim StrFolderName As String

        MyDlgOpenFolder.ShowNewFolderButton = False
        MyDlgOpenFolder.RootFolder = Environment.SpecialFolder.MyComputer
        If MyDlgOpenFolder.ShowDialog() = DialogResult.OK Then
            StrFolderName = MyDlgOpenFolder.SelectedPath
            TxtBoxSplitImage_DestinationFolder.Text = StrFolderName
        End If
    End Sub
    '
    ' Sub BtnSplitImage_SplitImage_Click
    ' rev: 20062022
    ' warning: you can't choose a compress Ffu file for split because it's not supported
    '
    Private Sub BtnSplitImage_SplitImage_Click(sender As Object, e As EventArgs) Handles BtnSplitImage_SplitImage.Click
        ' strDISMArguments = "/Split-Image /ImageFile:" + """" + TxtBoxSplitImage_WIMFilename.Text + """" + " /SWMFile:" + """" + TxtBoxSplitImage_DestinationFolder.Text + "\" + TxtBoxSplitImage_SWMFilename.Text + """" + " /FileSize:" + Convert.ToUInt64(TxtBoxSplitImage_Filesize.Text)

        ' add extension file automatically if forgotten
        'If (Path.GetExtension(TxtBoxSplitImage_SWMFilename.Text.ToUpper()) <> ".SWM") Then
        ' TxtBoxSplitImage_SWMFilename.Text = TxtBoxSplitImage_SWMFilename.Text + ".swm"
        'End If

        If Path.GetExtension(TxtBoxSplitImage_WIMFilename.Text.ToUpper()) = ".WIM" Then
            TxtBoxSplitImage_SWMFilename.Text = Path.GetFileNameWithoutExtension(TxtBoxSplitImage_SWMFilename.Text) + ".swm"
            strDISMArguments = "/Split-Image /ImageFile:" + """" + TxtBoxSplitImage_WIMFilename.Text + """" + " /SWMFile:" + """" + TxtBoxSplitImage_DestinationFolder.Text + "\" + TxtBoxSplitImage_SWMFilename.Text + """" + " /FileSize:" + TxtBoxSplitImage_Filesize.Text
        End If

        If Path.GetExtension(TxtBoxSplitImage_WIMFilename.Text.ToUpper()) = ".FFU" Then
            TxtBoxSplitImage_SWMFilename.Text = Path.GetFileNameWithoutExtension(TxtBoxSplitImage_SWMFilename.Text) + ".sfu"
            strDISMArguments = "/Split-Image /ImageFile:" + """" + TxtBoxSplitImage_WIMFilename.Text + """" + " /SFUFile:" + """" + TxtBoxSplitImage_DestinationFolder.Text + "\" + TxtBoxSplitImage_SWMFilename.Text + """" + " /FileSize:" + TxtBoxSplitImage_Filesize.Text
        End If

        If ChkBoxSplitImage_CheckIntegrity.Checked = True Then
            strDISMArguments = strDISMArguments + " /CheckIntegrity"
        End If

        'txtOutput.Text = strDISMArguments
        BackgroundWorkerDISMCommand.RunWorkerAsync(strDISMArguments)
        frmProgress.ShowDialog()
    End Sub
    '
    ' Sub LstBoxCaptureFfu_LogicalDrive_SelectedIndexChanged
    ' rev: 20062022
    '
    Private Sub LstBoxCaptureFfu_LogicalDrive_SelectedIndexChanged(sender As Object, e As EventArgs) Handles LstBoxCaptureFfu_LogicalDrive.SelectedIndexChanged
        Dim LogicalDiskID = LstBoxCaptureFfu_LogicalDrive.SelectedItem
        Dim DeviceID = String.Empty
        Dim Query As String
        Dim Partition, Drive

        Query = "ASSOCIATORS OF {Win32_LogicalDisk.DeviceID='" + LogicalDiskID + "'} WHERE AssocClass = Win32_LogicalDiskToPartition"
        Dim QueryResults As New ManagementObjectSearcher(Query)
        Dim Partitions = QueryResults.Get()

        For Each Partition In Partitions
            Query = "ASSOCIATORS OF {Win32_DiskPartition.DeviceID='" + Partition("DeviceID") + "'} WHERE AssocClass = Win32_DiskDriveToDiskPartition"
            QueryResults = New ManagementObjectSearcher(Query)
            Dim Drives = QueryResults.Get()

            For Each Drive In Drives
                DeviceID = Drive("DeviceID").ToString()
            Next
        Next
        TxtBoxCaptFfu_PhysicalDrive.Text = DeviceID
    End Sub
    '
    ' Sub BtnCaptureFfu_UpdateLogicalDrive_Click
    ' rev: 20062022
    '
    Private Sub BtnCaptureFfu_UpdateLogicalDrive_Click(sender As Object, e As EventArgs) Handles BtnCaptureFfu_UpdateLogicalDrive.Click
        Dim d As DriveInfo

        LstBoxCaptureFfu_LogicalDrive.Items.Clear()
        For Each d In DriveInfo.GetDrives()
            LstBoxCaptureFfu_LogicalDrive.Items.Add(d.Name.Substring(0, (d.Name.Length) - 1))
        Next
    End Sub
    '
    ' Sub BtnCaptureFfu_SetTargetFolder_Click
    ' rev: 20062022
    '
    Private Sub BtnCaptureFfu_SetTargetFolder_Click(sender As Object, e As EventArgs) Handles BtnCaptureFfu_SetTargetFolder.Click
        Dim MyDlgOpenFolder As New System.Windows.Forms.FolderBrowserDialog()
        Dim StrFolderName As String

        MyDlgOpenFolder.ShowNewFolderButton = False
        MyDlgOpenFolder.RootFolder = Environment.SpecialFolder.MyComputer
        If MyDlgOpenFolder.ShowDialog() = DialogResult.OK Then
            StrFolderName = MyDlgOpenFolder.SelectedPath
            TxtBoxCaptFfu_TargetFolder.Text = StrFolderName
        End If
    End Sub
    '
    ' Sub BtnCaptFfu_StartCapture_Click
    ' rev: 20062022
    '
    Private Sub BtnCaptFfu_StartCapture_Click(sender As Object, e As EventArgs) Handles BtnCaptFfu_StartCapture.Click

        If (Path.GetExtension(TxtBoxCaptFfu_TargetFilename.Text.ToUpper) = "") Then
            TxtBoxCaptFfu_TargetFilename.Text = TxtBoxCaptFfu_TargetFilename.Text + ".ffu"
        End If

        strDISMArguments = "/Capture-Ffu /ImageFile:" + """" + TxtBoxCaptFfu_TargetFolder.Text + "\" + TxtBoxCaptFfu_TargetFilename.Text + """" + " /CaptureDrive:" + """" + TxtBoxCaptFfu_PhysicalDrive.Text + """"
        strDISMArguments = strDISMArguments + " /Name:" + """" + TxtBoxCaptFfu_Name.Text + """" + " /Description:" + """" + TxtBoxCaptureFfu_Description.Text + """" + " /PlatformIds:" + """" + TxtBoxCaptFfu_PlatformID.Text + """"
        strDISMArguments = strDISMArguments + " /Compress:" + CmbBoxCaptureFfu_Compression.SelectedItem

        'txtOutput.Text = strDISMArguments
        BackgroundWorkerDISMCommand.RunWorkerAsync(strDISMArguments)
        frmProgress.ShowDialog()
    End Sub
    '
    ' Sub LstBoxApplyFfuImage_LogicalDrive_SelectedIndexChanged
    ' rev: 20062022
    '
    Private Sub LstBoxApplyFfuImage_LogicalDrive_SelectedIndexChanged(sender As Object, e As EventArgs) Handles LstBoxApplyFfuImage_LogicalDrive.SelectedIndexChanged
        Dim LogicalDiskID = LstBoxApplyFfuImage_LogicalDrive.SelectedItem
        Dim DeviceID = String.Empty
        Dim Query As String
        Dim Partition, Drive

        Query = "ASSOCIATORS OF {Win32_LogicalDisk.DeviceID='" + LogicalDiskID + "'} WHERE AssocClass = Win32_LogicalDiskToPartition"
        Dim QueryResults As New ManagementObjectSearcher(Query)
        Dim Partitions = QueryResults.Get()

        For Each Partition In Partitions
            Query = "ASSOCIATORS OF {Win32_DiskPartition.DeviceID='" + Partition("DeviceID") + "'} WHERE AssocClass = Win32_DiskDriveToDiskPartition"
            QueryResults = New ManagementObjectSearcher(Query)
            Dim Drives = QueryResults.Get()

            For Each Drive In Drives
                DeviceID = Drive("DeviceID").ToString()
            Next
        Next
        TxtBoxApplyFfuImage_PhysicalDrive.Text = DeviceID
    End Sub
    '
    ' Sub BtnApplyFfuImage_UpdateLogicalDrive_Click
    ' rev: 20062022
    '
    Private Sub BtnApplyFfuImage_UpdateLogicalDrive_Click(sender As Object, e As EventArgs) Handles BtnApplyFfuImage_UpdateLogicalDrive.Click
        Dim d As DriveInfo

        LstBoxApplyFfuImage_LogicalDrive.Items.Clear()
        For Each d In DriveInfo.GetDrives()
            LstBoxApplyFfuImage_LogicalDrive.Items.Add(d.Name.Substring(0, (d.Name.Length) - 1))
        Next
    End Sub
    '
    ' Sub BtnApplyFfuImage_SelectFfuFile_Click
    ' rev: 20062022
    '
    Private Sub BtnApplyFfuImage_SelectFfuFile_Click(sender As Object, e As EventArgs) Handles BtnApplyFfuImage_SelectFfuFile.Click
        Dim MyDlgOpenFile = New System.Windows.Forms.OpenFileDialog() ' instance of dialog box

        MyDlgOpenFile.InitialDirectory = Environment.SpecialFolder.MyComputer                    ' default root path
        MyDlgOpenFile.Title = "Choose Ffu or SFU file to Open"    ' title of dialog box
        MyDlgOpenFile.Filter = ("Ffu Files(*.Ffu)|*.Ffu|Sfu Files(*.Sfu)|*.Sfu") ' filter extension

        If MyDlgOpenFile.ShowDialog = DialogResult.OK Then        ' user selected filename from dialog box ?
            TxtBoxApplyFfuImage_FfuSourceFilename.Text = MyDlgOpenFile.FileName
        End If

        If (Path.GetExtension(TxtBoxApplyFfuImage_FfuSourceFilename.Text.ToUpper) = ".SFU") Then
            TxtBoxApplyFfuImageFfu_MotifSFUFile.Text = TxtBoxApplyFfuImage_FfuSourceFilename.Text
            TxtBoxApplyFfuImageFfu_MotifSFUFile.Text = Replace(TxtBoxApplyFfuImageFfu_MotifSFUFile.Text, ".sfu", "*.sfu")
        End If

        If TxtBoxApplyFfuImage_FfuSourceFilename.Text = "" Then
            MessageBox.Show("You must selected a Ffu file", "Information Ffu", MessageBoxButtons.OK)
        End If
    End Sub
    '
    ' Sub BtnApplyFfuImage_ApplyFfuImage_Clic
    ' rev: 14072022
    ' warning: for Sfu files, you must use dism command /apply-image because /apply-Ffu is bugged (sfu file only)
    '
    Private Sub BtnApplyFfuImage_ApplyFfuImage_Click(sender As Object, e As EventArgs) Handles BtnApplyFfuImage_ApplyFfuImage.Click

        If Path.GetExtension(TxtBoxApplyFfuImage_FfuSourceFilename.Text.ToUpper()) = ".FFU" Then
            strDISMArguments = "/Apply-Ffu /ImageFile:" + """" + TxtBoxApplyFfuImage_FfuSourceFilename.Text + """" + " /ApplyDrive:" + """" + TxtBoxApplyFfuImage_PhysicalDrive.Text + """"
        End If

        If Path.GetExtension(TxtBoxApplyFfuImage_FfuSourceFilename.Text.ToUpper()) = ".SFU" Then
            strDISMArguments = "/Apply-image /ImageFile:" + """" + TxtBoxApplyFfuImage_FfuSourceFilename.Text + """" + " /SFUFile:""" + TxtBoxApplyFfuImageFfu_MotifSFUFile.Text + """" + " /ApplyDrive:" + """" + TxtBoxApplyFfuImage_PhysicalDrive.Text + """"
        End If

        'txtOutput.Text = strDISMArguments
        BackgroundWorkerDISMCommand.RunWorkerAsync(strDISMArguments)
        frmProgress.ShowDialog()
    End Sub
    '
    ' Sub BtnSplitFfuImage_StartSplitImage_Click
    ' rev: 14072022
    '
    Private Sub BtnSplitFfuImage_StartSplitImage_Click(sender As Object, e As EventArgs) Handles BtnSplitFfuImage_StartSplitImage.Click
        strDISMArguments = "/Split-Ffu /ImageFile:" + """" + TxtBoxSplitFfu_FfuFilename.Text + """" + " /SFUFile:" + """" + TxtBoxSplitFfu_TargetFolder.Text + "\" + TxtBoxSplitFfu_SFUFilename.Text + """" + " /FileSize:" + TxtBoxSplitFfu_SplitFileSize.Text
        If (ChkBoxSplitFfu_CheckIntegrity.Checked = True) Then
            strDISMArguments = strDISMArguments + " /CheckIntegrity"
        End If
        'txtOutput.Text = strDISMArguments
        BackgroundWorkerDISMCommand.RunWorkerAsync(strDISMArguments)
        frmProgress.ShowDialog()
    End Sub
    '
    ' Sub BtnSplitFfuImage_StartSplitImage_Click
    ' rev: 20062022
    '
    Private Sub cmbApplyIndex_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbApplyIndex.SelectedIndexChanged
        TxtBoxApplyWim_Name.Text = ListInfosWimApplyImage.ElementAt(cmbApplyIndex.SelectedIndex).Nom.ToString()
        TxtBoxApplyWim_Description.Text = ListInfosWimApplyImage.ElementAt(cmbApplyIndex.SelectedIndex).Description.ToString()
        TxtBoxApplyWim_Size.Text = ListInfosWimApplyImage.ElementAt(cmbApplyIndex.SelectedIndex).Taille.ToString()
    End Sub
    '
    ' Sub Btn_ClearConsole_Click
    ' rev: 14072022
    '
    Private Sub Btn_ClearConsole_Click(sender As Object, e As EventArgs) Handles Btn_ClearConsole.Click
        txtOutput.Text = ""
    End Sub
    '
    ' Sub ExtractDismVersion
    ' rev: 14072022
    '
    Private Sub ExtractDismVersion()
        Dim IdxStart, IdxEnd As Integer

        strDISMArguments = ""
        BackgroundWorkerDISMCommand.RunWorkerAsync(strDISMArguments)
        frmProgress.ShowDialog()
        IdxStart = txtOutput.Text.IndexOf(" : ")
        IdxEnd = txtOutput.Text.IndexOf("DISM")
        TxtBox_DismVersion.Text = txtOutput.Text.Substring(IdxStart + 2, IdxEnd - (IdxStart + 2))
        txtOutput.Text = ""       ' clear console to mask dism help command
    End Sub
    '
    ' Sub BtnSplitFfu_SelectFfuFile_Click
    ' rev: 14072022
    '
    Private Sub BtnSplitFfu_SelectFfuFile_Click(sender As Object, e As EventArgs) Handles BtnSplitFfu_SelectFfuFile.Click
        Dim MyDlgOpenFile = New System.Windows.Forms.OpenFileDialog() ' instance of dialog box

        MyDlgOpenFile.InitialDirectory = Environment.SpecialFolder.MyComputer                    ' default root path
        MyDlgOpenFile.Title = "Choose Ffu file to Open"    ' title of dialog box
        MyDlgOpenFile.Filter = ("Ffu Files(*.Ffu)|*.Ffu")  ' filter extension

        If MyDlgOpenFile.ShowDialog = DialogResult.OK Then ' user selected filename from dialog box ?
            TxtBoxSplitFfu_FfuFilename.Text = MyDlgOpenFile.FileName
        End If
        If TxtBoxSplitFfu_FfuFilename.Text = "" Then       ' check Ffu filename
            MessageBox.Show("You must selected a Ffu file", "Information Ffu", MessageBoxButtons.OK)
        End If
    End Sub
    '
    ' Sub BtnSplitFfu_SelectTargetFolder_Click
    ' rev: 14072022
    '
    Private Sub BtnSplitFfu_SelectTargetFolder_Click(sender As Object, e As EventArgs) Handles BtnSplitFfu_SelectTargetFolder.Click
        Dim MyDlgOpenFolder As New System.Windows.Forms.FolderBrowserDialog()
        Dim StrFolderName As String

        MyDlgOpenFolder.ShowNewFolderButton = False
        MyDlgOpenFolder.RootFolder = Environment.SpecialFolder.MyComputer
        If MyDlgOpenFolder.ShowDialog() = DialogResult.OK Then
            StrFolderName = MyDlgOpenFolder.SelectedPath
            TxtBoxSplitFfu_TargetFolder.Text = StrFolderName
        End If
    End Sub
    '
    ' Sub BtnMountControl_DisplayImageInfo_Click
    ' rev: 14072022
    '
    Private Sub BtnMountControl_DisplayImageInfo_Click(sender As Object, e As EventArgs) Handles BtnMountControl_DisplayImageInfo.Click
        If TxtMountControl_WimFile.Text = "" Then
            MsgBox("You must select a WIM file first")
        Else
            strWIM = TxtMountControl_WimFile.Text
            strDISMArguments = "/Get-ImageInfo /ImageFile:""" & strWIM & """"
            BackgroundWorkerDISMCommand.RunWorkerAsync(strDISMArguments)
            frmProgress.ShowDialog()
        End If
    End Sub
    '
    ' Sub BtnGetPackageInfo_Click
    ' rev: 14072022
    '
    Private Sub BtnGetPackageInfo_Click(sender As Object, e As EventArgs) Handles BtnGetPackageInfo.Click
        If (WIMMounted = False And ChkBoxPackageManagement_Online.Checked = False) Then
            MessageBox.Show("No WIM is mounted.  You must mount a WIM before running this command (Offline mode) or use /Online option.")
        Else
            If (ChkBoxPackageManagement_Online.Checked = True) Then
                strDISMArguments = "/Online" & " /Get-PackageInfo"
                If txtPackageName.Text <> "" Then strDISMArguments = strDISMArguments & " /PackageName:""" & txtPackageName.Text & """"
                If txtPackagePath.Text <> "" Then strDISMArguments = strDISMArguments & " /PackagePath:""" & txtPackagePath.Text & """"
            Else
                strDISMArguments = "/Image:""" & strMountedImageLocation & """ /Get-PackageInfo"
                If txtPackageName.Text <> "" Then strDISMArguments = strDISMArguments & " /PackageName:""" & txtPackageName.Text & """"
                If txtPackagePath.Text <> "" Then strDISMArguments = strDISMArguments & " /PackagePath:""" & txtPackagePath.Text & """"
            End If
            BackgroundWorkerDISMCommand.RunWorkerAsync(strDISMArguments)
            frmProgress.ShowDialog()
            ' txtOutput.Text = txtOutput.Text & strOutput
        End If
    End Sub
    '
    ' Sub BtnDefaultAppAssocServ_GetDefaultAppAssoc_Click
    ' rev: 14072022
    '
    Private Sub BtnDefaultAppAssocServ_GetDefaultAppAssoc_Click(sender As Object, e As EventArgs) Handles BtnDefaultAppAssocServ_GetDefaultAppAssoc.Click

        If (WIMMounted = False And ChkBoxDefaultAppAssocServ_Online.Checked = False) Then
            MessageBox.Show("No WIM is mounted.  You must mount a WIM before running this command (Offline mode) or use /Online option.")
        Else
            If (ChkBoxDefaultAppAssocServ_Online.Checked = True) Then
                strDISMArguments = "/Online" & " /Get-DefaultAppAssociations"
            Else
                strDISMArguments = "/Image:""" & strMountedImageLocation & """ /Get-DefaultAppAssociations"
            End If
            BackgroundWorkerDISMCommand.RunWorkerAsync(strDISMArguments)
            frmProgress.ShowDialog()
            ' txtOutput.Text = txtOutput.Text & strOutput
        End If
    End Sub
    '
    ' Sub BtnDefaultAppAssocServ_ChooseFolder_Click
    ' rev: 14072022
    '
    Private Sub BtnDefaultAppAssocServ_ChooseFolder_Click(sender As Object, e As EventArgs) Handles BtnDefaultAppAssocServ_ChooseFile.Click
        Dim DidWork As Integer = dlgOpenXML.ShowDialog

        dlgOpenXML.InitialDirectory = Environment.SpecialFolder.MyComputer
        dlgOpenXML.Title = "Choose XML file to Open"
        dlgOpenXML.Filter = ("XML Files(*.xml)|*.xml|All Files (*.*)|*.*")

        If DidWork = DialogResult.Cancel Then
            'Do Nothing
        Else
            ' Dim strXMLFileName As String = dlgOpenXML.FileName
            strXMLFileName = dlgOpenXML.FileName
            TxtBoxDefaultAppAssocServ_ImportFilenameXML.Text = strXMLFileName
        End If
    End Sub
    '
    ' Sub BtnDefaultAppAssocServ_ChooseFolder_Click
    ' rev: 14072022
    '
    Private Sub BtnDefaultAppAssocServ_ChooseFolder_Click_1(sender As Object, e As EventArgs) Handles BtnDefaultAppAssocServ_ChooseFolder.Click
        dlgOpenFolder.ShowNewFolderButton = False
        dlgOpenFolder.RootFolder = Environment.SpecialFolder.MyComputer
        dlgOpenFolder.ShowDialog()
        Dim strFolderName As String = dlgOpenFolder.SelectedPath

        TxtBoxDefaultAppAssocServ_ExportFolder.Text = strFolderName
    End Sub
    '
    ' Sub BtnDefaultAppAssocServ_Export_Click
    ' rev: 14072022
    '
    Private Sub BtnDefaultAppAssocServ_Export_Click(sender As Object, e As EventArgs) Handles BtnDefaultAppAssocServ_Export.Click

        If (TxtBoxDefaultAppAssocServ_ExportFolder.Text = "" Or TxtBoxDefaultAppAssocServ_ExportFilenameXML.Text = "") Then
            MessageBox.Show("Items export folder and export filename must be enter")
            Exit Sub
        End If

        ' add extension filename automatically if forgotten
        If (Path.GetExtension(TxtBoxDefaultAppAssocServ_ExportFilenameXML.Text.ToUpper()) <> ".XML") Then
            TxtBoxDefaultAppAssocServ_ExportFilenameXML.Text = TxtBoxDefaultAppAssocServ_ExportFilenameXML.Text + ".xml"
        End If

        If (WIMMounted = False And ChkBoxDefaultAppAssocServ_Online.Checked = False) Then
            MessageBox.Show("No WIM is mounted.  You must mount a WIM before running this command (Offline mode) or use /Online option.")
        Else
            If (ChkBoxDefaultAppAssocServ_Online.Checked = True) Then
                strDISMArguments = "/Online" & " /Export-DefaultAppAssociations:""" & TxtBoxDefaultAppAssocServ_ExportFolder.Text & "\" & TxtBoxDefaultAppAssocServ_ExportFilenameXML.Text & """"
            Else
                strDISMArguments = "/Image:""" & strMountedImageLocation & """ /Export-DefaultAppAssociations:""" & TxtBoxDefaultAppAssocServ_ExportFolder.Text & "\" & TxtBoxDefaultAppAssocServ_ExportFilenameXML.Text & """"
            End If

            BackgroundWorkerDISMCommand.RunWorkerAsync(strDISMArguments)
            frmProgress.ShowDialog()
            'txtOutput.Text = txtOutput.Text & strOutput
        End If
    End Sub
    '
    ' BtnDefaultAppAssocServ_Import_Click
    ' rev: 14072022
    '
    Private Sub BtnDefaultAppAssocServ_Import_Click(sender As Object, e As EventArgs) Handles BtnDefaultAppAssocServ_Import.Click

        If (TxtBoxDefaultAppAssocServ_ImportFilenameXML.Text = "") Then
            MessageBox.Show("Item Import Filename filename must be enter")
            Exit Sub
        End If

        ' add extension filename automatically if forgotten
        If (Path.GetExtension(TxtBoxDefaultAppAssocServ_ExportFilenameXML.Text.ToUpper()) <> ".XML") Then
            TxtBoxDefaultAppAssocServ_ExportFilenameXML.Text = TxtBoxDefaultAppAssocServ_ExportFilenameXML.Text + ".xml"
        End If

        If (WIMMounted = False And ChkBoxDefaultAppAssocServ_Online.Checked = False) Then
            MessageBox.Show("No WIM is mounted.  You must mount a WIM before running this command (Offline mode) or use /Online option.")
        Else
            If (ChkBoxDefaultAppAssocServ_Online.Checked = True) Then
                strDISMArguments = "/Online /Import-DefaultAppAssociations:" & """" & TxtBoxDefaultAppAssocServ_ImportFilenameXML.Text & """"
            Else
                strDISMArguments = "/Image:""" & strMountedImageLocation & """ /Import-DefaultAppAssociations:" & """" & TxtBoxDefaultAppAssocServ_ImportFilenameXML.Text & """"
            End If

            BackgroundWorkerDISMCommand.RunWorkerAsync(strDISMArguments)
            frmProgress.ShowDialog()
            'txtOutput.Text = txtOutput.Text & strOutput
        End If
    End Sub
    '
    ' BtnSetLanguage_DisplayInfo_Click
    ' rev: 14072022
    '
    Private Sub BtnSetLanguage_DisplayInfo_Click(sender As Object, e As EventArgs) Handles BtnSetLanguage_DisplayInfo.Click

        If (WIMMounted = False And ChkBoxLangAndInterServ_Online.Checked = False) Then
            MessageBox.Show("No WIM is mounted.  You must mount a WIM before running this command (Offline mode) or use /Online option.")
        Else
            If ChkBoxLangAndInterServ_Online.Checked Then
                strDISMArguments = "/Online /Get-Intl"
            Else
                strDISMArguments = "/Image:" + """" + strMountedImageLocation + """" + " /Get-Intl"
            End If
            'txtOutput.Text = strDISMArguments
            BackgroundWorkerDISMCommand.RunWorkerAsync(strDISMArguments)
            frmProgress.ShowDialog()
        End If
    End Sub
    '
    ' BtnLangAndInterServ_ApplyUILang_Click
    ' rev: 14072022
    '
    Private Sub BtnLangAndInterServ_ApplyUILang_Click(sender As Object, e As EventArgs) Handles BtnLangAndInterServ_ApplyUILang.Click

        If WIMMounted = False Then
            MessageBox.Show("No WIM is mounted.  You must mount a WIM before running this command (Offline mode only).")
        Else
            If CmbBoxLangAndInterServ_SetUILang.Text <> "" Then
                strDISMArguments = "/Image:" + """" + strMountedImageLocation + """" + " /Set-UILang:" + CmbBoxLangAndInterServ_SetUILang.Text
                ' txtOutput.Text = strDISMArguments
                BackgroundWorkerDISMCommand.RunWorkerAsync(strDISMArguments)
                frmProgress.ShowDialog()
            Else
                MessageBox.Show("You must enter a value for /Set-UILang option !")
            End If
        End If
    End Sub
    '
    ' BtnLangAndInterServ_ApplyUILangFallback_Click
    ' rev: 14072022
    '
    Private Sub BtnLangAndInterServ_ApplyUILangFallback_Click(sender As Object, e As EventArgs) Handles BtnLangAndInterServ_ApplyUILangFallback.Click

        If WIMMounted = False Then
            MessageBox.Show("No WIM is mounted.  You must mount a WIM before running this command (Offline mode only).")
        Else
            If CmbBoxLangAndInterServ_SetUILangFallback.Text <> "" Then
                strDISMArguments = "/Image:" + """" + strMountedImageLocation + """" + " /Set-UILangFallback:" + CmbBoxLangAndInterServ_SetUILangFallback.Text
                ' txtOutput.Text = strDISMArguments
                BackgroundWorkerDISMCommand.RunWorkerAsync(strDISMArguments)
                frmProgress.ShowDialog()
            Else
                MessageBox.Show("You must enter a value for /Set-UILangFallback option !")
            End If
        End If
    End Sub
    '
    ' BtnLangAndInterServ_ApplySysUILang_Click
    ' rev: 14072022
    '
    Private Sub BtnLangAndInterServ_ApplySysUILang_Click(sender As Object, e As EventArgs) Handles BtnLangAndInterServ_ApplySysUILang.Click

        If WIMMounted = False Then
            MessageBox.Show("No WIM is mounted.  You must mount a WIM before running this command (Offline mode only).")
        Else
            If CmbBoxLangAndInterServ_SetSysUILang.Text <> "" Then
                strDISMArguments = "/Image:" + """" + strMountedImageLocation + """" + " /Set-SysUILang:" + CmbBoxLangAndInterServ_SetSysUILang.Text
                ' txtOutput.Text = strDISMArguments
                BackgroundWorkerDISMCommand.RunWorkerAsync(strDISMArguments)
                frmProgress.ShowDialog()
            Else
                MessageBox.Show("You must enter a value for /Set-SysUILang option !")
            End If
        End If
    End Sub
    '
    ' BtnLangAndInterServ_ApplySysLocale_Click
    ' rev: 14072022
    '
    Private Sub BtnLangAndInterServ_ApplySysLocale_Click(sender As Object, e As EventArgs) Handles BtnLangAndInterServ_ApplySysLocale.Click

        If WIMMounted = False Then
            MessageBox.Show("No WIM is mounted.  You must mount a WIM before running this command (Offline mode only).")
        Else
            If CmbBoxLangAndInterServ_SetUILang_SysLocale.Text <> "" Then
                strDISMArguments = "/Image:" + """" + strMountedImageLocation + """" + " /Set-SysLocale:" + CmbBoxLangAndInterServ_SetUILang_SysLocale.Text
                ' txtOutput.Text = strDISMArguments
                BackgroundWorkerDISMCommand.RunWorkerAsync(strDISMArguments)
                frmProgress.ShowDialog()
            Else
                MessageBox.Show("You must enter a value for /Set-SysLocale option !")
            End If
        End If
    End Sub
    '
    ' BtnLangAndInterServ_ApplyUserLocale_Click
    ' rev: 14072022
    '
    Private Sub BtnLangAndInterServ_ApplyUserLocale_Click(sender As Object, e As EventArgs) Handles BtnLangAndInterServ_ApplyUserLocale.Click

        If WIMMounted = False Then
            MessageBox.Show("No WIM is mounted.  You must mount a WIM before running this command (Offline mode only).")
        Else
            If CmbBoxLangAndInterServ_SetUserLocale.Text <> "" Then
                strDISMArguments = "/Image:" + """" + strMountedImageLocation + """" + " /Set-UserLocale:" + CmbBoxLangAndInterServ_SetUserLocale.Text
                ' txtOutput.Text = strDISMArguments
                BackgroundWorkerDISMCommand.RunWorkerAsync(strDISMArguments)
                frmProgress.ShowDialog()
            Else
                MessageBox.Show("You must enter a value for /Set-UserLocale option !")
            End If
        End If
    End Sub
End Class
